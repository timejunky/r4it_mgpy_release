# ManifestGuard Installation Guide

This guide is bundled with the package so installation instructions remain available even in restricted or offline environments.

## Online installation

Standard installation:

```bash
python -m pip install manifestguard
```

Inside a virtual environment:

```bash
python -m venv .venv
.venv\Scripts\activate
python -m pip install manifestguard
```

## Offline installation

ManifestGuard can also be installed without internet access if you prepare the wheel files in advance.

### Option 1: Download by package name on an online machine

```bash
mkdir offline_bundle
python -m pip download --dest offline_bundle manifestguard
```

This downloads the package wheel plus dependency wheels into `offline_bundle`.

Copy that folder to the offline machine and install with:

```bash
python -m pip install --no-index --find-links offline_bundle manifestguard
```

### Option 2: Install from a specific local wheel

If you received a wheel file directly, place it together with all required dependency wheels in one folder, for example `offline_bundle`.

Then install with:

```bash
python -m pip install --no-index --find-links offline_bundle manifestguard-<version>-py3-none-any.whl
```

### Protected payload case

If your organization uses a protected/commercial ManifestGuard wheel distributed outside public PyPI, the recommended flow is still `pip`-based:

```bash
python -m pip install --no-index --find-links offline_bundle manifestguard-<version>-py3-none-any.whl
```

Do not unpack wheels manually into Python directories. Keep `pip` as the installer backend so dependency handling and uninstall/update behavior remain consistent.

## Verify installation

```bash
manifestguard --version
manifestguard check --help
```