"""Quick Check Cache - ADR-010 Caching Implementation

Provides file-based caching for QuickCheck results with TTL and file change detection.
Analog to VS Extension quickCheckCache.

Features:
- TTL-based cache expiration (default: 60 seconds)
- File change detection via content hashing
- Automatic cache invalidation on manifest changes
- LRU cache size limiting

Author: Nejat Philip Eryigit
Copyright: (c) 2025 ready-4-it.com
License: MIT
"""

import hashlib
import json
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any


@dataclass
class CacheEntry:
    """Cache entry with metadata

    Python Translation of VS Extension CacheEntry:
    - key: str (cache key from generateCacheKey)
    - result: Any (QuickCheckResult)
    - timestamp: float (Unix timestamp)
    - ttl: int (milliseconds)
    - content_hashes: dict[str, str] (file path -> hash)
    """

    key: str
    result: Any
    timestamp: float
    ttl: int  # milliseconds
    content_hashes: dict[str, str]


class QuickCheckCache:
    """Cache manager for QuickCheck results

    ADR-010 Analog Implementation:
    1. generate_cache_key() - Like generateCacheKey()
    2. calculate_file_hash() - Like calculateFileHash()
    3. get() - Retrieve from cache with validation
    4. set() - Store with TTL and hashes
    5. invalidate() - Clear specific or all entries

    Python Translation Strategy:
    - Use hashlib for SHA-256 file hashing
    - Store cache in .manifestguard/cache/ directory
    - JSON serialization for cross-process compatibility
    """

    def __init__(self, cache_dir: Path | None = None, max_entries: int = 100):
        """Initialize cache manager

        Args:
            cache_dir: Directory for cache files (default: .manifestguard/cache)
            max_entries: Maximum number of cache entries (LRU)

        """
        self.cache_dir = cache_dir or Path.cwd() / ".manifestguard" / "cache"
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        self.max_entries = max_entries
        self._memory_cache: dict[str, CacheEntry] = {}

    def generate_cache_key(self, project_path: Path, project_type: str) -> str:
        """Generate cache key from project path and type

        VS Extension Analog: generateCacheKey()

        Key Format: sha256(project_path + project_type)

        Args:
            project_path: Absolute path to project root
            project_type: ProjectType enum value

        Returns:
            Cache key (hex string)

        Example:
            >>> cache = QuickCheckCache()
            >>> key = cache.generate_cache_key(Path("/project"), "pyproject.toml")
            >>> print(len(key))
            64

        """
        # project_path is already Path | str in signature
        resolved_path = Path(project_path).resolve() if isinstance(project_path, str) else project_path.resolve()  # type: ignore[unreachable]
        data = f"{resolved_path}:{project_type}"
        return hashlib.sha256(data.encode()).hexdigest()

    def calculate_file_hash(self, file_path: Path) -> str:
        """Calculate SHA-256 hash of file content

        VS Extension Analog: calculateFileHash()

        Args:
            file_path: Path to file

        Returns:
            SHA-256 hex digest

        Example:
            >>> cache = QuickCheckCache()
            >>> hash_val = cache.calculate_file_hash(Path("pyproject.toml"))
            >>> print(len(hash_val))
            64

        """
        if not file_path.exists():
            return ""

        sha256 = hashlib.sha256()
        with file_path.open("rb") as f:
            while chunk := f.read(8192):
                sha256.update(chunk)

        return sha256.hexdigest()

    def calculate_content_hashes(self, project_path: Path) -> dict[str, str]:
        """Calculate hashes for all relevant project files

        VS Extension Analog: calculateContentHashes()

        Files to hash:
        - pyproject.toml
        - setup.py
        - setup.cfg
        - requirements.txt
        - Pipfile
        - environment.yml
        - manifestguard.json

        Args:
            project_path: Path to project root

        Returns:
            Dictionary mapping file path -> hash

        Example:
            >>> cache = QuickCheckCache()
            >>> hashes = cache.calculate_content_hashes(Path("."))
            >>> print(hashes.keys())
            dict_keys(['pyproject.toml', 'manifestguard.json'])

        """
        hashes = {}

        manifest_files = [
            "pyproject.toml",
            "setup.py",
            "setup.cfg",
            "requirements.txt",
            "Pipfile",
            "environment.yml",
            "manifestguard.json",
        ]

        for filename in manifest_files:
            file_path = project_path / filename
            if file_path.exists():
                hashes[filename] = self.calculate_file_hash(file_path)

        return hashes

    def get(self, key: str, project_path: Path) -> Any | None:
        """Get cached result if valid

        Validation:
        1. Check if entry exists
        2. Check TTL expiration
        3. Check file changes via content hashes

        Args:
            key: Cache key from generate_cache_key()
            project_path: Path to project (for hash validation)

        Returns:
            Cached result or None if invalid/expired

        Example:
            >>> cache = QuickCheckCache()
            >>> key = cache.generate_cache_key(Path("."), "pyproject.toml")
            >>> result = cache.get(key, Path("."))
            >>> if result is None:
            ...     print("Cache miss")

        """
        memory_entry = self._get_memory_entry(key, project_path)
        if memory_entry:
            return memory_entry.result

        disk_entry = self._load_disk_entry(key)
        if not disk_entry:
            return None

        if self._entry_invalid(disk_entry, project_path):
            self._delete_cache_file(key)
            return None

        self._memory_cache[key] = disk_entry
        return disk_entry.result

    def _get_memory_entry(self, key: str, project_path: Path) -> CacheEntry | None:
        entry = self._memory_cache.get(key)
        if not entry:
            return None

        if self._entry_invalid(entry, project_path):
            self._invalidate_memory_entry(key)
            self._delete_cache_file(key)
            return None

        return entry

    def _entry_invalid(self, entry: CacheEntry, project_path: Path) -> bool:
        if self._is_entry_expired(entry):
            return True
        return bool(self._hashes_changed(entry, project_path))

    def _is_entry_expired(self, entry: CacheEntry) -> bool:
        return self._current_time_ms() - entry.timestamp > entry.ttl

    def _hashes_changed(self, entry: CacheEntry, project_path: Path) -> bool:
        current_hashes = self.calculate_content_hashes(project_path)
        return current_hashes != entry.content_hashes

    def _invalidate_memory_entry(self, key: str) -> None:
        if key in self._memory_cache:
            del self._memory_cache[key]

    def _load_disk_entry(self, key: str) -> CacheEntry | None:
        cache_file = self.cache_dir / f"{key}.json"
        if not cache_file.exists():
            return None

        try:
            with cache_file.open(encoding="utf-8") as f:
                data = json.load(f)
        except Exception:
            cache_file.unlink(missing_ok=True)
            return None

        try:
            return CacheEntry(**data)
        except TypeError:
            cache_file.unlink(missing_ok=True)
            return None

    def _current_time_ms(self) -> float:
        return time.time() * 1000

    def set(
        self,
        key: str,
        result: Any,
        project_path: Path,
        ttl: int = 60000,
    ) -> None:
        """Store result in cache with TTL

        Args:
            key: Cache key from generate_cache_key()
            result: QuickCheck result to cache
            project_path: Path to project (for hash calculation)
            ttl: Time-to-live in milliseconds (default: 60000 = 60s)

        Example:
            >>> cache = QuickCheckCache()
            >>> key = cache.generate_cache_key(Path("."), "pyproject.toml")
            >>> cache.set(key, result, Path("."), ttl=60000)

        """
        # Calculate file hashes
        content_hashes = self.calculate_content_hashes(project_path)

        # Create entry
        entry = CacheEntry(
            key=key,
            result=result,
            timestamp=time.time() * 1000,  # milliseconds
            ttl=ttl,
            content_hashes=content_hashes,
        )

        # Store in memory
        self._memory_cache[key] = entry

        # Store to disk
        cache_file = self.cache_dir / f"{key}.json"
        try:
            with cache_file.open("w", encoding="utf-8") as f:
                json.dump(asdict(entry), f, indent=2)
        except Exception:
            pass

        # LRU eviction if needed
        self._evict_if_needed()

    def invalidate(self, key: str | None = None) -> None:
        """Invalidate cache entries

        Args:
            key: Specific cache key to invalidate (None = invalidate all)

        Example:
            >>> cache = QuickCheckCache()
            >>> cache.invalidate()  # Clear all
            >>> cache.invalidate(key)  # Clear specific

        """
        if key is None:
            # Invalidate all
            self._memory_cache.clear()
            for cache_file in self.cache_dir.glob("*.json"):
                cache_file.unlink(missing_ok=True)
        else:
            # Invalidate specific key
            if key in self._memory_cache:
                del self._memory_cache[key]
            self._delete_cache_file(key)

    def _delete_cache_file(self, key: str) -> None:
        """Delete cache file from disk"""
        cache_file = self.cache_dir / f"{key}.json"
        cache_file.unlink(missing_ok=True)

    def _evict_if_needed(self) -> None:
        """Evict oldest entries if cache exceeds max_entries

        LRU Strategy: Remove entries with oldest timestamp
        """
        if len(self._memory_cache) <= self.max_entries:
            return

        # Sort by timestamp (oldest first)
        sorted_entries = sorted(
            self._memory_cache.items(),
            key=lambda item: item[1].timestamp,
        )

        # Remove oldest entries
        excess = len(self._memory_cache) - self.max_entries
        for i in range(excess):
            key, _ = sorted_entries[i]
            del self._memory_cache[key]
            self._delete_cache_file(key)

    def get_stats(self) -> dict[str, Any]:
        """Get cache statistics

        Returns:
            Dictionary with cache stats (entries, size, hit rate)

        Example:
            >>> cache = QuickCheckCache()
            >>> stats = cache.get_stats()
            >>> print(f"Cache entries: {stats['entry_count']}")

        """
        # Count disk cache files
        disk_files = list(self.cache_dir.glob("*.json"))

        # Calculate total size
        total_size = sum(f.stat().st_size for f in disk_files)

        return {
            "entry_count": len(self._memory_cache),
            "disk_files": len(disk_files),
            "total_size_bytes": total_size,
            "cache_dir": str(self.cache_dir),
        }


# Global cache instance
_global_cache: QuickCheckCache | None = None


def get_cache() -> QuickCheckCache:
    """Get global cache instance (singleton)

    Returns:
        Global QuickCheckCache instance

    Example:
        >>> from manifestguard.api.quick_check_cache import get_cache
        >>> cache = get_cache()
        >>> stats = cache.get_stats()

    """
    global _global_cache  # noqa: PLW0603  # Singleton pattern
    if _global_cache is None:
        _global_cache = QuickCheckCache()
    return _global_cache
