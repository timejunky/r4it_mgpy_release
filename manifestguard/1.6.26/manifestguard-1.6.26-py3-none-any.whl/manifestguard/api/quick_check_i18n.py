from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from manifestguard.api.quick_check import ConfigTemplate, ProjectInfo


def apply_i18n_hardcoded_gui_strings_settings(
    template: "ConfigTemplate",
    project_info: "ProjectInfo",
) -> None:
    """Add default config block for the hardcoded GUI strings scan.

    Stored under settings to ensure it merges cleanly without requiring
    schema-wide changes in older configs.
    """

    enabled = "gui" in project_info.detected_features

    template.settings.setdefault(
        "i18nHardcodedGuiStrings",
        {
            "enabled": enabled,
            # Optional filters (workspace-relative globs). Leave empty to use
            # scanner defaults (src/gui/**/*.py + gui/**/*.py).
            "include": [],
            "exclude": [
                "**/tests/**",
                "**/_generated/**",
                "**/generated/**",
            ],
            # Safety valve for CI noise; 0 means unlimited.
            "maxFindings": 0,
        },
    )


def apply_i18n_hardcoded_cli_strings_settings(
    template: "ConfigTemplate",
    project_info: "ProjectInfo",
) -> None:
    """Add default config block for the hardcoded CLI strings scan."""

    enabled = "cli" in project_info.detected_features

    template.settings.setdefault(
        "i18nHardcodedCliStrings",
        {
            "enabled": enabled,
            "include": [],
            "exclude": [
                "**/tests/**",
                "**/_generated/**",
                "**/generated/**",
            ],
            "maxFindings": 0,
        },
    )
