"""Integration test helper for external projects.

Provides utilities for testing ManifestGuard integration in other projects.
"""

import json
import subprocess
import sys
from collections.abc import Iterable
from typing import Any


class IntegrationTestHelper:
    """Helper for testing ManifestGuard integration.

    External projects can use this to validate their integration
    with ManifestGuard API.
    """

    def __init__(self, manifestguard_path: str | None = None):
        """Initialize integration test helper.

        Args:
            manifestguard_path: Path to manifestguard executable (uses system if None)

        """
        self.manifestguard_path = manifestguard_path or "manifestguard"

    def get_available_interfaces(self) -> dict[str, Any]:
        """Get all available ManifestGuard interfaces.

        Returns:
            Dictionary with interface definitions

        """
        result = subprocess.run(  # Controlled CLI invocation  # noqa: S603
            [self.manifestguard_path, "list-interfaces"],
            check=False,
            capture_output=True,
            text=True,
        )

        if result.returncode != 0:
            raise RuntimeError(f"Failed to list interfaces: {result.stderr}")

        data: dict[str, Any] = json.loads(result.stdout)
        return data

    def validate_call(self, command: str, arguments: dict[str, Any]) -> dict[str, Any]:
        """Validate a command call before executing.

        Args:
            command: Command name
            arguments: Command arguments

        Returns:
            Validation result

        """
        args_json = json.dumps(arguments)
        validate_str = f"{command} {args_json}"

        result = subprocess.run(  # Controlled CLI invocation  # noqa: S603
            [self.manifestguard_path, "list-interfaces", "--validate", validate_str],
            check=False,
            capture_output=True,
            text=True,
        )

        data: dict[str, Any] = json.loads(result.stdout)
        return data

    def test_interface(
        self, command: str, arguments: dict[str, Any], expected_success: bool = True
    ) -> bool:
        """Test an interface call.

        Args:
            command: Command name
            arguments: Command arguments
            expected_success: Whether the call should succeed

        Returns:
            True if test passed

        """
        # First validate the call
        validation = self.validate_call(command, arguments)

        if not validation["valid"]:
            print(f"❌ Validation failed for {command}: {validation['errors']}", file=sys.stderr)
            return not expected_success

        if validation.get("warnings"):
            print(f"⚠️  Warnings for {command}: {validation['warnings']}", file=sys.stderr)

        # Then execute if validation passed
        # (Actual execution would depend on command implementation)
        return expected_success

    def run_test_suite(self, tests: list[dict[str, Any]]) -> dict[str, Any]:
        """Run a test suite of interface calls.

        Args:
            tests: List of test cases with command, arguments, expected_success

        Returns:
            Test results summary

        """
        results: dict[str, Any] = {
            "total": len(tests),
            "passed": 0,
            "failed": 0,
            "failures": [],
        }

        for test in tests:
            command = test["command"]
            arguments = test.get("arguments", {})
            expected_success = test.get("expected_success", True)

            try:
                passed = self.test_interface(command, arguments, expected_success)
                if passed:
                    results["passed"] += 1
                    print(f"✅ Test passed: {command}")
                else:
                    results["failed"] += 1
                    results["failures"].append(
                        {
                            "command": command,
                            "reason": "Unexpected result",
                        }
                    )
                    print(f"❌ Test failed: {command}")
            except Exception as e:
                results["failed"] += 1
                results["failures"].append(
                    {
                        "command": command,
                        "reason": str(e),
                    }
                )
                print(f"❌ Test error: {command} - {e}")

        return results

    def get_example_calls(self, command: str) -> list[str]:
        """Get example calls for a command.

        Args:
            command: Command name

        Returns:
            List of example command strings

        """
        interfaces = self.get_available_interfaces()

        cmd_interface = interfaces.get("manifestguard", {}).get("interfaces", {}).get(command)

        if not cmd_interface:
            return []

        examples = cmd_interface.get("examples", [])
        return [ex.get("command", "") for ex in examples]

    def generate_test_suite(self, categories: list[str] | None = None) -> list[dict[str, Any]]:
        """Generate test cases for CLI interfaces with default arguments."""
        test_cases = []
        for command, interface in self._iter_cli_interfaces(categories):
            test_cases.append(self._build_test_case(command, interface))
        return test_cases

    def _iter_cli_interfaces(
        self,
        categories: list[str] | None,
    ) -> Iterable[tuple[str, dict[str, Any]]]:
        cli_interfaces = (
            self.get_available_interfaces().get("manifestguard", {}).get("interfaces", {})
        )
        for command, interface in cli_interfaces.items():
            if categories and interface.get("category") not in categories:
                continue
            yield command, interface

    def _build_test_case(self, command: str, interface: dict[str, Any]) -> dict[str, Any]:
        return {
            "command": command,
            "arguments": self._build_required_arguments(interface),
            "expected_success": True,
            "description": interface.get("description", ""),
        }

    def _build_required_arguments(self, interface: dict[str, Any]) -> dict[str, Any]:
        arguments: dict[str, Any] = {}
        for param in interface.get("parameters", []):
            if not param.get("required", True):
                continue
            default = self._default_for_type(param.get("type", "str"))
            if default is not None:
                arguments[param["name"]] = default
        return arguments

    def _default_for_type(self, type_name: str | None) -> Any:
        param_type = (type_name or "str").lower()
        if param_type == "bool":
            return False
        if param_type == "int":
            return 0
        if param_type in {"path", "str"}:
            return "test"
        return None


def example_integration_test():
    """Example integration test for external projects.

    Usage:
        from manifestguard.api.integration_test import example_integration_test
        example_integration_test()
    """
    helper = IntegrationTestHelper()

    # Test 1: Check command with default file
    print("\n🧪 Test 1: Validate check command")
    result = helper.validate_call("check", {"file": "pyproject.toml", "extended": True})
    print(f"   Valid: {result['valid']}")
    if result.get("warnings"):
        print(f"   Warnings: {result['warnings']}")

    # Test 2: List available tests
    print("\n🧪 Test 2: Validate list-tests command")
    result = helper.validate_call("list-tests", {"json": True})
    print(f"   Valid: {result['valid']}")

    # Test 3: Invalid command test
    print("\n🧪 Test 3: Validate invalid command")
    result = helper.validate_call("nonexistent-command", {})
    print(f"   Valid: {result['valid']} (expected: False)")
    print(f"   Errors: {result.get('errors', [])}")

    # Test 4: Run test suite
    print("\n🧪 Test 4: Run generated test suite")
    test_suite = helper.generate_test_suite(categories=["meta"])
    results = helper.run_test_suite(test_suite)
    print(f"\n📊 Results: {results['passed']}/{results['total']} passed")

    if results["failures"]:
        print("\n❌ Failures:")
        for failure in results["failures"]:
            print(f"   - {failure['command']}: {failure['reason']}")


if __name__ == "__main__":
    example_integration_test()
