"""FastAPI Application with VS Code-inspired contribution model.

Loads manifest.json (like package.json contributions in VS Code) to:
- Register routes dynamically
- Configure middleware pipeline
- Map exception handlers
"""

import contextlib
import importlib
import json
import time
from collections.abc import Callable
from pathlib import Path

from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse

from ..core import logging as mg_logging
from ..core.audit import audit
from ..i18n.i18n import get_i18n
from .routes import environment as env_router

_logger = mg_logging.setup_logger(__name__)
_i18n = get_i18n()


def create_app() -> FastAPI:
    """Create and configure FastAPI application.

    Initializes the ManifestGuard REST API with VS Code-inspired
    contribution model. Loads manifest.json to dynamically register
    routes, middleware, and exception handlers.

    Returns:
        Configured FastAPI application instance.

    """
    app = FastAPI(
        title="ManifestGuard API",
        description="Multi-language REST API for ManifestGuard",
        version="0.1.0",
    )

    # Load manifest.json (VS Code-style contribution points)
    manifest_path = Path(__file__).parent / "manifest.json"
    manifest = json.loads(manifest_path.read_text())

    # Register exception handlers from manifest
    def make_handler(status: int) -> Callable:
        async def _handler(request: Request, exc: Exception) -> JSONResponse:
            request.state.lang if hasattr(request.state, "lang") else "en"
            return JSONResponse(status_code=status, content={"error": str(exc)})

        return _handler

    for handler_def in manifest.get("contributes", {}).get("exceptionHandlers", []):
        exc_class_path = handler_def["exception"]
        status_code = handler_def["status"]
        # dynamically import exception class
        mod_path, cls_name = exc_class_path.rsplit(".", 1)
        mod = importlib.import_module(mod_path)
        exc_class = getattr(mod, cls_name)

        app.add_exception_handler(exc_class, make_handler(status_code))

    # Middleware: i18n (extract lang from query param)
    @app.middleware("http")
    async def i18n_middleware(request: Request, call_next: Callable) -> JSONResponse:
        lang = request.query_params.get("lang", "en")
        request.state.lang = lang
        return await call_next(request)

    @app.middleware("http")
    async def audit_middleware(request: Request, call_next: Callable) -> JSONResponse:
        response = await call_next(request)
        # audit after response (best-effort)
        with contextlib.suppress(Exception):
            audit.record(
                actor=request.client.host if request.client else "unknown",
                action=f"{request.method} {request.url.path}",
                target=None,
                details={"status": response.status_code},
            )
        return response

    @app.middleware("http")
    async def logging_middleware(request: Request, call_next: Callable) -> JSONResponse:
        start = time.time()
        response = await call_next(request)
        duration = time.time() - start
        mg_logging.log_struct(
            _logger,
            "info",
            "request",
            method=request.method,
            path=str(request.url.path),
            status=response.status_code,
            duration_ms=int(duration * 1000),
        )
        return response

    # Register routes from manifest
    app.include_router(env_router.router, tags=["environment"])

    return app


app = create_app()
