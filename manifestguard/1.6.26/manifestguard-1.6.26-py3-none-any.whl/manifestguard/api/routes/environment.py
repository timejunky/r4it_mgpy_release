"""Environment Routes (VS Code-style contribution handler)

Uses Pydantic models from manifestguard.models for request/response validation
and automatic OpenAPI documentation generation.
"""

from datetime import datetime, timezone

from fastapi import APIRouter, Request

from manifestguard.models import (
    EnvironmentCreate,
    EnvironmentListResponse,
    EnvironmentResponse,
    EnvironmentUpdate,
    ErrorResponse,
)

from ...environment.service import service as env_service

router = APIRouter()


@router.get(
    "/environment",
    response_model=EnvironmentListResponse,
    responses={
        500: {"model": ErrorResponse, "description": "Internal server error"},
    },
    summary="List all environments",
    description="Retrieve a list of all configured environments with their details",
)
async def list_environments(request: Request) -> EnvironmentListResponse:
    """List all environments with automatic response validation."""
    getattr(request.state, "lang", "en")
    result = env_service.list()

    # Convert service result to EnvironmentListResponse
    # Service returns list of dicts, we need to add updated_at and wrap in response
    environments = []
    for env_dict in result:
        # Add updated_at from created_at if missing
        if "updated_at" not in env_dict:
            # Convert timestamp to datetime
            created_dt = datetime.fromtimestamp(env_dict["created_at"], tz=timezone.utc)
            env_dict["created_at"] = created_dt
            env_dict["updated_at"] = created_dt
        environments.append(EnvironmentResponse(**env_dict))

    return EnvironmentListResponse(environments=environments, total=len(environments))


@router.post(
    "/environment",
    status_code=201,
    response_model=EnvironmentResponse,
    responses={
        400: {"model": ErrorResponse, "description": "Invalid request data"},
        422: {"model": ErrorResponse, "description": "Validation error"},
        500: {"model": ErrorResponse, "description": "Internal server error"},
    },
    summary="Create new environment",
    description="Create a new environment with the provided configuration",
)
async def create_environment(
    payload: EnvironmentCreate,
    request: Request,
) -> EnvironmentResponse:
    """Create new environment with automatic validation."""
    lang = getattr(request.state, "lang", "en")
    result = env_service.create(payload.model_dump(), lang=lang)

    # Convert service result to EnvironmentResponse
    # Service returns dict with timestamp, convert to datetime and add updated_at
    created_dt = datetime.fromtimestamp(result["created_at"], tz=timezone.utc)
    result["created_at"] = created_dt
    result["updated_at"] = created_dt  # Same as created_at for new environments
    return EnvironmentResponse(**result)


@router.get(
    "/environment/{env_id}",
    response_model=EnvironmentResponse,
    responses={
        404: {"model": ErrorResponse, "description": "Environment not found"},
        500: {"model": ErrorResponse, "description": "Internal server error"},
    },
    summary="Get environment by ID",
    description="Retrieve detailed information about a specific environment",
)
async def get_environment(env_id: str, request: Request) -> EnvironmentResponse:
    """Get environment by ID with automatic validation."""
    lang = getattr(request.state, "lang", "en")
    result = env_service.get(env_id, lang=lang)

    # Convert service result to EnvironmentResponse
    created_dt = datetime.fromtimestamp(result["created_at"], tz=timezone.utc)
    result["created_at"] = created_dt
    result["updated_at"] = created_dt  # Use created_at since service doesn't track updates
    return EnvironmentResponse(**result)


@router.put(
    "/environment/{env_id}",
    response_model=EnvironmentResponse,
    responses={
        400: {"model": ErrorResponse, "description": "Invalid request data"},
        404: {"model": ErrorResponse, "description": "Environment not found"},
        422: {"model": ErrorResponse, "description": "Validation error"},
        500: {"model": ErrorResponse, "description": "Internal server error"},
    },
    summary="Update environment",
    description="Update an existing environment with partial or complete data",
)
async def update_environment(
    env_id: str,
    payload: EnvironmentUpdate,
    request: Request,
) -> EnvironmentResponse:
    """Update environment with automatic validation."""
    lang = getattr(request.state, "lang", "en")
    result = env_service.update(env_id, payload.model_dump(exclude_unset=True), lang=lang)

    # Convert service result to EnvironmentResponse
    created_dt = datetime.fromtimestamp(result["created_at"], tz=timezone.utc)
    result["created_at"] = created_dt
    result["updated_at"] = datetime.now(timezone.utc)  # Current time for updates
    return EnvironmentResponse(**result)


@router.delete(
    "/environment/{env_id}",
    status_code=204,
    responses={
        404: {"model": ErrorResponse, "description": "Environment not found"},
        500: {"model": ErrorResponse, "description": "Internal server error"},
    },
    summary="Delete environment",
    description="Remove an environment from the system",
)
async def delete_environment(env_id: str, request: Request) -> None:
    """Delete environment with automatic validation."""
    lang = getattr(request.state, "lang", "en")
    env_service.delete(env_id, lang=lang)
