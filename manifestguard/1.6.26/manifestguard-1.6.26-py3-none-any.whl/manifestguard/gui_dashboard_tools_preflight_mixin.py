from __future__ import annotations

from importlib.util import find_spec
from pathlib import Path
from typing import TYPE_CHECKING, Any, cast
import sys

from PySide6.QtCore import QObject, QThread, Qt
from PySide6.QtWidgets import (
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QMessageBox,
    QPushButton,
    QTextEdit,
    QTreeWidget,
    QTreeWidgetItem,
    QVBoxLayout,
    QWidget,
)


class GuiDashboardToolsPreflightMixin:
    if TYPE_CHECKING:
        def __getattr__(self, name: str) -> Any: ...

    def _create_dashboard_show_page(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)

        header = QLabel(
            "<h2>👁️ Show</h2>"
            "<p>Quick commands and views for the <b>active project</b>. "
            "All actions run mgpy CLI commands with streamed output.</p>"
        )
        header.setWordWrap(True)
        layout.addWidget(header)

        tools = QGroupBox("Tools (active project)")
        tools_layout = QVBoxLayout(tools)

        btn_row = QHBoxLayout()

        self.btn_tools_run_all = QPushButton("Run All (Quick)")
        self.btn_tools_run_all.setToolTip("Runs: check → complexity → coverage-weekly")
        self.btn_tools_run_all.clicked.connect(self._run_tool_run_all_quick)
        btn_row.addWidget(self.btn_tools_run_all)

        self.btn_tools_run_all_basic = QPushButton("Run All (Basic)")
        self.btn_tools_run_all_basic.setToolTip("Runs: check (no --extended) → complexity → coverage-weekly")
        self.btn_tools_run_all_basic.clicked.connect(self._run_tool_run_all_basic)
        btn_row.addWidget(self.btn_tools_run_all_basic)

        self.btn_tools_run_all_extended = QPushButton("Run All (Extended)")
        self.btn_tools_run_all_extended.setToolTip("Runs: check --extended → complexity → coverage-weekly")
        self.btn_tools_run_all_extended.clicked.connect(self._run_tool_run_all_extended)
        btn_row.addWidget(self.btn_tools_run_all_extended)

        self.btn_tools_pytest = QPushButton("Run Pytest")
        self.btn_tools_pytest.setToolTip("Runs: python -m pytest (if installed)")
        self.btn_tools_pytest.clicked.connect(self._run_tool_pytest)
        btn_row.addWidget(self.btn_tools_pytest)

        self.btn_tools_complexity = QPushButton("Run Complexity")
        self.btn_tools_complexity.clicked.connect(self._run_tool_complexity)
        btn_row.addWidget(self.btn_tools_complexity)

        self.btn_tools_baseline_trend = QPushButton("Baseline Trend")
        self.btn_tools_baseline_trend.clicked.connect(self._run_tool_baseline_trend)
        btn_row.addWidget(self.btn_tools_baseline_trend)

        self.btn_tools_validate_views = QPushButton("Validate Views")
        self.btn_tools_validate_views.clicked.connect(self._run_tool_validate_views)
        btn_row.addWidget(self.btn_tools_validate_views)

        btn_row.addStretch()

        self.btn_tools_cancel = QPushButton("Cancel")
        self.btn_tools_cancel.setEnabled(False)
        self.btn_tools_cancel.clicked.connect(self._cancel_tools_command)
        btn_row.addWidget(self.btn_tools_cancel)

        tools_layout.addLayout(btn_row)

        btn_row2 = QHBoxLayout()

        self.btn_tools_coverage_track = QPushButton("Coverage Track")
        self.btn_tools_coverage_track.setToolTip("Tracks coverage.json into .mgpy/metrics/manifestguard-history.json")
        self.btn_tools_coverage_track.clicked.connect(self._run_tool_coverage_track)
        btn_row2.addWidget(self.btn_tools_coverage_track)

        self.btn_tools_coverage_weekly = QPushButton("Coverage Weekly")
        self.btn_tools_coverage_weekly.setToolTip("Reconstruct weekly aggregates from metrics history (.mgpy/metrics/)")
        self.btn_tools_coverage_weekly.clicked.connect(self._run_tool_coverage_weekly)
        btn_row2.addWidget(self.btn_tools_coverage_weekly)

        btn_row2.addStretch()
        tools_layout.addLayout(btn_row2)

        open_row = QHBoxLayout()
        btn_open_manifestguard_dir = QPushButton("Open .manifestguard Folder")
        btn_open_manifestguard_dir.clicked.connect(self._open_manifestguard_dir)
        open_row.addWidget(btn_open_manifestguard_dir)

        btn_open_history = QPushButton("Open Metrics History")
        btn_open_history.clicked.connect(self._open_history_file)
        open_row.addWidget(btn_open_history)

        btn_open_metrics = QPushButton("Open metrics.json")
        btn_open_metrics.clicked.connect(self._open_complexity_metrics_file)
        open_row.addWidget(btn_open_metrics)

        open_row.addStretch()
        tools_layout.addLayout(open_row)

        layout.addWidget(tools)

        self.tools_output = QTextEdit()
        self.tools_output.setReadOnly(True)
        self.tools_output.setPlaceholderText("Run a tool to see output...")
        layout.addWidget(self.tools_output)

        self._tools_run_buttons = [
            self.btn_tools_run_all,
            self.btn_tools_pytest,
            self.btn_tools_complexity,
            self.btn_tools_baseline_trend,
            self.btn_tools_validate_views,
            self.btn_tools_coverage_track,
            self.btn_tools_coverage_weekly,
        ]

        layout.addStretch()
        return page

    def _create_dashboard_preflight_page(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)

        header = QLabel(
            "<h2>🧪 Preflight VENV</h2>"
            "<p>Select virtual environments from the active project and run the venv-wizard preflight in sequence.</p>"
        )
        header.setWordWrap(True)
        layout.addWidget(header)

        controls = QGroupBox("Venvs")
        controls_layout = QVBoxLayout(controls)

        self.preflight_tree = QTreeWidget()
        self.preflight_tree.setHeaderLabels(["Run", "Venv Path"])
        self.preflight_tree.setColumnWidth(0, 80)
        controls_layout.addWidget(self.preflight_tree)

        btn_row = QHBoxLayout()
        btn_add = QPushButton("Detect Venvs")
        btn_add.clicked.connect(self._detect_and_populate_venvs)
        btn_row.addWidget(btn_add)

        btn_up = QPushButton("Move Up")
        btn_up.clicked.connect(self._preflight_move_up)
        btn_row.addWidget(btn_up)

        btn_down = QPushButton("Move Down")
        btn_down.clicked.connect(self._preflight_move_down)
        btn_row.addWidget(btn_down)

        btn_row.addStretch()
        controls_layout.addLayout(btn_row)

        layout.addWidget(controls)

        actions = QHBoxLayout()
        self.btn_preflight_run = QPushButton("Run Selected")
        self.btn_preflight_run.clicked.connect(self._preflight_run_selected)
        actions.addWidget(self.btn_preflight_run)

        self.btn_preflight_compare = QPushButton("Compare All")
        self.btn_preflight_compare.setToolTip("Run AI cross-venv comparison for the last preflight results")
        self.btn_preflight_compare.setEnabled(False)
        self.btn_preflight_compare.clicked.connect(self._preflight_compare_last)
        actions.addWidget(self.btn_preflight_compare)

        self.btn_preflight_cancel = QPushButton("Cancel")
        self.btn_preflight_cancel.setEnabled(False)
        self.btn_preflight_cancel.clicked.connect(self._cancel_tools_command)
        actions.addWidget(self.btn_preflight_cancel)

        actions.addStretch()
        layout.addLayout(actions)

        self.preflight_output = QTextEdit()
        self.preflight_output.setReadOnly(True)
        self.preflight_output.setPlaceholderText("Preflight run output...")
        layout.addWidget(self.preflight_output)

        return page

    def _append_tools_output(self, text: str) -> None:
        tools_output = cast(QTextEdit | None, getattr(self, "tools_output", None))
        if tools_output is not None:
            tools_output.append(text)

    def _append_preflight_output(self, text: str) -> None:
        preflight_output = cast(QTextEdit | None, getattr(self, "preflight_output", None))
        if preflight_output is not None:
            preflight_output.append(text)

    def _set_widget_enabled_safe(self, name: str, enabled: bool) -> None:
        widget = getattr(self, name, None)
        if widget is None:
            return
        try:
            widget.setEnabled(enabled)
        except Exception:
            pass

    def _can_compare_preflight_reports(self, *, running: bool) -> bool:
        reports = getattr(self, "_preflight_last_reports", {}) or {}
        return (not running) and len(reports) >= 2

    def _set_tools_running(self, running: bool) -> None:
        for btn in getattr(self, "_tools_run_buttons", []) or []:
            try:
                btn.setEnabled(not running)
            except Exception:
                pass
        self._set_widget_enabled_safe("btn_tools_cancel", running)
        self._set_widget_enabled_safe("btn_preflight_run", not running)
        self._set_widget_enabled_safe(
            "btn_preflight_compare",
            self._can_compare_preflight_reports(running=running),
        )
        self._set_widget_enabled_safe("btn_preflight_cancel", running)

    def _start_tools_command(self, *, cmd: list[str], title: str) -> None:
        root = self._get_active_project_root()
        if root is None:
            QMessageBox.warning(cast(QWidget, self), "Missing Project", "Please select an active project first.")
            return

        tools_thread = getattr(self, "_tools_thread", None)
        if tools_thread is not None and tools_thread.isRunning():
            QMessageBox.information(cast(QWidget, self), "Already Running", "Another tool command is still running.")
            return

        tools_output = cast(QTextEdit | None, getattr(self, "tools_output", None))
        if tools_output is not None:
            tools_output.clear()

        self._append_tools_output(title)
        self._set_tools_running(True)

        from manifestguard.gui_workers import CommandWorker as _CommandWorker

        self._tools_thread = QThread(cast(QObject, self))
        self._tools_worker = _CommandWorker(cwd=root, cmd=cmd)
        self._tools_worker.moveToThread(self._tools_thread)

        self._tools_thread.started.connect(self._tools_worker.run)
        self._tools_worker.output.connect(self._append_tools_output)
        self._tools_worker.output.connect(self._append_preflight_output)
        self._tools_worker.finished.connect(self._on_tools_command_finished)
        self._tools_worker.finished.connect(self._tools_thread.quit)
        self._tools_worker.finished.connect(self._tools_worker.deleteLater)
        self._tools_thread.finished.connect(self._tools_thread.deleteLater)

        self._tools_thread.start()

    def _start_tools_sequence(self, *, commands: list[list[str]], title: str) -> None:
        root = self._get_active_project_root()
        if root is None:
            QMessageBox.warning(cast(QWidget, self), "Missing Project", "Please select an active project first.")
            return

        tools_thread = getattr(self, "_tools_thread", None)
        if tools_thread is not None and tools_thread.isRunning():
            QMessageBox.information(cast(QWidget, self), "Already Running", "Another tool command is still running.")
            return

        tools_output = cast(QTextEdit | None, getattr(self, "tools_output", None))
        if tools_output is not None:
            tools_output.clear()

        self._append_tools_output(title)
        self._set_tools_running(True)

        self._tools_thread = QThread(cast(QObject, self))

        state = self._load_gui_state()
        ai_enabled = bool(state.get("preflight_ai_enabled", False))
        capture_packages = bool(state.get("preflight_capture_packages", False))
        write_full_snapshot = bool(state.get("preflight_packages_write_full_snapshot", True))

        scope = self._get_repo_settings_scope(state)
        repo_state = self._get_effective_repo_settings_state(state, scope)
        wheel_repo_path = (repo_state.get("wheel_repo_path") if isinstance(repo_state, dict) else None) or ""
        wheel_backfill_enabled = bool(state.get("wheel_backfill_enabled", False)) and bool(
            state.get("wheel_backfill_consent", False)
        )
        if scope != "userwide":
            wheel_backfill_enabled = False
            wheel_repo_path = ""

        from manifestguard.gui_workers import CommandSequenceWorker as _CommandSequenceWorker

        self._tools_worker = _CommandSequenceWorker(
            cwd=root,
            commands=commands,
            ai_preflight_enabled=ai_enabled,
            capture_packages_enabled=capture_packages,
            packages_write_full_snapshot=write_full_snapshot,
            wheel_repo_path=str(wheel_repo_path) if wheel_repo_path else None,
            wheel_backfill_enabled=wheel_backfill_enabled,
        )
        self._tools_worker.moveToThread(self._tools_thread)

        self._tools_thread.started.connect(self._tools_worker.run)
        self._tools_worker.output.connect(self._append_tools_output)
        self._tools_worker.output.connect(self._append_preflight_output)
        self._tools_worker.report.connect(self._on_preflight_report)
        self._tools_worker.finished.connect(self._on_tools_command_finished)
        self._tools_worker.finished.connect(self._tools_thread.quit)
        self._tools_worker.finished.connect(self._tools_worker.deleteLater)
        self._tools_thread.finished.connect(self._tools_thread.deleteLater)

        self._tools_thread.start()

    def _detect_and_populate_venvs(self) -> None:
        root = self._get_active_project_root()
        if root is None:
            QMessageBox.warning(cast(QWidget, self), "Missing Project", "Please select an active project first.")
            return

        candidates = self._discover_venv_candidates(root)
        preflight_tree = cast(QTreeWidget | None, getattr(self, "preflight_tree", None))
        if preflight_tree is None:
            return

        self._populate_preflight_tree(preflight_tree, candidates)
        if not candidates:
            self._show_no_venvs_detected_message()

    def _discover_venv_candidates(self, root: Path) -> list[Path]:
        candidates: list[Path] = []
        for name in [".venv", "venv", "env", "venvs"]:
            p = root / name
            if not p.exists() or not p.is_dir():
                continue
            if name == "venvs":
                candidates.extend(child for child in sorted(p.iterdir()) if child.is_dir())
                continue
            candidates.append(p)
        return candidates

    def _populate_preflight_tree(self, preflight_tree: QTreeWidget, candidates: list[Path]) -> None:
        preflight_tree.clear()
        for venv_path in candidates:
            item = QTreeWidgetItem(preflight_tree)
            item.setCheckState(0, Qt.CheckState.Unchecked)
            item.setText(1, str(venv_path))
            preflight_tree.addTopLevelItem(item)

    def _show_no_venvs_detected_message(self) -> None:
        preflight_output = cast(QTextEdit | None, getattr(self, "preflight_output", None))
        if preflight_output is not None:
            preflight_output.setPlainText("No venvs detected in project root.")

    def _preflight_move_up(self) -> None:
        preflight_tree = cast(QTreeWidget | None, getattr(self, "preflight_tree", None))
        if preflight_tree is None:
            return

        idx = preflight_tree.currentIndex().row()
        if idx <= 0:
            return
        item = preflight_tree.takeTopLevelItem(idx)
        if item is None:
            return
        preflight_tree.insertTopLevelItem(idx - 1, item)
        preflight_tree.setCurrentItem(item)

    def _preflight_move_down(self) -> None:
        preflight_tree = cast(QTreeWidget | None, getattr(self, "preflight_tree", None))
        if preflight_tree is None:
            return

        idx = preflight_tree.currentIndex().row()
        if idx < 0 or idx >= preflight_tree.topLevelItemCount() - 1:
            return
        item = preflight_tree.takeTopLevelItem(idx)
        if item is None:
            return
        preflight_tree.insertTopLevelItem(idx + 1, item)
        preflight_tree.setCurrentItem(item)

    def _build_preflight_commands(
        self,
        *,
        preflight_tree: QTreeWidget,
        root: Path,
        workspace_root: Path,
    ) -> list[list[str]]:
        cmds: list[list[str]] = []
        for i in range(preflight_tree.topLevelItemCount()):
            item = preflight_tree.topLevelItem(i)
            if item is None or item.checkState(0) != Qt.CheckState.Checked:
                continue
            venv_path = Path(item.text(1))
            cmds.append(
                [
                    sys.executable,
                    "-m",
                    "manifestguard",
                    "worker",
                    "venv-wizard-preflight",
                    "--project-root",
                    str(root),
                    "--python",
                    str(self._python_from_venv(venv_path)),
                    "--workspace",
                    str(workspace_root),
                    "--json",
                ]
            )
        return cmds

    def _prepare_preflight_ui_for_run(self, workspace_root: Path) -> None:
        preflight_output = cast(QTextEdit | None, getattr(self, "preflight_output", None))
        if preflight_output is not None:
            preflight_output.clear()

        self._append_preflight_output(f"Workspace for history/artifacts: {workspace_root}")
        state = self._load_gui_state()
        if bool(state.get("preflight_capture_packages", False)):
            self._append_preflight_output(
                "(info) Packages snapshot enabled: artifacts under .manifestguard/venv-packages; history timeline stores deltas only."
            )

        self._preflight_last_reports = {}
        self._set_widget_enabled_safe("btn_preflight_compare", False)

    def _preflight_run_selected(self) -> None:
        root = self._get_active_project_root()
        if root is None:
            QMessageBox.warning(cast(QWidget, self), "Missing Project", "Please select an active project first.")
            return

        user_repo = self._get_user_repo_root()
        workspace_root = user_repo or root

        preflight_tree = cast(QTreeWidget | None, getattr(self, "preflight_tree", None))
        if preflight_tree is None:
            return

        cmds = self._build_preflight_commands(
            preflight_tree=preflight_tree,
            root=root,
            workspace_root=workspace_root,
        )

        if not cmds:
            QMessageBox.information(cast(QWidget, self), "Nothing Selected", "Select one or more venvs to run.")
            return

        self._prepare_preflight_ui_for_run(workspace_root)
        self._set_tools_running(True)
        self._start_tools_sequence(commands=cmds, title="Running preflight sequence...\n")

    def _on_preflight_report(self, payload: object) -> None:
        try:
            if not isinstance(payload, dict):
                return
            venv_path = payload.get("venvPath")
            report = payload.get("healthReport")
            if not isinstance(venv_path, str) or not isinstance(report, dict):
                return

            preflight_last_reports = getattr(self, "_preflight_last_reports", None)
            if not isinstance(preflight_last_reports, dict):
                self._preflight_last_reports = {}
                preflight_last_reports = self._preflight_last_reports

            preflight_last_reports[venv_path] = report

            btn_preflight_compare = getattr(self, "btn_preflight_compare", None)
            if btn_preflight_compare is not None:
                try:
                    btn_preflight_compare.setEnabled(len(preflight_last_reports) >= 2)
                except Exception:
                    pass

        except Exception:
            return

    def _preflight_compare_last(self) -> None:
        if len(getattr(self, "_preflight_last_reports", {}) or {}) < 2:
            QMessageBox.information(
                cast(QWidget, self), "Not enough data", "Run preflight for at least 2 venvs first."
            )
            return

        ai_thread = getattr(self, "_ai_thread", None)
        if ai_thread is not None and ai_thread.isRunning():
            QMessageBox.information(cast(QWidget, self), "Already Running", "AI comparison is still running.")
            return

        state = self._load_gui_state()
        if not bool(state.get("preflight_ai_enabled", False)):
            QMessageBox.information(
                cast(QWidget, self),
                "AI disabled",
                "Enable 'AI analysis after VENV preflight' in AI Settings first.",
            )
            return

        preflight_last_reports = cast(dict[str, dict], getattr(self, "_preflight_last_reports", {}) or {})
        venv_paths = list(preflight_last_reports.keys())
        reports = [preflight_last_reports[p] for p in venv_paths]

        self._append_preflight_output("\n" + ("=" * 60))
        self._append_preflight_output("🤖 AI Cross-VENV Comparison")
        self._append_preflight_output(("=" * 60))

        from manifestguard.gui_workers import PreflightCrossAIWorker as _PreflightCrossAIWorker

        self._ai_thread = QThread(cast(QObject, self))
        self._ai_worker = _PreflightCrossAIWorker(health_reports=reports, venv_paths=venv_paths)
        self._ai_worker.moveToThread(self._ai_thread)

        self._ai_thread.started.connect(self._ai_worker.run)
        self._ai_worker.output.connect(self._append_preflight_output)
        self._ai_worker.finished.connect(self._ai_thread.quit)
        self._ai_worker.finished.connect(self._ai_worker.deleteLater)
        self._ai_thread.finished.connect(self._ai_thread.deleteLater)

        self._ai_thread.start()

    def _cancel_tools_command(self) -> None:
        worker = getattr(self, "_tools_worker", None)
        if worker is None:
            return
        try:
            worker.cancel()
        except Exception:
            return

    def _on_tools_command_finished(self, exit_code: int) -> None:
        self._set_tools_running(False)
        if exit_code == 0:
            self._append_tools_output("\n✅ Done.")
        else:
            self._append_tools_output(f"\n❌ Failed (exit code {exit_code}).")

    def _run_tool_complexity(self) -> None:
        cmd = [
            sys.executable,
            "-m",
            "manifestguard",
            "complexity",
            "--output",
            str(Path(".manifestguard") / "metrics.json"),
        ]
        self._start_tools_command(cmd=cmd, title="Running complexity...\n")

    def _run_tool_pytest(self) -> None:
        if find_spec("pytest") is None:
            QMessageBox.information(
                cast(QWidget, self),
                "pytest not installed",
                "pytest is not installed in this Python environment.\n\n"
                "Install it in the active environment, e.g.:\n"
                "  pip install pytest\n",
            )
            return
        cmd = [sys.executable, "-m", "pytest"]
        self._start_tools_command(cmd=cmd, title="Running pytest...\n")

    def _run_tool_run_all_quick(self) -> None:
        root = self._get_active_project_root()
        if root is None:
            QMessageBox.warning(cast(QWidget, self), "Missing Project", "Please select an active project first.")
            return

        rec = self._get_active_project_record() or {}
        last_report = rec.get("lastReport")
        report_path = self._resolve_project_relative_path(
            root,
            last_report if isinstance(last_report, str) and last_report else "manifestguard-report.json",
        )

        last_ext = rec.get("lastExtended")
        extended = bool(last_ext) if isinstance(last_ext, bool) else True

        check_cmd: list[str] = [sys.executable, "-m", "manifestguard", "check"]
        if extended:
            check_cmd.append("--extended")
        check_cmd.extend(["--report", str(report_path)])

        commands = [
            check_cmd,
            [
                sys.executable,
                "-m",
                "manifestguard",
                "complexity",
                "--output",
                str(Path(".manifestguard") / "metrics.json"),
            ],
            [sys.executable, "-m", "manifestguard", "coverage-weekly"],
        ]

        self._start_tools_sequence(commands=commands, title="Running quick full suite...\n")

    def _run_tool_run_all_basic(self) -> None:
        root = self._get_active_project_root()
        if root is None:
            QMessageBox.warning(cast(QWidget, self), "Missing Project", "Please select an active project first.")
            return

        rec = self._get_active_project_record() or {}
        last_report = rec.get("lastReport")
        report_path = self._resolve_project_relative_path(
            root,
            last_report if isinstance(last_report, str) and last_report else "manifestguard-report.json",
        )

        projects = self._get_projects()
        active = self._get_active_project_root_str()
        for p in projects:
            if p.get("root") == active:
                p["lastExtended"] = False
                p["lastUsedAt"] = self._now_iso()
                break
        self._save_projects(self._sorted_projects(projects), active_root=active)

        check_cmd: list[str] = [sys.executable, "-m", "manifestguard", "check", "--report", str(report_path)]

        commands = [
            check_cmd,
            [
                sys.executable,
                "-m",
                "manifestguard",
                "complexity",
                "--output",
                str(Path(".manifestguard") / "metrics.json"),
            ],
            [sys.executable, "-m", "manifestguard", "coverage-weekly"],
        ]

        self._start_tools_sequence(commands=commands, title="Running basic suite...\n")

    def _run_tool_run_all_extended(self) -> None:
        root = self._get_active_project_root()
        if root is None:
            QMessageBox.warning(cast(QWidget, self), "Missing Project", "Please select an active project first.")
            return

        rec = self._get_active_project_record() or {}
        last_report = rec.get("lastReport")
        report_path = self._resolve_project_relative_path(
            root,
            last_report if isinstance(last_report, str) and last_report else "manifestguard-report.json",
        )

        projects = self._get_projects()
        active = self._get_active_project_root_str()
        for p in projects:
            if p.get("root") == active:
                p["lastExtended"] = True
                p["lastUsedAt"] = self._now_iso()
                break
        self._save_projects(self._sorted_projects(projects), active_root=active)

        check_cmd: list[str] = [
            sys.executable,
            "-m",
            "manifestguard",
            "check",
            "--extended",
            "--report",
            str(report_path),
        ]

        commands = [
            check_cmd,
            [
                sys.executable,
                "-m",
                "manifestguard",
                "complexity",
                "--output",
                str(Path(".manifestguard") / "metrics.json"),
            ],
            [sys.executable, "-m", "manifestguard", "coverage-weekly"],
        ]

        self._start_tools_sequence(commands=commands, title="Running extended suite...\n")

    def _run_tool_baseline_trend(self) -> None:
        cmd = [sys.executable, "-m", "manifestguard", "baseline", "--trend"]
        self._start_tools_command(cmd=cmd, title="Running baseline trend...\n")

    def _run_tool_validate_views(self) -> None:
        cmd = [sys.executable, "-m", "manifestguard", "validate-views"]
        self._start_tools_command(cmd=cmd, title="Running validate-views...\n")

    def _run_tool_coverage_track(self) -> None:
        cmd = [sys.executable, "-m", "manifestguard", "coverage-track"]
        self._start_tools_command(cmd=cmd, title="Running coverage-track...\n")

    def _run_tool_coverage_weekly(self) -> None:
        cmd = [sys.executable, "-m", "manifestguard", "coverage-weekly"]
        self._start_tools_command(cmd=cmd, title="Running coverage-weekly...\n")

    def _open_manifestguard_dir(self) -> None:
        root = self._get_active_project_root()
        if root is None:
            QMessageBox.warning(cast(QWidget, self), "Missing Project", "Please select an active project first.")
            return
        folder = root / ".manifestguard"
        if not folder.exists():
            QMessageBox.information(cast(QWidget, self), "Not Found", f"Folder does not exist yet: {folder}")
            return
        self._open_path_in_os(folder)

    def _open_history_file(self) -> None:
        from manifestguard.extended.metrics_history_export import resolve_history_file_path

        root = self._get_active_project_root()
        if root is None:
            QMessageBox.warning(cast(QWidget, self), "Missing Project", "Please select an active project first.")
            return
        history_path = resolve_history_file_path(root, create_if_missing=False)
        if history_path is None or not history_path.exists():
            QMessageBox.information(cast(QWidget, self), "Not Found", "Metrics history file not found (checked .mgpy/metrics/, legacy locations)")
            return
        self._open_path_in_os(history_path)

    def _open_complexity_metrics_file(self) -> None:
        root = self._get_active_project_root()
        if root is None:
            QMessageBox.warning(cast(QWidget, self), "Missing Project", "Please select an active project first.")
            return
        metrics_path = root / ".manifestguard" / "metrics.json"
        if not metrics_path.exists():
            QMessageBox.information(cast(QWidget, self), "Not Found", f"File does not exist yet: {metrics_path}")
            return
        self._open_path_in_os(metrics_path)
