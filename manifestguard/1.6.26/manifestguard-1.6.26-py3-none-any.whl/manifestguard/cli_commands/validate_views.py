"""
validate-views: View registration and HTML hygiene validation for mgpy.

This module implements Phase P0 of the validate-views guardrail:
- VV-001: TUI screen registration check
- VV-002: HTML inline style detection
- VV-003: HTML inline event handler detection

Based on concept.validate-views.en.md, adapted for Python/mgpy context.
"""

import ast
import re
from abc import ABC, abstractmethod
from dataclasses import dataclass
from pathlib import Path
import sys


@dataclass
class Violation:
    """Represents a single validate-views violation."""
    rule: str
    file: Path
    line: int
    column: int
    message: str
    severity: str  # ERROR or WARNING

    def __str__(self) -> str:
        """Format violation for console output (CI-friendly)."""
        rel_path = self.file.as_posix()
        return f"{rel_path}:{self.line}:{self.column} {self.rule} {self.message}"


class ViewValidator(ABC):
    """Base class for view validation rules."""

    def __init__(self, target_dirs: list[Path], ignore_patterns: list[str]):
        self.target_dirs = target_dirs
        self.ignore_patterns = ignore_patterns
        self.violations: list[Violation] = []

    def should_ignore(self, file_path: Path) -> bool:
        """Check if file should be ignored based on patterns."""
        file_str = file_path.as_posix()
        for pattern in self.ignore_patterns:
            # Simple glob-style matching
            if pattern.endswith("/**"):
                prefix = pattern[:-3]
                if prefix in file_str:
                    return True
            elif pattern in file_str:
                return True
        return False

    @abstractmethod
    def validate(self) -> list[Violation]:
        """Run validation and return violations."""
        ...


class TUIScreenRegistrationValidator(ViewValidator):
    """VV-001: Ensure all TUI screen classes are registered in router."""

    def __init__(self, target_dirs: list[Path], ignore_patterns: list[str]):
        super().__init__(target_dirs, ignore_patterns)
        self.screen_base_class = "Screen"  # Base class name for screens
        # Allow IDs like "metrics-history" (kebab-case), not just \w.
        self.registration_pattern = r"register(?:_screen|_view)\s*\(\s*['\"]([\w-]+)['\"]"

    def find_screen_classes(self, file_path: Path) -> list[tuple[str, int]]:
        """Find all Screen subclasses in a Python file. Returns [(class_name, line_number), ...]."""
        try:
            content = file_path.read_text(encoding="utf-8")
            tree = ast.parse(content, filename=str(file_path))
        except (SyntaxError, UnicodeDecodeError):
            return []

        screens = []
        for node in ast.walk(tree):
            if isinstance(node, ast.ClassDef):
                # Check if class inherits from Screen (or similar)
                for base in node.bases:
                    if isinstance(base, ast.Name) and base.id == self.screen_base_class:
                        screens.append((node.name, node.lineno))
                        break
        return screens

    def find_registrations(self, file_path: Path) -> set[str]:
        """Find all registered screen IDs in router files."""
        try:
            content = file_path.read_text(encoding="utf-8")
        except (UnicodeDecodeError, FileNotFoundError):
            return set()

        # Look for registration calls like register_screen('screen-id')
        matches = re.findall(self.registration_pattern, content, re.IGNORECASE)
        return set(matches)

    def _collect_screen_files(self) -> list[Path]:
        """Return all non-ignored .py files from target directories."""
        files: list[Path] = []
        for target_dir in self.target_dirs:
            if not target_dir.exists():
                continue
            for py_file in target_dir.rglob("*.py"):
                if not self.should_ignore(py_file):
                    files.append(py_file)
        return files

    def _collect_registered_ids(self) -> set[str]:
        """Return all registered screen IDs found in router/registry files."""
        registered: set[str] = set()
        for target_dir in self.target_dirs:
            if not target_dir.exists():
                continue
            for py_file in target_dir.rglob("*.py"):
                if "router" in py_file.stem.lower() or "registry" in py_file.stem.lower():
                    registered.update(self.find_registrations(py_file))
        return registered

    @staticmethod
    def _screen_kebab_id(class_name: str) -> str:
        """Convert ClassName to kebab-case screen ID (e.g. MetricsHistoryScreen -> metrics-history)."""
        snake = re.sub(r"(?<!^)(?=[A-Z])", "_", class_name).lower().replace("_screen", "")
        return snake.replace("_", "-")

    def validate(self) -> list[Violation]:
        """Check for unregistered TUI screens."""
        self.violations = []

        all_screens: list[tuple[Path, str, int]] = [
            (fp, name, line)
            for fp in self._collect_screen_files()
            for name, line in self.find_screen_classes(fp)
        ]

        registered_ids = self._collect_registered_ids()

        for file_path, screen_name, line_no in all_screens:
            screen_id_kebab = self._screen_kebab_id(screen_name)
            screen_id_snake = screen_id_kebab.replace("-", "_")
            if screen_id_snake not in registered_ids and screen_id_kebab not in registered_ids:
                self.violations.append(Violation(
                    rule="VV-001",
                    file=file_path,
                    line=line_no,
                    column=1,
                    message=f"TUI screen '{screen_name}' not registered in router (expected ID: '{screen_id_kebab}')",
                    severity="WARNING",
                ))

        return self.violations


class HTMLInlineStyleValidator(ViewValidator):
    """VV-002: Detect inline styles in HTML (CSP violation risk)."""

    def __init__(self, target_dirs: list[Path], ignore_patterns: list[str]):
        super().__init__(target_dirs, ignore_patterns)
        # Patterns for inline style detection
        self.patterns = [
            (r"<style[^>]*>", "Inline <style> block detected (CSP violation risk)"),
            (r'style\s*=\s*["\']', "Inline style attribute detected (CSP violation risk)"),
            (r'\.style\.cssText\s*=', "cssText assignment detected (CSP violation risk)"),
        ]

    def validate(self) -> list[Violation]:
        """Check for inline styles in HTML files and Python string literals."""
        self.violations = []

        for target_dir in self.target_dirs:
            if not target_dir.exists():
                continue
            # Scan .html, .htm, .jinja2, .j2, .mako files
            for pattern in ["*.html", "*.htm", "*.jinja2", "*.j2", "*.mako"]:
                for file_path in target_dir.rglob(pattern):
                    if self.should_ignore(file_path):
                        continue
                    self._check_file(file_path)

            # Also scan Python files for HTML string literals
            for py_file in target_dir.rglob("*.py"):
                if self.should_ignore(py_file):
                    continue
                self._check_python_html(py_file)

        return self.violations

    def _check_file(self, file_path: Path):
        """Check a single HTML file for inline styles."""
        try:
            content = file_path.read_text(encoding="utf-8")
        except (UnicodeDecodeError, FileNotFoundError):
            return

        lines = content.splitlines()
        for line_no, line in enumerate(lines, start=1):
            for pattern, message in self.patterns:
                if re.search(pattern, line, re.IGNORECASE):
                    self.violations.append(Violation(
                        rule="VV-002",
                        file=file_path,
                        line=line_no,
                        column=1,
                        message=message,
                        severity="ERROR"
                    ))

    def _check_python_html(self, file_path: Path):
        """Check Python source for inline style patterns.

        We scan *all* lines because CSP-violating patterns like
        `element.style.cssText = ...` can appear outside HTML literals.
        """
        try:
            content = file_path.read_text(encoding="utf-8")
        except (UnicodeDecodeError, FileNotFoundError):
            return

        lines = content.splitlines()
        for line_no, line in enumerate(lines, start=1):
            for pattern, message in self.patterns:
                if re.search(pattern, line, re.IGNORECASE):
                    self.violations.append(
                        Violation(
                            rule="VV-002",
                            file=file_path,
                            line=line_no,
                            column=1,
                            message=message,
                            severity="ERROR",
                        )
                    )


class HTMLInlineEventHandlerValidator(ViewValidator):
    """VV-003: Detect inline event handlers in HTML (XSS risk)."""

    def __init__(self, target_dirs: list[Path], ignore_patterns: list[str]):
        super().__init__(target_dirs, ignore_patterns)
        # Common inline event handlers
        self.event_handlers = [
            "onclick", "onload", "onerror", "onmouseover", "onmouseout",
            "onkeydown", "onkeyup", "onchange", "onsubmit", "onfocus", "onblur"
        ]
        self.patterns = [
            (rf'{handler}\s*=\s*["\']', f"Inline {handler} handler detected (XSS risk)")
            for handler in self.event_handlers
        ]

    def validate(self) -> list[Violation]:
        """Check for inline event handlers in HTML files and Python string literals."""
        self.violations = []

        for target_dir in self.target_dirs:
            if not target_dir.exists():
                continue
            # Scan .html, .htm, .jinja2, .j2, .mako files
            for pattern in ["*.html", "*.htm", "*.jinja2", "*.j2", "*.mako"]:
                for file_path in target_dir.rglob(pattern):
                    if self.should_ignore(file_path):
                        continue
                    self._check_file(file_path)

            # Also scan Python files for HTML string literals
            for py_file in target_dir.rglob("*.py"):
                if self.should_ignore(py_file):
                    continue
                self._check_python_html(py_file)

        return self.violations

    def _check_file(self, file_path: Path):
        """Check a single HTML file for inline event handlers."""
        try:
            content = file_path.read_text(encoding="utf-8")
        except (UnicodeDecodeError, FileNotFoundError):
            return

        lines = content.splitlines()
        for line_no, line in enumerate(lines, start=1):
            for pattern, message in self.patterns:
                if re.search(pattern, line, re.IGNORECASE):
                    self.violations.append(Violation(
                        rule="VV-003",
                        file=file_path,
                        line=line_no,
                        column=1,
                        message=message,
                        severity="ERROR"
                    ))

    def _check_python_html(self, file_path: Path):
        """Check Python string literals for HTML with inline event handlers."""
        try:
            content = file_path.read_text(encoding="utf-8")
        except (UnicodeDecodeError, FileNotFoundError):
            return

        lines = content.splitlines()
        for line_no, line in enumerate(lines, start=1):
            # Only check lines that look like HTML (heuristic: contains < and >)
            if "<" in line and ">" in line:
                for pattern, message in self.patterns:
                    if re.search(pattern, line, re.IGNORECASE):
                        self.violations.append(Violation(
                            rule="VV-003",
                            file=file_path,
                            line=line_no,
                            column=1,
                            message=message,
                            severity="ERROR"
                        ))


def run_validate_views(
    target_dirs: list[str] | None = None,
    ignore_patterns: list[str] | None = None,
    enabled_rules: set[str] | None = None,
) -> dict[str, list[Violation]]:
    """
    Run all validate-views checks.

    Args:
        target_dirs: List of directories to scan (default: src/manifestguard/extended/tui, src/templates)
        ignore_patterns: List of glob patterns to ignore (default: tests/**, docs/**, examples/**)
        enabled_rules: Set of rule IDs to run (default: all)

    Returns:
        Dict mapping rule ID to list of violations
    """
    if target_dirs is None:
        target_dirs = [
            "src/manifestguard/extended/tui",
            "src/templates",
            "src/manifestguard/reporters"
        ]

    if ignore_patterns is None:
        ignore_patterns = ["tests/**", "docs/**", "examples/**", "__pycache__/**"]

    target_paths = [Path(d) for d in target_dirs]

    validators = [
        TUIScreenRegistrationValidator(target_paths, ignore_patterns),
        HTMLInlineStyleValidator(target_paths, ignore_patterns),
        HTMLInlineEventHandlerValidator(target_paths, ignore_patterns),
    ]

    results: dict[str, list[Violation]] = {}
    for validator in validators:
        violations = validator.validate()
        if violations:
            rule_id = violations[0].rule  # All violations from same validator share same rule ID
            results[rule_id] = violations

    # Filter by enabled rules if specified
    if enabled_rules:
        results = {k: v for k, v in results.items() if k in enabled_rules}

    return results


def format_violations(violations: dict[str, list[Violation]]) -> str:
    """Format violations for console output."""
    if not violations:
        return "✓ No validate-views violations found."

    output_lines = []
    total = 0

    for rule_id in sorted(violations.keys()):
        for violation in violations[rule_id]:
            output_lines.append(str(violation))
            total += 1

    # Add summary
    output_lines.append("")
    output_lines.append("Summary:")
    for rule_id in sorted(violations.keys()):
        count = len(violations[rule_id])
        rule_name = {
            "VV-001": "TUI Registration",
            "VV-002": "HTML Inline Style",
            "VV-003": "HTML Inline Event Handler"
        }.get(rule_id, rule_id)
        output_lines.append(f"  {rule_id} ({rule_name}): {count} violation{'s' if count != 1 else ''}")
    output_lines.append(f"  Total: {total} violation{'s' if total != 1 else ''}")
    output_lines.append("")

    return "\n".join(output_lines)


def main():
    """CLI entry point for validate-views."""
    results = run_validate_views()
    output = format_violations(results)
    print(output)

    # Exit with code 2 if violations found (standard for linting tools)
    sys.exit(2 if results else 0)


if __name__ == "__main__":
    main()
