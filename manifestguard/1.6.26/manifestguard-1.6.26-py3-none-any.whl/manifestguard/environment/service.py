"""Environment management service for ManifestGuard."""

import contextlib
import time
import uuid
from dataclasses import asdict, dataclass

from ..core import logging as mg_logging
from ..core.audit import audit
from ..i18n.i18n import get_i18n

_i18n = get_i18n()
_logger = mg_logging.setup_logger(__name__)


class EnvironmentError(Exception):  # noqa: A001
    """Base exception for environment operations."""

    status_code = 400


class NotFoundError(EnvironmentError):
    """Raised when environment is not found."""

    status_code = 404


class ValidationError(EnvironmentError):
    """Raised when environment validation fails."""

    status_code = 400


@dataclass
class Environment:
    """Environment data model.

    Attributes:
        id: Unique environment identifier.
        name: Environment name.
        description: Optional environment description.
        created_at: Unix timestamp of creation.

    """

    id: str
    name: str
    description: str | None
    created_at: int


class EnvironmentService:
    """Service for managing environments.

    Provides CRUD operations for environments with audit logging.
    """

    def __init__(self):
        """Initialize environment service."""
        self._store: dict[str, Environment] = {}

    def list(self):
        """List all environments.

        Returns:
            List of environment dictionaries.

        """
        return [asdict(e) for e in self._store.values()]

    def get(self, env_id: str, lang: str | None = None) -> dict:
        """Get environment by ID.

        Args:
            env_id: Environment ID.
            lang: Language code for error messages.

        Returns:
            Environment dictionary.

        Raises:
            NotFoundError: When environment doesn't exist.

        """
        if env_id not in self._store:
            raise NotFoundError(
                _i18n.get("environment.get.not_found", lang=lang, module="environment"),
            )
        return asdict(self._store[env_id])

    def create(self, payload: dict, lang: str | None = None) -> dict:
        """Create new environment.

        Args:
            payload: Environment data (name, description).
            lang: Language code for error messages.

        Returns:
            Created environment dictionary.

        Raises:
            ValidationError: When validation fails.

        """
        name = payload.get("name")
        if not name:
            raise ValidationError(
                _i18n.get(
                    "environment.create.validation.name_missing",
                    lang=lang,
                    module="environment",
                ),
            )
        env_id = str(uuid.uuid4())
        now = int(time.time())
        env = Environment(
            id=env_id,
            name=name,
            description=payload.get("description"),
            created_at=now,
        )
        self._store[env_id] = env
        # audit + log
        with contextlib.suppress(Exception):
            audit.record(
                actor="system",
                action="environment.create",
                target=env_id,
                details={"name": name},
            )
        mg_logging.log_struct(_logger, "info", "environment.created", env_id=env_id, name=name)
        return asdict(env)

    def update(self, env_id: str, payload: dict, lang: str | None = None) -> dict:
        """Update existing environment.

        Args:
            env_id: Environment ID.
            payload: Updated environment data.
            lang: Language code for error messages.

        Returns:
            Updated environment dictionary.

        Raises:
            NotFoundError: When environment doesn't exist.

        """
        if env_id not in self._store:
            raise NotFoundError(
                _i18n.get("environment.get.not_found", lang=lang, module="environment"),
            )
        env = self._store[env_id]
        if payload.get("name"):
            env.name = payload["name"]
        if "description" in payload:
            env.description = payload["description"]
        self._store[env_id] = env
        with contextlib.suppress(Exception):
            audit.record(
                actor="system",
                action="environment.update",
                target=env_id,
                details={"payload": payload},
            )
        mg_logging.log_struct(_logger, "info", "environment.updated", env_id=env_id)
        return asdict(env)

    def delete(self, env_id: str, lang: str | None = None) -> bool:
        """Delete environment.

        Args:
            env_id: Environment ID.
            lang: Language code for error messages.

        Returns:
            True if deletion was successful.

        Raises:
            NotFoundError: When environment doesn't exist.

        """
        if env_id not in self._store:
            raise NotFoundError(
                _i18n.get("environment.get.not_found", lang=lang, module="environment"),
            )
        del self._store[env_id]
        with contextlib.suppress(Exception):
            audit.record(actor="system", action="environment.delete", target=env_id)
        mg_logging.log_struct(_logger, "info", "environment.deleted", env_id=env_id)
        return True


# singleton for tests / simple usage
service = EnvironmentService()
