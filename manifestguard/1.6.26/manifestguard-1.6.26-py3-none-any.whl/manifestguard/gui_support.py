"""Non-Qt helpers for the ManifestGuard desktop GUI.

This module must stay importable without PySide6 so we can unit-test
multi-project behavior (discovery, bounds, etc.) in environments where
GUI dependencies are not installed.
"""

from __future__ import annotations

import os
import shutil
import subprocess
from collections import deque
from pathlib import Path
from typing import Callable


_DISCOVERY_EXCLUDED_DIR_NAMES = {
    ".git",
    ".hg",
    ".svn",
    ".tox",
    ".venv",
    "venv",
    "env",
    "__pycache__",
    "node_modules",
    "dist",
    "build",
    ".manifestguard",
    ".eggs",
}


class _PythonProjectDiscoverer:
    def __init__(
        self,
        *,
        base_dir: Path,
        max_depth: int,
        max_projects: int,
        emit: Callable[[str], None],
        should_cancel: Callable[[], bool],
    ) -> None:
        self.base_dir = base_dir
        self.max_depth = max_depth
        self.max_projects = max_projects
        self.emit = emit
        self.should_cancel = should_cancel

    def run(self) -> list[Path]:
        if not self.base_dir.exists() or not self.base_dir.is_dir():
            return []

        found: list[Path] = []
        queue: deque[tuple[Path, int]] = deque([(self.base_dir, 0)])
        visited = 0

        self.emit(f"Scanning: {self.base_dir}")
        self.emit(f"maxDepth={self.max_depth}, maxProjects={self.max_projects}")

        while queue and len(found) < self.max_projects:
            if self.should_cancel():
                break

            current, depth = queue.popleft()
            visited += 1

            self._maybe_add_project(found, current)
            if depth < self.max_depth:
                for child in self._iter_child_dirs(current):
                    queue.append((child, depth + 1))

            if visited % 250 == 0:
                self.emit(f"... scanned {visited} folders (found {len(found)})")

        if self.should_cancel():
            self.emit("Cancelled.")

        self.emit(f"Done. Found {len(found)} project(s).")
        return self._unique_sorted(found)

    def _maybe_add_project(self, found: list[Path], current: Path) -> None:
        try:
            if self._is_python_project_dir(current):
                found.append(current.resolve())
                self.emit(f"Found: {current}")
        except Exception:
            # Best-effort scanning: ignore transient FS issues.
            return

    def _is_python_project_dir(self, dir_path: Path) -> bool:
        return any(
            (dir_path / marker).is_file() for marker in ("pyproject.toml", "setup.cfg", "setup.py")
        )

    def _iter_child_dirs(self, dir_path: Path) -> list[Path]:
        children: list[Path] = []
        try:
            with os.scandir(dir_path) as it:
                for entry in it:
                    if self.should_cancel():
                        break
                    if not self._is_scannable_dir_entry(entry):
                        continue
                    children.append(Path(entry.path))
        except Exception:
            return []
        return children

    def _is_scannable_dir_entry(self, entry: os.DirEntry) -> bool:
        try:
            if not entry.is_dir(follow_symlinks=False):
                return False
        except Exception:
            return False

        name = entry.name
        if not name:
            return False
        if name in _DISCOVERY_EXCLUDED_DIR_NAMES:
            return False
        return not name.startswith(".")

    def _unique_sorted(self, found: list[Path]) -> list[Path]:
        unique: dict[str, Path] = {}
        for p in found:
            unique[str(p)] = p
        return [unique[k] for k in sorted(unique.keys())]


def discover_python_projects(
    *,
    base_dir: Path,
    max_depth: int,
    max_projects: int,
    progress: Callable[[str], None] | None = None,
    cancel_requested: Callable[[], bool] | None = None,
) -> list[Path]:
    """Discover Python projects under a base directory.

    A "project" is any directory containing one of:
    - pyproject.toml
    - setup.cfg
    - setup.py

    Discovery is bounded by max_depth and max_projects.

    Notes:
    - Uses a breadth-first traversal for predictable behavior.
    - Skips common heavyweight or irrelevant directories.
    """

    base_dir = base_dir.expanduser().resolve()
    max_depth = max(0, int(max_depth))
    max_projects = max(1, int(max_projects))

    def emit(msg: str) -> None:
        if progress is not None:
            progress(msg)

    def should_cancel() -> bool:
        return bool(cancel_requested() if cancel_requested is not None else False)

    return _PythonProjectDiscoverer(
        base_dir=base_dir,
        max_depth=max_depth,
        max_projects=max_projects,
        emit=emit,
        should_cancel=should_cancel,
    ).run()



def detect_git_origin_url(repo_root: Path, *, timeout_seconds: int = 2) -> str | None:
    """Best-effort: detect the `origin` remote URL for a git repository.

    This helper is intentionally non-Qt so it can be tested without PySide6.

    Returns:
        The origin URL as a string, or None if not found / git unavailable.
    """
    try:
        repo_root = Path(repo_root).expanduser().resolve()
    except Exception:
        return None

    if not repo_root.exists() or not repo_root.is_dir():
        return None

    # Fast path: avoid spawning git for non-repos.
    if not (repo_root / ".git").exists():
        return None

    if shutil.which("git") is None:
        return None

    try:
        completed = subprocess.run(
            [
                "git",
                "-C",
                str(repo_root),
                "remote",
                "get-url",
                "origin",
            ],
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=max(1, int(timeout_seconds)),
            check=False,
        )
    except Exception:
        return None

    if completed.returncode != 0:
        return None

    url = (completed.stdout or "").strip()
    return url or None
