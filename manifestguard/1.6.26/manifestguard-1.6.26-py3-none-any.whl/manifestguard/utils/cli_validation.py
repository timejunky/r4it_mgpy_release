"""CLI input validation helpers.

Provides reusable validators for common CLI input patterns using the
manifestguard.utils.validation toolkit.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

from manifestguard.utils import validation


def validate_workspace_root(value: Any) -> Path:
    """Validate workspace root directory.

    Args:
        value: Path string to validate

    Returns:
        Validated Path object

    Raises:
        validation.ValidationError: If path is invalid

    """
    path = validation.is_safe_path(value, param="workspace_root")
    path = validation.is_existing_dir(path, param="workspace_root")
    return path


def validate_output_format(value: Any) -> str:
    """Validate output format choice.

    Args:
        value: Format string to validate

    Returns:
        Validated format string

    Raises:
        validation.ValidationError: If format is invalid

    """
    return validation.one_of(
        ["json", "sarif", "yaml", "markdown"],
        value,
        param="format",
    )


def validate_report_path(value: Any, *, allow_overwrite: bool = True) -> Path:
    """Validate report output path.

    Args:
        value: Path string to validate
        allow_overwrite: Whether to allow overwriting existing files

    Returns:
        Validated Path object

    Raises:
        validation.ValidationError: If path is invalid

    """
    path = validation.is_safe_path(value, param="report_path")

    # Validate parent directory exists and is writable
    parent = path.parent
    if not parent.exists():
        raise validation.ValidationError(
            "Parent directory does not exist",
            param="report_path",
            value=str(path),
            hint=f"Create directory first: {parent}",
        )

    if not allow_overwrite and path.exists():
        raise validation.ValidationError(
            "Report file already exists",
            param="report_path",
            value=str(path),
            hint="Use different filename or remove existing file",
        )

    return path


def validate_manifest_file(value: Any) -> Path:
    """Validate manifest file path.

    Args:
        value: Path string to validate

    Returns:
        Validated Path object

    Raises:
        validation.ValidationError: If file is invalid

    """
    path = validation.is_safe_path(value, param="manifest_file")
    path = validation.is_readable_file(path, param="manifest_file")

    # Check if it's a known manifest type
    valid_names = {
        "pyproject.toml",
        "setup.py",
        "setup.cfg",
        "requirements.txt",
        "Pipfile",
        "poetry.lock",
    }

    if path.name not in valid_names:
        raise validation.ValidationError(
            "Unknown manifest file type",
            param="manifest_file",
            value=str(path),
            expected=f"one of: {', '.join(valid_names)}",
            hint="Provide a recognized Python manifest file",
        )

    return path


def validate_json_payload(
    data: Any,
    *,
    param: str = "json_data",
) -> dict[str, Any]:
    """Validate that data is a JSON-compatible dictionary.

    Args:
        data: Data to validate
        param: Parameter name for error messages

    Returns:
        Validated dictionary

    Raises:
        validation.ValidationError: If data is invalid

    """
    if not isinstance(data, dict):
        raise validation.ValidationError(
            "Expected JSON object (dictionary)",
            param=param,
            expected="dict",
            value=type(data).__name__,
            hint="Provide a dictionary/object",
        )

    return data


def validate_metrics_history_entry(entry: Any) -> dict[str, Any]:
    """Validate metrics history entry structure.

    Args:
        entry: Entry data to validate

    Returns:
        Validated entry dictionary

    Raises:
        validation.ValidationError: If entry is invalid

    """
    if not isinstance(entry, dict):
        raise validation.ValidationError(
            "Expected JSON object (dictionary)",
            param="history_entry",
            expected="dict",
            value=type(entry).__name__,
            hint="Provide a dictionary/object",
        )

    # Require timestamp, but keep all other fields as-is.
    if "timestamp" not in entry:
        raise validation.ValidationError(
            "Missing required field",
            param="history_entry.timestamp",
            expected="field 'timestamp'",
            value="<missing>",
            hint="Add required field: timestamp",
        )

    validated: dict[str, Any] = dict(entry)
    validated["timestamp"] = validation.is_non_empty_str(
        entry.get("timestamp"),
        param="history_entry.timestamp",
    )

    # Additional quality score validation if present
    if "quality" in validated and isinstance(validated["quality"], dict):
        quality = validated["quality"]
        if "score" in quality:
            try:
                score = float(quality["score"])
            except (ValueError, TypeError) as e:
                raise validation.ValidationError(
                    "Quality score must be a number",
                    param="history_entry.quality.score",
                    value=quality["score"],
                    hint="Provide a numeric score",
                ) from e

            if not (0 <= score <= 100):
                raise validation.ValidationError(
                    "Quality score must be between 0 and 100",
                    param="history_entry.quality.score",
                    value=score,
                    hint="Provide a score between 0 and 100",
                )

    return validated


def validate_config_dict(config: Any) -> dict[str, Any]:
    """Validate manifestguard.json configuration dictionary.

    Args:
        config: Configuration data to validate

    Returns:
        Validated configuration dictionary

    Raises:
        validation.ValidationError: If configuration is invalid

    """
    config_dict = validate_json_payload(config, param="config")

    # Validate top-level structure (optional fields)
    if "rules" in config_dict:
        rules = config_dict["rules"]
        if not isinstance(rules, dict):
            raise validation.ValidationError(
                "Config 'rules' must be an object",
                param="config.rules",
                expected="dict",
                value=type(rules).__name__,
                hint="Provide a dictionary of rule configurations",
            )

    if "ignorePatterns" in config_dict:
        patterns = config_dict["ignorePatterns"]
        if not isinstance(patterns, list):
            raise validation.ValidationError(
                "Config 'ignorePatterns' must be an array",
                param="config.ignorePatterns",
                expected="list",
                value=type(patterns).__name__,
                hint="Provide a list of glob patterns",
            )

    return config_dict
