"""Parameter validation errors for ManifestGuard.

Provides a central ValidationError class for consistent parameter validation
across the codebase.
"""

from __future__ import annotations

from typing import Any


class ValidationError(ValueError):
    """Error raised when parameter validation fails.

    Attributes:
        message: Primary error message
        param: Optional parameter name that failed validation
        expected: Optional description of expected value/type
        value: Optional actual value that failed validation
        hint: Optional suggestion for fixing the issue

    """

    def __init__(
        self,
        message: str,
        *,
        param: str | None = None,
        expected: str | None = None,
        value: Any = None,
        hint: str | None = None,
    ) -> None:
        """Initialize validation error.

        Args:
            message: Primary error message
            param: Parameter name that failed validation
            expected: Description of expected value/type
            value: Actual value that failed validation
            hint: Suggestion for fixing the issue

        """
        super().__init__(message)
        self.param = param
        self.expected = expected
        self.value = value
        self.hint = hint

    def to_user_message(self) -> str:
        """Generate user-friendly error message.

        Returns:
            Formatted error message with all available context

        """
        parts = [self.args[0]]

        if self.param:
            parts.append(f"param={self.param}")
        if self.expected:
            parts.append(f"expected={self.expected}")
        if self.value is not None:
            # Safely stringify value
            try:
                value_str = str(self.value)
                if len(value_str) > 50:
                    value_str = value_str[:47] + "..."
                parts.append(f"value={value_str}")
            except Exception:  # noqa: S110 - Safe value stringification
                parts.append("value=<unstringifiable>")
        if self.hint:
            parts.append(f"hint={self.hint}")

        return " | ".join(parts)

    def __str__(self) -> str:
        """String representation using user-friendly format."""
        return self.to_user_message()
