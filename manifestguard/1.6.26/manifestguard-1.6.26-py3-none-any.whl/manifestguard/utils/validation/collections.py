"""Collection validators for ManifestGuard.

Provides validators for lists, dictionaries and other collection types.
"""

from __future__ import annotations

from typing import Any, Callable, TypeVar

from manifestguard.utils.validation.errors import ValidationError

T = TypeVar("T")


def is_list_of(
    validator: Callable[[Any], T],
    val: Any,
    *,
    param: str | None = None,
    min_length: int | None = None,
    max_length: int | None = None,
) -> list[T]:
    """Validate that value is a list where each element passes a validator.

    Args:
        validator: Function to validate each element
        val: Value to validate
        param: Parameter name for error messages
        min_length: Optional minimum list length
        max_length: Optional maximum list length

    Returns:
        Validated list with typed elements

    Raises:
        ValidationError: If value is not a list or elements fail validation

    """
    if not isinstance(val, list):
        raise ValidationError(
            "Expected list",
            param=param,
            expected="list",
            value=val,
            hint="Provide a list value",
        )

    if min_length is not None and len(val) < min_length:
        raise ValidationError(
            f"List too short (minimum {min_length} elements)",
            param=param,
            expected=f"list with >= {min_length} elements",
            value=f"list with {len(val)} elements",
            hint=f"Provide at least {min_length} elements",
        )

    if max_length is not None and len(val) > max_length:
        raise ValidationError(
            f"List too long (maximum {max_length} elements)",
            param=param,
            expected=f"list with <= {max_length} elements",
            value=f"list with {len(val)} elements",
            hint=f"Provide at most {max_length} elements",
        )

    validated = []
    for i, item in enumerate(val):
        try:
            validated.append(validator(item))
        except ValidationError as e:
            # Enhance error with index information
            raise ValidationError(
                f"Element {i} validation failed: {e.args[0]}",
                param=f"{param}[{i}]" if param else f"[{i}]",
                expected=e.expected,
                value=item,
                hint=e.hint,
            ) from e

    return validated


def is_dict_with_keys(
    val: Any,
    *,
    param: str | None = None,
    required_keys: set[str] | None = None,
    optional_keys: set[str] | None = None,
) -> dict[str, Any]:
    """Validate that value is a dict with specific keys.

    Args:
        val: Value to validate
        param: Parameter name for error messages
        required_keys: Set of required keys
        optional_keys: Set of optional keys (allows unknown keys if None)

    Returns:
        Validated dictionary

    Raises:
        ValidationError: If value is not a dict or missing required keys

    """
    if not isinstance(val, dict):
        raise ValidationError(
            "Expected dictionary",
            param=param,
            expected="dict",
            value=val,
            hint="Provide a dictionary value",
        )

    if required_keys:
        missing = required_keys - val.keys()
        if missing:
            raise ValidationError(
                f"Missing required keys: {', '.join(sorted(missing))}",
                param=param,
                expected=f"dict with keys: {', '.join(sorted(required_keys))}",
                value=f"dict with keys: {', '.join(sorted(val.keys()))}",
                hint=f"Add missing keys: {', '.join(sorted(missing))}",
            )

    if optional_keys is not None:
        allowed = (required_keys or set()) | optional_keys
        unexpected = val.keys() - allowed
        if unexpected:
            raise ValidationError(
                f"Unexpected keys: {', '.join(sorted(unexpected))}",
                param=param,
                expected=f"dict with allowed keys: {', '.join(sorted(allowed))}",
                value=f"dict with keys: {', '.join(sorted(val.keys()))}",
                hint=f"Remove unexpected keys: {', '.join(sorted(unexpected))}",
            )

    return val


def one_of(
    allowed: list[T],
    val: Any,
    *,
    param: str | None = None,
) -> T:
    """Validate that value is one of allowed values.

    Args:
        allowed: List of allowed values
        val: Value to validate
        param: Parameter name for error messages

    Returns:
        Validated value

    Raises:
        ValidationError: If value is not in allowed list

    """
    if val not in allowed:
        # Format allowed values for display
        allowed_str = ", ".join(repr(v) for v in allowed)
        raise ValidationError(
            f"Value must be one of: {allowed_str}",
            param=param,
            expected=f"one of: {allowed_str}",
            value=val,
            hint=f"Choose from: {allowed_str}",
        )
    return val


def is_non_empty_list(val: Any, *, param: str | None = None) -> list[Any]:
    """Validate that value is a non-empty list.

    Args:
        val: Value to validate
        param: Parameter name for error messages

    Returns:
        Validated non-empty list

    Raises:
        ValidationError: If value is not a list or is empty

    """
    if not isinstance(val, list):
        raise ValidationError(
            "Expected list",
            param=param,
            expected="list",
            value=val,
            hint="Provide a list value",
        )

    if not val:
        raise ValidationError(
            "List must not be empty",
            param=param,
            expected="non-empty list",
            value=val,
            hint="Provide at least one element",
        )

    return val
