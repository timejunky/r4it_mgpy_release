"""Primitive type validators for ManifestGuard.

Provides basic validators for strings, integers, booleans and other primitive types.
"""

from __future__ import annotations

from typing import Any

from manifestguard.utils.validation.errors import ValidationError


def is_str(val: Any, *, param: str | None = None) -> str:
    """Validate that value is a string.

    Args:
        val: Value to validate
        param: Parameter name for error messages

    Returns:
        Validated string value

    Raises:
        ValidationError: If value is not a string

    """
    if not isinstance(val, str):
        raise ValidationError(
            "Expected string",
            param=param,
            expected="str",
            value=val,
            hint="Provide a string value",
        )
    return val


def is_non_empty_str(val: Any, *, param: str | None = None) -> str:
    """Validate that value is a non-empty string.

    Args:
        val: Value to validate
        param: Parameter name for error messages

    Returns:
        Validated non-empty string

    Raises:
        ValidationError: If value is not a string or is empty

    """
    if not isinstance(val, str):
        raise ValidationError(
            "Expected string",
            param=param,
            expected="str",
            value=val,
            hint="Provide a string value",
        )
    if not val.strip():
        raise ValidationError(
            "String must not be empty",
            param=param,
            expected="non-empty string",
            value=val,
            hint="Provide a non-empty string",
        )
    return val


def is_int(val: Any, *, param: str | None = None) -> int:
    """Validate that value is an integer.

    Args:
        val: Value to validate
        param: Parameter name for error messages

    Returns:
        Validated integer value

    Raises:
        ValidationError: If value is not an integer

    """
    if not isinstance(val, int) or isinstance(val, bool):
        raise ValidationError(
            "Expected integer",
            param=param,
            expected="int",
            value=val,
            hint="Provide an integer value",
        )
    return val


def is_positive_int(val: Any, *, param: str | None = None) -> int:
    """Validate that value is a positive integer.

    Args:
        val: Value to validate
        param: Parameter name for error messages

    Returns:
        Validated positive integer

    Raises:
        ValidationError: If value is not a positive integer

    """
    if not isinstance(val, int) or isinstance(val, bool):
        raise ValidationError(
            "Expected integer",
            param=param,
            expected="int",
            value=val,
            hint="Provide an integer value",
        )
    if val <= 0:
        raise ValidationError(
            "Integer must be positive",
            param=param,
            expected=">0",
            value=val,
            hint="Provide a positive integer (>0)",
        )
    return val


def is_non_negative_int(val: Any, *, param: str | None = None) -> int:
    """Validate that value is a non-negative integer.

    Args:
        val: Value to validate
        param: Parameter name for error messages

    Returns:
        Validated non-negative integer

    Raises:
        ValidationError: If value is not a non-negative integer

    """
    if not isinstance(val, int) or isinstance(val, bool):
        raise ValidationError(
            "Expected integer",
            param=param,
            expected="int",
            value=val,
            hint="Provide an integer value",
        )
    if val < 0:
        raise ValidationError(
            "Integer must be non-negative",
            param=param,
            expected=">=0",
            value=val,
            hint="Provide a non-negative integer (>=0)",
        )
    return val


def is_bool(val: Any, *, param: str | None = None) -> bool:
    """Validate that value is a boolean.

    Args:
        val: Value to validate
        param: Parameter name for error messages

    Returns:
        Validated boolean value

    Raises:
        ValidationError: If value is not a boolean

    """
    if not isinstance(val, bool):
        raise ValidationError(
            "Expected boolean",
            param=param,
            expected="bool",
            value=val,
            hint="Provide a boolean value (True/False)",
        )
    return val


def is_float(val: Any, *, param: str | None = None) -> float:
    """Validate that value is a float.

    Args:
        val: Value to validate
        param: Parameter name for error messages

    Returns:
        Validated float value

    Raises:
        ValidationError: If value is not a float or int

    """
    if not isinstance(val, (int, float)) or isinstance(val, bool):
        raise ValidationError(
            "Expected number",
            param=param,
            expected="float",
            value=val,
            hint="Provide a numeric value",
        )
    return float(val)


def is_positive_float(val: Any, *, param: str | None = None) -> float:
    """Validate that value is a positive float.

    Args:
        val: Value to validate
        param: Parameter name for error messages

    Returns:
        Validated positive float

    Raises:
        ValidationError: If value is not a positive float

    """
    num = is_float(val, param=param)
    if num <= 0:
        raise ValidationError(
            "Number must be positive",
            param=param,
            expected=">0",
            value=val,
            hint="Provide a positive number (>0)",
        )
    return num
