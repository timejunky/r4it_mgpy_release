"""Path validators for ManifestGuard.

Provides validators for file paths, directory paths and path safety checks.
"""

from __future__ import annotations

import os
from pathlib import Path
from pathlib import PurePosixPath, PureWindowsPath
from typing import Any

from manifestguard.utils.validation.errors import ValidationError
from manifestguard.utils.validation.primitives import is_str


def _as_path(val: Any, *, param: str | None = None) -> Path:
    if isinstance(val, Path):
        return val
    path_str = is_str(val, param=param)
    return Path(path_str)

# Control characters and path traversal patterns
UNSAFE_PATH_CHARS = {"\0", "\n", "\r", "\t"}
TRAVERSAL_PATTERNS = {"..", "~"}


def is_existing_file(val: Any, *, param: str | None = None) -> Path:
    """Validate that value is an existing file path.

    Args:
        val: Value to validate
        param: Parameter name for error messages

    Returns:
        Validated Path object to existing file

    Raises:
        ValidationError: If path doesn't exist or is not a file

    """
    path = _as_path(val, param=param)

    if not path.exists():
        raise ValidationError(
            "File does not exist",
            param=param,
            expected="existing file",
            value=val,
            hint=f"Ensure file exists: {path}",
        )

    if not path.is_file():
        raise ValidationError(
            "Path is not a file",
            param=param,
            expected="file",
            value=val,
            hint=f"Path is a directory: {path}",
        )

    return path


def is_existing_dir(val: Any, *, param: str | None = None) -> Path:
    """Validate that value is an existing directory path.

    Args:
        val: Value to validate
        param: Parameter name for error messages

    Returns:
        Validated Path object to existing directory

    Raises:
        ValidationError: If path doesn't exist or is not a directory

    """
    path = _as_path(val, param=param)

    if not path.exists():
        raise ValidationError(
            "Directory does not exist",
            param=param,
            expected="existing directory",
            value=val,
            hint=f"Ensure directory exists: {path}",
        )

    if not path.is_dir():
        raise ValidationError(
            "Path is not a directory",
            param=param,
            expected="directory",
            value=val,
            hint=f"Path is a file: {path}",
        )

    return path


def is_safe_path(val: Any, *, param: str | None = None, allow_absolute: bool = True) -> Path:
    """Validate that path is safe (no traversal, no control chars).

    Args:
        val: Value to validate
        param: Parameter name for error messages
        allow_absolute: Whether to allow absolute paths

    Returns:
        Validated Path object

    Raises:
        ValidationError: If path contains unsafe patterns

    """
    if isinstance(val, Path):
        path_str = str(val)
    else:
        path_str = is_str(val, param=param)

    # Check for control characters
    for char in UNSAFE_PATH_CHARS:
        if char in path_str:
            raise ValidationError(
                "Path contains control characters",
                param=param,
                expected="safe path",
                value=val,
                hint="Remove control characters from path",
            )

    path = Path(path_str)

    # Check for absolute path if not allowed.
    # On Windows, POSIX-style paths like "/work/x" are not considered absolute by
    # pathlib.Path, so we evaluate both Windows and POSIX path semantics.
    if not allow_absolute and (
        PurePosixPath(path_str).is_absolute() or PureWindowsPath(path_str).is_absolute()
    ):
        raise ValidationError(
            "Absolute paths not allowed",
            param=param,
            expected="relative path",
            value=val,
            hint="Use a relative path",
        )

    # Check for path traversal patterns
    parts = path.parts
    for part in parts:
        if part in TRAVERSAL_PATTERNS:
            raise ValidationError(
                "Path contains traversal patterns",
                param=param,
                expected="safe path",
                value=val,
                hint="Remove '..' or '~' from path",
            )

    return path


def is_path(val: Any, *, param: str | None = None) -> Path:
    """Validate that value can be converted to a Path.

    Args:
        val: Value to validate
        param: Parameter name for error messages

    Returns:
        Path object

    Raises:
        ValidationError: If value cannot be converted to Path

    """
    path_str = is_str(val, param=param)
    try:
        return Path(path_str)
    except (TypeError, ValueError) as e:
        raise ValidationError(
            "Invalid path",
            param=param,
            expected="valid path",
            value=val,
            hint=f"Cannot convert to path: {e}",
        ) from e


def is_readable_file(val: Any, *, param: str | None = None) -> Path:
    """Validate that file exists and is readable.

    Args:
        val: Value to validate
        param: Parameter name for error messages

    Returns:
        Validated Path object to readable file

    Raises:
        ValidationError: If file doesn't exist, is not a file, or is not readable

    """
    path = is_existing_file(val, param=param)

    if not os.access(path, os.R_OK):
        raise ValidationError(
            "File is not readable",
            param=param,
            expected="readable file",
            value=val,
            hint=f"Check file permissions: {path}",
        )

    return path


def is_writable_dir(val: Any, *, param: str | None = None) -> Path:
    """Validate that directory exists and is writable.

    Args:
        val: Value to validate
        param: Parameter name for error messages

    Returns:
        Validated Path object to writable directory

    Raises:
        ValidationError: If directory doesn't exist or is not writable

    """
    path = is_existing_dir(val, param=param)

    if not os.access(path, os.W_OK):
        raise ValidationError(
            "Directory is not writable",
            param=param,
            expected="writable directory",
            value=val,
            hint=f"Check directory permissions: {path}",
        )

    return path
