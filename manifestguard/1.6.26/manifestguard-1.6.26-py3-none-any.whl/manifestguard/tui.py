"""Terminal User Interface (TUI) Dashboard for ManifestGuard.

Provides interactive terminal dashboard with Rich library for:
- Live metrics display
- Color-coded status panels
- Keyboard navigation
- Real-time updates

Key Bindings:
- q: Quit dashboard
- r: Refresh metrics
- h: Show help
- Ctrl+C: Emergency exit
"""

from __future__ import annotations

import asyncio
import sys
from pathlib import Path
from typing import Any

from rich.console import Console
from rich.layout import Layout
from rich.live import Live
from rich.panel import Panel

from manifestguard.extended import ExtendedTestRunner
from manifestguard.extended.dependency_collection import collect_current_dependency_inventory
from manifestguard.tui_history import build_trends_from_entries
from manifestguard.tui_history import extract_history_entries
from manifestguard.tui_history import load_latest_history_metrics
from manifestguard.tui_history import load_latest_report_metrics
from manifestguard.tui_history import merge_runtime_metrics
from manifestguard.tui_history import pick_history_source_file
from manifestguard.tui_history import take_recent_entries
from manifestguard.tui_history import try_load_json_file
from manifestguard.tui_snapshot import export_markdown_snapshot
from manifestguard.validation import ValidationResult

from manifestguard.tui_panels import create_dependencies_panel
from manifestguard.tui_panels import create_footer_panel
from manifestguard.tui_panels import create_header_panel
from manifestguard.tui_panels import create_license_panel
from manifestguard.tui_panels import create_metrics_panel
from manifestguard.tui_panels import create_packaging_panel
from manifestguard.tui_panels import create_performance_panel
from manifestguard.tui_panels import create_policy_panel
from manifestguard.tui_panels import create_progress_panel
from manifestguard.tui_panels import create_quickfix_panel
from manifestguard.tui_panels import create_sbom_panel
from manifestguard.tui_panels import create_validation_panel


class TUIManager:
    """Terminal UI Manager for ManifestGuard dashboard."""

    def __init__(self, workspace_root: Path, console: Console | None = None):
        self.workspace_root = workspace_root
        self.console = console or Console()
        self.layout = Layout()
        self.metrics_data: dict[str, Any] = {}
        self.validation_result: ValidationResult | None = None

        self.validation_state: str = "pending"  # Validation pipeline state
        self.extended_state: str = "pending"  # Extended analysis pipeline state
        self.validation_error: str | None = None
        self.extended_error: str | None = None

        # Progress state for extended tests
        self.progress_message: str = "Waiting to start extended tests…"
        self.progress_step: int = 0
        self.progress_total: int = 9
        self.spinner_frames: list[str] = ["-", "\\", "|", "/"]
        self.spinner_index: int = 0
        self.tests_current: int | None = None
        self.tests_total: int | None = None
        self.eta_seconds: int | None = None

        # Interactive state
        self.running: bool = True
        self.show_help: bool = False
        self.last_key: str = ""
        self.history_cache: dict[str, list[float]] | None = None
        self.history_cache_mtime: float | None = None
        self.footer_message: str | None = None
        self.metrics_source: str = "none"
        self.metrics_timestamp: str | None = None

        self._preload_metrics_from_history()

    def _preload_metrics_from_history(self) -> None:
        """Load the latest persisted MGPY metrics so the dashboard is useful immediately."""
        history_metrics, history_timestamp = load_latest_history_metrics(self.workspace_root)
        report_metrics, report_timestamp = load_latest_report_metrics(self.workspace_root)

        if history_metrics and report_metrics:
            self.metrics_data = merge_runtime_metrics(report_metrics, history_metrics)
            self.metrics_source = "history+report"
            self.metrics_timestamp = history_timestamp or report_timestamp
        elif history_metrics:
            self.metrics_data = history_metrics
            self.metrics_source = "history"
            self.metrics_timestamp = history_timestamp
        elif report_metrics:
            self.metrics_data = report_metrics
            self.metrics_source = "report"
            self.metrics_timestamp = report_timestamp

        self._refresh_current_dependency_snapshot()

    def _refresh_current_dependency_snapshot(self) -> None:
        """Overlay current dependency counts so stale reports do not keep showing zeros."""
        if not self.metrics_data:
            return

        dependency = self.metrics_data.setdefault("dependency", {})
        if not isinstance(dependency, dict):
            return

        existing_direct = dependency.get("direct_count")
        existing_transitive = dependency.get("transitive_count")
        if not (
            isinstance(existing_direct, (int, float))
            and isinstance(existing_transitive, (int, float))
            and int(existing_direct) == 0
            and int(existing_transitive) == 0
        ):
            return

        direct_count, transitive_count = collect_current_dependency_inventory(self.workspace_root)

        dependency["direct_count"] = direct_count
        dependency["transitive_count"] = transitive_count
        dependency["total_count"] = direct_count + transitive_count

    def _load_history_trends(self) -> dict[str, list[float]]:
        """Load recent history for trend sparklines."""
        source_file = pick_history_source_file(self.workspace_root)
        if source_file is None:
            self.history_cache = {}
            self.history_cache_mtime = None
            return {}

        mtime = source_file.stat().st_mtime
        if self.history_cache is not None and self.history_cache_mtime == mtime:
            return self.history_cache

        data = try_load_json_file(source_file)
        if data is None:
            self.history_cache = {}
            self.history_cache_mtime = mtime
            return {}

        entries = extract_history_entries(data)
        recent = take_recent_entries(entries, limit=8)
        trends = build_trends_from_entries(recent, history_file=source_file)

        self.history_cache = trends
        self.history_cache_mtime = mtime
        return self.history_cache

    def _generate_sparkline(self, values: list[float]) -> str:
        """Generate Unicode sparkline from values."""
        if not values:
            return ""

        # Remove None/invalid values
        clean = [v for v in values if v is not None and isinstance(v, (int, float))]
        if len(clean) == 1:
            return "▄"
        if len(clean) < 2:
            return ""

        # Normalize to 0-7 range for 8 Unicode blocks
        min_val = min(clean)
        max_val = max(clean)
        if max_val == min_val:
            return "▄" * len(clean)  # Flat line

        blocks = "▁▂▃▄▅▆▇█"
        normalized = [int((v - min_val) / (max_val - min_val) * 7) for v in clean]
        sparkline = "".join(blocks[n] for n in normalized)

        # Add trend arrow
        if len(clean) >= 2:
            diff = clean[-1] - clean[-2]
            if abs(diff) < (max_val - min_val) * 0.05:  # Less than 5% change
                arrow = "→"
            elif diff > 0:
                arrow = "↗"
            else:
                arrow = "↘"
            return f"{sparkline} {arrow}"

        return sparkline

    def setup_layout(self) -> None:
        """Setup the dashboard layout with panels."""
        self.layout.split_column(
            Layout(name="header", size=3),
            Layout(name="main", ratio=1),
            Layout(name="footer", size=3),
        )

        self.layout["main"].split_row(
            Layout(name="status", ratio=2),
            Layout(name="quality", ratio=3),
            Layout(name="dependencies", ratio=2),
            Layout(name="compliance", ratio=2),
        )

        # Status column (left) - operational state
        self.layout["main"]["status"].split_column(
            Layout(name="progress", size=4),
            Layout(name="validation", ratio=1),
            Layout(name="quickfix", ratio=1),
        )

        # Quality column - code metrics summary (larger for 5 metrics)
        self.layout["main"]["quality"].split_column(
            Layout(name="summary", ratio=1),
        )

        # Dependencies column - supply chain health
        self.layout["main"]["dependencies"].split_column(
            Layout(name="deps", ratio=1),
            Layout(name="sbom", ratio=1),
            Layout(name="packaging", ratio=1),
        )

        # Compliance column - policy & governance
        self.layout["main"]["compliance"].split_column(
            Layout(name="policy", ratio=1),
            Layout(name="license", ratio=1),
            Layout(name="performance", ratio=1),
        )

    # Intentionally complex for parsing multiple progress message formats with error resilience
    # manifestguard-ignore-next-line: COMPLEXITY
    def _on_progress(self, msg: str) -> None:
        """Receive progress updates from runner."""
        self.progress_message = msg

        # Parse test counts and ETA: "Tests cur/total (ETA Ns)"
        if msg.startswith("Tests "):
            try:
                parts = msg.split()
                counts = parts[1]  # cur/total
                cur_str, total_str = counts.split("/")
                self.tests_current = int(cur_str)
                self.tests_total = int(total_str)
                if "ETA" in msg:
                    # message may end with "(ETA Ns)" or "ETA Ns"
                    for i, token in enumerate(parts):
                        if token.startswith("ETA"):
                            val = parts[i + 1] if i + 1 < len(parts) else ""
                            val = val.rstrip(")")
                            if val.endswith("s"):
                                val = val[:-1]
                            self.eta_seconds = int(val)
                            break
            except Exception:
                pass

        # Parse "Step X/Y:" if present
        if "Step" in msg and "/" in msg:
            try:
                prefix = msg.split(":")[0].strip()
                parts = prefix.replace("Step", "").strip().split("/")
                self.progress_step = int(parts[0])
                self.progress_total = int(parts[1])
            except Exception:
                pass

    def create_header_panel(self) -> Panel:
        return create_header_panel(self)

    def create_validation_panel(self) -> Panel:
        return create_validation_panel(self)

    def create_quickfix_panel(self) -> Panel:
        return create_quickfix_panel(self)

    # Intentionally complex for comprehensive metrics panel rendering with multiple categories and states
    # manifestguard-ignore-next-line: COMPLEXITY
    def create_metrics_panel(self) -> Panel:
        return create_metrics_panel(self)

    def create_dependencies_panel(self) -> Panel:
        return create_dependencies_panel(self)

    def create_policy_panel(self) -> Panel:
        return create_policy_panel(self)

    def create_sbom_panel(self) -> Panel:
        return create_sbom_panel(self)

    def create_packaging_panel(self) -> Panel:
        return create_packaging_panel(self)

    def create_license_panel(self) -> Panel:
        return create_license_panel(self)

    def create_performance_panel(self) -> Panel:
        return create_performance_panel(self)

    def create_progress_panel(self) -> Panel:
        return create_progress_panel(self)

    def update_layout(self) -> Layout:
        """Update the layout with current data."""
        self.layout["header"].update(self.create_header_panel())
        self.layout["footer"].update(self.create_footer_panel())
        # Status column - operational state
        self.layout["main"]["status"]["progress"].update(self.create_progress_panel())
        self.layout["main"]["status"]["validation"].update(self.create_validation_panel())
        self.layout["main"]["status"]["quickfix"].update(self.create_quickfix_panel())
        # Quality column - code metrics
        self.layout["main"]["quality"]["summary"].update(self.create_metrics_panel())
        # Dependencies column - supply chain
        self.layout["main"]["dependencies"]["deps"].update(self.create_dependencies_panel())
        self.layout["main"]["dependencies"]["sbom"].update(self.create_sbom_panel())
        self.layout["main"]["dependencies"]["packaging"].update(self.create_packaging_panel())
        # Compliance column - policy & governance
        self.layout["main"]["compliance"]["policy"].update(self.create_policy_panel())
        self.layout["main"]["compliance"]["license"].update(self.create_license_panel())
        self.layout["main"]["compliance"]["performance"].update(self.create_performance_panel())

        return self.layout

    def create_footer_panel(self) -> Panel:
        return create_footer_panel(self)

    def _export_markdown_snapshot(self) -> Path:
        return export_markdown_snapshot(
            workspace_root=self.workspace_root,
            validation_result=self.validation_result,
            validation_state=self.validation_state,
            validation_error=self.validation_error,
            metrics_data=self.metrics_data,
            extended_state=self.extended_state,
            extended_error=self.extended_error,
        )

    async def run_validation(self) -> None:
        """Run manifest validation and collect results."""
        from manifestguard.cli import _run_manifest_validation  # noqa: PLC0415 - avoid circular import

        self.validation_state = "running"
        self.validation_error = None
        try:
            self.validation_result = _run_manifest_validation(self.workspace_root)
            self.validation_state = "done"
        except Exception as e:
            self.validation_state = "error"
            self.validation_error = str(e)

    async def run_extended_tests(self) -> None:
        """Run extended tests and collect metrics."""
        runner = ExtendedTestRunner(self.workspace_root)

        # Invalidate cached history; extended tests may update history on disk.
        self.history_cache = None
        self.history_cache_mtime = None

        if not runner.is_enabled():
            self.extended_state = "disabled"
            return

        self.extended_state = "running"
        self.extended_error = None
        self.progress_message = "Starting extended tests…"
        self.progress_step = 0
        try:
            metrics = await runner.run(progress_callback=self._on_progress)

            if metrics:
                metrics_dict = metrics.to_dict()
                self.metrics_data = metrics_dict.get("metrics", {}) or {}
                self.metrics_data["quality_score"] = metrics.quality_score
                self.metrics_source = "live"
                self.metrics_timestamp = metrics_dict.get("timestamp")

            self.extended_state = "done"
            # Finalize progress
            self.progress_step = self.progress_total
            self.progress_message = "Extended tests complete"

            # Reload trends on next paint.
            self.history_cache = None
            self.history_cache_mtime = None
        except Exception as e:
            self.extended_state = "error"
            self.extended_error = str(e)

    async def run_dashboard(self) -> None:
        """Run the interactive dashboard."""
        self.setup_layout()

        # Start dashboard immediately and collect data in the background.
        # Print instruction before entering Live; avoid printing while Live is active.
        self.console.print("[dim]Press 'q' to quit, 'r' to refresh, 'h' for help[/dim]\n")

        self.validation_state = "pending"
        self.extended_state = "pending"
        self.running = True

        # Display dashboard. We intentionally keep manual refresh; PowerShell can duplicate
        # output when auto-refresh is enabled.
        with Live(
            self.update_layout(), console=self.console, auto_refresh=False, screen=True
        ) as live:
            validation_task = asyncio.create_task(self.run_validation())
            extended_task = asyncio.create_task(self.run_extended_tests())
            keyboard_task = asyncio.create_task(self._handle_keyboard_input())

            try:
                while self.running:
                    live.update(self.update_layout(), refresh=True)
                    # Keep the UI responsive while background tasks run.
                    await asyncio.sleep(0.2)
            except KeyboardInterrupt:
                self.running = False

            # Ensure background tasks are finished/collected to avoid "Task exception was never retrieved".
            keyboard_task.cancel()
            await asyncio.gather(
                validation_task, extended_task, keyboard_task, return_exceptions=True
            )

    async def _handle_keyboard_input(self) -> None:
        """Handle keyboard input in non-blocking async manner."""
        try:
            # Check platform for appropriate keyboard handling
            if sys.platform == "win32":
                await self._handle_keyboard_windows()
            else:
                await self._handle_keyboard_unix()
        except asyncio.CancelledError:
            pass

    async def _handle_keyboard_windows(self) -> None:
        """Handle keyboard input on Windows using msvcrt."""
        import msvcrt  # noqa: PLC0415 - platform-specific Windows module

        while self.running:
            if msvcrt.kbhit():
                try:
                    key = msvcrt.getch().decode("utf-8").lower()
                    await self._process_key(key)
                except Exception:
                    pass  # Ignore decode errors
            await asyncio.sleep(0.05)

    async def _handle_keyboard_unix(self) -> None:
        """Handle keyboard input on Unix-like systems."""
        import select  # noqa: PLC0415 - platform-specific Unix module
        import termios  # noqa: PLC0415 - platform-specific Unix module
        import tty  # noqa: PLC0415 - platform-specific Unix module

        # Save terminal settings
        old_settings = termios.tcgetattr(sys.stdin)  # type: ignore[attr-defined]

        try:
            # Set terminal to raw mode for immediate key reading
            tty.setraw(sys.stdin.fileno())  # type: ignore[attr-defined]

            while self.running:
                # Check if input is available
                if select.select([sys.stdin], [], [], 0.05)[0]:
                    key = sys.stdin.read(1).lower()
                    await self._process_key(key)
                await asyncio.sleep(0.05)
        finally:
            # Restore terminal settings
            termios.tcsetattr(sys.stdin, termios.TCSADRAIN, old_settings)  # type: ignore[attr-defined]

    async def _process_key(self, key: str) -> None:
        """Process a keyboard input."""
        self.last_key = key

        if key == "q":
            self.running = False
        elif key == "r":
            # Refresh metrics by re-running tasks
            self.history_cache = None
            self.history_cache_mtime = None
            self.footer_message = None
            validation_task = asyncio.create_task(self.run_validation())
            extended_task = asyncio.create_task(self.run_extended_tests())
            # Store references to prevent garbage collection
            self.validation_task = validation_task
            self.extended_task = extended_task
        elif key == "h":
            self.show_help = not self.show_help
        elif key == "m":
            try:
                path = self._export_markdown_snapshot()
                self.footer_message = f"MD exported: {path.relative_to(self.workspace_root)}"
            except Exception as e:
                self.footer_message = f"MD export failed: {e}"


def run_dashboard(workspace_root: Path) -> None:
    """Run the ManifestGuard TUI dashboard."""
    console = Console()

    # Check if Rich is available
    try:
        from importlib.util import find_spec  # noqa: PLC0415 - runtime dependency check

        if find_spec("rich") is None:
            raise ImportError
        console.print("[dim]Using Rich library[/dim]")
    except ImportError:
        console.print("[red]Rich library not available. Install with: pip install rich[/red]")
        return

    manager = TUIManager(workspace_root, console)
    try:
        asyncio.run(manager.run_dashboard())
        console.print("\n[bold green]Dashboard closed[/bold green]")
    except Exception as e:
        console.print(f"[red]Dashboard error: {e}[/red]")
