from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING, Any, cast

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QCheckBox,
    QComboBox,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMessageBox,
    QPushButton,
    QSplitter,
    QStackedWidget,
    QTextEdit,
    QTreeWidget,
    QTreeWidgetItem,
    QVBoxLayout,
    QWidget,
)

from manifestguard.gui_dashboard_tools_preflight_mixin import GuiDashboardToolsPreflightMixin


class GuiDashboardMixin(GuiDashboardToolsPreflightMixin):
    if TYPE_CHECKING:
        def __getattr__(self, name: str) -> Any: ...

    def _create_dashboard_tab(self) -> QWidget:
        """Dashboard workflow tree."""
        widget = QWidget()
        layout = QVBoxLayout(widget)

        splitter = QSplitter(Qt.Orientation.Horizontal)

        dashboard_tree = QTreeWidget()
        dashboard_tree.setHeaderHidden(True)
        self.dashboard_tree = dashboard_tree

        root = QTreeWidgetItem(["ManifestGuard"])
        root.setExpanded(True)
        dashboard_tree.addTopLevelItem(root)

        def add_node(label: str, key: str) -> QTreeWidgetItem:
            item = QTreeWidgetItem([label])
            item.setData(0, Qt.ItemDataRole.UserRole, key)
            root.addChild(item)
            return item

        add_node("Config", "config")
        add_node("Control", "control")
        add_node("Report", "report")
        add_node("Stats", "stats")
        add_node("Guides", "guides")
        add_node("Show", "show")
        add_node("Preflight VENV", "preflight")
        add_node("Help", "help")
        add_node("License", "license")

        dashboard_stack = QStackedWidget()
        self.dashboard_stack = dashboard_stack
        self._dashboard_pages: dict[str, int] = {}

        def add_page(key: str, page: QWidget) -> None:
            idx = dashboard_stack.addWidget(page)
            self._dashboard_pages[key] = idx

        add_page("config", self._create_dashboard_config_page())
        add_page("control", self._create_dashboard_control_page())
        add_page("report", self._create_dashboard_report_page())
        add_page("stats", self._create_dashboard_stats_page())
        add_page("guides", self._create_dashboard_guides_page())
        add_page("show", self._create_dashboard_show_page())
        add_page("preflight", self._create_dashboard_preflight_page())
        add_page("help", self._create_dashboard_help_page())
        add_page("license", self._create_dashboard_license_page())

        dashboard_tree.itemSelectionChanged.connect(self._on_dashboard_selection_changed)
        dashboard_tree.setCurrentItem(root.child(1))

        splitter.addWidget(dashboard_tree)
        splitter.addWidget(dashboard_stack)
        splitter.setStretchFactor(0, 0)
        splitter.setStretchFactor(1, 1)

        layout.addWidget(splitter)
        return widget

    def _on_dashboard_selection_changed(self) -> None:
        dashboard_tree = cast(QTreeWidget | None, getattr(self, "dashboard_tree", None))
        if dashboard_tree is None:
            return

        items = dashboard_tree.selectedItems()
        if not items:
            return
        item = items[0]
        key = item.data(0, Qt.ItemDataRole.UserRole)
        if isinstance(key, str):
            self._dashboard_show(key)

    def _dashboard_show(self, key: str) -> None:
        dashboard_pages = cast(dict[str, int] | None, getattr(self, "_dashboard_pages", None))
        if not dashboard_pages:
            return

        idx = dashboard_pages.get(key)
        if idx is None:
            return

        dashboard_stack = cast(QStackedWidget | None, getattr(self, "dashboard_stack", None))
        if dashboard_stack is None:
            return

        dashboard_stack.setCurrentIndex(idx)

    def _open_dashboard(self, key: str) -> None:
        tabs = getattr(self, "tabs", None)
        if tabs is not None:
            try:
                tabs.setCurrentIndex(0)
            except Exception:
                pass

        dashboard_tree = cast(QTreeWidget | None, getattr(self, "dashboard_tree", None))
        if dashboard_tree is None:
            self._dashboard_show(key)
            return

        root = dashboard_tree.topLevelItem(0)
        if root is None:
            self._dashboard_show(key)
            return

        for i in range(root.childCount()):
            child = root.child(i)
            if child.data(0, Qt.ItemDataRole.UserRole) == key:
                dashboard_tree.setCurrentItem(child)
                break

    def _create_dashboard_config_page(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)

        info = QLabel(
            "<h2>⚙️ Config</h2>"
            "<p>Workspace configuration lives in <b>manifestguard.json</b> in your project root.</p>"
            "<p>Tip: generate/update the config via:</p>"
            "<pre>python -m manifestguard init-config --merge --output manifestguard.json</pre>"
        )
        info.setWordWrap(True)
        layout.addWidget(info)

        project_box = QGroupBox("Project")
        project_layout = QVBoxLayout(project_box)

        selector_row = QHBoxLayout()
        selector_row.addWidget(QLabel("Active project:"))
        self.project_selector_combo = QComboBox()
        self.project_selector_combo.currentIndexChanged.connect(self._on_active_project_changed)
        selector_row.addWidget(self.project_selector_combo)

        btn_add = QPushButton("Add...")
        btn_add.clicked.connect(self._add_project_via_dialog)
        selector_row.addWidget(btn_add)

        btn_remove = QPushButton("Remove")
        btn_remove.clicked.connect(self._remove_selected_project)
        selector_row.addWidget(btn_remove)

        btn_pin = QPushButton("Pin/Unpin")
        btn_pin.clicked.connect(self._toggle_pin_selected_project)
        selector_row.addWidget(btn_pin)

        self.btn_scan_projects = QPushButton("Scan...")
        self.btn_scan_projects.clicked.connect(self._scan_projects_dialog)
        selector_row.addWidget(self.btn_scan_projects)

        self.btn_cancel_scan_projects = QPushButton("Cancel")
        self.btn_cancel_scan_projects.setEnabled(False)
        self.btn_cancel_scan_projects.clicked.connect(self._cancel_project_scan)
        selector_row.addWidget(self.btn_cancel_scan_projects)

        selector_row.addStretch()
        project_layout.addLayout(selector_row)

        row = QHBoxLayout()
        row.addWidget(QLabel("Project folder:"))
        self.project_root_edit = QLineEdit()
        self.project_root_edit.setPlaceholderText("Select a project...")
        self.project_root_edit.setReadOnly(True)
        row.addWidget(self.project_root_edit)
        btn_open_folder = QPushButton("Open Folder")
        btn_open_folder.clicked.connect(self._open_project_folder)
        row.addWidget(btn_open_folder)
        project_layout.addLayout(row)

        actions = QHBoxLayout()
        self.btn_init_config = QPushButton("Init/Update manifestguard.json")
        self.btn_init_config.setToolTip(
            "Runs: python -m manifestguard init-config --merge --output manifestguard.json"
        )
        self.btn_init_config.clicked.connect(lambda: self._run_init_config(open_after=False))
        actions.addWidget(self.btn_init_config)

        self.btn_cancel_init_config = QPushButton("Cancel")
        self.btn_cancel_init_config.setEnabled(False)
        self.btn_cancel_init_config.clicked.connect(self._cancel_init_config)
        actions.addWidget(self.btn_cancel_init_config)

        btn_open_config = QPushButton("Open manifestguard.json")
        btn_open_config.clicked.connect(self._open_manifestguard_json)
        actions.addWidget(btn_open_config)

        btn_create_and_open = QPushButton("Init + Open")
        btn_create_and_open.clicked.connect(lambda: self._run_init_config(open_after=True))
        actions.addWidget(btn_create_and_open)

        actions.addStretch()
        project_layout.addLayout(actions)

        docs = QHBoxLayout()
        btn_open_cli_help = QPushButton("Open CLI Help")
        btn_open_cli_help.clicked.connect(self._open_cli_help)
        docs.addWidget(btn_open_cli_help)
        btn_open_docs = QPushButton("Open Docs (GitHub)")
        btn_open_docs.clicked.connect(self._open_manifestguard_docs)
        docs.addWidget(btn_open_docs)
        docs.addStretch()
        project_layout.addLayout(docs)

        layout.addWidget(project_box)

        self.config_output = QTextEdit()
        self.config_output.setReadOnly(True)
        self.config_output.setPlaceholderText("Config actions output...")
        layout.addWidget(self.config_output)

        state = self._load_gui_state()
        if not state.get("projects"):
            cwd = Path.cwd().resolve()
            self._save_projects([self._create_project_record(cwd)], active_root=str(cwd))

        self._refresh_project_selector_ui()
        self._apply_active_project_to_views()

        layout.addStretch()
        return page

    def _create_dashboard_control_page(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)

        header = QLabel(
            "<h2>✅ Control</h2>"
            "<p>Run validation checks (equivalent to <code>python -m manifestguard check</code>).</p>"
        )
        header.setWordWrap(True)
        layout.addWidget(header)

        controls = QGroupBox("Run")
        controls_layout = QVBoxLayout(controls)

        workspace_row = QHBoxLayout()
        workspace_row.addWidget(QLabel("Project folder:"))
        self.validation_workspace_edit = QLineEdit()
        self.validation_workspace_edit.setPlaceholderText("Active project folder...")
        self.validation_workspace_edit.setReadOnly(True)
        workspace_row.addWidget(self.validation_workspace_edit)
        btn_browse = QPushButton("Select...")
        btn_browse.clicked.connect(self._add_project_via_dialog)
        workspace_row.addWidget(btn_browse)
        controls_layout.addLayout(workspace_row)

        options_row = QHBoxLayout()
        self.validation_extended_checkbox = QCheckBox("Extended analysis")
        self.validation_extended_checkbox.setChecked(True)
        options_row.addWidget(self.validation_extended_checkbox)
        options_row.addStretch()
        controls_layout.addLayout(options_row)

        report_row = QHBoxLayout()
        report_row.addWidget(QLabel("Report file:"))
        self.validation_report_edit = QLineEdit()
        self.validation_report_edit.setPlaceholderText("manifestguard-report.json")
        report_row.addWidget(self.validation_report_edit)
        btn_report = QPushButton("Browse")
        btn_report.clicked.connect(self._browse_validation_report)
        report_row.addWidget(btn_report)
        controls_layout.addLayout(report_row)

        actions_row = QHBoxLayout()
        self.btn_validate = QPushButton("Run Validation")
        self.btn_validate.clicked.connect(self._run_validation)
        actions_row.addWidget(self.btn_validate)

        self.btn_preflight_venv = QPushButton("Preflight VENV")
        self.btn_preflight_venv.setToolTip(
            "Open Preflight VENV panel: select venvs and run preflight tests in sequence"
        )
        self.btn_preflight_venv.clicked.connect(lambda: self._open_dashboard("preflight"))
        actions_row.addWidget(self.btn_preflight_venv)

        self.btn_cancel_validation = QPushButton("Cancel")
        self.btn_cancel_validation.setEnabled(False)
        self.btn_cancel_validation.clicked.connect(self._cancel_validation)
        actions_row.addWidget(self.btn_cancel_validation)

        btn_open_report = QPushButton("Open Dashboard → Report")
        btn_open_report.clicked.connect(lambda: self._open_dashboard("report"))
        actions_row.addWidget(btn_open_report)

        actions_row.addStretch()
        controls_layout.addLayout(actions_row)

        layout.addWidget(controls)

        self.validation_output = QTextEdit()
        self.validation_output.setReadOnly(True)
        self.validation_output.setPlaceholderText("Run validation to see output...")
        layout.addWidget(self.validation_output)

        self._apply_active_project_to_views()

        return page

    def _create_dashboard_report_page(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)

        header = QLabel(
            "<h2>📄 Report</h2>"
            "<p>Open and inspect a ManifestGuard JSON report (e.g. <code>manifestguard-report.json</code>).</p>"
        )
        header.setWordWrap(True)
        layout.addWidget(header)

        row = QHBoxLayout()
        row.addWidget(QLabel("Report file:"))
        self.dashboard_report_path_edit = QLineEdit()
        self.dashboard_report_path_edit.setPlaceholderText("Path to report JSON...")
        row.addWidget(self.dashboard_report_path_edit)
        btn_browse = QPushButton("Browse")
        btn_browse.clicked.connect(self._browse_dashboard_report)
        row.addWidget(btn_browse)
        btn_load = QPushButton("Load")
        btn_load.clicked.connect(self._load_dashboard_report)
        row.addWidget(btn_load)
        btn_open = QPushButton("Open Folder")
        btn_open.clicked.connect(self._open_dashboard_report_folder)
        row.addWidget(btn_open)
        layout.addLayout(row)

        self.dashboard_report_summary = QTextEdit()
        self.dashboard_report_summary.setReadOnly(True)
        self.dashboard_report_summary.setPlaceholderText("Load a report to see summary...")
        layout.addWidget(self.dashboard_report_summary)

        self._apply_active_project_to_views()

        return page

    def _create_dashboard_stats_page(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.addWidget(QLabel("<h2>📈 Stats</h2>"))
        self.dashboard_stats_text = QTextEdit()
        self.dashboard_stats_text.setReadOnly(True)
        self.dashboard_stats_text.setPlaceholderText("Load a report in Dashboard → Report to see stats.")
        layout.addWidget(self.dashboard_stats_text)
        return page

    def _create_dashboard_guides_page(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)
        info = QLabel(
            "<h2>📖 Guides</h2>"
            "<ul>"
            "<li>Use Dashboard → Control to run checks.</li>"
            "<li>Use Dashboard → Report to open the JSON report.</li>"
            "<li>AI configuration is under the AI Assistant tab.</li>"
            "</ul>"
        )
        info.setWordWrap(True)
        layout.addWidget(info)
        layout.addStretch()
        return page

    def _create_dashboard_help_page(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)
        info = QLabel(
            "<h2>❓ Help</h2>"
            "<p>Run <code>python -m manifestguard --help</code> for CLI usage.</p>"
        )
        info.setWordWrap(True)
        layout.addWidget(info)
        layout.addStretch()
        return page

    def _create_dashboard_license_page(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)
        header = QLabel(
            "<h2>🔑 License</h2>"
            "<p>View license status (equivalent to <code>python -m manifestguard license status</code>).</p>"
        )
        header.setWordWrap(True)
        layout.addWidget(header)

        btn = QPushButton("Refresh License Status")
        btn.clicked.connect(self._refresh_license_status)
        layout.addWidget(btn)

        self.license_output = QTextEdit()
        self.license_output.setReadOnly(True)
        self.license_output.setPlaceholderText("Click refresh to load license status...")
        layout.addWidget(self.license_output)

        return page
