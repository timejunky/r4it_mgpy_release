from __future__ import annotations

import time
from pathlib import Path
from typing import Any

from manifestguard.validation import ValidationResult


def _append_snapshot_header(*, lines: list[str], workspace_root: Path) -> None:
    lines.append("# ManifestGuard TUI Snapshot")
    lines.append("")
    lines.append(f"Generated: {time.strftime('%Y-%m-%d %H:%M:%S')}")
    lines.append(f"Workspace: {workspace_root}")
    lines.append("")


def _append_snapshot_validation(
    *,
    lines: list[str],
    validation_result: ValidationResult | None,
    validation_state: str,
    validation_error: str | None,
) -> None:
    lines.append("## Validation")
    if validation_result:
        lines.append(f"- Files checked: {len(validation_result.validated_files)}")
        lines.append(f"- Errors: {validation_result.error_count}")
        lines.append(f"- Warnings: {validation_result.warning_count}")
        lines.append(f"- Infos: {validation_result.info_count}")
    else:
        lines.append(f"- State: {validation_state}")
        if validation_error:
            lines.append(f"- Error: {validation_error}")
    lines.append("")


def _append_snapshot_metrics(
    *,
    lines: list[str],
    metrics_data: dict[str, Any] | None,
    extended_state: str,
    extended_error: str | None,
) -> None:
    lines.append("## Metrics")
    if not metrics_data:
        lines.append(f"- State: {extended_state}")
        if extended_error:
            lines.append(f"- Error: {extended_error}")
        lines.append("")
        return

    cov = metrics_data.get("coverage", {})
    comp = metrics_data.get("complexity", {})
    sec = metrics_data.get("security", {})
    bugfixes = metrics_data.get("bugfixes", {})

    unit_cov = cov.get("unit_percent", 0)
    comp_files_scanned = comp.get("files_scanned", 0)
    avg_complexity = (
        comp.get("average_complexity")
        if comp.get("average_complexity") is not None
        else comp.get("avg_complexity")
    )
    unsafe_count = sec.get("unsafe_exec_count", 0)
    quality_score = metrics_data.get("quality_score", 0)
    bpd = bugfixes.get("bpd", 0.0)
    total_bugfixes = bugfixes.get("total", 0)

    lines.append("| Metric | Value |")
    lines.append("|---|---:|")
    lines.append(f"| Coverage | {unit_cov:.1f}% |")
    if not comp_files_scanned:
        lines.append("| Complexity | n/a |")
    else:
        lines.append(f"| Complexity | {float(avg_complexity or 0.0):.2f} |")
    lines.append(f"| Security (unsafe exec) | {unsafe_count} |")
    lines.append(f"| Quality Score | {quality_score:.1f}% |")
    lines.append(f"| BPD | {bpd:.2f} ({total_bugfixes}) |")
    lines.append("")


def _append_snapshot_coverage_trends(*, lines: list[str], workspace_root: Path) -> None:
    lines.append("## Coverage Trends")
    try:
        from manifestguard.extended.coverage_weekly import (
            calculate_multi_week_trend,
            reconstruct_weekly_coverage,
        )
        from manifestguard.extended.metrics_history_export import resolve_history_file_path

        history_file = resolve_history_file_path(workspace_root, create_if_missing=False)
        if history_file is None or not history_file.exists():
            lines.append("- History file not found")
            lines.append("")
            return

        weekly_data = reconstruct_weekly_coverage(history_file)
        if not weekly_data:
            lines.append("- No weekly coverage data available")
            lines.append("")
            return

        recent_weeks = sorted(weekly_data.keys())[-4:]
        lines.append("| Week | Avg Coverage | Measurements | Trend |")
        lines.append("|---|---:|---:|---|")
        for week in recent_weeks:
            agg = weekly_data[week]
            trend_icon = {
                "improving": "↗",
                "declining": "↘",
                "stable": "→",
                "insufficient_data": "•",
            }.get(agg["trend"], "?")
            lines.append(
                f"| {week} | {agg['avg_coverage']:.2f}% | "
                f"{agg['measurements']} | {trend_icon} {agg['trend']} |",
            )

        multi_trend = calculate_multi_week_trend(weekly_data)
        if multi_trend.get("trend") not in ["no_data", "insufficient_data"]:
            lines.append("")
            lines.append(
                f"**Multi-Week Trend**: {multi_trend['trend']} "
                f"({multi_trend['total_change_percent']:+.2f}% over "
                f"{multi_trend['total_weeks']} weeks)",
            )
    except Exception as e:
        lines.append(f"- Error loading coverage trends: {e}")
    lines.append("")


def _append_snapshot_dependencies(
    *,
    lines: list[str],
    metrics_data: dict[str, Any] | None,
    extended_state: str,
) -> None:
    lines.append("## Dependencies")
    dep = metrics_data.get("dependency", {}) if metrics_data else {}
    if dep:
        direct = dep.get("direct_count", 0)
        transitive = dep.get("transitive_count", 0)
        outdated = dep.get("outdated_count", 0)
        vuln_high = dep.get("vulnerable_high", 0)
        vuln_critical = dep.get("vulnerable_critical", 0)
        lines.append(f"- Direct: {direct}")
        lines.append(f"- Transitive: {transitive}")
        lines.append(f"- Outdated: {outdated}")
        lines.append(
            f"- Vulnerable: {int(vuln_high or 0) + int(vuln_critical or 0)} (H:{vuln_high} C:{vuln_critical})",
        )
    else:
        lines.append(f"- State: {extended_state}")
    lines.append("")


def _append_snapshot_policy(
    *,
    lines: list[str],
    metrics_data: dict[str, Any] | None,
    extended_state: str,
) -> None:
    lines.append("## Policy")
    policy = metrics_data.get("policy", {}) if metrics_data else {}
    if policy:
        whitelist = len(policy.get("whitelist_violations", []))
        blacklist = len(policy.get("blacklist_violations", []))
        dummy_total = policy.get("dummy_code_total_findings", 0)
        dummy_scanned = policy.get("dummy_code_scanned_files", 0)
        duplication_groups = policy.get("duplication", {}).get("duplicate_groups_count", 0)
        lines.append(f"- Whitelist violations: {whitelist}")
        lines.append(f"- Blacklist violations: {blacklist}")
        lines.append(f"- Dummy code findings: {dummy_total}")
        lines.append(f"- Dummy code scanned files: {dummy_scanned}")
        lines.append(f"- Duplication groups: {duplication_groups}")
    else:
        lines.append(f"- State: {extended_state}")
    lines.append("")


def _append_snapshot_kv_section(
    *,
    lines: list[str],
    section: str,
    key: str,
    metrics_data: dict[str, Any] | None,
    extended_state: str,
) -> None:
    lines.append(f"## {section}")
    block = metrics_data.get(key, {}) if metrics_data else {}
    if isinstance(block, dict) and block:
        for k, v in block.items():
            if isinstance(v, dict | list):
                lines.append(f"- {k}: {len(v)}")
            else:
                lines.append(f"- {k}: {v}")
    else:
        lines.append(f"- State: {extended_state}")
    lines.append("")


def build_markdown_snapshot_lines(
    *,
    workspace_root: Path,
    validation_result: ValidationResult | None,
    validation_state: str,
    validation_error: str | None,
    metrics_data: dict[str, Any] | None,
    extended_state: str,
    extended_error: str | None,
) -> list[str]:
    lines: list[str] = []
    _append_snapshot_header(lines=lines, workspace_root=workspace_root)
    _append_snapshot_validation(
        lines=lines,
        validation_result=validation_result,
        validation_state=validation_state,
        validation_error=validation_error,
    )
    _append_snapshot_metrics(
        lines=lines,
        metrics_data=metrics_data,
        extended_state=extended_state,
        extended_error=extended_error,
    )
    _append_snapshot_coverage_trends(lines=lines, workspace_root=workspace_root)
    _append_snapshot_dependencies(
        lines=lines,
        metrics_data=metrics_data,
        extended_state=extended_state,
    )
    _append_snapshot_policy(lines=lines, metrics_data=metrics_data, extended_state=extended_state)

    for section, key in (
        ("SBOM", "sbom"),
        ("Packaging", "packaging"),
        ("License", "license"),
        ("Performance", "performance"),
    ):
        _append_snapshot_kv_section(
            lines=lines,
            section=section,
            key=key,
            metrics_data=metrics_data,
            extended_state=extended_state,
        )

    return lines


def export_markdown_snapshot(
    *,
    workspace_root: Path,
    validation_result: ValidationResult | None,
    validation_state: str,
    validation_error: str | None,
    metrics_data: dict[str, Any] | None,
    extended_state: str,
    extended_error: str | None,
) -> Path:
    """Export a Markdown snapshot of current dashboard data to a file."""

    out_dir = workspace_root / ".manifestguard"
    out_dir.mkdir(parents=True, exist_ok=True)
    out_path = out_dir / "tui-snapshot.md"

    lines = build_markdown_snapshot_lines(
        workspace_root=workspace_root,
        validation_result=validation_result,
        validation_state=validation_state,
        validation_error=validation_error,
        metrics_data=metrics_data,
        extended_state=extended_state,
        extended_error=extended_error,
    )

    out_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return out_path
