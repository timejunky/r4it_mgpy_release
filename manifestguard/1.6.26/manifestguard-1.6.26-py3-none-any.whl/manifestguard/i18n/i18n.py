"""Internationalization (i18n) support for ManifestGuard."""

import json
import logging
from functools import lru_cache
from pathlib import Path
from typing import Any

LOG = logging.getLogger(__name__)


class I18nError(Exception):
    """Raised when i18n operations fail."""

    pass


class I18n:
    """Internationalization service.

    Loads translations from JSON files organized by language and module.
    """

    def __init__(self, base_path: Path, default_lang: str = "en"):
        """Initialize i18n service.

        Args:
            base_path: Base path to language files.
            default_lang: Default language code.

        """
        self.base_path = Path(base_path)
        self.default = default_lang

    @lru_cache(maxsize=256)  # noqa: B019
    def load_module(self, lang: str, module: str) -> dict[str, Any]:
        """Load translation module for language.

        Args:
            lang: Language code.
            module: Module name.

        Returns:
            Translation dictionary.

        """
        path = self.base_path / lang / f"{module}.json"
        if not path.exists():
            LOG.debug("i18n: module file not found: %s", path)
            return {}
        try:
            return json.loads(path.read_text(encoding="utf-8"))
        except Exception as e:
            LOG.exception("failed to load i18n file %s: %s", path, e)
            return {}

    def get(self, key: str, lang: str | None = None, module: str = "core") -> str:
        """Get translated message.

        Args:
            key: Translation key.
            lang: Language code (uses default if None).
            module: Module name.

        Returns:
            Translated message (or key if not found).

        """
        lang = lang or self.default
        # try requested lang
        data = self.load_module(lang, module)
        if key in data:
            return data[key]
        # fallback to default
        if lang != self.default:
            data_def = self.load_module(self.default, module)
            if key in data_def:
                return data_def[key]
        LOG.warning("i18n key missing: %s (lang=%s, module=%s)", key, lang, module)
        # last resort: return key
        return key


def get_i18n():
    """Get i18n singleton instance.

    Returns:
        I18n instance configured for ManifestGuard.

    """
    root = Path(__file__).parent / "locales"
    return I18n(root)
