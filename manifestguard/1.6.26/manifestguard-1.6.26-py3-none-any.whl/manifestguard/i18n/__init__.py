"""ManifestGuard i18n (Internationalization) Module

Supports: EN (English), DE (Deutsch), FR (Français), LB (Lëtzebuergesch), TR (Türkçe)

Usage:
    from manifestguard.i18n import t, set_language, get_current_language

    # Auto-detect from environment
    print(t("validation.success"))

    # Set language explicitly
    set_language("de")
    print(t("validation.success"))  # "Validierung erfolgreich"
"""

import locale
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from .i18n import I18n
from manifestguard.core.user_settings import load_user_settings

# Supported languages
SUPPORTED_LANGUAGES = ["en", "de", "fr", "lb", "tr"]
DEFAULT_LANGUAGE = "en"


@dataclass
class _I18nState:
    instance: I18n | None = None
    language: str = DEFAULT_LANGUAGE
    language_source: str = "default"


_STATE = _I18nState()


def _get_i18n() -> I18n:
    """Get or create the global i18n instance."""
    if _STATE.instance is None:
        locales_path = Path(__file__).parent / "locales"
        _STATE.instance = I18n(locales_path, default_lang=DEFAULT_LANGUAGE)
    return _STATE.instance


def detect_language() -> str:
    """Detect language from environment variables.

    Checks (in order):
    1. MANIFESTGUARD_LANG
    2. Per-user settings (user.json: {"language": "de"})
    3. System locale (e.g., de_DE -> de)
    4. LANG (e.g., "de_DE.UTF-8" -> "de")
    5. LC_ALL
    6. Falls back to DEFAULT_LANGUAGE

    Returns:
        Language code (en, de, fr, lb, tr)

    """
    # Check MANIFESTGUARD_LANG first
    lang = os.environ.get("MANIFESTGUARD_LANG", "").lower()
    if lang in SUPPORTED_LANGUAGES:
        return lang

    # Check per-user settings (persisted preference)
    try:
        user_settings = load_user_settings()
        persisted = str(user_settings.get("language", "")).strip().lower()
        if persisted in SUPPORTED_LANGUAGES:
            return persisted
    except Exception:
        pass

    # Check system locale (works well on Windows)
    try:
        sys_locale, _enc = locale.getlocale()
        if sys_locale:
            lang_code = sys_locale.split("_")[0].split(".")[0].lower()
            if lang_code in SUPPORTED_LANGUAGES:
                return lang_code
    except Exception:
        pass

    # Check LANG environment variable
    lang = os.environ.get("LANG", "").lower()
    if lang:
        # Extract language code (e.g., "de_DE.UTF-8" -> "de")
        lang_code = lang.split("_")[0].split(".")[0]
        if lang_code in SUPPORTED_LANGUAGES:
            return lang_code

    # Check LC_ALL
    lang = os.environ.get("LC_ALL", "").lower()
    if lang:
        lang_code = lang.split("_")[0].split(".")[0]
        if lang_code in SUPPORTED_LANGUAGES:
            return lang_code

    return DEFAULT_LANGUAGE


def detect_language_with_source() -> tuple[str, str]:
    """Detect language and return (lang, source).

    Sources:
      - env:MANIFESTGUARD_LANG
      - user-settings
      - system-locale
      - env:LANG
      - env:LC_ALL
      - default
    """

    # 1) MANIFESTGUARD_LANG
    lang = os.environ.get("MANIFESTGUARD_LANG", "").lower()
    if lang in SUPPORTED_LANGUAGES:
        return lang, "env:MANIFESTGUARD_LANG"

    # 2) persisted per-user preference
    try:
        user_settings = load_user_settings()
        persisted = str(user_settings.get("language", "")).strip().lower()
        if persisted in SUPPORTED_LANGUAGES:
            return persisted, "user-settings"
    except Exception:
        pass

    # 3) system locale
    try:
        sys_locale, _enc = locale.getlocale()
        if sys_locale:
            lang_code = sys_locale.split("_")[0].split(".")[0].lower()
            if lang_code in SUPPORTED_LANGUAGES:
                return lang_code, "system-locale"
    except Exception:
        pass

    # 4) LANG
    lang = os.environ.get("LANG", "").lower()
    if lang:
        lang_code = lang.split("_")[0].split(".")[0]
        if lang_code in SUPPORTED_LANGUAGES:
            return lang_code, "env:LANG"

    # 5) LC_ALL
    lang = os.environ.get("LC_ALL", "").lower()
    if lang:
        lang_code = lang.split("_")[0].split(".")[0]
        if lang_code in SUPPORTED_LANGUAGES:
            return lang_code, "env:LC_ALL"

    return DEFAULT_LANGUAGE, "default"


def set_language(lang: str, *, source: str | None = None) -> None:
    """Set the current language.

    Args:
        lang: Language code (en, de, fr, lb, tr)

    Raises:
        ValueError: If language is not supported

    """
    if lang not in SUPPORTED_LANGUAGES:
        raise ValueError(
            f"Unsupported language: {lang}. " f"Supported: {', '.join(SUPPORTED_LANGUAGES)}",
        )
    _STATE.language = lang
    if source is not None:
        _STATE.language_source = source


def get_current_language() -> str:
    """Get the current language code."""
    return _STATE.language


def get_current_language_source() -> str:
    """Return where the current language was resolved from."""
    return _STATE.language_source


def t(key: str, module: str = "core", lang: str | None = None) -> str:
    """Translate a key to the current language.

    Args:
        key: Translation key (e.g., "validation.success")
        module: Module name (default: "core")
        lang: Override language (if None, uses current language)

    Returns:
        Translated string, or the key itself if not found

    Examples:
        >>> t("validation.success")  # Auto-detect from environment
        'Validation successful'

        >>> set_language("de")
        >>> t("validation.success")
        'Validierung erfolgreich'

        >>> t("validation.success", lang="fr")
        'Validation réussie'

    """
    i18n = _get_i18n()
    effective_lang = lang or _STATE.language
    return i18n.get(key, lang=effective_lang, module=module)


def t_format(
    key: str, *args: Any, module: str = "core", lang: str | None = None, **kwargs: Any
) -> str:
    """Translate a key and format with arguments.

    Args:
        key: Translation key
        *args: Positional format arguments
        module: Module name (default: "core")
        lang: Override language
        **kwargs: Keyword format arguments

    Returns:
        Translated and formatted string

    Examples:
        >>> # Assuming translation: "Found {count} {type}"
        >>> t_format("validation.found_issues", count=5, type="errors")
        'Found 5 errors'

    """
    translated = t(key, module=module, lang=lang)
    try:
        if args and kwargs:
            return translated.format(*args, **kwargs)
        if args:
            return translated.format(*args)
        if kwargs:
            return translated.format(**kwargs)
        return translated
    except (KeyError, IndexError):
        # Fallback: return unformatted string
        return translated


# Auto-detect language on module import
_lang, _src = detect_language_with_source()
_STATE.language = _lang
_STATE.language_source = _src


__all__ = [
    "DEFAULT_LANGUAGE",
    "SUPPORTED_LANGUAGES",
    "detect_language",
    "detect_language_with_source",
    "get_current_language",
    "get_current_language_source",
    "set_language",
    "t",
    "t_format",
]
