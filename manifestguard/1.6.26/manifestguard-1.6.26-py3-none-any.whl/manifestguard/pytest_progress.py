"""Pytest progress reporter for ManifestGuard.

Emits machine-parseable progress lines to stdout:
  [MG-PROGRESS] TOTAL <total>
  [MG-PROGRESS] RUN <current>/<total> ETA <seconds>

This is designed to be loaded via `-p manifestguard.pytest_progress`.
"""

from __future__ import annotations

import time
from typing import Any

_state: dict[str, Any] = {
    "start": None,
    "total": 0,
    "current": 0,
}


def pytest_sessionstart(session) -> None:  # type: ignore[no-untyped-def]
    _state["start"] = time.time()


def pytest_collection_finish(session) -> None:  # type: ignore[no-untyped-def]
    total = len(getattr(session, "items", []) or [])
    _state["total"] = total
    print(f"[MG-PROGRESS] TOTAL {total}", flush=True)


def pytest_runtest_logreport(report) -> None:  # type: ignore[no-untyped-def]
    if report.when != "call":
        return
    if report.outcome not in ("passed", "failed", "skipped"):
        return

    _state["current"] = int(_state.get("current", 0)) + 1
    total = int(_state.get("total", 0)) or 0
    current = int(_state["current"]) or 0

    start = _state.get("start") or time.time()
    elapsed = max(time.time() - float(start), 0.001)
    per_test = elapsed / max(current, 1)
    remaining = max(total - current, 0)
    eta_seconds = int(per_test * remaining)

    print(f"[MG-PROGRESS] RUN {current}/{total} ETA {eta_seconds}", flush=True)
