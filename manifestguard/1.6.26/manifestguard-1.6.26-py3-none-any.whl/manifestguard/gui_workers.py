"""Qt worker objects for ManifestGuard GUI.

This module contains QObject-based background workers used by the GUI to run
subprocess-based tasks without blocking the main thread.

It is intentionally separated from `manifestguard.gui` to keep the GUI entry
module smaller and to make the worker logic easier to test and maintain.
"""

from __future__ import annotations

import json
import os
import subprocess
import sys
from pathlib import Path

from PySide6.QtCore import QObject, Signal

from manifestguard import __version__
from manifestguard.gui_support import discover_python_projects


class ValidationWorker(QObject):
    output = Signal(str)
    finished = Signal(int)

    def __init__(
        self,
        *,
        workspace_root: Path,
        extended: bool,
        report_path: Path,
    ) -> None:
        super().__init__()
        self._workspace_root = workspace_root
        self._extended = extended
        self._report_path = report_path
        self._process: subprocess.Popen[str] | None = None
        self._cancel_requested = False

    def cancel(self) -> None:
        self._cancel_requested = True
        proc = self._process
        if proc is None:
            return
        try:
            proc.terminate()
        except Exception:
            return

    def run(self) -> None:
        cmd: list[str] = [sys.executable, "-m", "manifestguard", "check"]
        if self._extended:
            cmd.append("--extended")
        cmd.extend(["--report", str(self._report_path)])

        self.output.emit(f"$ {' '.join(cmd)}")
        self.output.emit(f"cwd: {self._workspace_root}")

        env = dict(os.environ)
        env.setdefault("PYTHONIOENCODING", "utf-8")

        try:
            self._process = subprocess.Popen(
                cmd,
                cwd=str(self._workspace_root),
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                encoding="utf-8",
                errors="replace",
                bufsize=1,
                env=env,
            )
        except Exception as e:
            self.output.emit(f"Failed to start process: {e}")
            self.finished.emit(1)
            return

        assert self._process.stdout is not None
        for line in self._process.stdout:
            if self._cancel_requested:
                break
            self.output.emit(line.rstrip("\n"))

        try:
            exit_code = self._process.wait(timeout=5 if self._cancel_requested else None)
        except Exception:
            try:
                self._process.kill()
            except Exception:
                pass
            exit_code = 1

        if self._cancel_requested:
            self.output.emit("\nCancelled.")
        else:
            self.output.emit(f"\nExit code: {exit_code}")

        self.finished.emit(int(exit_code))


class PreflightAndValidationWorker(QObject):
    output = Signal(str)
    finished = Signal(int)

    def __init__(
        self,
        *,
        workspace_root: Path,
        extended: bool,
        report_path: Path,
        preflight_timeout_seconds: float,
    ) -> None:
        super().__init__()
        self._workspace_root = workspace_root
        self._extended = extended
        self._report_path = report_path
        self._preflight_timeout_seconds = float(preflight_timeout_seconds)
        self._process: subprocess.Popen[str] | None = None
        self._cancel_requested = False

    def cancel(self) -> None:
        self._cancel_requested = True
        proc = self._process
        if proc is None:
            return
        try:
            proc.terminate()
        except Exception:
            return

    def _run_streamed(self, cmd: list[str]) -> int:
        self.output.emit(f"$ {' '.join(cmd)}")
        self.output.emit(f"cwd: {self._workspace_root}")

        env = dict(os.environ)
        env.setdefault("PYTHONIOENCODING", "utf-8")

        try:
            self._process = subprocess.Popen(
                cmd,
                cwd=str(self._workspace_root),
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                encoding="utf-8",
                errors="replace",
                bufsize=1,
                env=env,
            )
        except Exception as e:
            self.output.emit(f"Failed to start process: {e}")
            return 1

        assert self._process.stdout is not None
        for line in self._process.stdout:
            if self._cancel_requested:
                break
            self.output.emit(line.rstrip("\n"))

        try:
            exit_code = self._process.wait(timeout=5 if self._cancel_requested else None)
        except Exception:
            try:
                self._process.kill()
            except Exception:
                pass
            exit_code = 1

        return int(exit_code)

    def run(self) -> None:
        # 1) vwpy preflight via mgpy stable worker command
        self.output.emit("Starting vwpy preflight (venv_wizard)...")
        preflight_cmd: list[str] = [
            sys.executable,
            "-m",
            "manifestguard",
            "worker",
            "venv-wizard-preflight",
            "--project-root",
            str(self._workspace_root),
            "--python",
            sys.executable,
            "--workspace",
            str(self._workspace_root),
            "--timeout",
            str(self._preflight_timeout_seconds),
        ]

        preflight_exit = self._run_streamed(preflight_cmd)
        if self._cancel_requested:
            self.output.emit("\nCancelled.")
            self.finished.emit(1)
            return

        self.output.emit(f"\nPreflight exit code: {preflight_exit}")

        # 2) Always run validation to produce a report
        self.output.emit("\nStarting ManifestGuard validation...")
        validate_cmd: list[str] = [sys.executable, "-m", "manifestguard", "check"]
        if self._extended:
            validate_cmd.append("--extended")
        validate_cmd.extend(["--report", str(self._report_path)])

        validate_exit = self._run_streamed(validate_cmd)
        if self._cancel_requested:
            self.output.emit("\nCancelled.")
            self.finished.emit(1)
            return

        self.output.emit(f"\nValidation exit code: {validate_exit}")

        # Prefer validation exit code, but keep preflight failure visible if validation succeeded.
        final_exit = validate_exit if validate_exit != 0 else preflight_exit
        self.finished.emit(int(final_exit))


class _PackagesAndMetricsMixin:
    """Helper mixin shared by workers that capture venv package metrics.

    This keeps the main worker method smaller by extracting backfill and
    history-payload helpers while preserving existing behavior.
    """

    output: Signal
    _cwd: Path
    _wheel_backfill_enabled: bool
    _wheel_repo_path: str | None
    _cancel_requested: bool
    _packages_write_full_snapshot: bool

    def _maybe_backfill_missing_wheels(self, workspace_root: Path, venv_python: Path, meta: dict, venv_path: str) -> None:
        try:
            from manifestguard.extended.wheel_backfill import (  # noqa: PLC0415
                backfill_missing_wheels,
            )

            if (
                not self._wheel_backfill_enabled
                or not self._wheel_repo_path
                or not isinstance(meta.get("delta"), dict)
                or self._cancel_requested
            ):
                return

            summary = backfill_missing_wheels(
                python_exe=venv_python,
                wheel_repo_dir=Path(self._wheel_repo_path),
                delta=meta.get("delta") or {},
                emit=lambda s: self.output.emit(s),
                cancel_requested=lambda: self._cancel_requested,
            )
            self.output.emit(
                "(backfill) Done: "
                f"downloaded={summary.get('downloaded', 0)} "
                f"skipped={summary.get('skipped', 0)} "
                f"failed={summary.get('failed', 0)}"
            )
        except Exception as e:  # pragma: no cover - defensive logging
            self.output.emit(f"(backfill) Failed: {e}")

    def _build_venv_packages_history_payload(self, workspace_root: Path, venv_path: str, meta: dict) -> dict:
        venv_abs = Path(venv_path)
        try:
            venv_rel = str(venv_abs.resolve().relative_to(workspace_root.resolve()))
        except Exception:
            venv_rel = str(venv_abs)

        def _rel_path(p: str | None) -> str | None:
            if not p:
                return None
            try:
                return str(Path(p).resolve().relative_to(workspace_root.resolve()))
            except Exception:
                return p

        return {
            "venvPath": venv_rel,
            "venvAbsolutePath": str(venv_abs.resolve()),
            "venvId": meta.get("venvId"),
            "delta": meta.get("delta"),
            "deltaRequirementsPath": _rel_path(meta.get("deltaRequirementsPath")),
            "removedRequirementsPath": _rel_path(meta.get("removedRequirementsPath")),
            "snapshotPath": _rel_path(meta.get("snapshotPath")) if self._packages_write_full_snapshot else None,
        }


class CommandWorker(QObject):
    output = Signal(str)
    finished = Signal(int)

    def __init__(self, *, cwd: Path, cmd: list[str]) -> None:
        super().__init__()
        self._cwd = cwd
        self._cmd = cmd
        self._process: subprocess.Popen[str] | None = None
        self._cancel_requested = False

    def cancel(self) -> None:
        self._cancel_requested = True
        proc = self._process
        if proc is None:
            return
        try:
            proc.terminate()
        except Exception:
            return

    def run(self) -> None:
        self.output.emit(f"$ {' '.join(self._cmd)}")
        self.output.emit(f"cwd: {self._cwd}")

        env = dict(os.environ)
        env.setdefault("PYTHONIOENCODING", "utf-8")

        try:
            self._process = subprocess.Popen(
                self._cmd,
                cwd=str(self._cwd),
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                encoding="utf-8",
                errors="replace",
                bufsize=1,
                env=env,
            )
        except Exception as e:
            self.output.emit(f"Failed to start process: {e}")
            self.finished.emit(1)
            return

        assert self._process.stdout is not None
        for line in self._process.stdout:
            if self._cancel_requested:
                break
            self.output.emit(line.rstrip("\n"))

        try:
            exit_code = self._process.wait(timeout=5 if self._cancel_requested else None)
        except Exception:
            try:
                self._process.kill()
            except Exception:
                pass
            exit_code = 1

        if self._cancel_requested:
            self.output.emit("\nCancelled.")
        else:
            self.output.emit(f"\nExit code: {exit_code}")

        self.finished.emit(int(exit_code))


class ProjectDiscoveryWorker(QObject):
    output = Signal(str)
    finished = Signal(object)

    def __init__(
        self,
        *,
        base_dir: Path,
        max_depth: int,
        max_projects: int,
    ) -> None:
        super().__init__()
        self._base_dir = base_dir
        self._max_depth = max(0, int(max_depth))
        self._max_projects = max(1, int(max_projects))
        self._cancel_requested = False

    def cancel(self) -> None:
        self._cancel_requested = True

    def run(self) -> None:
        results = discover_python_projects(
            base_dir=self._base_dir,
            max_depth=self._max_depth,
            max_projects=self._max_projects,
            progress=lambda s: self.output.emit(s),
            cancel_requested=lambda: self._cancel_requested,
        )
        self.finished.emit([str(p) for p in results])


class CommandSequenceWorker(_PackagesAndMetricsMixin, QObject):
    output = Signal(str)
    finished = Signal(int)
    report = Signal(object)

    def __init__(
        self,
        *,
        cwd: Path,
        commands: list[list[str]],
        ai_preflight_enabled: bool = False,
        capture_packages_enabled: bool = False,
        packages_write_full_snapshot: bool = True,
        wheel_repo_path: str | None = None,
        wheel_backfill_enabled: bool = False,
    ) -> None:
        super().__init__()
        self._cwd = cwd
        self._commands = commands
        self._ai_preflight_enabled = bool(ai_preflight_enabled)
        self._capture_packages_enabled = bool(capture_packages_enabled)
        self._packages_write_full_snapshot = bool(packages_write_full_snapshot)
        self._wheel_repo_path = (wheel_repo_path or "").strip() or None
        self._wheel_backfill_enabled = bool(wheel_backfill_enabled)
        self._process: subprocess.Popen[str] | None = None
        self._cancel_requested = False

    def _extract_venv_path_from_cmd(self, cmd: list[str]) -> str | None:
        try:
            idx = cmd.index("--python")
            py = Path(cmd[idx + 1])
        except Exception:
            return None

        try:
            # Windows: <venv>/Scripts/python.exe, Unix: <venv>/bin/python
            venv_root = py.parent.parent
            return str(venv_root)
        except Exception:
            return None

    def _extract_workspace_root_from_cmd(self, cmd: list[str]) -> Path | None:
        try:
            idx = cmd.index("--workspace")
            return Path(cmd[idx + 1])
        except Exception:
            return None

    def _extract_venv_python_from_cmd(self, cmd: list[str]) -> Path | None:
        try:
            idx = cmd.index("--python")
            return Path(cmd[idx + 1])
        except Exception:
            return None

    def _try_parse_json_from_text(self, text: str) -> dict | None:
        text = (text or "").strip()
        if not text:
            return None
        try:
            obj = json.loads(text)
            return obj if isinstance(obj, dict) else None
        except Exception:
            pass

        # Fallback: extract the last JSON object substring
        start = text.find("{")
        end = text.rfind("}")
        if start >= 0 and end > start:
            candidate = text[start : end + 1]
            try:
                obj = json.loads(candidate)
                return obj if isinstance(obj, dict) else None
            except Exception:
                return None
        return None

    def cancel(self) -> None:
        self._cancel_requested = True
        proc = self._process
        if proc is None:
            return
        try:
            proc.terminate()
        except Exception:
            return

    def _make_env(self) -> dict[str, str]:
        env = dict(os.environ)
        env.setdefault("PYTHONIOENCODING", "utf-8")
        return env

    def _emit_step_header(self, *, idx: int, total: int, cmd: list[str]) -> None:
        self.output.emit("\n" + ("=" * 60))
        self.output.emit(f"Step {idx}/{total}")
        self.output.emit(f"$ {' '.join(cmd)}")
        self.output.emit(f"cwd: {self._cwd}")
        self.output.emit(("=" * 60))

    def _start_process(self, cmd: list[str], env: dict[str, str]) -> subprocess.Popen[str] | None:
        try:
            self._process = subprocess.Popen(
                cmd,
                cwd=str(self._cwd),
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                encoding="utf-8",
                errors="replace",
                bufsize=1,
                env=env,
            )
            return self._process
        except Exception as e:
            self.output.emit(f"Failed to start process: {e}")
            return None

    def _read_process_output(self, proc: subprocess.Popen[str]) -> list[str]:
        assert proc.stdout is not None
        buffered_lines: list[str] = []
        for line in proc.stdout:
            if self._cancel_requested:
                break
            stripped = line.rstrip("\n")
            buffered_lines.append(stripped)
            self.output.emit(stripped)
        return buffered_lines

    def _wait_for_exit(self, proc: subprocess.Popen[str]) -> int:
        try:
            return int(proc.wait(timeout=5 if self._cancel_requested else None))
        except Exception:
            try:
                proc.kill()
            except Exception:
                pass
            return 1

    @staticmethod
    def _count_children_by_status(children: list[dict], status: str) -> int:
        return sum(1 for child in children if isinstance(child, dict) and child.get("status") == status)

    @staticmethod
    def _coalesce_bool(report_obj: dict, *, camel: str, snake: str, default: bool = False) -> bool:
        value = report_obj.get(camel)
        if value is not None:
            return bool(value)
        return bool(report_obj.get(snake, default))

    def _emit_health_report_and_metrics(self, *, cmd: list[str], report_obj: dict, venv_path: str) -> None:
        self.report.emit({"venvPath": venv_path, "healthReport": report_obj})

        try:
            from manifestguard.extended.metrics_history_export import add_venv_health_to_history  # noqa: PLC0415

            workspace_root = self._extract_workspace_root_from_cmd(cmd) or self._cwd

            raw_children = report_obj.get("managedChildren")
            if not isinstance(raw_children, list):
                raw_children = report_obj.get("managed_children")
            if not isinstance(raw_children, list):
                raw_children = []

            children: list[dict] = [c for c in raw_children if isinstance(c, dict)]

            venv_abs = Path(venv_path)
            try:
                venv_rel = str(venv_abs.resolve().relative_to(workspace_root.resolve()))
            except Exception:
                venv_rel = str(venv_abs)

            venv_health = {
                "venvPath": venv_rel,
                "venvAbsolutePath": str(venv_abs.resolve()),
                "status": report_obj.get("status", "unknown"),
                "processStats": {
                    "totalManaged": len(children),
                    "running": self._count_children_by_status(children, "running"),
                    "zombies": self._count_children_by_status(children, "zombie"),
                    "dead": self._count_children_by_status(children, "dead"),
                },
                "warnings": report_obj.get("warnings", []),
                "autoFixApplied": self._coalesce_bool(
                    report_obj,
                    camel="autoFixApplied",
                    snake="auto_fix_applied",
                    default=False,
                ),
                "autoFixDetails": report_obj.get("autoFixDetails")
                if report_obj.get("autoFixDetails") is not None
                else report_obj.get("auto_fix_details"),
                "psutilAvailable": self._coalesce_bool(
                    report_obj,
                    camel="psutilAvailable",
                    snake="psutil_available",
                    default=False,
                ),
            }

            if add_venv_health_to_history(workspace_root, venv_health, mgpy_version=__version__):
                self.output.emit(f"(metrics) venvHealth appended to history under: {workspace_root}")
        except Exception:
            pass

    def _capture_packages_and_metrics(self, *, cmd: list[str], venv_path: str) -> None:
        try:
            from manifestguard.extended.metrics_history_export import (  # noqa: PLC0415
                add_venv_packages_delta_to_history,
            )
            from manifestguard.extended.venv_packages_snapshot import (  # noqa: PLC0415
                get_venv_packages,
                persist_venv_packages_snapshot,
            )

            workspace_root = self._extract_workspace_root_from_cmd(cmd) or self._cwd
            venv_python = self._extract_venv_python_from_cmd(cmd)
            if venv_python is None:
                raise RuntimeError("Could not determine venv python executable")

            self.output.emit(
                f"(packages) Capturing installed packages via: {venv_python} -m pip list --format=json"
            )
            packages = get_venv_packages(venv_python, timeout_seconds=90)

            meta = persist_venv_packages_snapshot(
                workspace_root,
                venv_path=Path(venv_path),
                packages=packages,
                write_full_snapshot=self._packages_write_full_snapshot,
            )

            delta_counts = None
            delta_obj = meta.get("delta")
            if isinstance(delta_obj, dict):
                counts = delta_obj.get("counts")
                if isinstance(counts, dict):
                    delta_counts = counts

            if delta_counts is not None:
                self.output.emit(
                    "(packages) Delta: "
                    f"+{delta_counts.get('added', 0)} "
                    f"~{delta_counts.get('changed', 0)} "
                    f"-{delta_counts.get('removed', 0)}"
                )
            # Optional: wheel backfill to shared repo.
            self._maybe_backfill_missing_wheels(workspace_root, venv_python, meta, venv_path)

            # Build metrics history payload (paths normalized relative to workspace root).
            history_payload = self._build_venv_packages_history_payload(workspace_root, venv_path, meta)

            if add_venv_packages_delta_to_history(
                workspace_root,
                history_payload,
                mgpy_version=__version__,
            ):
                self.output.emit(f"(metrics) venvPackagesDelta appended to history under: {workspace_root}")
        except Exception as e:
            self.output.emit(f"(packages) Capture failed: {e}")

    def _emit_ai_preflight(self, *, report_obj: dict, venv_path: str) -> None:
        try:
            from manifestguard.ai.preflight_analyzer import analyze_health_report  # noqa: PLC0415
            from manifestguard.ai.shared_preferences import get_shared_preferences  # noqa: PLC0415

            prefs = get_shared_preferences()
            ai_result = analyze_health_report(
                report_obj,
                venv_path=venv_path,
                preferences=prefs,
            )

            self.output.emit("\n" + ("-" * 60))
            self.output.emit(f"🤖 AI Preflight Analysis: {venv_path}")
            if ai_result.get("success"):
                summary = ai_result.get("summary") or ""
                if summary:
                    self.output.emit(summary)
                recs = ai_result.get("recommendations") or []
                if recs:
                    self.output.emit("Recommendations:")
                    for rec in recs:
                        self.output.emit(f"- {rec}")
                else:
                    self.output.emit("No recommendations.")
            else:
                err = ai_result.get("error") or "Unknown error"
                self.output.emit(f"AI analysis failed: {err}")
            self.output.emit(("-" * 60))
        except Exception as e:
            self.output.emit(f"AI analysis error: {e}")

    def _maybe_handle_health_report(self, *, cmd: list[str], buffered_lines: list[str]) -> None:
        report_obj = self._try_parse_json_from_text("\n".join(buffered_lines))
        venv_path = self._extract_venv_path_from_cmd(cmd)
        if report_obj is None or not venv_path:
            if venv_path:
                self.output.emit(f"(info) No parsable JSON health report for {venv_path}.")
            return

        self._emit_health_report_and_metrics(cmd=cmd, report_obj=report_obj, venv_path=venv_path)

        if self._capture_packages_enabled and not self._cancel_requested:
            self._capture_packages_and_metrics(cmd=cmd, venv_path=venv_path)

        if self._ai_preflight_enabled and not self._cancel_requested:
            self._emit_ai_preflight(report_obj=report_obj, venv_path=venv_path)

    def run(self) -> None:
        env = self._make_env()

        for idx, cmd in enumerate(self._commands, start=1):
            if self._cancel_requested:
                self.output.emit("\nCancelled.")
                self.finished.emit(1)
                return

            self._emit_step_header(idx=idx, total=len(self._commands), cmd=cmd)

            proc = self._start_process(cmd, env)
            if proc is None:
                self.finished.emit(1)
                return

            buffered_lines = self._read_process_output(proc)

            exit_code = self._wait_for_exit(proc)

            if self._cancel_requested:
                self.output.emit("\nCancelled.")
                self.finished.emit(1)
                return

            if int(exit_code) != 0:
                self.output.emit(f"\nExit code: {exit_code}")
                self.finished.emit(int(exit_code))
                return

            self.output.emit("\nExit code: 0")

            self._maybe_handle_health_report(cmd=cmd, buffered_lines=buffered_lines)

        self.finished.emit(0)


class PreflightCrossAIWorker(QObject):
    output = Signal(str)
    finished = Signal(object)

    def __init__(self, *, health_reports: list[dict], venv_paths: list[str]) -> None:
        super().__init__()
        self._health_reports = health_reports
        self._venv_paths = venv_paths

    def run(self) -> None:
        try:
            from manifestguard.ai.preflight_analyzer import analyze_cross_venv_health  # noqa: PLC0415
            from manifestguard.ai.shared_preferences import get_shared_preferences  # noqa: PLC0415

            prefs = get_shared_preferences()
            result = analyze_cross_venv_health(
                self._health_reports,
                self._venv_paths,
                preferences=prefs,
            )

            if result.get("success"):
                comparison = result.get("comparison") or ""
                riskiest = result.get("riskiest_venv")
                if riskiest:
                    self.output.emit(f"Riskiest venv: {riskiest}")
                if comparison:
                    self.output.emit(comparison)
                recs = result.get("recommendations") or []
                if recs:
                    self.output.emit("Recommendations:")
                    for rec in recs:
                        self.output.emit(f"- {rec}")
            else:
                err = result.get("error") or "Unknown error"
                self.output.emit(f"AI comparison failed: {err}")
            self.finished.emit(result)
        except Exception as e:
            self.output.emit(f"AI comparison error: {e}")
            self.finished.emit({"success": False, "error": str(e)})
