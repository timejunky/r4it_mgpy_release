"""File operation helpers for QuickFix system.

Provides safe file manipulation functions with backup support.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .backup import BackupContext

logger = logging.getLogger(__name__)


def read_lines(file_path: Path) -> list[str]:
    """Read file lines with proper encoding handling.

    Args:
        file_path: Path to file to read

    Returns:
        List of lines (with newlines preserved)

    Raises:
        FileNotFoundError: If file doesn't exist
        UnicodeDecodeError: If file encoding is not UTF-8
    """
    try:
        with file_path.open("r", encoding="utf-8") as f:
            return f.readlines()
    except FileNotFoundError:
        logger.error(f"File not found: {file_path}")
        raise
    except UnicodeDecodeError as e:
        logger.error(f"Encoding error reading {file_path}: {e}")
        raise


def write_lines(file_path: Path, lines: list[str]) -> None:
    """Write lines to file with proper encoding.

    Args:
        file_path: Path to file to write
        lines: List of lines to write (newlines should be included)

    Raises:
        OSError: If file cannot be written
    """
    try:
        with file_path.open("w", encoding="utf-8") as f:
            f.writelines(lines)
    except OSError as e:
        logger.error(f"Error writing {file_path}: {e}")
        raise


def remove_line(file_path: Path, line_number: int, backup_ctx: BackupContext | None = None) -> bool:
    """Safely remove a line from a file.

    Args:
        file_path: Path to file to modify
        line_number: Line number to remove (1-based)
        backup_ctx: Optional backup context for rollback support

    Returns:
        True if line was removed, False otherwise

    Raises:
        ValueError: If line_number is invalid
        OSError: If file operations fail
    """
    if line_number < 1:
        raise ValueError(f"Invalid line number: {line_number} (must be >= 1)")

    if backup_ctx and file_path.exists():
        backup_ctx.backup_file(file_path)

    try:
        lines = read_lines(file_path)

        if line_number > len(lines):
            logger.warning(
                f"Line {line_number} does not exist in {file_path} (only {len(lines)} lines)"
            )
            return False

        # Remove line (convert to 0-based index)
        lines.pop(line_number - 1)

        write_lines(file_path, lines)
        logger.info(f"Removed line {line_number} from {file_path}")
        return True

    except (FileNotFoundError, UnicodeDecodeError, OSError) as e:
        logger.error(f"Failed to remove line {line_number} from {file_path}: {e}")
        raise


def replace_line(
    file_path: Path, line_number: int, new_content: str, backup_ctx: BackupContext | None = None
) -> bool:
    """Replace a specific line in a file.

    Args:
        file_path: Path to file to modify
        line_number: Line number to replace (1-based)
        new_content: New content for the line (newline will be added if missing)
        backup_ctx: Optional backup context for rollback support

    Returns:
        True if line was replaced, False otherwise

    Raises:
        ValueError: If line_number is invalid
        OSError: If file operations fail
    """
    if line_number < 1:
        raise ValueError(f"Invalid line number: {line_number} (must be >= 1)")

    if backup_ctx and file_path.exists():
        backup_ctx.backup_file(file_path)

    try:
        lines = read_lines(file_path)

        if line_number > len(lines):
            logger.warning(
                f"Line {line_number} does not exist in {file_path} (only {len(lines)} lines)"
            )
            return False

        # Ensure newline at end
        if not new_content.endswith("\n"):
            new_content += "\n"

        # Replace line (convert to 0-based index)
        lines[line_number - 1] = new_content

        write_lines(file_path, lines)
        logger.info(f"Replaced line {line_number} in {file_path}")
        return True

    except (FileNotFoundError, UnicodeDecodeError, OSError) as e:
        logger.error(f"Failed to replace line {line_number} in {file_path}: {e}")
        raise


def insert_after_line(
    file_path: Path, line_number: int, content: str, backup_ctx: BackupContext | None = None
) -> bool:
    """Insert content after a specific line.

    Args:
        file_path: Path to file to modify
        line_number: Line number after which to insert (1-based, 0 = insert at start)
        content: Content to insert (newline will be added if missing)
        backup_ctx: Optional backup context for rollback support

    Returns:
        True if content was inserted, False otherwise

    Raises:
        ValueError: If line_number is invalid
        OSError: If file operations fail
    """
    if line_number < 0:
        raise ValueError(f"Invalid line number: {line_number} (must be >= 0)")

    if backup_ctx and file_path.exists():
        backup_ctx.backup_file(file_path)

    try:
        lines = read_lines(file_path) if file_path.exists() else []

        if line_number > len(lines):
            logger.warning(
                f"Line {line_number} does not exist in {file_path} (only {len(lines)} lines)"
            )
            return False

        # Ensure newline at end
        if not content.endswith("\n"):
            content += "\n"

        # Insert after line_number (convert to 0-based index)
        lines.insert(line_number, content)

        write_lines(file_path, lines)
        logger.info(f"Inserted content after line {line_number} in {file_path}")
        return True

    except (FileNotFoundError, UnicodeDecodeError, OSError) as e:
        logger.error(f"Failed to insert content after line {line_number} in {file_path}: {e}")
        raise


def get_line_content(file_path: Path, line_number: int) -> str | None:
    """Get content of a specific line.

    Args:
        file_path: Path to file
        line_number: Line number to retrieve (1-based)

    Returns:
        Line content (with newline) or None if line doesn't exist

    Raises:
        ValueError: If line_number is invalid
        OSError: If file operations fail
    """
    if line_number < 1:
        raise ValueError(f"Invalid line number: {line_number} (must be >= 1)")

    try:
        lines = read_lines(file_path)

        if line_number > len(lines):
            return None

        return lines[line_number - 1]

    except (FileNotFoundError, UnicodeDecodeError, OSError) as e:
        logger.error(f"Failed to read line {line_number} from {file_path}: {e}")
        raise
