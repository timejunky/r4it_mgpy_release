"""Backup and restore mechanism for QuickFix operations.

Provides two complementary safety layers:

* :class:`BackupContext` for fine-grained, per-file backups within a
    single QuickFix operation (used by individual transforms).
* Snapshot helpers (:func:`create_snapshot`, :func:`restore_snapshot`)
    for coarse-grained workspace-level backups as described in ADR-037.

The snapshot helpers persist a ZIP archive under ``.manifestguard/quickfix``
inside the project root so users (or tooling) can restore the complete
workspace state around QuickFix sessions.
"""

from __future__ import annotations

import os
import shutil
import tempfile
import zipfile
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any

_SNAPSHOT_PREFIX = "snapshot-"
_SNAPSHOT_EXT = ".zip"
_EXCLUDED_DIRS = {".git", ".venv", "venv", "__pycache__", ".pytest_cache", ".mypy_cache"}


@dataclass
class BackupEntry:
    """A single file backup entry."""

    original_path: Path
    backup_path: Path
    timestamp: datetime = field(default_factory=datetime.now)


@dataclass
class BackupContext:
    """Context for managing file backups during QuickFix operations."""

    backup_dir: Path
    entries: list[BackupEntry] = field(default_factory=list)

    @classmethod
    def create(cls, _project_root: Path) -> BackupContext:
        """Create a new backup context with temporary storage.

        Args:
            _project_root: Project root for naming the backup directory

        Returns:
            BackupContext instance with unique backup directory

        """
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_dir = Path(tempfile.mkdtemp(prefix=f"manifestguard_backup_{timestamp}_"))
        return cls(backup_dir=backup_dir)

    def backup_file(self, file_path: Path) -> BackupEntry:
        """Create backup of a file before modification.

        Args:
            file_path: Path to file to backup

        Returns:
            BackupEntry with backup location

        Raises:
            FileNotFoundError: If file doesn't exist
            IOError: If backup fails

        """
        if not file_path.exists():
            raise FileNotFoundError(f"Cannot backup non-existent file: {file_path}")

        # Create unique backup filename
        backup_name = f"{file_path.name}.{len(self.entries)}.bak"
        backup_path = self.backup_dir / backup_name

        # Copy file to backup location
        shutil.copy2(file_path, backup_path)

        entry = BackupEntry(
            original_path=file_path.resolve(),
            backup_path=backup_path,
        )
        self.entries.append(entry)
        return entry

    def restore_all(self) -> None:
        """Restore all backed-up files to their original locations.

        This is used when a QuickFix operation needs to be rolled back.
        """
        for entry in reversed(self.entries):
            if entry.backup_path.exists():
                shutil.copy2(entry.backup_path, entry.original_path)

    def cleanup(self) -> None:
        """Remove backup directory and all backup files.

        Call this after successful operations to clean up temporary backups.
        """
        if self.backup_dir.exists():
            shutil.rmtree(self.backup_dir)

    def __enter__(self) -> BackupContext:
        """Context manager entry."""
        return self

    def __exit__(
        self, exc_type: type[BaseException] | None, exc_val: BaseException | None, exc_tb: Any
    ) -> None:
        """Context manager exit - auto-cleanup on success."""
        if exc_type is None:
            # Success - cleanup backups
            self.cleanup()
        else:
            # Error - restore backups
            try:
                self.restore_all()
            finally:
                self.cleanup()


def _ensure_quickfix_dir(project_root: Path) -> Path:
    """Return the directory used to store QuickFix snapshots.

    The layout is ``<project_root>/.manifestguard/quickfix``. Directories
    are created if they do not yet exist.
    """

    quickfix_dir = Path(project_root) / ".manifestguard" / "quickfix"
    quickfix_dir.mkdir(parents=True, exist_ok=True)
    return quickfix_dir


def create_snapshot(project_root: Path) -> Path:
    """Create a workspace snapshot archive for the given project.

    The snapshot is a ZIP file stored under ``.manifestguard/quickfix``
    in the project root. It intentionally skips common virtual
    environment and cache directories (e.g. ``.venv``, ``.git``,
    ``__pycache__``).

    Args:
        project_root: Root directory of the project to snapshot.

    Returns:
        Path to the created snapshot file.
    """

    project_root = Path(project_root).resolve()
    if not project_root.exists():
        raise FileNotFoundError(f"Project root does not exist: {project_root}")

    quickfix_dir = _ensure_quickfix_dir(project_root)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    snapshot_name = f"{_SNAPSHOT_PREFIX}{timestamp}{_SNAPSHOT_EXT}"
    snapshot_path = quickfix_dir / snapshot_name

    with zipfile.ZipFile(snapshot_path, "w", zipfile.ZIP_DEFLATED) as zf:
        for root, dirs, files in os.walk(project_root):
            root_path = Path(root)
            rel_root = root_path.relative_to(project_root)

            # Skip excluded directories anywhere in the tree
            dirs[:] = [d for d in dirs if d not in _EXCLUDED_DIRS]

            # Also skip the quickfix snapshot directory itself to avoid
            # recursive growth if snapshots are taken multiple times.
            if (
                any(part == ".manifestguard" for part in rel_root.parts)
                and rel_root.parts[:2] == (".manifestguard", "quickfix")
            ):
                continue

            for file_name in files:
                file_path = root_path / file_name
                rel_path = file_path.relative_to(project_root)

                # Do not include existing snapshot archives
                if ".manifestguard" in rel_path.parts and "quickfix" in rel_path.parts:
                    continue

                zf.write(file_path, rel_path.as_posix())

    return snapshot_path


def restore_snapshot(snapshot_path: Path) -> Path:
    """Restore a workspace snapshot previously created with :func:`create_snapshot`.

    The project root is inferred from the snapshot location, assuming the
    standard layout ``<project_root>/.manifestguard/quickfix/<snapshot>.zip``.

    Args:
        snapshot_path: Path to the snapshot ZIP archive.

    Returns:
        The inferred project root path that was restored.
    """

    snapshot_path = Path(snapshot_path).resolve()
    if not snapshot_path.exists():
        raise FileNotFoundError(f"Snapshot file does not exist: {snapshot_path}")

    quickfix_dir = snapshot_path.parent
    # .../project_root/.manifestguard/quickfix/<snapshot>.zip
    project_root = quickfix_dir.parent.parent

    if not project_root.exists():
        raise FileNotFoundError(f"Inferred project root does not exist: {project_root}")

    with zipfile.ZipFile(snapshot_path, "r") as zf:
        zf.extractall(project_root)

    return project_root
