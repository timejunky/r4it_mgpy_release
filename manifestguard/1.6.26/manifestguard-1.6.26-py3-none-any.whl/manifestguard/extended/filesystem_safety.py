"""Filesystem safety utilities for secure file operations.

Provides protection against symlink/reparse-point traversal attacks
and enforces bounded scanning limits for DoS resilience.
"""

from __future__ import annotations

import fnmatch
import logging
import os
from pathlib import Path

logger = logging.getLogger(__name__)


# Common huge directories that should not be traversed during project scans.
# This is a performance/scope guardrail: callers can still explicitly point
# scans at these directories if they really want to.
_SKIP_DIR_NAMES = {
    ".git",
    ".hg",
    ".svn",
    ".cvs",
    "__pycache__",
    ".pytest_cache",
    ".mypy_cache",
    ".ruff_cache",
    ".tox",
    ".venv",
    "venv",
    "ENV",
    "env",
    "node_modules",
    "dist",
    "build",
    "out",
    "site-packages",
}


def is_safe_path(path: Path, root: Path) -> bool:
    """Check if path is safe to access: must be within root and not a symlink/reparse point.
    Returns False if path is outside root or is a symlink.
    """
    try:
        # Resolve to absolute path
        resolved = path.resolve()
        root_resolved = root.resolve()

        # Check containment
        if not str(resolved).startswith(str(root_resolved)):
            logger.warning(
                f"Path traversal detected: {path} resolves outside workspace root {root}",
            )
            return False

        # Check if it's a symlink (before resolving)
        if path.is_symlink():
            logger.warning(f"Symlink detected and skipped: {path}")
            return False

        return True
    except (OSError, RuntimeError) as e:
        logger.warning(f"Path safety check failed for {path}: {e}")
        return False


def _matches_glob(root: Path, pattern: str, file_path: Path) -> bool:
    # Support both file-name patterns ("*.py") and relative patterns
    # ("pkg/**/*.py") as best-effort.
    try:
        rel = file_path.relative_to(root).as_posix()
    except Exception:
        rel = file_path.as_posix()
    return fnmatch.fnmatch(rel, pattern) or fnmatch.fnmatch(file_path.name, pattern)


def _is_contained_fast(path: Path, root_resolved: Path) -> bool:
    try:
        return str(path.resolve()).startswith(str(root_resolved))
    except Exception:
        return True


def _is_dir_no_follow(entry: os.DirEntry) -> bool:
    try:
        return entry.is_dir(follow_symlinks=False)
    except OSError:
        return False


def _is_file_no_follow(entry: os.DirEntry) -> bool:
    try:
        return entry.is_file(follow_symlinks=False)
    except OSError:
        return False


def _is_symlink(entry: os.DirEntry) -> bool:
    try:
        return entry.is_symlink()
    except OSError:
        return True


def _iter_scandir(dir_path: Path):
    try:
        with os.scandir(dir_path) as it:
            yield from it
    except (OSError, RuntimeError) as e:
        logger.error(f"Error during safe rglob of {dir_path}: {e}")


def _safe_rglob_handle_entry(
    *,
    entry: os.DirEntry,
    root: Path,
    pattern: str,
    root_resolved: Path,
) -> tuple[Path | None, Path | None]:
    """Return (dir_to_push, file_to_add) for a scandir entry."""

    name = entry.name
    if name in _SKIP_DIR_NAMES and _is_dir_no_follow(entry):
        return (None, None)

    if _is_symlink(entry):
        return (None, None)

    full_path = Path(entry.path)
    if not _is_contained_fast(full_path, root_resolved):
        return (None, None)

    if _is_dir_no_follow(entry):
        return (full_path, None)

    if _is_file_no_follow(entry) and _matches_glob(root, pattern, full_path) and is_safe_path(full_path, root):
        return (None, full_path)

    return (None, None)


def safe_rglob(root: Path, pattern: str, *, max_files: int | None = None) -> list[Path]:
    """Safely walk directory tree, skipping symlinks and enforcing containment.

    This implementation intentionally prunes common huge directories (like
    `.venv/`, `node_modules/`, `.git/`) to avoid accidental whole-workspace scans
    becoming unbounded.

    Args:
        root: Root directory to search
        pattern: Glob pattern (e.g., "*.py")
        max_files: Optional limit on number of files returned

    Returns:
        List of safe paths matching pattern

    """
    results: list[Path] = []
    root = Path(root)

    try:
        root_resolved = root.resolve()
    except Exception:
        root_resolved = root

    stack: list[Path] = [root]
    while stack:
        if max_files and len(results) >= max_files:
            break

        dir_path = stack.pop()
        for entry in _iter_scandir(dir_path):
            if max_files and len(results) >= max_files:
                break

            dir_to_push, file_to_add = _safe_rglob_handle_entry(
                entry=entry,
                root=root,
                pattern=pattern,
                root_resolved=root_resolved,
            )

            if dir_to_push is not None:
                stack.append(dir_to_push)
                continue
            if file_to_add is not None:
                results.append(file_to_add)

    if max_files and len(results) >= max_files:
        msg = f"Reached file limit ({max_files}) during scan of {root}"
        # Small limits are commonly used for existence checks/heuristics and
        # should not look like user-facing problems in normal runs.
        if max_files <= 100:
            logger.debug(msg)
        else:
            logger.warning(msg)

    return results


def safe_read_file(path: Path, max_bytes: int = 10 * 1024 * 1024) -> str:
    """Safely read file content with size limit enforcement.

    Args:
        path: File to read
        max_bytes: Maximum file size in bytes (default: 10MB)

    Returns:
        File content as string

    Raises:
        ValueError: If file exceeds size limit

    """
    try:
        file_size = path.stat().st_size
        if file_size > max_bytes:
            raise ValueError(
                f"File {path} exceeds size limit ({file_size} > {max_bytes} bytes)",
            )
        return path.read_text(encoding="utf-8", errors="ignore")
    except OSError as e:
        logger.warning(f"Failed to read {path}: {e}")
        return ""
