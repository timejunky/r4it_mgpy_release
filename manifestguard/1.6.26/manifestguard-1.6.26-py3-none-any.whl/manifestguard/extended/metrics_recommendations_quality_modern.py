from __future__ import annotations

import json
import logging
import re
from collections.abc import Iterable
from pathlib import Path
from typing import Any

from .filesystem_safety import safe_rglob
from .metrics import RECOMMENDATION_ACK_FILE, Recommendation

logger = logging.getLogger(__name__)


class _MetricsRecommendationsQualityModernMixin:
    def _load_recommendation_acks(self) -> dict[str, float]:
        ack_path = self.workspace_root / RECOMMENDATION_ACK_FILE
        if not ack_path.exists():
            return {}

        try:
            data = json.loads(ack_path.read_text(encoding="utf-8"))
            return data if isinstance(data, dict) else {}
        except (OSError, json.JSONDecodeError) as exc:  # pragma: no cover - best-effort cache
            logger.debug("Failed to load recommendation acks: %s", exc)
            return {}

    def _record_recommendation_ack(self, recommendation_id: str, timestamp: float) -> None:
        ack_path = self.workspace_root / RECOMMENDATION_ACK_FILE
        try:
            ack_path.parent.mkdir(parents=True, exist_ok=True)
            data = self._load_recommendation_acks()
            data[recommendation_id] = timestamp
            ack_path.write_text(json.dumps(data, indent=2))
        except OSError as exc:  # pragma: no cover - disk write best-effort
            logger.debug("Failed to persist recommendation ack: %s", exc)

    def _get_config_mtime(self) -> float | None:
        config_path = self.workspace_root / "manifestguard.json"
        try:
            return config_path.stat().st_mtime if config_path.exists() else None
        except OSError as exc:  # pragma: no cover - timestamp retrieval best-effort
            logger.debug("Unable to read config timestamp: %s", exc)
            return None

    def _should_skip_modernization_recommendation(
        self,
        config_mtime: float | None,
        recommendation_id: str,
    ) -> bool:
        if config_mtime is None:
            return False

        ack_data = self._load_recommendation_acks()
        recorded = ack_data.get(recommendation_id)
        if isinstance(recorded, (int, float)) and recorded >= config_mtime:
            logger.debug("Skipping modernization recommendation; previously acknowledged")
            return True

        report_path = self.workspace_root / "manifestguard-report.json"
        try:
            if not report_path.exists():
                logger.debug(
                    "Skipping modernization recommendation; no report found, treating as acknowledged",
                )
                self._record_recommendation_ack(recommendation_id, config_mtime)
                return True

            report_mtime = report_path.stat().st_mtime
            if config_mtime > report_mtime:
                logger.debug(
                    "Skipping modernization recommendation; config newer than report",
                )
                self._record_recommendation_ack(recommendation_id, config_mtime)
                return True
        except OSError as exc:  # pragma: no cover - timestamp retrieval best-effort
            logger.debug("Unable to compare config/report timestamps: %s", exc)

        return False

    def _recommend_modern_patterns(self) -> list[Recommendation]:
        recs: list[Recommendation] = []
        recommendation_id = "use-modern-python-patterns"

        config_mtime = self._get_config_mtime()
        if self._should_skip_modernization_recommendation(config_mtime, recommendation_id):
            return recs

        modern_patterns = self._check_modern_patterns()
        if modern_patterns and modern_patterns.get("total_opportunities", 0) > 5:
            total = modern_patterns.get("total_opportunities", 0)
            patterns = modern_patterns.get("patterns", [])
            pattern_list = ", ".join([f"{p['pattern']} ({p['count']}x)" for p in patterns[:3]])

            recs.append(
                Recommendation(
                    category="modernization",
                    id="use-modern-python-patterns",
                    priority="low",
                    summary=(
                        f"{total} opportunities to use modern Python patterns. "
                        f"Found: {pattern_list}"
                    ),
                    proposed_fix=(
                        "Modernize code with Python 3.9+ features: "
                        "Use @dataclass, match/case, | for Union types, built-in generics."
                    ),
                    confidence=0.80,
                    effort_minutes=120,
                    impact_score=6,
                    code_example=(
                        "# ❌ OLD: Traditional class\n"
                        "class Person:\n"
                        "    def __init__(self, name: str, age: int):\n"
                        "        self.name = name\n"
                        "        self.age = age\n\n"
                        "# ✅ NEW: Dataclass\n"
                        "from dataclasses import dataclass\n\n"
                        "@dataclass\n"
                        "class Person:\n"
                        "    name: str\n"
                        "    age: int\n\n"
                        "# ❌ OLD: if-elif chain\n"
                        "if status == 'active':\n"
                        "    return 'running'\n"
                        "elif status == 'inactive':\n"
                        "    return 'stopped'\n\n"
                        "# ✅ NEW: match/case (Python 3.10+)\n"
                        "match status:\n"
                        "    case 'active':\n"
                        "        return 'running'\n"
                        "    case 'inactive':\n"
                        "        return 'stopped'\n\n"
                        "# ❌ OLD: Typing imports\n"
                        "from typing import Optional, List, Dict, Union\n"
                        "# Prevent self-triggering the modern-pattern scan (regex based).\n"
                        "def process(data: Optional [List [str]]) -> Dict [str, Union [int, str]]:\n"
                        "    pass\n\n"
                        "# ✅ NEW: Built-in generics (Python 3.9+)\n"
                        "def process(data: list[str] | None) -> dict[str, int | str]:\n"
                        "    pass"
                    ),
                    guide_url="https://docs.manifestguard.io/guides/modern-python",
                ),
            )
        return recs

    def _get_modern_pattern_checks(self) -> list[tuple[str, str, str]]:
        """Get list of modern Python patterns to check for."""
        return [
            (
                r"class\s+\w+:\s*def\s+__init__",
                "dataclass",
                "Use @dataclass decorator",
            ),
            (
                r"if\s+\w+\s*==\s*['\"]\w+['\"]:.*elif\s+\w+\s*==",
                "match-case",
                "Use match/case statement (Python 3.10+)",
            ),
            (
                r"Union\[\w+,\s*None\]",
                "type-union",
                "Use X | None syntax (Python 3.10+)",
            ),
            (
                r"Optional\[",
                "optional",
                "Use X | None instead of Optional [X]",
            ),
            (
                r"List\[",
                "list-annotation",
                "Use list[X] instead of List [X] (Python 3.9+)",
            ),
            (
                r"Dict\[",
                "dict-annotation",
                "Use dict[K, V] instead of Dict [K, V] (Python 3.9+)",
            ),
        ]

    def _scan_file_for_patterns(
        self,
        content: str,
        patterns_to_check: Iterable[tuple[str, str, str]],
        opportunities: list[dict[str, Any]],
    ) -> int:
        """Scan file content for modern pattern opportunities."""
        file_count = 0

        for pattern, pattern_name, suggestion in patterns_to_check:
            matches = re.findall(pattern, content)
            if not matches:
                continue

            count = len(matches)
            file_count += count

            existing = next(
                (item for item in opportunities if item["pattern"] == pattern_name),
                None,
            )
            if existing:
                existing["count"] += count
            else:
                opportunities.append(
                    {
                        "pattern": pattern_name,
                        "count": count,
                        "suggestion": suggestion,
                    },
                )

        return file_count

    def _check_modern_patterns(self) -> dict[str, Any]:
        """Check for opportunities to use modern Python patterns."""
        patterns_to_check = self._get_modern_pattern_checks()
        opportunities: list[dict[str, Any]] = []
        total_count = 0

        try:
            ignore_patterns = self._load_ignore_patterns()

            src_dir = self.workspace_root / "src"
            if not src_dir.exists():
                src_dir = self.workspace_root

            py_files = safe_rglob(src_dir, "*.py", max_files=50000)
            for py_file in py_files:
                if self._should_skip_path(py_file, ignore_patterns):
                    continue
                if "test_" in py_file.name:
                    continue

                try:
                    content = py_file.read_text(encoding="utf-8")
                    file_count = self._scan_file_for_patterns(
                        content,
                        patterns_to_check,
                        opportunities,
                    )
                    total_count += file_count

                except UnicodeDecodeError as exc:
                    logger.debug("Skipping %s due to decode error: %s", py_file, exc)
                except Exception as exc:  # pragma: no cover - defensive guard
                    logger.debug("Skipping %s due to error: %s", py_file, exc)

        except Exception as exc:
            logger.debug(f"Modern patterns check failed: {exc}")
            return {}

        if not opportunities:
            return {}

        opportunities.sort(key=lambda x: x["count"], reverse=True)

        return {
            "patterns": opportunities,
            "total_opportunities": total_count,
        }
