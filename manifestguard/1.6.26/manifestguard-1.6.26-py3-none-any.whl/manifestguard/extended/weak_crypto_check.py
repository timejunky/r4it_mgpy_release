"""Weak-cryptography detection used by quality recommendations."""

from __future__ import annotations

import logging
import re
from pathlib import Path
from typing import Any

from manifestguard.validation.inline_markers import is_line_suppressed

from .filesystem_safety import safe_rglob
from .scan_utils import load_ignore_patterns, should_skip_path

logger = logging.getLogger(__name__)


def _get_weak_crypto_patterns() -> list[tuple[str, str, str]]:
    return [
        (r"hashlib\.md5\s*\(", "MD5", "Use SHA-256 or SHA-512"),
        (r"hashlib\.sha1\s*\(", "SHA-1", "Use SHA-256 or SHA-512"),
        (r"Crypto\.Hash\.MD5", "MD5", "Use SHA-256 or SHA-512"),
        (r"Crypto\.Hash\.SHA1", "SHA-1", "Use SHA-256 or SHA-512"),
        (r"Crypto\.Cipher\.DES", "DES", "Use AES-256-GCM"),
        (r"Crypto\.Cipher\.DES3", "3DES", "Use AES-256-GCM"),
        (r"Crypto\.Cipher\.ARC4", "RC4", "Use AES-256-GCM"),
        (r"Crypto\.Cipher\.Blowfish", "Blowfish", "Use AES-256-GCM"),
    ]


def _scan_file_for_weak_crypto(
    py_file: Path,
    workspace_root: Path,
    weak_patterns: list[tuple[str, str, str]],
    weak_algorithms: list[dict[str, Any]],
    affected_files: set[str],
) -> int:
    file_occurrences = 0

    try:
        content = py_file.read_text(encoding="utf-8")

        for pattern, algo_name, recommendation in weak_patterns:
            compiled = re.compile(pattern)

            count = 0
            for idx, line in enumerate(content.splitlines(), start=1):
                if not compiled.search(line):
                    continue
                if is_line_suppressed(py_file, idx, "SECURITY") or is_line_suppressed(
                    py_file,
                    idx,
                    "SEC-WEAK-CRYPTO",
                ):
                    continue
                count += 1

            if not count:
                continue

            file_occurrences += count
            rel_path = str(py_file.relative_to(workspace_root))
            affected_files.add(rel_path)

            existing = next(
                (item for item in weak_algorithms if item["algorithm"] == algo_name),
                None,
            )
            if existing:
                existing["count"] += count
                if rel_path not in existing["files"]:
                    existing["files"].append(rel_path)
            else:
                weak_algorithms.append(
                    {
                        "algorithm": algo_name,
                        "count": count,
                        "recommendation": recommendation,
                        "files": [rel_path],
                    },
                )

    except UnicodeDecodeError as exc:
        logger.debug("Skipping %s due to decode error: %s", py_file, exc)
    except Exception as exc:  # pragma: no cover - defensive guard
        logger.debug("Skipping %s due to error: %s", py_file, exc)

    return file_occurrences


def check_weak_crypto(workspace_root: Path) -> dict:
    """Check for weak cryptographic algorithms (MD5, SHA1, DES) (best-effort)."""
    weak_patterns = _get_weak_crypto_patterns()
    weak_algorithms: list[dict[str, Any]] = []
    affected_files: set[str] = set()
    total_occurrences = 0

    try:
        ignore_patterns = load_ignore_patterns(workspace_root)

        src_dir = workspace_root / "src"
        if not src_dir.exists():
            src_dir = workspace_root

        py_files = safe_rglob(src_dir, "*.py", max_files=50000)
        for py_file in py_files:
            if should_skip_path(py_file, ignore_patterns, workspace_root):
                continue
            if "test_" in py_file.name:
                continue

            total_occurrences += _scan_file_for_weak_crypto(
                py_file,
                workspace_root,
                weak_patterns,
                weak_algorithms,
                affected_files,
            )

    except Exception as exc:
        logger.debug("Weak crypto check failed: %s", exc)
        return {}

    if not weak_algorithms:
        return {}

    weak_algorithms.sort(key=lambda x: x["count"], reverse=True)

    return {
        "weak_algorithms": weak_algorithms,
        "affected_files": list(affected_files)[:10],
        "total_occurrences": total_occurrences,
    }
