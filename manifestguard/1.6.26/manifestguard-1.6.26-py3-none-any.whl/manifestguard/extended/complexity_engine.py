from __future__ import annotations

import ast
import importlib.metadata as md
from dataclasses import dataclass


class _ComplexityVisitor(ast.NodeVisitor):
    """AST visitor for calculating McCabe cyclomatic complexity.

    Counts decision points in Python code according to the McCabe method:
    - Base complexity = 1 (one path through the code)
    - +1 for each branching point (if, while, for, except, etc.)
    - +1 for boolean operators (and/or) in conditions
    - +1 for comprehensions

    """

    def __init__(self) -> None:
        self.complexity = 1

    def visit_If(self, node: ast.If) -> None:
        """Count if/elif branches"""
        self.complexity += 1
        self.generic_visit(node)

    def visit_While(self, node: ast.While) -> None:
        """Count while loops"""
        self.complexity += 1
        self.generic_visit(node)

    def visit_For(self, node: ast.For) -> None:
        """Count for loops"""
        self.complexity += 1
        self.generic_visit(node)

    def visit_ExceptHandler(self, node: ast.ExceptHandler) -> None:
        """Count except clauses"""
        self.complexity += 1
        self.generic_visit(node)

    def visit_With(self, node: ast.With) -> None:
        """Count context manager entries (implicit exception handling)"""
        self.complexity += 1
        self.generic_visit(node)

    def visit_Assert(self, node: ast.Assert) -> None:
        """Count assertions (conditional branch)"""
        self.complexity += 1
        self.generic_visit(node)

    def visit_BoolOp(self, node: ast.BoolOp) -> None:
        """Count boolean operators (and/or)"""
        self.complexity += len(node.values) - 1
        self.generic_visit(node)

    def visit_ListComp(self, node: ast.ListComp) -> None:
        """Count list comprehensions"""
        self.complexity += len(node.generators)
        self.generic_visit(node)

    def visit_SetComp(self, node: ast.SetComp) -> None:
        """Count set comprehensions"""
        self.complexity += len(node.generators)
        self.generic_visit(node)

    def visit_DictComp(self, node: ast.DictComp) -> None:
        """Count dict comprehensions"""
        self.complexity += len(node.generators)
        self.generic_visit(node)

    def visit_GeneratorExp(self, node: ast.GeneratorExp) -> None:
        """Count generator expressions"""
        self.complexity += len(node.generators)
        self.generic_visit(node)


@dataclass
class _FunctionResult:
    """Internal structure matching radon result shape for compatibility"""

    name: str
    lineno: int
    complexity: int


def _complexity_rank(complexity: int) -> str:
    """Classify complexity score into letter grade (A-F)"""
    if complexity <= 5:
        return "A"
    if complexity <= 10:
        return "B"
    if complexity <= 20:
        return "C"
    if complexity <= 30:
        return "D"
    if complexity <= 40:
        return "E"
    return "F"


def _calculate_complexity(node: ast.FunctionDef | ast.AsyncFunctionDef) -> int:
    """Calculate McCabe complexity for a function/method node"""
    visitor = _ComplexityVisitor()
    visitor.visit(node)
    return visitor.complexity


def _extract_functions(tree: ast.AST) -> list[_FunctionResult]:
    """Extract all function/method definitions with complexity from AST"""
    results = []
    for node in ast.walk(tree):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            complexity = _calculate_complexity(node)
            results.append(
                _FunctionResult(
                    name=node.name,
                    lineno=node.lineno,
                    complexity=complexity,
                )
            )
    return results


def _extract_functions_radon(source: str) -> list[_FunctionResult]:
    """Extract functions/methods from Python source using radon (optional).

    Notes:
        - Kept as a best-effort compatibility path.
        - We only rely on fields used by mgpy telemetry: name, lineno, complexity.
    """
    try:
        from radon.complexity import cc_visit  # type: ignore[import-not-found]
    except Exception as exc:  # pragma: no cover - exercised via optional tests
        raise ImportError(
            "Radon is not installed. Install via 'manifestguard[radon]' or 'pip install radon'."
        ) from exc

    results: list[_FunctionResult] = []
    blocks = cc_visit(source)

    for block in blocks:
        name = getattr(block, "name", None)
        lineno = getattr(block, "lineno", None)
        complexity = getattr(block, "complexity", None)
        if not isinstance(name, str) or not name:
            continue
        if not isinstance(lineno, int) or lineno <= 0:
            continue
        if not isinstance(complexity, int) or complexity <= 0:
            continue
        results.append(_FunctionResult(name=name, lineno=lineno, complexity=complexity))

    return results


def _resolve_engine_version(engine: str) -> str | None:
    engine = (engine or "").strip().lower()
    if engine in {"mgpy", "mgpy-analyzer"}:
        return None
    if engine == "radon":
        try:
            return md.version("radon")
        except Exception:
            return None
    return None
