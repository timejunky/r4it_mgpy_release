"""Wheel-repo backfill for newly added/changed packages.

This module is best-effort by design.

Concept:
- When the GUI is configured with a *user-wide* wheel repository (e.g. F:\\r4it_py_stack\\wheels)
- and package delta capture is enabled
- we can auto-download missing wheels for the delta packages into the shared wheel repo.

The actual backfill is guarded by a one-time user consent stored in gui.json.
"""

from __future__ import annotations

import os
import subprocess
from pathlib import Path
from typing import Callable, Iterable


def _norm_name_for_wheel_prefix(name: str) -> str:
    # Wheel filenames use distribution with underscores.
    return (name or "").strip().lower().replace("-", "_").replace(".", "_")


def _iter_wheel_files(wheel_repo_dir: Path) -> Iterable[Path]:
    try:
        for p in wheel_repo_dir.iterdir():
            if p.is_file() and p.suffix.lower() == ".whl":
                yield p
    except Exception:
        return


def wheel_exists(*, wheel_repo_dir: Path, name: str, version: str) -> bool:
    """Return True if a wheel matching name+version exists in wheel_repo_dir."""
    try:
        wheel_repo_dir = Path(wheel_repo_dir).expanduser().resolve()
    except Exception:
        return False

    if not wheel_repo_dir.exists() or not wheel_repo_dir.is_dir():
        return False

    n = _norm_name_for_wheel_prefix(name)
    v = (version or "").strip()
    if not n or not v:
        return False

    # Common wheel prefix format: {dist}-{version}-...
    prefix = f"{n}-{v}-"

    for p in _iter_wheel_files(wheel_repo_dir):
        fn = p.name.lower()
        if fn.startswith(prefix):
            return True

    return False


def _extend_specs_from_entries(
    entries: object,
    *,
    version_key: str,
    out: list[tuple[str, str]],
) -> None:
    """Append valid (name, version) pairs from a list of dict entries.

    This helper keeps specs_from_delta small while preserving validation rules.
    """
    if not isinstance(entries, list):
        return

    for item in entries:
        if not isinstance(item, dict):
            continue
        name = item.get("name")
        version = item.get(version_key)
        if not (isinstance(name, str) and isinstance(version, str)):
            continue
        name = name.strip()
        version = version.strip()
        if not name or not version:
            continue
        out.append((name, version))


def specs_from_delta(delta: dict) -> list[tuple[str, str]]:
    """Extract (name, version) specs from a delta dict (added + changed->to)."""
    if not isinstance(delta, dict):
        return []

    out: list[tuple[str, str]] = []

    _extend_specs_from_entries(delta.get("added"), version_key="version", out=out)
    _extend_specs_from_entries(delta.get("changed"), version_key="to", out=out)

    # De-dup deterministically
    seen: set[tuple[str, str]] = set()
    dedup: list[tuple[str, str]] = []
    for spec in sorted(out, key=lambda t: (t[0].lower(), t[1])):
        if spec in seen:
            continue
        seen.add(spec)
        dedup.append(spec)

    return dedup


def _download_single_wheel(
    *,
    python_exe: Path,
    wheel_repo_dir: Path,
    name: str,
    version: str,
    env: dict,
    emit_msg: Callable[[str], None],
    timeout_seconds: int,
) -> bool:
    """Download one wheel via pip. Returns True if downloaded successfully."""
    spec = f"{name}=={version}"
    emit_msg(f"(backfill) pip download {spec}")

    cmd = [
        str(python_exe), "-m", "pip", "download",
        "--only-binary=:all:", "--no-deps",
        "--dest", str(wheel_repo_dir), spec,
    ]

    try:
        completed = subprocess.run(
            cmd, capture_output=True, text=True, encoding="utf-8",
            errors="replace", timeout=max(1, timeout_seconds), check=False, env=env,
        )
    except Exception as e:
        emit_msg(f"(backfill) Failed: {spec}: {e}")
        return False

    if completed.stdout:
        emit_msg(completed.stdout.strip())
    if completed.stderr:
        emit_msg(completed.stderr.strip())

    if completed.returncode != 0:
        emit_msg(f"(backfill) pip download failed (exit {completed.returncode}) for {spec}")
        return False

    # Treat as success even if name normalization differs in filename.
    return True


def backfill_missing_wheels(
    *,
    python_exe: Path,
    wheel_repo_dir: Path,
    delta: dict,
    emit: Callable[[str], None] | None = None,
    cancel_requested: Callable[[], bool] | None = None,
    timeout_seconds_per_package: int = 120,
) -> dict:
    """Download missing wheels for delta packages into wheel_repo_dir.

    Returns a small summary dict.
    """

    empty_summary = {"attempted": 0, "downloaded": 0, "skipped": 0, "failed": 0}
    emit_msg = emit if emit is not None else (lambda _msg: None)

    specs = specs_from_delta(delta)
    if not specs:
        return dict(empty_summary)

    try:
        wheel_repo_dir = Path(wheel_repo_dir).expanduser().resolve()
    except Exception:
        return dict(empty_summary)

    wheel_repo_dir.mkdir(parents=True, exist_ok=True)

    missing: list[tuple[str, str]] = []
    for name, version in specs:
        if wheel_exists(wheel_repo_dir=wheel_repo_dir, name=name, version=version):
            continue
        missing.append((name, version))

    if not missing:
        emit_msg(f"(backfill) Wheel repo already has all {len(specs)} delta package(s).")
        return {"attempted": len(specs), "downloaded": 0, "skipped": len(specs), "failed": 0}

    emit_msg(f"(backfill) Missing wheels: {len(missing)} / {len(specs)} (target: {wheel_repo_dir})")

    env = dict(os.environ)
    env.setdefault("PYTHONIOENCODING", "utf-8")

    downloaded = 0
    failed = 0
    skipped = len(specs) - len(missing)

    for name, version in missing:
        if cancel_requested is not None and bool(cancel_requested()):
            emit_msg("(backfill) Cancelled.")
            break

        success = _download_single_wheel(
            python_exe=python_exe,
            wheel_repo_dir=wheel_repo_dir,
            name=name,
            version=version,
            env=env,
            emit_msg=emit_msg,
            timeout_seconds=timeout_seconds_per_package,
        )
        if success:
            downloaded += 1
        else:
            failed += 1

    return {
        "attempted": len(specs),
        "downloaded": downloaded,
        "skipped": skipped,
        "failed": failed,
    }
