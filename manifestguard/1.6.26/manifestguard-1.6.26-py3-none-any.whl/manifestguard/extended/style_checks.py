"""Style-related checks used by quality recommendations."""

from __future__ import annotations

import logging
from pathlib import Path

from .filesystem_safety import safe_rglob
from .scan_utils import load_ignore_patterns, should_skip_path

logger = logging.getLogger(__name__)


def check_pep8_violations(workspace_root: Path) -> dict:
    """Check PEP8 violations using pycodestyle (best-effort)."""
    try:
        import pycodestyle  # noqa: PLC0415 - optional dependency
    except ImportError:  # pragma: no cover - optional dependency
        logger.debug("pycodestyle not installed, skipping PEP 8 check")
        return {}

    try:
        style_guide = pycodestyle.StyleGuide(quiet=True)
        result = style_guide.check_files([str(workspace_root)])

        violation_counts = dict(result.counters.items())

        top_types = sorted(
            [{"code": k, "count": v} for k, v in violation_counts.items()],
            key=lambda x: x["count"],
            reverse=True,
        )[:5]

        # Note: pycodestyle doesn't easily expose file lists without a custom reporter.
        return {
            "total_violations": result.total_errors,
            "top_violation_types": top_types,
            "files_with_violations": [],
        }

    except Exception as exc:
        logger.debug("PEP 8 check failed: %s", exc)
        return {}


def _analyze_quote_style(content: str) -> str:
    single_quotes = content.count("'")
    double_quotes = content.count('"')

    if single_quotes > double_quotes * 2:
        return "single"
    if double_quotes > single_quotes * 2:
        return "double"
    return "mixed"


def _analyze_indentation_style(content: str) -> str:
    lines = content.split("\n")
    for line in lines[:50]:
        if line.startswith("\t"):
            return "tabs"
        if line.startswith("    "):
            return "spaces"
    return "none"


def _collect_style_metrics(
    workspace_root: Path, ignore_patterns: set[str]
) -> tuple[int, int, int, int]:
    single_quote_files = 0
    double_quote_files = 0
    tab_files = 0
    space_files = 0

    src_dir = workspace_root / "src"
    search_root = src_dir if src_dir.exists() else workspace_root

    py_files = safe_rglob(search_root, "*.py", max_files=50000)
    for py_file in py_files:
        if should_skip_path(py_file, ignore_patterns, workspace_root) or py_file.name.startswith(
            "test_"
        ):
            continue

        try:
            content = py_file.read_text(encoding="utf-8")
        except UnicodeDecodeError as exc:
            logger.debug("Skipping %s due to decode error: %s", py_file, exc)
            continue
        except Exception as exc:  # pragma: no cover - defensive guard
            logger.debug("Skipping %s due to error: %s", py_file, exc)
            continue

        quote_style = _analyze_quote_style(content)
        single_quote_files += int(quote_style == "single")
        double_quote_files += int(quote_style == "double")

        indent_style = _analyze_indentation_style(content)
        tab_files += int(indent_style == "tabs")
        space_files += int(indent_style == "spaces")

    return single_quote_files, double_quote_files, tab_files, space_files


def check_style_consistency(workspace_root: Path) -> dict:
    """Check code style consistency (quotes, indentation)."""
    try:
        ignore_patterns = load_ignore_patterns(workspace_root)
        single_quote_files, double_quote_files, tab_files, space_files = _collect_style_metrics(
            workspace_root,
            ignore_patterns,
        )

        issue_types: list[str] = []
        affected_files: list[str] = []
        inconsistencies = 0

        if single_quote_files > 5 and double_quote_files > 5:
            inconsistencies += abs(single_quote_files - double_quote_files)
            issue_types.append("mixed quote styles")
            affected_files.append("Multiple files")

        if tab_files > 2 and space_files > 2:
            inconsistencies += abs(tab_files - space_files)
            issue_types.append("mixed indentation (tabs/spaces)")

        if inconsistencies == 0:
            return {}

        return {
            "inconsistencies": inconsistencies,
            "issue_types": issue_types,
            "affected_files": affected_files,
        }

    except Exception as exc:
        logger.debug("Style consistency check failed: %s", exc)
        return {}
