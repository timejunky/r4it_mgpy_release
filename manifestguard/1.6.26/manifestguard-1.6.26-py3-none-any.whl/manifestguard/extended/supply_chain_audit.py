"""Supply-chain security auditing utilities.

Provides automated auditing of wheel contents and dependency vulnerabilities.
"""

import json
import logging
import re
import subprocess
import sys
import zipfile
from pathlib import Path

logger = logging.getLogger(__name__)


def audit_wheel_contents(workspace_root: Path) -> tuple[int, list[str]]:
    """Audit dist/*.whl for unintended/suspicious packaged files.

    Returns:
        (issue_count, findings)

    """
    dist_dir = workspace_root / "dist"
    if not dist_dir.exists():
        return 0, []

    wheels = sorted(dist_dir.glob("*.whl"))
    if not wheels:
        return 0, []

    # Keep patterns aligned with ADR wheel-content audit quick checks.
    banned_patterns = [
        re.compile(r"(^|/)tests?/"),
        re.compile(r"(^|/)fixtures/"),
        re.compile(r"(^|/)\.manifestguard/"),
        re.compile(r"(^|/)(dogfooding-report\.json|coverage\.xml|coverage\.json)$"),
        re.compile(r"(^|/)\.env$"),
        re.compile(r"(^|/)(id_rsa|private_key)(\.|$)"),
    ]

    findings: list[str] = []
    issue_count = 0

    for wheel in wheels:
        try:
            with zipfile.ZipFile(wheel, "r") as zf:
                for name in zf.namelist():
                    normalized = name.replace("\\", "/")
                    if any(p.search(normalized) for p in banned_patterns):
                        issue_count += 1
                        if len(findings) < 25:
                            findings.append(f"{wheel.name}: {normalized}")
        except Exception as exc:  # pragma: no cover - best effort
            logger.debug("Wheel audit failed for %s: %s", wheel, exc)

    return issue_count, findings


def audit_supply_chain(workspace_root: Path) -> tuple[int, list[str]]:
    """Run pip-audit to check for known vulnerabilities in dependencies.

    Returns:
        (vulnerability_count, findings)

    """
    try:
        # Check if pip-audit is available
        check_result = subprocess.run(  # Controlled pip invocation  # noqa: S603
            [sys.executable, "-m", "pip", "show", "pip-audit"],
            capture_output=True,
            text=True,
            timeout=5,
            check=False,
        )

        if check_result.returncode != 0:
            logger.debug("pip-audit not installed; skipping supply-chain audit")
            return 0, []

        # Run pip-audit with JSON output
        audit_result = subprocess.run(  # Controlled pip_audit invocation  # noqa: S603
            [sys.executable, "-m", "pip_audit", "--format=json"],
            cwd=workspace_root,
            capture_output=True,
            text=True,
            timeout=60,
            check=False,
        )

        if audit_result.returncode != 0:
            # pip-audit exits with non-zero if vulnerabilities found
            logger.debug(f"pip-audit found issues (exit code {audit_result.returncode})")

        # Parse JSON output
        try:
            data = json.loads(audit_result.stdout)
            findings: list[str] = []
            vuln_count = 0

            # pip-audit JSON format: {"dependencies": [...]}
            for dep in data.get("dependencies", []):
                package_name = dep.get("name", "unknown")
                for vuln in dep.get("vulns", []):
                    vuln_count += 1
                    vuln_id = vuln.get("id", "UNKNOWN")
                    description = vuln.get("description", "")[:100]

                    if len(findings) < 25:
                        findings.append(f"{package_name}: {vuln_id} - {description}")

            return vuln_count, findings

        except json.JSONDecodeError:
            logger.warning("Failed to parse pip-audit JSON output")
            return 0, []

    except FileNotFoundError:
        logger.debug("pip-audit not found; skipping supply-chain audit")
        return 0, []
    except subprocess.TimeoutExpired:
        logger.warning("pip-audit timed out after 60s")
        return 0, []
    except Exception as exc:
        logger.debug(f"Supply-chain audit failed: {exc}")
        return 0, []
