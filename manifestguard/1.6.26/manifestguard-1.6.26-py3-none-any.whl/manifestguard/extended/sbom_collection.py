"""SBOM completeness collection used by extended metrics."""

from __future__ import annotations

import asyncio
import json
import logging
import subprocess
import sys
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .metrics import SBOMMetrics

logger = logging.getLogger(__name__)


def _collect_sbom_metrics_sync(
    workspace_root: Path,
    *,
    installed_packages: list[dict[str, str]] | None = None,
) -> SBOMMetrics:
    """Collect SBOM completeness data (best-effort)."""
    from .metrics import SBOMMetrics  # noqa: PLC0415 - avoid circular import

    metrics = SBOMMetrics()

    try:
        if installed_packages is not None:
            metrics.components_count = len(installed_packages)
        else:
            result = subprocess.run(  # Controlled pip invocation  # noqa: S603
                [sys.executable, "-m", "pip", "list", "--format=json"],
                check=False,
                cwd=workspace_root,
                capture_output=True,
                text=True,
                timeout=10,
            )
            if result.returncode == 0:
                packages = json.loads(result.stdout)
                if isinstance(packages, list):
                    metrics.components_count = len(packages)

        if metrics.missing_licenses == 0 and metrics.components_count > 0:
            metrics.spdx_compliance = True

    except Exception as exc:
        logger.debug("SBOM metrics collection failed: %s", exc)

    return metrics


async def collect_sbom_metrics(
    workspace_root: Path,
    *,
    installed_packages: list[dict[str, str]] | None = None,
) -> SBOMMetrics:
    """Collect SBOM completeness data (best-effort)."""
    return await asyncio.to_thread(
        _collect_sbom_metrics_sync,
        workspace_root,
        installed_packages=installed_packages,
    )
