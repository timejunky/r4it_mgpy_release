"""Venv package snapshot + delta storage.

This supports the GUI concept:
- capture a full package snapshot (requirements-style) per venv
- compute deltas between snapshots
- keep the history timeline lightweight by storing deltas only (optional)

Artifacts live under:
  <workspace>/.manifestguard/venv-packages/<venv_id>/

This module is best-effort by design: callers should treat failures as non-fatal.
"""

from __future__ import annotations

import hashlib
import json
import subprocess
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


@dataclass(frozen=True)
class VenvPackagesDelta:
    added: list[dict[str, str]]
    removed: list[dict[str, str]]
    changed: list[dict[str, str]]

    def to_dict(self) -> dict[str, Any]:
        return {
            "added": self.added,
            "removed": self.removed,
            "changed": self.changed,
            "counts": {
                "added": len(self.added),
                "removed": len(self.removed),
                "changed": len(self.changed),
            },
        }


def _utc_ts_compact() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z").replace(":", "").replace("-", "")


def _venv_id_from_path(venv_path: Path) -> str:
    # Stable, filesystem-safe id derived from absolute path.
    raw = str(venv_path.resolve()).encode("utf-8", errors="replace")
    return hashlib.sha256(raw).hexdigest()[:12]


def _normalize_pkg_name(name: str) -> str:
    # Normalize similar to PEP 503 (simple index): casefold and replace separators.
    return (name or "").strip().lower().replace("_", "-")


def get_venv_packages(
    python_exe: Path,
    *,
    timeout_seconds: int = 60,
) -> list[dict[str, str]]:
    """Return installed packages in a venv as a list of {name, version}.

    Uses `python -m pip list --format=json` for reliability.
    """
    cmd = [str(python_exe), "-m", "pip", "list", "--format=json"]
    completed = subprocess.run(
        cmd,
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
        timeout=max(1, int(timeout_seconds)),
        check=False,
    )
    if completed.returncode != 0:
        raise RuntimeError(
            f"pip list failed (exit {completed.returncode}): {completed.stdout.strip()} {completed.stderr.strip()}"
        )

    data = json.loads((completed.stdout or "").strip() or "[]")
    if not isinstance(data, list):
        raise ValueError("pip list returned non-list JSON")

    out: list[dict[str, str]] = []
    for item in data:
        if not isinstance(item, dict):
            continue
        name = item.get("name")
        version = item.get("version")
        if isinstance(name, str) and isinstance(version, str):
            out.append({"name": name, "version": version})
    return out


def _extract_package_name_and_version(pkg: object) -> tuple[str, str] | None:
    if not isinstance(pkg, dict):
        return None
    name = pkg.get("name")
    version = pkg.get("version")
    if not isinstance(name, str) or not isinstance(version, str):
        return None
    return name, version


def _build_package_maps(packages: list[dict[str, str]]) -> tuple[dict[str, str], dict[str, str]]:
    versions: dict[str, str] = {}
    name_casing: dict[str, str] = {}
    for pkg in packages:
        extracted = _extract_package_name_and_version(pkg)
        if extracted is None:
            continue
        name, version = extracted
        norm = _normalize_pkg_name(name)
        versions[norm] = version
        name_casing.setdefault(norm, name)
    return versions, name_casing


def _collect_added_and_changed_packages(
    prev_map: dict[str, str],
    cur_map: dict[str, str],
    name_casing: dict[str, str],
) -> tuple[list[dict[str, str]], list[dict[str, str]]]:
    added: list[dict[str, str]] = []
    changed: list[dict[str, str]] = []
    for norm, ver in sorted(cur_map.items()):
        if norm not in prev_map:
            added.append({"name": name_casing.get(norm, norm), "version": ver})
            continue
        prev_ver = prev_map[norm]
        if prev_ver != ver:
            changed.append({
                "name": name_casing.get(norm, norm),
                "from": prev_ver,
                "to": ver,
            })
    return added, changed


def _collect_removed_packages(prev_map: dict[str, str], cur_map: dict[str, str]) -> list[dict[str, str]]:
    removed: list[dict[str, str]] = []
    for norm, prev_ver in sorted(prev_map.items()):
        if norm not in cur_map:
            removed.append({"name": norm, "version": prev_ver})
    return removed


def compute_packages_delta(
    previous: list[dict[str, str]] | None,
    current: list[dict[str, str]] | None,
) -> VenvPackagesDelta:
    """Compute added/removed/changed between two package lists."""
    prev_list = previous or []
    cur_list = current or []

    prev_map, _ = _build_package_maps(prev_list)
    cur_map, name_casing = _build_package_maps(cur_list)
    added, changed = _collect_added_and_changed_packages(prev_map, cur_map, name_casing)
    removed = _collect_removed_packages(prev_map, cur_map)

    return VenvPackagesDelta(added=added, removed=removed, changed=changed)


def _render_requirements_lines(packages: list[dict[str, str]]) -> list[str]:
    lines: list[str] = []
    tmp: list[tuple[str, str]] = []
    for pkg in packages:
        if isinstance(pkg, dict):
            name = pkg.get("name")
            version = pkg.get("version")
            if isinstance(name, str) and isinstance(version, str):
                tmp.append((_normalize_pkg_name(name), version))
    for name, version in sorted(tmp):
        lines.append(f"{name}=={version}")
    return lines


def _load_prev_packages(latest_snapshot_path: Path) -> list[dict[str, str]] | None:
    """Load previous packages from the latest snapshot, or return None."""
    if not latest_snapshot_path.exists():
        return None
    try:
        prev_obj = json.loads(latest_snapshot_path.read_text(encoding="utf-8"))
        raw = prev_obj.get("packages") if isinstance(prev_obj, dict) else None
        return [p for p in raw if isinstance(p, dict)] if isinstance(raw, list) else None  # type: ignore[return-value]
    except Exception:
        return None


def _write_delta_files(
    delta: VenvPackagesDelta,
    deltas_dir: Path,
    delta_obj: dict,
    delta_path: Path,
    ts: str,
) -> tuple[Path, Path]:
    """Write delta JSON and requirements files; return (delta_req_path, removed_path)."""
    delta_path.write_text(json.dumps(delta_obj, indent=2, sort_keys=True), encoding="utf-8")

    delta_req_lines: list[str] = []
    for item in delta.added:
        delta_req_lines.append(f"{_normalize_pkg_name(item['name'])}=={item['version']}")
    for item in delta.changed:
        delta_req_lines.append(f"{_normalize_pkg_name(item['name'])}=={item['to']}")

    delta_req_path = deltas_dir / f"requirements.delta.{ts}.txt"
    removed_path = deltas_dir / f"requirements.removed.{ts}.txt"

    delta_req_path.write_text(
        "\n".join(sorted(set(delta_req_lines))) + ("\n" if delta_req_lines else ""),
        encoding="utf-8",
    )
    removed_lines = [item["name"] for item in delta.removed if isinstance(item.get("name"), str)]
    removed_path.write_text("\n".join(sorted(set(removed_lines))) + ("\n" if removed_lines else ""), encoding="utf-8")
    return delta_req_path, removed_path


def persist_venv_packages_snapshot(
    workspace_root: Path,
    *,
    venv_path: Path,
    packages: list[dict[str, str]],
    timestamp: str | None = None,
    write_full_snapshot: bool = True,
) -> dict[str, Any]:
    """Persist snapshot + delta artifacts under workspace_root.

    Returns metadata with file paths and delta summary.
    """
    ts = timestamp or _utc_ts_compact()
    venv_abs = venv_path.resolve()
    venv_id = _venv_id_from_path(venv_abs)

    base_dir = workspace_root / ".manifestguard" / "venv-packages" / venv_id
    snapshots_dir = base_dir / "snapshots"
    deltas_dir = base_dir / "deltas"

    snapshots_dir.mkdir(parents=True, exist_ok=True)
    deltas_dir.mkdir(parents=True, exist_ok=True)

    latest_snapshot_path = snapshots_dir / "latest.json"
    prev_packages = _load_prev_packages(latest_snapshot_path)
    delta = compute_packages_delta(prev_packages, packages)

    snapshot_obj = {
        "timestamp": ts,
        "venvPath": str(venv_abs),
        "packageCount": len(packages),
        "packages": packages,
    }
    delta_obj = {
        "timestamp": ts,
        "venvPath": str(venv_abs),
        "delta": delta.to_dict(),
    }

    snapshot_path = snapshots_dir / f"packages.{ts}.json"
    delta_path = deltas_dir / f"delta.{ts}.json"

    if write_full_snapshot:
        snapshot_path.write_text(json.dumps(snapshot_obj, indent=2, sort_keys=True), encoding="utf-8")
        latest_snapshot_path.write_text(json.dumps(snapshot_obj, indent=2, sort_keys=True), encoding="utf-8")
        req_lines = _render_requirements_lines(packages)
        req_content = "\n".join(req_lines) + ("\n" if req_lines else "")
        (snapshots_dir / f"requirements.{ts}.txt").write_text(req_content, encoding="utf-8")
        (snapshots_dir / "requirements.latest.txt").write_text(req_content, encoding="utf-8")

    delta_req_path, removed_path = _write_delta_files(delta, deltas_dir, delta_obj, delta_path, ts)

    meta = {
        "venvId": venv_id,
        "venvAbsolutePath": str(venv_abs),
        "timestamp": ts,
        "snapshotPath": str(snapshot_path) if write_full_snapshot else None,
        "deltaPath": str(delta_path),
        "deltaRequirementsPath": str(delta_req_path),
        "removedRequirementsPath": str(removed_path),
        "delta": delta.to_dict(),
    }

    (base_dir / "meta.json").write_text(json.dumps(meta, indent=2, sort_keys=True), encoding="utf-8")
    return meta
