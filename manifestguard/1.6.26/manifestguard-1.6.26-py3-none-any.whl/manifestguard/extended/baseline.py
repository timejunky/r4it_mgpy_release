"""Baseline Storage and Comparison - Trend Analysis Module

This module provides baseline management for tracking extended test metrics over time.
It enables regression detection, trend analysis, and historical comparison of quality metrics.

Key Features:
- Persistent baseline storage in `.manifestguard/baselines/` directory
- Multiple baseline support (e.g., 'latest', 'v1.0.0', 'main-branch')
- Automatic regression detection with severity levels
- Trend analysis across multiple baselines
- JSON-based storage format for human readability

Use Cases:
1. **CI/CD Integration**: Compare current metrics against production baseline
2. **Release Validation**: Ensure quality hasn't regressed before release
3. **Progress Tracking**: Monitor improvements over development cycles
4. **Team Dashboards**: Generate trend reports for quality metrics

Example Usage:
    # Save a baseline after CI run
    manager = BaselineManager(Path("/project"))
    manager.save_baseline(metrics, label="v1.2.0")

    # Compare current run to production baseline
    comparison = manager.compare_to_baseline(current_metrics, baseline_label="production")
    if comparison["regressions"]:
        print(f"⚠️ Found {len(comparison['regressions'])} regressions!")

    # Generate trend report for last 10 runs
    trends = manager.generate_trend_report(limit=10)
    print(f"Coverage trend: {trends['trends']['coverage']}")

Storage Format:
    Baselines are stored as JSON files in `.manifestguard/baselines/`:

    .manifestguard/
    └── baselines/
        ├── latest.json
        ├── v1.0.0.json
        ├── v1.1.0.json
        └── production.json

Privacy & Performance:
- All data stored locally, no external services
- JSON format allows easy inspection and version control
- Lightweight storage (~2-5KB per baseline)
"""

import json
import logging
from pathlib import Path
from typing import Any

from .metrics import ExtendedTestMetrics

logger = logging.getLogger(__name__)


class BaselineManager:
    """Manages baseline metrics storage, comparison, and trend analysis.

    The BaselineManager provides a complete solution for tracking quality metrics
    over time. It handles persistent storage, regression detection, and trend
    reporting for all Extended Test Mode metrics.

    Attributes:
        workspace_root (Path): Project root directory
        baseline_dir (Path): Directory where baselines are stored
                            (.manifestguard/baselines/)

    Storage Structure:
        Each baseline is stored as a JSON file containing:
        - label: Baseline identifier (e.g., "v1.0.0", "latest")
        - timestamp: ISO 8601 timestamp of baseline creation
        - metrics: Complete ExtendedTestMetrics dictionary

    Regression Detection:
        The manager automatically detects regressions using these thresholds:
        - Coverage: -5% change triggers "medium", -10% triggers "high"
        - Vulnerabilities: Any increase triggers "critical"
        - Unsafe patterns: Any increase triggers "high"

    Example:
        >>> manager = BaselineManager(Path("/project"))
        >>>
        >>> # Save current metrics
        >>> manager.save_baseline(metrics, label="v1.0.0")
        >>>
        >>> # Compare to previous version
        >>> comparison = manager.compare_to_baseline(new_metrics, "v1.0.0")
        >>> if comparison["regressions"]:
        ...     for reg in comparison["regressions"]:
        ...         print(f"Regression: {reg['metric']} - {reg['severity']}")

    """

    def __init__(self, workspace_root: Path):
        self.workspace_root = workspace_root
        self.baseline_dir = workspace_root / ".manifestguard" / "baselines"
        self.baseline_dir.mkdir(parents=True, exist_ok=True)

    def save_baseline(self, metrics: ExtendedTestMetrics, label: str = "latest") -> Path:
        """Persist metrics as a named baseline for future comparison.

        Saves the complete metrics object to a JSON file in the baselines directory.
        If a baseline with the same label exists, it will be overwritten.

        Args:
            metrics: Complete ExtendedTestMetrics object to save
            label: Baseline identifier (default: "latest")
                  Common patterns:
                  - "latest": Current main branch state
                  - "v1.0.0": Version tag baselines
                  - "production": Deployed version
                  - "main-branch": Branch-specific baselines

        Returns:
            Path: Absolute path to the saved baseline file

        Example:
            >>> metrics = await collector.collect_metrics()
            >>> baseline_path = manager.save_baseline(metrics, label="v1.2.0")
            >>> print(f"Saved to {baseline_path}")
            Saved to /project/.manifestguard/baselines/v1.2.0.json

        Note:
            - Creates `.manifestguard/baselines/` directory if it doesn't exist
            - Overwrites existing baselines with the same label
            - Uses JSON format with 2-space indentation for readability

        """
        baseline_file = self.baseline_dir / f"{label}.json"

        data = {
            "label": label,
            "timestamp": metrics.timestamp,
            "metrics": metrics.to_dict(),
        }

        baseline_file.write_text(json.dumps(data, indent=2))
        logger.info(f"Saved baseline '{label}' to {baseline_file}")

        return baseline_file

    def load_baseline(self, label: str = "latest") -> dict[str, Any] | None:
        """Load a previously saved baseline by its label.

        Reads the baseline JSON file and returns the stored metrics dictionary.
        Note: Currently returns the raw dict - full ExtendedTestMetrics reconstruction
        would require additional deserialization logic.

        Args:
            label: Baseline identifier to load (default: "latest")

        Returns:
            Dict containing metrics data if found, None if baseline doesn't exist
            or loading fails.

        Example:
            >>> baseline = manager.load_baseline("v1.0.0")
            >>> if baseline:
            ...     print(f"Coverage: {baseline['coverage']['unit_percent']}%")

        Note:
            - Returns None if baseline file doesn't exist (logs debug message)
            - Returns None on JSON parsing errors (logs error with exception)
            - Does not raise exceptions - safe to call without try/except

        """
        baseline_file = self.baseline_dir / f"{label}.json"

        if not baseline_file.exists():
            logger.debug(f"Baseline '{label}' not found")
            return None

        try:
            data = json.loads(baseline_file.read_text())
            # Reconstruct metrics from dict (simplified - full reconstruction would
            # require additional helper methods)
            return data.get("metrics")
        except Exception as e:
            logger.error(f"Failed to load baseline '{label}': {e}")
            return None

    def compare_to_baseline(
        self,
        current: ExtendedTestMetrics,
        baseline_label: str = "latest",
    ) -> dict[str, Any] | None:
        """Compare current metrics against a saved baseline to detect regressions.

        Performs a detailed comparison across key metrics and identifies both
        regressions (negative changes) and improvements (positive changes).

        Args:
            current: Current ExtendedTestMetrics to compare
            baseline_label: Label of baseline to compare against (default: "latest")

        Returns:
            Comparison dictionary with structure:
            {
                "baseline_label": str,           # Label of baseline used
                "baseline_timestamp": str,        # When baseline was created
                "current_timestamp": str,         # When current metrics collected
                "deltas": {                       # Numeric differences
                    "coverage_percent": float,    # Change in coverage
                    "vulnerable_dependencies": int,
                    "outdated_packages": int
                },
                "regressions": [                  # Negative changes
                    {
                        "metric": str,            # e.g., "coverage"
                        "baseline": float,        # Baseline value
                        "current": float,         # Current value
                        "delta": float,           # Difference
                        "severity": str           # "critical"|"high"|"medium"
                    }
                ],
                "improvements": [                 # Positive changes
                    {
                        "metric": str,
                        "baseline": float,
                        "current": float,
                        "delta": float
                    }
                ]
            }

            Returns None if baseline not found.

        Regression Thresholds:
            - Coverage: <-5% → medium, <-10% → high
            - Vulnerabilities: Any increase → critical
            - Unsafe patterns: Any increase → high

        Example:
            >>> comparison = manager.compare_to_baseline(current, "v1.0.0")
            >>> if comparison:
            ...     print(f"Regressions: {len(comparison['regressions'])}")
            ...     print(f"Coverage delta: {comparison['deltas']['coverage_percent']}%")
            ...     for reg in comparison['regressions']:
            ...         print(f"  {reg['metric']}: {reg['severity']} severity")

        """
        baseline_data = self.load_baseline(baseline_label)
        if not baseline_data:
            return None

        comparison: dict[str, Any] = {
            "baseline_label": baseline_label,
            "baseline_timestamp": baseline_data.get("timestamp"),
            "current_timestamp": current.timestamp,
            "deltas": {},
            "regressions": [],
            "improvements": [],
        }

        # Compare coverage
        baseline_cov = baseline_data.get("metrics", {}).get("coverage", {})
        current_cov = current.coverage

        if baseline_cov:
            cov_delta = current_cov.unit_percent - baseline_cov.get("unit_percent", 0)
            comparison["deltas"]["coverage_percent"] = round(cov_delta, 2)

            if cov_delta < -5.0:  # 5% regression threshold
                comparison["regressions"].append(
                    {
                        "metric": "coverage",
                        "baseline": baseline_cov.get("unit_percent"),
                        "current": current_cov.unit_percent,
                        "delta": cov_delta,
                        "severity": "high" if cov_delta < -10.0 else "medium",
                    },
                )
            elif cov_delta > 5.0:
                comparison["improvements"].append(
                    {
                        "metric": "coverage",
                        "baseline": baseline_cov.get("unit_percent"),
                        "current": current_cov.unit_percent,
                        "delta": cov_delta,
                    },
                )

        # Compare dependencies
        baseline_dep = baseline_data.get("metrics", {}).get("dependency", {})
        current_dep = current.dependency

        if baseline_dep:
            vuln_delta = current_dep.vulnerable_high - baseline_dep.get("vulnerable_high", 0)
            comparison["deltas"]["vulnerable_dependencies"] = vuln_delta

            if vuln_delta > 0:
                comparison["regressions"].append(
                    {
                        "metric": "vulnerable_dependencies",
                        "baseline": baseline_dep.get("vulnerable_high"),
                        "current": current_dep.vulnerable_high,
                        "delta": vuln_delta,
                        "severity": "critical",
                    },
                )

            outdated_delta = current_dep.outdated_count - baseline_dep.get("outdated_count", 0)
            comparison["deltas"]["outdated_packages"] = outdated_delta

        # Compare security
        baseline_sec = baseline_data.get("metrics", {}).get("security", {})
        current_sec = current.security

        if baseline_sec:
            exec_delta = current_sec.unsafe_exec_count - baseline_sec.get("unsafe_exec_count", 0)
            if exec_delta > 0:
                comparison["regressions"].append(
                    {
                        "metric": "unsafe_exec",
                        "baseline": baseline_sec.get("unsafe_exec_count"),
                        "current": current_sec.unsafe_exec_count,
                        "delta": exec_delta,
                        "severity": "high",
                    },
                )

        return comparison

    def list_baselines(self) -> list[dict[str, str]]:
        """Retrieve metadata for all available baselines, sorted by timestamp.

        Scans the baselines directory and returns information about each baseline
        without loading the full metrics data. Useful for UI displays and
        baseline selection.

        Returns:
            List of baseline metadata dictionaries, sorted newest first:
            [
                {
                    "label": str,      # Baseline identifier
                    "timestamp": str,  # ISO 8601 timestamp
                    "file": str        # Absolute path to baseline file
                },
                ...
            ]

            Returns empty list if no baselines exist.

        Example:
            >>> baselines = manager.list_baselines()
            >>> for baseline in baselines:
            ...     print(f"{baseline['label']}: {baseline['timestamp']}")
            v1.2.0: 2024-01-15T10:30:00
            v1.1.0: 2024-01-10T14:20:00
            v1.0.0: 2024-01-01T09:00:00

        Note:
            - Skips baselines with corrupt JSON (logs warning)
            - Sorted by timestamp descending (newest first)
            - Safe to call even if baselines directory is empty

        """
        baselines = []

        for baseline_file in self.baseline_dir.glob("*.json"):
            try:
                data = json.loads(baseline_file.read_text())
                baselines.append(
                    {
                        "label": data.get("label", baseline_file.stem),
                        "timestamp": data.get("timestamp"),
                        "file": str(baseline_file),
                    },
                )
            except Exception as e:
                logger.warning(f"Failed to read baseline {baseline_file}: {e}")

        return sorted(baselines, key=lambda x: x.get("timestamp", ""), reverse=True)

    def generate_trend_report(self, limit: int = 10) -> dict[str, Any]:
        """Generate a trend analysis report from recent baselines.

        Analyzes multiple baselines to identify trends in key metrics over time.
        Useful for dashboard visualizations and progress tracking.

        Args:
            limit: Maximum number of recent baselines to analyze (default: 10)

        Returns:
            Trend report dictionary with structure:
            {
                "baselines_count": int,           # Number of baselines analyzed
                "period": {
                    "from": str,                  # Oldest timestamp
                    "to": str                     # Newest timestamp
                },
                "trends": {
                    "coverage": [                 # List of data points
                        {
                            "timestamp": str,
                            "value": float
                        },
                        ...
                    ],
                    "vulnerabilities": [...],
                    "outdated_packages": [...],
                    "unsafe_patterns": [...]
                }
            }

            Returns {"baselines_count": 0, "trends": {}} if no baselines exist.

        Example:
            >>> trends = manager.generate_trend_report(limit=5)
            >>> coverage_trend = trends["trends"]["coverage"]
            >>>
            >>> # Calculate coverage improvement
            >>> if len(coverage_trend) >= 2:
            ...     start = coverage_trend[-1]["value"]
            ...     end = coverage_trend[0]["value"]
            ...     improvement = end - start
            ...     print(f"Coverage improved by {improvement:.1f}%")
            Coverage improved by 12.3%

        Use Cases:
            - CI/CD dashboard trend charts
            - Monthly/quarterly quality reports
            - Detecting long-term quality erosion
            - Validating quality improvement initiatives

        Note:
            - Trends are ordered newest to oldest
            - Skips baselines with missing or corrupt data
            - Returns empty trends if fewer than 2 baselines exist

        """
        baselines = self.list_baselines()[:limit]

        if not baselines:
            return {"baselines_count": 0, "trends": {}}

        trends: dict[str, list] = {
            "coverage": [],
            "vulnerabilities": [],
            "outdated_packages": [],
            "unsafe_patterns": [],
        }

        for baseline_info in baselines:
            try:
                data = json.loads(Path(baseline_info["file"]).read_text())
                metrics = data.get("metrics", {}).get("metrics", {})

                trends["coverage"].append(
                    {
                        "timestamp": baseline_info["timestamp"],
                        "value": metrics.get("coverage", {}).get("unit_percent", 0),
                    },
                )

                trends["vulnerabilities"].append(
                    {
                        "timestamp": baseline_info["timestamp"],
                        "value": metrics.get("dependency", {}).get("vulnerable_high", 0),
                    },
                )

                trends["outdated_packages"].append(
                    {
                        "timestamp": baseline_info["timestamp"],
                        "value": metrics.get("dependency", {}).get("outdated_count", 0),
                    },
                )

                trends["unsafe_patterns"].append(
                    {
                        "timestamp": baseline_info["timestamp"],
                        "value": metrics.get("security", {}).get("unsafe_exec_count", 0),
                    },
                )

            except Exception as e:
                logger.warning(f"Failed to process baseline for trends: {e}")

        return {
            "baselines_count": len(baselines),
            "period": {
                "from": baselines[-1]["timestamp"] if baselines else None,
                "to": baselines[0]["timestamp"] if baselines else None,
            },
            "trends": trends,
        }
