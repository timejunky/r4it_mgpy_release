from __future__ import annotations

from dataclasses import dataclass, field


# Report-only exclusions (do not include in complexity/LOC metrics; do not repair).
# These are intentionally narrow, exact paths relative to the workspace root.
_COMPLEXITY_LOC_REPORT_ONLY_EXEMPTIONS: list[tuple[str, str]] = [
    (
        "examples/run_manifestguard.py",
        "Reported but do not repair (bootstrap/example script).",
    ),
]


def _normalize_relpath(value: str) -> str:
    return str(value or "").replace("\\\\", "/").strip().lower()


@dataclass
class ComplexityViolation:
    """Represents a function that exceeds complexity threshold.

    Attributes:
        file_path: Relative path to the file containing the function
        function_name: Name of the function or method
        line_number: Line number where function is defined
        complexity: Cyclomatic complexity score
        rank: Letter grade (A-F)
        threshold: Configured threshold that was exceeded

    """

    file_path: str
    function_name: str
    line_number: int
    complexity: int
    rank: str
    threshold: int


@dataclass
class OversizedFile:
    """Represents an oversized source file (LOC-based maintainability risk)."""

    file_path: str
    line_count: int
    threshold: int


@dataclass
class ToolConfigStatus:
    """Status of tool configuration validation.

    Attributes:
        found: Whether tool configuration was found
        valid: Whether configuration is valid
        errors: List of configuration errors (if any)
        configured_threshold: Threshold from tool config (if found)
    """

    found: bool
    valid: bool
    errors: list[str] = field(default_factory=list)
    configured_threshold: int | None = None


@dataclass
class ComplexityMetrics:
    """Aggregate complexity metrics for the codebase.

    Attributes:
        violations: List of functions exceeding threshold
        total_functions: Total number of functions analyzed
        average_complexity: Mean complexity across all functions
        max_complexity: Highest complexity found
        files_scanned: Number of Python files analyzed
        threshold: Complexity threshold used for violations
        tool_config_status: Status of tool configuration validation

    """

    violations: list[ComplexityViolation] = field(default_factory=list)
    total_functions: int = 0
    average_complexity: float = 0.0
    max_complexity: int = 0
    files_scanned: int = 0
    threshold: int = 10
    engine: str = "mgpy-analyzer"
    engine_version: str | None = None
    tool_config_status: ToolConfigStatus | None = None

    # File-level maintainability signals (kept separate from function-level complexity)
    max_file_lines_threshold: int | None = None
    max_file_lines_observed: int = 0
    oversized_files: list[OversizedFile] = field(default_factory=list)

    @property
    def violations_count(self) -> int:
        """Convenience property for number of violations"""
        return len(self.violations)

    @property
    def oversized_files_count(self) -> int:
        return len(self.oversized_files)
