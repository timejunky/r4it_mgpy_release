"""Type-hint coverage analysis for extended metrics."""

from __future__ import annotations

import ast
import logging
from pathlib import Path

from .filesystem_safety import safe_rglob
from .scan_utils import load_ignore_patterns, should_skip_path

logger = logging.getLogger(__name__)


def _function_is_typed(node: ast.FunctionDef) -> bool:
    has_return_type = node.returns is not None
    has_arg_types = all(arg.annotation is not None for arg in node.args.args if arg.arg != "self")
    return has_return_type and has_arg_types


def _analyze_file_type_hints(py_file: Path) -> tuple[int, int, float]:
    try:
        content = py_file.read_text(encoding="utf-8")
        tree = ast.parse(content, filename=str(py_file))

        file_total = 0
        file_typed = 0

        for node in ast.walk(tree):
            if isinstance(node, ast.FunctionDef):
                file_total += 1
                if _function_is_typed(node):
                    file_typed += 1

        if file_total > 0:
            file_coverage = (file_typed / file_total) * 100
            return file_total, file_typed, file_coverage

    except (SyntaxError, UnicodeDecodeError):
        pass

    return 0, 0, 0.0


def analyze_type_hints(workspace_root: Path) -> dict:
    """Analyze type hint coverage using AST parsing."""
    total_funcs = 0
    typed_funcs = 0
    files_with_low_coverage: list[str] = []

    try:
        ignore_patterns = load_ignore_patterns(workspace_root)

        src_dir = workspace_root / "src"
        if not src_dir.exists():
            src_dir = workspace_root

        py_files = safe_rglob(src_dir, "*.py", max_files=50000)
        for py_file in py_files:
            if should_skip_path(py_file, ignore_patterns, workspace_root):
                continue
            if "test_" in py_file.name:
                continue

            file_total, file_typed, file_coverage = _analyze_file_type_hints(py_file)

            if file_total > 0:
                total_funcs += file_total
                typed_funcs += file_typed

                if file_coverage < 60:
                    rel_path = py_file.relative_to(workspace_root)
                    files_with_low_coverage.append(str(rel_path))

    except Exception as exc:
        logger.debug("Type hints analysis failed: %s", exc)
        return {}

    if total_funcs == 0:
        return {}

    coverage_percent = (typed_funcs / total_funcs) * 100

    return {
        "total_functions": total_funcs,
        "typed_functions": typed_funcs,
        "coverage_percent": round(coverage_percent, 1),
        "files_with_low_coverage": files_with_low_coverage,
    }
