from __future__ import annotations

import datetime as _dt
import fnmatch
import json
from pathlib import Path
from typing import Any

from .dummy_recognition_models import DummyCodeFinding


def _parse_expiry_date(value: object) -> _dt.date | None:  # noqa: PLR0911
    if value is None:
        return None
    if isinstance(value, _dt.datetime):
        return value.date()
    if isinstance(value, _dt.date):
        return value
    if not isinstance(value, str):
        return None

    s = value.strip()
    if len(s) < 10:
        return None
    prefix = s[:10]
    try:
        return _dt.date.fromisoformat(prefix)
    except Exception:
        return None


def _normalize_for_match(path: str, workspace_root: Path | None) -> str:
    p = Path(path)
    try:
        if workspace_root is not None:
            p = Path(path).resolve().relative_to(workspace_root.resolve())
    except Exception:
        p = Path(path)

    return str(p).replace("\\", "/").lstrip("./").lower()


def _as_codes(value: object) -> set[str] | None:
    if value is None:
        return None
    if isinstance(value, str):
        v = value.strip()
        return {v} if v else None
    if isinstance(value, list):
        codes: set[str] = set()
        for item in value:
            if isinstance(item, str) and item.strip():
                codes.add(item.strip())
        return codes or None
    return None


# Intentionally complex for backward-compatible suppression loading with multiple config locations
# manifestguard-ignore-next-line: COMPLEXITY
def load_dummy_recognition_suppressions_from_manifestguard_json(
    workspace_root: Path,
) -> list[dict[str, Any]]:
    """Load dummy recognition suppressions from manifestguard.json."""
    config_path = workspace_root / "manifestguard.json"
    if not config_path.exists():
        return []

    try:
        data = json.loads(config_path.read_text(encoding="utf-8"))
    except Exception:
        return []

    if not isinstance(data, dict):
        return []

    dummy_cfg = data.get("dummyRecognition")
    if isinstance(dummy_cfg, dict):
        suppressions = dummy_cfg.get("suppressions")
        if isinstance(suppressions, list):
            return [s for s in suppressions if isinstance(s, dict)]

    suppressions = data.get("dummyRecognitionSuppressions")
    if isinstance(suppressions, list):
        return [s for s in suppressions if isinstance(s, dict)]

    return []


# Intentionally complex for flexible suppression rule matching with multiple formats and expiry handling
# manifestguard-ignore-next-line: COMPLEXITY
def apply_dummy_recognition_suppressions(
    findings: list[DummyCodeFinding],
    suppressions: list[dict[str, Any]] | None,
    *,
    workspace_root: Path | None = None,
    now: _dt.date | _dt.datetime | None = None,
) -> tuple[list[DummyCodeFinding], int]:
    """Filter findings according to suppression rules."""
    if not suppressions:
        return findings, 0

    today = (now.date() if isinstance(now, _dt.datetime) else now) or _dt.date.today()
    normalized_cache: dict[str, str] = {}

    def _rule_pattern(rule: dict[str, Any]) -> str | None:
        pattern = rule.get("filePattern")
        if not isinstance(pattern, str) or not pattern.strip():
            pattern = rule.get("pattern")
        if not isinstance(pattern, str) or not pattern.strip():
            return None
        return pattern.strip().lower()

    def _rule_has_reason(rule: dict[str, Any]) -> bool:
        reason = rule.get("reason")
        return isinstance(reason, str) and bool(reason.strip())

    def _rule_is_expired(rule: dict[str, Any]) -> bool:
        expiry = _parse_expiry_date(rule.get("expires"))
        return expiry is not None and expiry < today

    def _rule_codes(rule: dict[str, Any]) -> set[str] | None:
        return _as_codes(rule.get("codes"))

    def _rule_matches(rule: dict[str, Any], normalized_path: str, code: str) -> bool:
        if not _rule_has_reason(rule):
            return False
        if _rule_is_expired(rule):
            return False
        pattern = _rule_pattern(rule)
        if pattern is None:
            return False
        codes = _rule_codes(rule)
        if not codes:
            return False
        if code not in codes and "*" not in codes:
            return False
        return fnmatch.fnmatchcase(normalized_path, pattern)

    suppressed = 0
    kept: list[DummyCodeFinding] = []

    for finding in findings:
        normalized_path = normalized_cache.get(finding.file)
        if normalized_path is None:
            normalized_path = _normalize_for_match(finding.file, workspace_root)
            normalized_cache[finding.file] = normalized_path

        if any(_rule_matches(rule, normalized_path, finding.code) for rule in suppressions):
            suppressed += 1
        else:
            kept.append(finding)

    return kept, suppressed
