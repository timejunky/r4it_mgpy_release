from __future__ import annotations

import ast
import logging
from pathlib import Path
from typing import Any

from .complexity_engine import (
    _complexity_rank,
    _extract_functions,
    _extract_functions_radon,
    _resolve_engine_version,
)
from .complexity_models import (
    _COMPLEXITY_LOC_REPORT_ONLY_EXEMPTIONS,
    _normalize_relpath,
    ComplexityMetrics,
    ComplexityViolation,
    OversizedFile,
    ToolConfigStatus,
)

logger = logging.getLogger(__name__)


_IGNORED_COMPLEXITY_DIRS = {
    ".git",
    ".hg",
    ".svn",
    ".tox",
    ".venv",
    "venv",
    "env",
    "__pycache__",
    ".pytest_cache",
    ".mypy_cache",
    ".ruff_cache",
    ".cache",
    "node_modules",
    "dist",
    "build",
    ".eggs",
    ".manifestguard",
    ".mgvs",
}


class ComplexityAnalyzer:
    """Analyzes cyclomatic complexity of Python code using AST.

    The analyzer scans all Python files in the workspace and identifies
    functions/methods that exceed the configured complexity threshold.

    Example:
        >>> analyzer = ComplexityAnalyzer(Path("/project"))
        >>> result = analyzer.analyze(threshold=10)
        >>> for violation in result.violations:
        ...     print(f"{violation.function_name}: {violation.complexity}")

    """

    def __init__(self, workspace_root: Path):
        """Initialize the complexity analyzer.

        Args:
            workspace_root: Root directory of the project to analyze

        """
        self.workspace_root = workspace_root
        self._ignore = None
        try:
            from manifestguard.core.ignore_patterns import IgnorePatterns

            ignore = IgnorePatterns(workspace_root)
            ignore.load()
            self._ignore = ignore
        except Exception:
            self._ignore = None

    def analyze(
        self,
        threshold: int = 10,
        include_tests: bool = False,
        min_rank: str = "A",
        engine: str = "mgpy-analyzer",
        validate_config: bool = True,
        max_file_lines: int | None = None,
    ) -> ComplexityMetrics:
        """Analyze cyclomatic complexity of Python files.

        Args:
            threshold: Complexity score above which to report violations (default: 10)
            include_tests: Whether to analyze test files (default: False)
            min_rank: Minimum rank to report (A-F, default: A)
            engine: Complexity engine to use ("mgpy-analyzer" or "radon")
            validate_config: Whether to validate tool configuration (default: True)

        Returns:
            ComplexityMetrics with violations and aggregate statistics

        Note:
            - Analysis is performed locally using Python AST, no external dependencies
            - The analyzer reports only functions with complexity > threshold
            - Implements McCabe cyclomatic complexity algorithm

        """
        tool_config_status = None
        if validate_config:
            tool_config_status = self._validate_tool_config(engine)
            if tool_config_status and not tool_config_status.valid:
                logger.warning(
                    f"Tool configuration issues detected: {', '.join(tool_config_status.errors)}"
                )

        min_rank = (min_rank or "A").strip().upper()
        valid_ranks = {"A", "B", "C", "D", "E", "F"}
        if min_rank not in valid_ranks:
            logger.debug(f"Invalid min_rank '{min_rank}', defaulting to 'A'")
            min_rank = "A"

        engine = (engine or "mgpy-analyzer").strip().lower()
        if engine == "mgpy":
            engine = "mgpy-analyzer"
        if engine not in {"mgpy-analyzer", "radon"}:
            logger.debug(f"Invalid complexity engine '{engine}', defaulting to 'mgpy-analyzer'")
            engine = "mgpy-analyzer"

        stats = self._scan_directories(threshold, include_tests, min_rank, engine, max_file_lines)

        logger.info(
            f"Complexity analysis: {len(stats['violations'])} violations "
            f"(threshold: {threshold}, files: {stats['files_scanned']})",
        )

        return ComplexityMetrics(
            violations=stats["violations"],
            total_functions=stats["total_functions"],
            average_complexity=stats["avg_complexity"],
            max_complexity=stats["max_complexity"],
            files_scanned=stats["files_scanned"],
            threshold=threshold,
            engine=engine,
            engine_version=_resolve_engine_version(engine),
            tool_config_status=tool_config_status,
            max_file_lines_threshold=max_file_lines,
            max_file_lines_observed=stats.get("max_file_lines_observed", 0),
            oversized_files=stats.get("oversized_files", []),
        )

    def _validate_tool_config(self, engine: str) -> ToolConfigStatus:
        """Validate tool configuration before running complexity analysis.

        Args:
            engine: Complexity engine being used ("mgpy-analyzer" or "radon")

        Returns:
            ToolConfigStatus with validation results
        """
        if engine == "mgpy-analyzer":
            return ToolConfigStatus(found=True, valid=True, errors=[])

        if engine == "radon":
            return self._validate_radon_config()

        return ToolConfigStatus(
            found=False,
            valid=False,
            errors=[f"Unknown complexity engine: {engine}"],
        )

    def _validate_radon_pyproject(self) -> ToolConfigStatus | None:
        """Try to read Radon config from pyproject.toml. Returns None if file missing."""
        pyproject_path = self.workspace_root / "pyproject.toml"
        if not pyproject_path.exists():
            return None
        try:
            import tomllib  # Python 3.11+
        except ImportError:
            try:
                import tomli as tomllib  # type: ignore[import-not-found]
            except ImportError:
                return ToolConfigStatus(
                    found=False, valid=False,
                    errors=["Cannot validate pyproject.toml: tomllib/tomli not available"],
                    configured_threshold=None,
                )
        try:
            with pyproject_path.open("rb") as f:
                data = tomllib.load(f)
            radon_config = data.get("tool", {}).get("radon", {})
            if not radon_config:
                return None
            errors: list[str] = []
            configured_threshold = None
            cc_config = radon_config.get("cc", {})
            if "max_complexity" in cc_config:
                configured_threshold = cc_config["max_complexity"]
                if not isinstance(configured_threshold, int) or configured_threshold < 1:
                    errors.append(f"Invalid max_complexity in pyproject.toml: {configured_threshold}")
            return ToolConfigStatus(found=True, valid=not errors, errors=errors, configured_threshold=configured_threshold)
        except Exception as e:
            return ToolConfigStatus(found=False, valid=False, errors=[f"Error parsing pyproject.toml: {e}"], configured_threshold=None)

    def _validate_radon_cfg(self) -> ToolConfigStatus | None:
        """Try to read Radon config from .radon.cfg. Returns None if file missing."""
        radon_cfg_path = self.workspace_root / ".radon.cfg"
        if not radon_cfg_path.exists():
            return None
        try:
            import configparser
            config = configparser.ConfigParser()
            config.read(radon_cfg_path)
            errors: list[str] = []
            configured_threshold = None
            if "cc" in config and "max_complexity" in config["cc"]:
                configured_threshold = int(config["cc"]["max_complexity"])
                if configured_threshold < 1:
                    errors.append(f"Invalid max_complexity in .radon.cfg: {configured_threshold}")
            return ToolConfigStatus(found=True, valid=not errors, errors=errors, configured_threshold=configured_threshold)
        except Exception as e:
            return ToolConfigStatus(found=False, valid=False, errors=[f"Error parsing .radon.cfg: {e}"], configured_threshold=None)

    def _validate_radon_config(self) -> ToolConfigStatus:
        """Validate Radon configuration in pyproject.toml or .radon.cfg."""
        result = self._validate_radon_pyproject()
        if result is not None:
            return result
        result = self._validate_radon_cfg()
        if result is not None:
            return result
        return ToolConfigStatus(
            found=False, valid=True,
            errors=["No Radon configuration found (pyproject.toml [tool.radon] or .radon.cfg)"],
            configured_threshold=None,
        )

    def _scan_directories(
        self,
        threshold: int,
        include_tests: bool,
        min_rank: str,
        engine: str,
        max_file_lines: int | None,
    ) -> dict:
        """Scan all directories and collect complexity metrics"""
        stats = self._create_scan_stats()
        for scan_dir in self._get_scan_dirs(include_tests=include_tests):
            if not scan_dir.exists():
                continue
            for file_stats in self._iter_file_stats(
                scan_dir,
                threshold=threshold,
                include_tests=include_tests,
                min_rank=min_rank,
                engine=engine,
                max_file_lines=max_file_lines,
            ):
                self._merge_scan_stats(stats, file_stats)

        total_functions = int(stats["total_functions"])
        avg_complexity = round(float(stats["total_complexity"]) / total_functions, 2) if total_functions > 0 else 0.0

        return {
            "violations": stats["violations"],
            "total_complexity": stats["total_complexity"],
            "total_functions": total_functions,
            "max_complexity": stats["max_complexity"],
            "avg_complexity": avg_complexity,
            "files_scanned": stats["files_scanned"],
            "oversized_files": stats["oversized_files"],
            "max_file_lines_observed": stats["max_file_lines_observed"],
        }

    def _get_scan_dirs(self, *, include_tests: bool) -> list[Path]:
        src_dir = self.workspace_root / "src"
        tests_dir = self.workspace_root / "tests"
        if not src_dir.exists():
            return [self.workspace_root]
        scan_dirs = [src_dir]
        if include_tests and tests_dir.exists():
            scan_dirs.append(tests_dir)
        return scan_dirs

    def _create_scan_stats(self) -> dict[str, Any]:
        return {
            "violations": [],
            "total_complexity": 0,
            "total_functions": 0,
            "max_complexity": 0,
            "files_scanned": 0,
            "oversized_files": [],
            "max_file_lines_observed": 0,
        }

    def _merge_scan_stats(self, stats: dict[str, Any], file_stats: dict[str, Any]) -> None:
        stats["violations"].extend(file_stats["violations"])
        stats["total_complexity"] += file_stats["total_complexity"]
        stats["total_functions"] += file_stats["total_functions"]
        stats["max_complexity"] = max(stats["max_complexity"], file_stats["max_complexity"])
        if file_stats["has_results"]:
            stats["files_scanned"] += 1
        line_count = int(file_stats.get("line_count", 0) or 0)
        stats["max_file_lines_observed"] = max(stats["max_file_lines_observed"], line_count)
        oversized = file_stats.get("oversized_file")
        if isinstance(oversized, OversizedFile):
            stats["oversized_files"].append(oversized)

    def _iter_file_stats(
        self,
        scan_dir: Path,
        *,
        threshold: int,
        include_tests: bool,
        min_rank: str,
        engine: str,
        max_file_lines: int | None,
    ):
        for py_file in scan_dir.rglob("*.py"):
            if self._should_skip_file(py_file, include_tests=include_tests):
                continue
            file_stats = self._analyze_file(
                py_file,
                threshold,
                min_rank,
                engine,
                max_file_lines=max_file_lines,
            )
            if file_stats:
                yield file_stats

    def _should_skip_file(self, py_file: Path, *, include_tests: bool) -> bool:
        """Check if file should be skipped."""
        if self._is_report_only_exempt(py_file):
            return True
        if py_file.name.startswith("__") and py_file.name.endswith("__.py"):
            return True
        if self._is_ignored_by_patterns(py_file):
            return True

        rel, parts = self._get_relative_parts(py_file)
        if parts.intersection(_IGNORED_COMPLEXITY_DIRS):
            return True
        return self._is_test_file(rel, include_tests=include_tests)

    def _is_report_only_exempt(self, py_file: Path) -> bool:
        try:
            rel = _normalize_relpath(str(py_file.relative_to(self.workspace_root)))
        except Exception:
            return False
        for rel_path, _reason in _COMPLEXITY_LOC_REPORT_ONLY_EXEMPTIONS:
            if rel == _normalize_relpath(rel_path):
                return True
        return False

    def _is_ignored_by_patterns(self, py_file: Path) -> bool:
        try:
            return bool(self._ignore is not None and self._ignore.is_ignored(py_file))
        except Exception:
            return False

    def _get_relative_parts(self, py_file: Path) -> tuple[Path | None, set[str]]:
        try:
            rel = py_file.relative_to(self.workspace_root)
        except Exception:
            return None, set(py_file.parts)
        return rel, set(rel.parts)

    def _is_test_file(self, rel: Path | None, *, include_tests: bool) -> bool:
        if include_tests or rel is None:
            return False
        first = rel.parts[0] if rel.parts else None
        return first in {"tests", "test"}

    def _analyze_file(
        self,
        py_file: Path,
        threshold: int,
        min_rank: str,
        engine: str,
        *,
        max_file_lines: int | None,
    ) -> dict[str, Any] | None:
        """Analyze a single Python file"""
        try:
            content = py_file.read_text(encoding="utf-8")

            line_count = 0
            if content:
                line_count = content.count("\n") + 1

            oversized_file: OversizedFile | None = None
            if isinstance(max_file_lines, int) and max_file_lines > 0 and line_count > max_file_lines:
                relative_path = str(py_file.relative_to(self.workspace_root))
                oversized_file = OversizedFile(
                    file_path=relative_path,
                    line_count=line_count,
                    threshold=max_file_lines,
                )

            if engine == "radon":
                results = _extract_functions_radon(content)
            else:
                tree = ast.parse(content, filename=str(py_file))
                results = _extract_functions(tree)

            rank_order = {"A": 1, "B": 2, "C": 3, "D": 4, "E": 5, "F": 6}
            min_rank_value = rank_order.get(min_rank, 1)

            violations: list[ComplexityViolation] = []
            total_complexity = 0
            total_functions = 0
            max_complexity = 0

            for result in results:
                total_functions += 1
                total_complexity += result.complexity
                max_complexity = max(max_complexity, result.complexity)

                rank = _complexity_rank(result.complexity)
                if result.complexity > threshold and rank_order.get(rank, 6) >= min_rank_value:
                    relative_path = str(py_file.relative_to(self.workspace_root))
                    violations.append(
                        ComplexityViolation(
                            file_path=relative_path,
                            function_name=result.name,
                            line_number=result.lineno,
                            complexity=result.complexity,
                            rank=rank,
                            threshold=threshold,
                        ),
                    )

            return {
                "violations": violations,
                "total_complexity": total_complexity,
                "total_functions": total_functions,
                "max_complexity": max_complexity,
                "has_results": bool(results),
                "line_count": line_count,
                "oversized_file": oversized_file,
            }
        except Exception as e:
            logger.debug(f"Failed to analyze {py_file}: {e}")
            return None

    def get_recommendations(self, metrics: ComplexityMetrics) -> list[str]:
        """Generate actionable recommendations based on complexity metrics."""
        try:
            present: list[str] = []
            for rel_path, _reason in _COMPLEXITY_LOC_REPORT_ONLY_EXEMPTIONS:
                if (self.workspace_root / Path(rel_path)).exists():
                    present.append(rel_path)
            if present:
                lines = ", ".join(sorted(set(present)))
                prefix = "ℹ️ Excluded from complexity/LOC metrics (do not repair): "
                if len(lines) > 400:
                    lines = lines[:397] + "..."
                base_note = prefix + lines
        except Exception:
            base_note = None

        if not metrics.violations:
            return ["✅ All functions are within complexity threshold"]

        recommendations: list[str] = []
        self._add_severity_recommendations(recommendations, metrics.violations)
        self._add_top_offenders_list(recommendations, metrics.violations)
        if "base_note" in locals() and base_note:
            recommendations.append(base_note)
        return recommendations

    def _add_severity_recommendations(self, recommendations: list, violations: list) -> None:
        """Add recommendations based on violation severity"""
        critical = [v for v in violations if v.complexity > 20]
        if critical:
            recommendations.append(
                f"🔴 {len(critical)} function(s) have very high complexity (>20). "
                "These are error-prone and should be refactored urgently.",
            )

        high = [v for v in violations if 15 < v.complexity <= 20]
        if high:
            recommendations.append(
                f"🟡 {len(high)} function(s) have high complexity (15-20). "
                "Consider breaking these into smaller functions.",
            )

        moderate = [v for v in violations if v.threshold < v.complexity <= 15]
        if moderate:
            recommendations.append(
                f"🟢 {len(moderate)} function(s) exceed threshold but are manageable. "
                "Review for potential simplification.",
            )

    def _add_top_offenders_list(self, recommendations: list, violations: list) -> None:
        """Add top complexity offenders to recommendations"""
        top_3 = sorted(violations, key=lambda x: x.complexity, reverse=True)[:3]
        recommendations.append("\n📊 Top complexity offenders:")
        for v in top_3:
            recommendations.append(
                f"   - {v.function_name} ({v.file_path}:{v.line_number}): "
                f"complexity {v.complexity} [rank {v.rank}]",
            )
