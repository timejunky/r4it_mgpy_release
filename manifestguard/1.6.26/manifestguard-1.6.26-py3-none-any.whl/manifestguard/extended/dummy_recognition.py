"""Dummy / placeholder code recognition (MGVS-inspired).

This module keeps the original public import path and exports, while the
implementation is split across submodules to keep file sizes below the LOC
threshold.
"""

from __future__ import annotations

__MGVS_TRANSFER_IMPLEMENTED__ = True

from .dummy_recognition_detection import run_dummy_recognition
from .dummy_recognition_models import DummyCodeFinding, DummyEvidence, DummyRecognitionResult
from .dummy_recognition_suppressions import (
    _as_codes,
    _normalize_for_match,
    _parse_expiry_date,
    apply_dummy_recognition_suppressions,
    load_dummy_recognition_suppressions_from_manifestguard_json,
)

__all__ = [
    "__MGVS_TRANSFER_IMPLEMENTED__",
    "DummyCodeFinding",
    "DummyEvidence",
    "DummyRecognitionResult",
    "run_dummy_recognition",
    "load_dummy_recognition_suppressions_from_manifestguard_json",
    "apply_dummy_recognition_suppressions",
    "_parse_expiry_date",
    "_normalize_for_match",
    "_as_codes",
]
