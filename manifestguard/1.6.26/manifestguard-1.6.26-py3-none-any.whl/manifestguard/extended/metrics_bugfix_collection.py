from __future__ import annotations

import logging
import re
import shutil
import subprocess
from datetime import datetime, timezone
from pathlib import Path

logger = logging.getLogger(__name__)


def _get_bugfix_patterns() -> tuple[re.Pattern[str], list[str], list[str], dict[str, list[str]]]:
    """Get compiled regex pattern and keyword lists for bugfix detection."""
    bugfix_patterns = [
        r"\bfix\b",
        r"\bbug\b",
        r"\bissue\b",
        r"\berror\b",
        r"\bcrash\b",
        r"\bfail\b",
        r"\bbroke\b",
        r"\bproblem\b",
        r"\bresolve\b",
        r"\bpatch\b",
        r"\bhotfix\b",
    ]
    combined_pattern = re.compile("|".join(bugfix_patterns), re.IGNORECASE)

    critical_keywords = ["critical", "blocker", "crash", "data loss", "security"]
    major_keywords = ["major", "important", "broken", "fail"]

    category_keywords = {
        "dashboard": ["dashboard", "ui", "gui", "view"],
        "api": ["api", "endpoint", "rest", "graphql"],
        "packaging": ["package", "build", "dist", "setup"],
        "tests": ["test", "spec", "pytest", "unittest"],
        "documentation": ["doc", "docs", "readme", "guide"],
        "i18n": ["i18n", "translation", "locale", "lang"],
    }

    return combined_pattern, critical_keywords, major_keywords, category_keywords


def _categorize_severity(msg_lower: str, metrics: object, critical_keywords: list[str], major_keywords: list[str]) -> None:
    by_severity = getattr(metrics, "by_severity", None)
    if not isinstance(by_severity, dict):
        return

    if any(kw in msg_lower for kw in critical_keywords):
        by_severity["critical"] = int(by_severity.get("critical", 0) or 0) + 1
    elif any(kw in msg_lower for kw in major_keywords):
        by_severity["major"] = int(by_severity.get("major", 0) or 0) + 1
    else:
        by_severity["minor"] = int(by_severity.get("minor", 0) or 0) + 1


def _categorize_category(msg_lower: str, metrics: object, category_keywords: dict[str, list[str]]) -> None:
    by_category = getattr(metrics, "by_category", None)
    if not isinstance(by_category, dict):
        return

    for category, keywords in category_keywords.items():
        if any(kw in msg_lower for kw in keywords):
            by_category[category] = int(by_category.get(category, 0) or 0) + 1
            return

    by_category["other"] = int(by_category.get("other", 0) or 0) + 1


def _store_recent_fix(metrics: object, msg: str) -> None:
    recent_fixes = getattr(metrics, "recent_fixes", None)
    if not isinstance(recent_fixes, list):
        return

    if len(recent_fixes) < 10:
        recent_fixes.append({"message": msg[:100], "timestamp": ""})


def _categorize_bugfix(
    msg: str,
    metrics: object,
    critical_keywords: list[str],
    major_keywords: list[str],
    category_keywords: dict[str, list[str]],
) -> None:
    msg_lower = msg.lower()
    _categorize_severity(msg_lower, metrics, critical_keywords, major_keywords)
    _categorize_category(msg_lower, metrics, category_keywords)
    _store_recent_fix(metrics, msg)


def _calculate_bpd_metrics(metrics: object, bugfix_count: int, month_start: datetime, now: datetime) -> None:
    setattr(metrics, "total", bugfix_count)

    days_analyzed = (now - month_start).days
    if days_analyzed == 0:
        days_analyzed = 1

    setattr(metrics, "days_analyzed", days_analyzed)
    total = int(getattr(metrics, "total", 0) or 0)
    setattr(metrics, "bpd", round((total / days_analyzed) * 100) / 100)


def collect_bugfix_metrics(workspace_root: Path):
    """Collect bugfix tracking metrics from git commit history.

    Kept in a separate module to keep extended/metrics.py under the LOC threshold.
    """

    # Import lazily to avoid circular imports at module load time.
    from .metrics import BugfixMetrics  # noqa: PLC0415

    metrics = BugfixMetrics()

    try:
        now = datetime.now(timezone.utc)
        month_start = now.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
        since_date = month_start.strftime("%Y-%m-%d")

        git_path = shutil.which("git")
        if git_path is None:
            logger.debug("git not available; skipping bugfix metrics")
            return metrics

        result = subprocess.run(  # Controlled git invocation  # noqa: S603
            [git_path, "log", f"--since={since_date}", "--pretty=format:%s"],
            check=False,
            cwd=workspace_root,
            capture_output=True,
            text=True,
            timeout=10,
        )

        if result.returncode != 0:
            logger.debug("Git not available or not a git repository")
            return metrics

        commit_messages = result.stdout.strip().split("\n")
        if not commit_messages or commit_messages == [""]:
            return metrics

        pattern, critical_kw, major_kw, category_kw = _get_bugfix_patterns()

        bugfixes: list[str] = []
        for msg in commit_messages:
            if pattern.search(msg):
                bugfixes.append(msg)
                _categorize_bugfix(msg, metrics, critical_kw, major_kw, category_kw)

        _calculate_bpd_metrics(metrics, len(bugfixes), month_start, now)

        logger.info(
            f"Bugfix analysis: {getattr(metrics, 'total', 0)} fixes, "
            f"{getattr(metrics, 'bpd', 0)} bugs/day over {getattr(metrics, 'days_analyzed', 0)} days",
        )

    except FileNotFoundError:
        logger.debug("Git not installed, bugfix metrics skipped")
    except Exception as exc:  # pragma: no cover - best-effort
        logger.debug(f"Bugfix metrics collection failed: {exc}")

    return metrics
