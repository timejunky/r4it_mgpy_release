from __future__ import annotations

import json
import logging
import shutil
import subprocess
import uuid
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any


logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class GitCommit:
    timestamp: datetime
    author: str
    subject: str
    files_touched: frozenset[str]
    lines_added: int
    lines_deleted: int


def _parse_iso_timestamp(value: Any) -> datetime | None:
    if not isinstance(value, str) or not value:
        return None
    try:
        return datetime.fromisoformat(value.replace("Z", "+00:00")).astimezone(timezone.utc)
    except Exception:
        return None


def _format_iso_z(dt: datetime) -> str:
    return dt.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")


def _load_or_create_wrapper(history_file: Path) -> dict[str, Any]:
    if not history_file.exists():
        return {
            "schemaVersion": "2.0",
            "formatVersion": "1.0.0",
            "historyId": str(uuid.uuid4()),
            "projectId": str(uuid.uuid4()),
            "entries": [],
        }

    try:
        parsed = json.loads(history_file.read_text(encoding="utf-8"))
        if isinstance(parsed, dict):
            if not isinstance(parsed.get("entries"), list):
                parsed["entries"] = []

            if not isinstance(parsed.get("historyId"), str) or not parsed.get("historyId"):
                parsed["historyId"] = str(uuid.uuid4())
            if not isinstance(parsed.get("projectId"), str) or not parsed.get("projectId"):
                parsed["projectId"] = str(uuid.uuid4())

            return parsed
    except Exception:
        pass

    return {
        "schemaVersion": "2.0",
        "formatVersion": "1.0.0",
        "historyId": str(uuid.uuid4()),
        "projectId": str(uuid.uuid4()),
        "entries": [],
    }


def _write_json_atomic(path: Path, payload: dict[str, Any]) -> None:
    tmp = path.with_suffix(path.suffix + ".tmp")
    try:
        tmp.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")
        tmp.replace(path)
    finally:
        if tmp.exists() and not path.exists():
            try:
                tmp.unlink()
            except Exception:
                pass


def _resolve_git_executable() -> str | None:
    return shutil.which("git")


def _append_commit_if_present(
    commits: list[GitCommit],
    *,
    timestamp: datetime | None,
    author: str,
    subject: str,
    files_touched: set[str],
    lines_added: int,
    lines_deleted: int,
) -> None:
    if timestamp is None:
        return
    commits.append(
        GitCommit(
            timestamp=timestamp,
            author=author,
            subject=subject,
            files_touched=frozenset(files_touched),
            lines_added=int(lines_added),
            lines_deleted=int(lines_deleted),
        )
    )


def _parse_commit_header(
    line: str,
    *,
    header_prefix: str,
    unit_sep: str,
) -> tuple[datetime, str, str] | None:
    payload = line[len(header_prefix) :]
    parts = payload.split(unit_sep)
    if len(parts) < 3:
        return None
    try:
        unix_ts = int(parts[0])
    except Exception:
        return None
    return datetime.fromtimestamp(unix_ts, tz=timezone.utc), parts[1], parts[2]


def _update_numstat_totals(
    line: str,
    *,
    files: set[str],
    added_total: int,
    deleted_total: int,
) -> tuple[int, int]:
    fields = line.split("\t")
    if len(fields) < 3:
        return added_total, deleted_total
    added_raw, deleted_raw, file_path = fields[0], fields[1], fields[2]
    files.add(file_path)
    if added_raw.isdigit():
        added_total += int(added_raw)
    if deleted_raw.isdigit():
        deleted_total += int(deleted_raw)
    return added_total, deleted_total


def _parse_git_log_output(
    output: str,
    *,
    header_prefix: str,
    unit_sep: str,
) -> list[GitCommit]:
    commits: list[GitCommit] = []
    current_ts: datetime | None = None
    current_author = ""
    current_subject = ""
    files: set[str] = set()
    added_total = 0
    deleted_total = 0

    for raw_line in output.splitlines():
        line = raw_line.rstrip("\n")
        if line.startswith(header_prefix):
            _append_commit_if_present(
                commits,
                timestamp=current_ts,
                author=current_author,
                subject=current_subject,
                files_touched=files,
                lines_added=added_total,
                lines_deleted=deleted_total,
            )
            current_ts = None
            current_author = ""
            current_subject = ""
            files = set()
            added_total = 0
            deleted_total = 0

            parsed_header = _parse_commit_header(
                line,
                header_prefix=header_prefix,
                unit_sep=unit_sep,
            )
            if parsed_header is None:
                continue
            current_ts, current_author, current_subject = parsed_header
            continue

        if current_ts is None or not line.strip():
            continue

        added_total, deleted_total = _update_numstat_totals(
            line,
            files=files,
            added_total=added_total,
            deleted_total=deleted_total,
        )

    _append_commit_if_present(
        commits,
        timestamp=current_ts,
        author=current_author,
        subject=current_subject,
        files_touched=files,
        lines_added=added_total,
        lines_deleted=deleted_total,
    )
    return commits


def _fetch_git_commits(
    *,
    repo_root: Path,
    since: datetime,
    until: datetime,
    path_filter: Path | None,
    timeout_seconds: int = 30,
) -> list[GitCommit]:
    git_path = _resolve_git_executable()
    if git_path is None:
        raise RuntimeError("git not found in PATH")

    # Use date-only bounds for robust cross-platform parsing.
    since_arg = since.astimezone(timezone.utc).date().isoformat()
    until_arg = until.astimezone(timezone.utc).date().isoformat()

    header_prefix = "@@@"
    unit_sep = "\x1f"
    pretty = f"{header_prefix}%ct{unit_sep}%an{unit_sep}%s"

    cmd = [
        git_path,
        "log",
        "--no-merges",
        f"--since={since_arg}",
        f"--until={until_arg}",
        f"--pretty=format:{pretty}",
        "--numstat",
    ]

    if path_filter is not None:
        cmd.append("--")
        cmd.append(str(path_filter).replace("\\", "/"))

    result = subprocess.run(  # Controlled invocation  # noqa: S603
        cmd,
        check=False,
        cwd=repo_root,
        capture_output=True,
        text=True,
        timeout=timeout_seconds,
    )

    if result.returncode != 0:
        stderr = (result.stderr or "").strip()
        raise RuntimeError(f"git log failed (exit {result.returncode}): {stderr}")

    commits = _parse_git_log_output(
        result.stdout or "",
        header_prefix=header_prefix,
        unit_sep=unit_sep,
    )

    # Git prints newest-first; we want oldest-first for window logic.
    commits.sort(key=lambda c: c.timestamp)
    return commits


def _compute_bugfix_metrics_and_corrections(
    *,
    commits: list[GitCommit],
    window_days: int,
) -> tuple[dict[str, Any], dict[str, Any]]:
    # Reuse the same heuristics as the extended bugfix collector.
    from manifestguard.extended.metrics_bugfix_collection import _get_bugfix_patterns  # noqa: PLC0415

    pattern, critical_kw, major_kw, category_kw = _get_bugfix_patterns()

    by_severity: dict[str, int] = {"critical": 0, "major": 0, "minor": 0}
    # Keep category set aligned with MGVS to avoid diverging chart semantics.
    by_category: dict[str, int] = {
        "dashboard": 0,
        "api": 0,
        "packaging": 0,
        "tests": 0,
        "other": 0,
    }

    total = 0
    files_touched_total = 0
    for commit in commits:
        msg = commit.subject or ""
        if not pattern.search(msg):
            continue

        total += 1
        files_touched_total += len(commit.files_touched)
        msg_lower = msg.lower()
        severity = _classify_bugfix_severity(msg_lower, critical_kw, major_kw)
        by_severity[severity] += 1
        category = _classify_bugfix_category(msg_lower, category_kw, allowed_categories=set(by_category))
        by_category[category] = int(by_category.get(category, 0) or 0) + 1

    days = max(1, int(window_days))
    bpd = round((total / days) * 100) / 100

    bugfixes = {
        "total": int(total),
        "bpd": float(bpd),
        "daysAnalyzed": int(days),
        "bySeverity": by_severity,
        "byCategory": by_category,
    }

    corrections = {
        "totalFilesCorrected": int(files_touched_total),
    }

    return bugfixes, corrections


def _classify_bugfix_severity(
    msg_lower: str,
    critical_kw: list[str],
    major_kw: list[str],
) -> str:
    if any(kw in msg_lower for kw in critical_kw):
        return "critical"
    if any(kw in msg_lower for kw in major_kw):
        return "major"
    return "minor"


def _classify_bugfix_category(
    msg_lower: str,
    category_kw: dict[str, list[str]],
    *,
    allowed_categories: set[str],
) -> str:
    for category, keywords in category_kw.items():
        if category not in allowed_categories:
            continue
        if any(kw in msg_lower for kw in keywords):
            return category
    return "other"


def _compute_repo_activity_metrics(
    *,
    commits: list[GitCommit],
    window_days: int,
) -> dict[str, Any]:
    authors = {c.author for c in commits if c.author}
    files: set[str] = set()
    lines_added = 0
    lines_deleted = 0

    for c in commits:
        files.update(c.files_touched)
        lines_added += int(c.lines_added)
        lines_deleted += int(c.lines_deleted)

    total_commits = len(commits)
    days = max(1, int(window_days))
    commits_per_day = round((total_commits / days) * 100) / 100

    return {
        "commitsTotal": int(total_commits),
        "commitsPerDay": float(commits_per_day),
        "authors": int(len(authors)),
        "filesTouched": int(len(files)),
        "linesAdded": int(lines_added),
        "linesDeleted": int(lines_deleted),
    }


def _select_starting_point(
    *,
    wrapper: dict[str, Any],
    starting_point: str,
    fixed_date_iso: str | None,
    now: datetime,
) -> datetime:
    if starting_point == "fixedDate":
        fixed = _parse_iso_timestamp(fixed_date_iso)
        if fixed is None:
            raise ValueError("fixedDate requires a valid --fixed-date-iso")
        return fixed

    if starting_point == "sinceLastReconstruct":
        cutoff_raw = wrapper.get("reconstructCutoffIso")
        cutoff = _parse_iso_timestamp(cutoff_raw)
        if cutoff is not None:
            return cutoff
        return now - timedelta(days=365)

    if starting_point == "lastYear":
        return now - timedelta(days=365)

    raise ValueError(f"Unknown starting_point: {starting_point}")


def _write_history_with_backup(
    history_file: Path,
    wrapper: dict[str, Any],
    now: datetime,
) -> "Path | None":
    """Write history JSON atomically, creating a timestamped backup first."""
    backup_path: Path | None = None
    try:
        if history_file.exists():
            backup_path = history_file.with_suffix(
                history_file.suffix + f".bak.{now.strftime('%Y%m%d-%H%M%S')}"
            )
            backup_path.write_text(history_file.read_text(encoding="utf-8"), encoding="utf-8")
    except Exception as exc:  # pragma: no cover (best-effort)
        logger.debug(f"Failed to create backup for {history_file}: {exc}")
        backup_path = None

    history_file.parent.mkdir(parents=True, exist_ok=True)
    _write_json_atomic(history_file, wrapper)
    return backup_path


def _resolve_history_file_path_for_reconstruct(
    workspace_root: Path,
    history_file: Path | None,
) -> Path:
    if history_file is not None:
        return history_file
    from manifestguard.extended.metrics_history_export import resolve_history_file_path

    return resolve_history_file_path(workspace_root, create_if_missing=True)


def _index_reconstructible_entries(
    entries: list[dict[str, Any]],
    *,
    effective_cutoff: datetime,
) -> list[tuple[int, datetime]]:
    indexed: list[tuple[int, datetime]] = []
    for idx, entry in enumerate(entries):
        ts = _parse_iso_timestamp(entry.get("timestamp"))
        if ts is None or ts < effective_cutoff:
            continue
        indexed.append((idx, ts))
    indexed.sort(key=lambda item: item[1])
    return indexed


def _apply_reconstructed_metrics(
    entries: list[dict[str, Any]],
    *,
    indexed_entries: list[tuple[int, datetime]],
    commits: list[GitCommit],
    window_days: int,
) -> int:
    updated_entries = 0
    for idx, ts in indexed_entries:
        window_start = ts - timedelta(days=window_days)
        bucket = [c for c in commits if window_start <= c.timestamp <= ts]
        bugfixes, corrections = _compute_bugfix_metrics_and_corrections(
            commits=bucket,
            window_days=window_days,
        )
        entries[idx]["bugfixes"] = bugfixes
        entries[idx]["corrections"] = corrections
        entries[idx]["repoActivity"] = _compute_repo_activity_metrics(commits=bucket, window_days=window_days)
        updated_entries += 1
    return updated_entries


def _update_reconstruct_wrapper(
    wrapper: dict[str, Any],
    *,
    entries: list[dict[str, Any]],
    now: datetime,
    starting_point: str,
    requested_cutoff: datetime,
    effective_cutoff: datetime,
    allow_widening: bool,
    window_days: int,
    widened_blocked: bool,
) -> None:
    wrapper["entries"] = entries
    wrapper["schemaVersion"] = str(wrapper.get("schemaVersion") or "2.0")
    wrapper["reconstructCutoffIso"] = _format_iso_z(effective_cutoff)
    wrapper["lastReconstruct"] = {
        "timestamp": _format_iso_z(now),
        "startingPoint": starting_point,
        "requestedCutoffIso": _format_iso_z(requested_cutoff),
        "effectiveCutoffIso": _format_iso_z(effective_cutoff),
        "allowWidening": bool(allow_widening),
        "windowDays": int(window_days),
        "metrics": ["bugfixes", "corrections", "repoActivity"],
        "wideningBlocked": bool(widened_blocked),
    }


def reconstruct_metrics_history_from_repo_history(
    *,
    workspace_root: Path,
    history_file: Path | None = None,
    starting_point: str = "sinceLastReconstruct",
    fixed_date_iso: str | None = None,
    allow_widening: bool = False,
    window_days: int = 30,
    path_filter: Path | None = None,
) -> dict[str, Any]:
    """Reconstruct repo-derived metrics for existing history entries.

    Updates entries in `.mgpy/metrics/manifestguard-history.json` by computing Git-based
    metrics in a sliding window ending at each entry timestamp.

    Currently reconstructs:
      - `entry.bugfixes`: total + BPD + breakdowns
      - `entry.repoActivity`: commits/authors/files/churn

    Deterministic cutoff:
      - Stores a stable `reconstructCutoffIso` in the wrapper.
      - Refuses to widen backward unless `allow_widening=True`.
    """

    resolved_history_file = _resolve_history_file_path_for_reconstruct(workspace_root, history_file)
    wrapper = _load_or_create_wrapper(resolved_history_file)

    entries_raw = wrapper.get("entries")
    entries: list[dict[str, Any]] = [e for e in (entries_raw or []) if isinstance(e, dict)]

    now = datetime.now(timezone.utc)
    requested_cutoff = _select_starting_point(
        wrapper=wrapper,
        starting_point=starting_point,
        fixed_date_iso=fixed_date_iso,
        now=now,
    )

    stored_cutoff = _parse_iso_timestamp(wrapper.get("reconstructCutoffIso"))
    effective_cutoff = requested_cutoff
    widened_blocked = False
    if stored_cutoff is not None and not allow_widening and requested_cutoff < stored_cutoff:
        effective_cutoff = stored_cutoff
        widened_blocked = True

    window_days_i = max(1, int(window_days))
    fetch_since = effective_cutoff - timedelta(days=window_days_i)

    commits = _fetch_git_commits(
        repo_root=workspace_root,
        since=fetch_since,
        until=now,
        path_filter=path_filter,
    )

    indexed = _index_reconstructible_entries(entries, effective_cutoff=effective_cutoff)
    updated_entries = _apply_reconstructed_metrics(
        entries,
        indexed_entries=indexed,
        commits=commits,
        window_days=window_days_i,
    )
    _update_reconstruct_wrapper(
        wrapper,
        entries=entries,
        now=now,
        starting_point=starting_point,
        requested_cutoff=requested_cutoff,
        effective_cutoff=effective_cutoff,
        allow_widening=allow_widening,
        window_days=window_days_i,
        widened_blocked=widened_blocked,
    )

    backup_path = _write_history_with_backup(resolved_history_file, wrapper, now)

    return {
        "historyFile": str(resolved_history_file),
        "backupFile": str(backup_path) if backup_path else None,
        "updatedEntries": int(updated_entries),
        "effectiveCutoffIso": wrapper.get("reconstructCutoffIso"),
        "wideningBlocked": bool(widened_blocked),
        "windowDays": int(window_days_i),
        "pathFilter": str(path_filter) if path_filter is not None else None,
    }
