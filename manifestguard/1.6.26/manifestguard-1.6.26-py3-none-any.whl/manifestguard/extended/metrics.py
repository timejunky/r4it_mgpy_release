"""Extended Test Mode - Metrics Collection Module

This module provides comprehensive quality metrics collection for Python packages,
analyzing 8 critical domains to support AI-driven recommendations for test and
code improvements.

Metric Categories:
    - Coverage: Test breadth, gaps, and untested modules
    - Dependency: Package health, vulnerabilities, and conflicts
    - Security: Risk patterns (eval, secrets, weak crypto)
    - SBOM: Software Bill of Materials completeness
    - Packaging: Distribution quality and metadata
    - Performance: Analysis timing and bottlenecks
    - Policy: Whitelist/blacklist compliance
    - License: SPDX compliance and consistency

Privacy:
    All metrics are collected locally. No code is transmitted to external
    services without explicit user consent. Paths are anonymized in reports.

Usage:
    collector = MetricsCollector(workspace_root)
    metrics = await collector.collect_metrics()
    recommendations = metrics.recommendations
"""

import asyncio
import json
import logging
import sys
import time
import traceback
from collections.abc import Callable, Iterable
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from manifestguard.validation.inline_markers import is_line_suppressed
from manifestguard.core.test_config_helper import (
    Config as _TestConfig,
    Thresholds as _TestThresholds,
    check_thresholds,
    resolve_test_config_from_dict,
)

from .complexity import ComplexityAnalyzer
from .coverage_collection import collect_coverage_metrics
from .dependency_collection import collect_dependency_metrics
from .documentation_coverage import analyze_documentation
from .metrics_history_export import export_metrics_history as _export_metrics_history
from .metrics_bugfix_collection import collect_bugfix_metrics as _collect_bugfix_metrics
from .metrics_complexity_collection import (
    collect_complexity_metrics as _collect_complexity_metrics,
    read_complexity_settings_from_manifest as _read_complexity_settings_from_manifest,
)
from .metrics_security_collection import collect_security_metrics as _collect_security_metrics
from .packaging_collection import collect_packaging_metrics
from .policy_collection import collect_policy_metrics
from .sbom_collection import collect_sbom_metrics
from .scan_utils import load_ignore_patterns, should_skip_path
from .style_checks import check_pep8_violations, check_style_consistency
from .typing_coverage import analyze_type_hints
from .weak_crypto_check import check_weak_crypto
from manifestguard.validation.runtime_metrics import run_manifest_validation_with_metrics

logger = logging.getLogger(__name__)
RECOMMENDATION_ACK_FILE = ".manifestguard/recommendation-acks.json"

@dataclass
class CoverageMetrics:
    """Test coverage and test suite health metrics.

    Attributes:
        unit_percent: Percentage of unit test coverage (0-100)
        unit_measured: True if unit_percent was measured for this run
        integration_percent: Percentage of integration test coverage (0-100)
        untested_modules: List of module paths without test coverage
        total_tests: Total number of tests in suite
        passing_tests: Number of tests that passed
        failing_tests: Number of tests that failed
        skipped_tests: Number of tests skipped or marked as TODO

    """

    unit_percent: float = 0.0
    unit_measured: bool = False
    integration_percent: float = 0.0
    untested_modules: list[str] = field(default_factory=list)
    total_tests: int = 0
    passing_tests: int = 0
    failing_tests: int = 0
    skipped_tests: int = 0

    def __post_init__(self) -> None:
        # Backward-compatible heuristic:
        # If a caller provides a non-zero unit_percent but does not set
        # unit_measured, treat it as measured. (A truly missing datapoint
        # should keep unit_percent at 0.0 and unit_measured=False.)
        if not self.unit_measured and self.unit_percent != 0.0:
            self.unit_measured = True


@dataclass
class DependencyMetrics:
    """Package dependency health and vulnerability metrics.

    Attributes:
        outdated_count: Number of dependencies with newer versions available
        vulnerable_high: Count of high-severity vulnerabilities
        vulnerable_critical: Count of critical-severity vulnerabilities
        conflicting_ranges: List of dependency version conflicts (PEP 440)
        direct_count: Number of direct dependencies in requirements
        transitive_count: Number of transitive (indirect) dependencies

    """

    outdated_count: int = 0
    vulnerable_high: int = 0
    vulnerable_critical: int = 0
    conflicting_ranges: list[str] = field(default_factory=list)
    direct_count: int = 0
    transitive_count: int = 0


@dataclass
class SecurityMetrics:
    """Static security analysis and risk indicators.

    Attributes:
        unsafe_exec_count: Number of eval/exec calls found
        hardcoded_secrets: Count of potential hardcoded secrets (API keys, tokens)
        hardcoded_paths: Count of files with hardcoded dev/user paths (ADR-011)
        subprocess_shell_true: Count of files using subprocess with shell=True
        unsafe_deserialization: Count of files using unsafe deserialization patterns
        tls_verify_disabled: Count of files disabling TLS verification (certificate verification disabled)
        insecure_tempfile: Count of files using insecure tempfile patterns (mktemp)
        wheel_content_issues: Count of suspicious/unintended wheel contents detected
        wheel_content_findings: List of wheel audit findings (limited)
        weak_crypto: List of files using weak cryptographic algorithms
        insecure_permissions: List of files with overly permissive file modes
        supply_chain_vulnerabilities: Count of known CVEs in dependencies (pip-audit)
        supply_chain_findings: List of dependency vulnerability findings (limited)

    Note:
        This is static analysis only. Does not replace dedicated security tools
        like Bandit or Snyk. Intended for early detection of common patterns.

    """

    unsafe_exec_count: int = 0
    hardcoded_secrets: int = 0
    hardcoded_paths: int = 0  # ADR-011: Hardcoded path detection
    subprocess_shell_true: int = 0
    unsafe_deserialization: int = 0
    tls_verify_disabled: int = 0
    insecure_tempfile: int = 0
    wheel_content_issues: int = 0
    wheel_content_findings: list[str] = field(default_factory=list)
    weak_crypto: list[str] = field(default_factory=list)
    insecure_permissions: list[str] = field(default_factory=list)
    supply_chain_vulnerabilities: int = 0
    supply_chain_findings: list[str] = field(default_factory=list)


@dataclass
class SBOMMetrics:
    """SBOM completeness metrics"""

    components_count: int = 0
    missing_licenses: int = 0
    unknown_origins: int = 0
    spdx_compliance: bool = False


@dataclass
class PackagingMetrics:
    """Package distribution quality"""

    missing_classifiers: list[str] = field(default_factory=list)
    has_py_typed: bool = False
    version_consistency: bool = True
    readme_present: bool = True
    license_present: bool = True


@dataclass
class PerformanceMetrics:
    """Build and analysis timing"""

    manifest_parse_ms: float = 0.0
    rule_engine_ms: float = 0.0
    dependency_graph_ms: float = 0.0
    total_analysis_ms: float = 0.0


@dataclass
class PolicyMetrics:
    """Policy enforcement status"""

    whitelist_violations: list[str] = field(default_factory=list)
    blacklist_violations: list[str] = field(default_factory=list)
    untagged_critical_deps: list[str] = field(default_factory=list)

    # Runtime no-op pattern recognition (MGVS-inspired)
    dummy_code_total_findings: int = 0
    dummy_code_scanned_files: int = 0
    dummy_code_marker_findings: int = 0
    dummy_code_constant_return_findings: int = 0
    dummy_code_no_op_findings: int = 0
    dummy_code_test_artifact_findings: int = 0

    # Optional, capped sample of findings for drill-down in reports.
    # Kept small to avoid bloating JSON and leaking too much code context.
    dummy_code_findings_sample: list[dict[str, Any]] = field(default_factory=list)

    # Code duplication detection (MGVS-inspired, P0)
    duplication: dict[str, Any] = field(default_factory=dict)

    # Hardcoded GUI strings (MGVS-inspired i18n guardrail)
    gui_hardcoded_strings_total_findings: int = 0
    gui_hardcoded_strings_unique_strings: int = 0
    gui_hardcoded_strings_scanned_files: int = 0
    gui_hardcoded_strings_findings_sample: list[dict[str, Any]] = field(default_factory=list)

    # Hardcoded CLI strings (MGVS-inspired i18n guardrail)
    cli_hardcoded_strings_total_findings: int = 0
    cli_hardcoded_strings_unique_strings: int = 0
    cli_hardcoded_strings_scanned_files: int = 0
    cli_hardcoded_strings_findings_sample: list[dict[str, Any]] = field(default_factory=list)


@dataclass
class LicenseMetrics:
    """License metadata consistency"""

    spdx_mismatches: list[str] = field(default_factory=list)
    license_file_missing: bool = False
    conflicting_notices: list[str] = field(default_factory=list)


@dataclass
class ComplexityMetrics:
    """Code complexity analysis metrics.

    Attributes:
        violations_count: Number of functions exceeding threshold
        average_complexity: Mean complexity across all functions
        max_complexity: Highest complexity found
        files_scanned: Number of Python files analyzed
        threshold: Complexity threshold used (default: 10)
        top_violations: List of top 5 most complex functions

    """

    violations_count: int = 0
    average_complexity: float = 0.0
    max_complexity: int = 0
    files_scanned: int = 0
    threshold: int = 10
    top_violations: list[dict[str, Any]] = field(default_factory=list)

    # Provenance
    engine: str = "mgpy-analyzer"
    engine_version: str | None = None

    # File-level maintainability hotspots (LOC-based)
    max_file_lines_threshold: int | None = None
    max_file_lines_observed: int = 0
    oversized_files_count: int = 0
    oversized_files: list[dict[str, Any]] = field(default_factory=list)


@dataclass
class BugfixMetrics:
    """Bugfix tracking metrics from git commit history.

    Analyzes commit messages to track bug resolution patterns and quality trends.

    Attributes:
        total: Total number of bugfixes detected
        bpd: Bugs Per Day (bugfixes / days_analyzed)
        days_analyzed: Number of days included in analysis
        by_severity: Breakdown by severity (critical, major, minor)
        by_category: Breakdown by category (dashboard, api, packaging, etc.)
        recent_fixes: List of recent bugfix commit messages

    """

    total: int = 0
    bpd: float = 0.0
    days_analyzed: int = 0
    by_severity: dict[str, int] = field(
        default_factory=lambda: {
            "critical": 0,
            "major": 0,
            "minor": 0,
        }
    )
    by_category: dict[str, int] = field(
        default_factory=lambda: {
            "dashboard": 0,
            "api": 0,
            "packaging": 0,
            "tests": 0,
            "documentation": 0,
            "i18n": 0,
            "other": 0,
        }
    )
    recent_fixes: list[dict[str, str]] = field(default_factory=list)


@dataclass
class Recommendation:
    """AI-generated or heuristic-based improvement recommendation.

    Multi-level recommendation system: Critical → High → Medium → Low

    Priority Levels:
        - critical: Fix immediately (security, breaking tests)
        - high: Fix within 1 week (coverage <50%, high complexity)
        - medium: Improve quality (documentation, packaging)
        - low: Optional enhancements (baseline tracking, performance)

    Attributes:
        category: Metric category (coverage, security, dependency, etc.)
        id: Unique recommendation identifier (kebab-case)
        priority: Severity level ('critical', 'high', 'medium', 'low')
        summary: Human-readable description of the issue
        proposed_fix: Optional actionable fix suggestion or command
        confidence: Confidence score 0.0-1.0 (1.0 = high confidence)
        effort_minutes: Estimated effort in minutes (5, 15, 30, 60, 120, 240)
        impact_score: Impact on quality score (0-100)
        code_example: Optional code snippet showing the fix
        guide_url: Optional link to tutorial/documentation
        files_affected: List of affected file paths (for tracking)

    Examples:
        Recommendation(
            category='coverage',
            id='add-integration-tests',
            priority='high',
            summary='Missing integration tests for CLI commands',
            proposed_fix='Add test_cli_integration.py with Click runner',
            confidence=0.85,
            effort_minutes=120,
            impact_score=15,
            code_example='from click.testing import CliRunner...',
            guide_url='https://docs.manifestguard.io/guides/testing',
            files_affected=['tests/test_cli_integration.py']
        )

    """

    category: str
    id: str
    priority: str  # 'critical', 'high', 'medium', 'low'
    summary: str
    proposed_fix: str | None = None
    confidence: float = 0.0
    effort_minutes: int = 0
    impact_score: int = 0
    code_example: str | None = None
    guide_url: str | None = None
    files_affected: list[str] = field(default_factory=list)


@dataclass
class ExtendedTestMetrics:
    """Complete extended test metrics"""

    timestamp: str
    enabled: bool = True
    coverage: CoverageMetrics = field(default_factory=CoverageMetrics)
    dependency: DependencyMetrics = field(default_factory=DependencyMetrics)
    security: SecurityMetrics = field(default_factory=SecurityMetrics)
    sbom: SBOMMetrics = field(default_factory=SBOMMetrics)
    packaging: PackagingMetrics = field(default_factory=PackagingMetrics)
    performance: PerformanceMetrics = field(default_factory=PerformanceMetrics)
    policy: PolicyMetrics = field(default_factory=PolicyMetrics)
    complexity: ComplexityMetrics = field(default_factory=ComplexityMetrics)
    license: LicenseMetrics = field(default_factory=LicenseMetrics)
    bugfixes: BugfixMetrics = field(default_factory=BugfixMetrics)
    recommendations: list[Recommendation] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)
    quality_score: float = 0.0  # Overall quality score (0-100)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for JSON serialization"""
        return {
            "timestamp": self.timestamp,
            "enabled": self.enabled,
            "quality_score": self.quality_score,
            "metrics": {
                "coverage": self.coverage.__dict__,
                "dependency": self.dependency.__dict__,
                "security": self.security.__dict__,
                "sbom": self.sbom.__dict__,
                "packaging": self.packaging.__dict__,
                "performance": self.performance.__dict__,
                "policy": self.policy.__dict__,
                "license": self.license.__dict__,
                "complexity": self.complexity.__dict__ if self.complexity else None,
                "bugfixes": (
                    {
                        "total": self.bugfixes.total,
                        "bpd": self.bugfixes.bpd,
                        "days_analyzed": self.bugfixes.days_analyzed,
                        "by_severity": self.bugfixes.by_severity,
                        "by_category": self.bugfixes.by_category,
                        "recent_fixes": self.bugfixes.recent_fixes,
                    }
                    if self.bugfixes
                    else None
                ),
            },
            "recommendations": [
                {
                    "category": r.category,
                    "id": r.id,
                    "priority": r.priority,
                    "summary": r.summary,
                    "proposedFix": r.proposed_fix,
                    "confidence": r.confidence,
                    "effort_minutes": r.effort_minutes,
                    "impact_score": r.impact_score,
                    "code_example": r.code_example,
                    "guide_url": r.guide_url,
                    "files_affected": r.files_affected,
                }
                for r in self.recommendations
            ],
            "errors": self.errors,
        }


from .metrics_recommendations_core import _MetricsRecommendationsCoreMixin
from .metrics_recommendations_quality import _MetricsRecommendationsQualityMixin


class MetricsCollector(_MetricsRecommendationsCoreMixin, _MetricsRecommendationsQualityMixin):
    """Collects extended test metrics from Python project workspace.

    This class orchestrates collection of 8 metric categories and generates
    AI-driven recommendations based on thresholds and patterns. All collection
    is done locally with error isolation per category.

    Args:
        workspace_root: Path to project root containing pyproject.toml/setup.py

    Example:
        collector = MetricsCollector(Path('/path/to/project'))
        metrics = await collector.collect_metrics()

        # Access specific metrics
        if metrics.coverage.unit_percent < 70:
            print('Low test coverage!')

        # Review recommendations
        for rec in metrics.recommendations:
            if rec.priority == 'critical':
                print(f'CRITICAL: {rec.summary}')

    """

    def __init__(
        self,
        workspace_root: Path,
        config: dict[str, Any] | None = None,
        gate_counts: tuple[int, int, int] | None = None,
    ):
        """Initialize metrics collector.

        Args:
            workspace_root: Absolute path to project root directory

        """
        self.workspace_root = workspace_root
        self.start_time = time.time()
        self.config: dict[str, Any] = config or {}
        self.gate_counts = gate_counts
        self._threshold_gate_blocked_tests: set[str] = set()
        self._threshold_gate_details: dict[str, str] = {}
        self._installed_packages_task: asyncio.Task[list[dict[str, str]]] | None = None

    def _test_config(self, test_name: str):
        return resolve_test_config_from_dict(test_name, self.config)

    def _should_run_expensive_step(self, test_name: str) -> tuple[bool, str | None]:
        cfg = self._test_config(test_name)
        if not cfg.enabled:
            return False, f"disabled via manifestguard.json testConfig.{test_name}.enabled=false"
        if not cfg.deep_analysis_mode:
            return False, f"deep analysis disabled via testConfig.{test_name}.deepAnalysisMode=false"

        # Threshold gate (concept): expensive checks run only once the current run's
        # validation counts (E/W/I) are within configured thresholds.
        if self.gate_counts is not None:
            errors, warnings, info = self.gate_counts

            # Always apply thresholds for expensive steps.
            # Default gate (when thresholds are not configured): E=0, W=0.
            thresholds = cfg.thresholds or _TestThresholds(
                max_errors=0,
                max_warnings=0,
                max_info=None,
            )
            gate_cfg = _TestConfig(
                enabled=cfg.enabled,
                deep_analysis_mode=cfg.deep_analysis_mode,
                thresholds=thresholds,
            )

            result = check_thresholds(
                test_name=test_name,
                errors=errors,
                warnings=warnings,
                info=info,
                config=gate_cfg,
            )
            if not result.passes:
                self._threshold_gate_blocked_tests.add(test_name)
                self._threshold_gate_details[test_name] = result.message
                return (
                    False,
                    "threshold gate not satisfied (expensive tests run only after E/W/I are within limits): "
                    + result.message,
                )

        return True, None

    async def _step_coverage(self, metrics: ExtendedTestMetrics, progress: Callable | None) -> None:
        if progress:
            progress("Step 1/9: Collecting coverage metrics…")
        should_run, reason = self._should_run_expensive_step("coverage")
        if not should_run:
            if progress:
                progress(f"Skipped coverage ({reason})")
            metrics.coverage = CoverageMetrics()
            return

        metrics.coverage = await self._collect_coverage_metrics(progress=progress)
        if progress and metrics.coverage.total_tests:
            progress(f"Discovered {metrics.coverage.total_tests} tests")

    async def _step_dependency(
        self, metrics: ExtendedTestMetrics, progress: Callable | None
    ) -> None:
        if progress:
            progress("Step 2/9: Evaluating dependency health…")
        step_start = time.time()
        metrics.dependency = await self._collect_dependency_metrics()
        metrics.performance.dependency_graph_ms = (time.time() - step_start) * 1000

    async def _step_security(self, metrics: ExtendedTestMetrics, progress: Callable | None) -> None:
        if progress:
            progress("Step 3/9: Scanning security indicators…")
        metrics.security = await self._collect_security_metrics()

    async def _step_sbom(self, metrics: ExtendedTestMetrics, progress: Callable | None) -> None:
        if progress:
            progress("Step 4/9: Assessing SBOM completeness…")
        metrics.sbom = await self._collect_sbom_metrics()

    async def _step_packaging(
        self, metrics: ExtendedTestMetrics, progress: Callable | None
    ) -> None:
        if progress:
            progress("Step 5/9: Checking packaging quality…")
        metrics.packaging = await self._collect_packaging_metrics()

    async def _step_policy(self, metrics: ExtendedTestMetrics, progress: Callable | None) -> None:
        if progress:
            progress("Step 6/9: Reviewing policy compliance…")
        metrics.policy = await self._collect_policy_metrics()

    async def _step_license(self, metrics: ExtendedTestMetrics, progress: Callable | None) -> None:
        if progress:
            progress("Step 7/9: Verifying license metadata…")
        metrics.license = await self._collect_license_metrics()

    async def _step_complexity(
        self, metrics: ExtendedTestMetrics, progress: Callable | None
    ) -> None:
        if progress:
            progress("Step 8/9: Analyzing code complexity…")
        should_run, reason = self._should_run_expensive_step("complexity")
        if not should_run:
            if progress:
                progress(f"Skipped complexity ({reason})")
            metrics.complexity = ComplexityMetrics()
            return

        metrics.complexity = await self._collect_complexity_metrics()

    async def _step_bugfixes(self, metrics: ExtendedTestMetrics, progress: Callable | None) -> None:
        if progress:
            progress("Step 9/9: Mining bugfix history…")
        should_run, reason = self._should_run_expensive_step("bugfixes")
        if not should_run:
            if progress:
                progress(f"Skipped bugfix history ({reason})")
            metrics.bugfixes = BugfixMetrics()
            return

        metrics.bugfixes = await self._collect_bugfix_metrics()

    async def _collect_all_metric_categories(
        self,
        metrics: ExtendedTestMetrics,
        progress: Callable | None,
    ) -> None:
        """Collect metrics from all 9 categories with progress reporting."""
        await self._step_coverage(metrics, progress)
        await asyncio.gather(
            self._step_dependency(metrics, progress),
            self._step_security(metrics, progress),
            self._step_sbom(metrics, progress),
            self._step_packaging(metrics, progress),
            self._step_policy(metrics, progress),
            self._step_license(metrics, progress),
        )
        await self._step_complexity(metrics, progress)
        await self._step_bugfixes(metrics, progress)

    async def collect_metrics(self, progress: Callable | None = None) -> ExtendedTestMetrics:
        """Collect all metrics across 8 categories with error isolation.

        Each metric category is collected independently. If one category fails,
        others continue and the error is logged to metrics.errors. This ensures
        partial results are always available.

        Returns:
            ExtendedTestMetrics containing all collected data and recommendations

        Raises:
            Never raises. All exceptions are caught and logged to metrics.errors

        Performance:
            Typical execution: 2-5 seconds for medium projects
            Large projects (1000+ files): 10-30 seconds

        """
        metrics = ExtendedTestMetrics(timestamp=datetime.now(timezone.utc).isoformat())
        perf_start = time.time()

        try:
            validation_metrics = run_manifest_validation_with_metrics(self.workspace_root)
            metrics.performance.manifest_parse_ms = validation_metrics.manifest_parse_ms
            metrics.performance.rule_engine_ms = validation_metrics.rule_engine_ms

            # If not provided by the caller, derive gate counts from the current
            # validation run (always available here).
            if self.gate_counts is None:
                vr = validation_metrics.result
                self.gate_counts = (
                    int(getattr(vr, "error_count", 0)),
                    int(getattr(vr, "warning_count", 0)),
                    int(getattr(vr, "info_count", 0)),
                )

            await self._collect_all_metric_categories(metrics, progress)

            # Performance metrics
            metrics.performance.total_analysis_ms = (time.time() - perf_start) * 1000

            # Generate recommendations
            if progress:
                progress("Generating AI recommendations…")
            metrics.recommendations = self._generate_recommendations(metrics)

            if self._threshold_gate_blocked_tests:
                blocked = ", ".join(sorted(self._threshold_gate_blocked_tests))
                detail = "; ".join(
                    f"{k}: {v}" for k, v in sorted(self._threshold_gate_details.items())
                )
                metrics.recommendations.insert(
                    0,
                    Recommendation(
                        category="gating",
                        id="threshold-gate-blocked-expensive-steps",
                        priority="high",
                        summary=(
                            "Threshold gate blocked expensive extended metrics "
                            f"({blocked})."
                        ),
                        proposed_fix=(
                            "Fix validation errors/warnings until thresholds are satisfied "
                            "(default: E=0 and W=0 unless configured otherwise), then rerun "
                            "`manifestguard check --extended` and address the extended findings "
                            "(coverage, complexity, bugfix history, duplication/redundancy, etc.). "
                            + (f" Gate details: {detail}" if detail else "")
                        ),
                        confidence=0.9,
                        effort_minutes=30,
                        impact_score=10,
                    ),
                )

            # Calculate quality score
            metrics.quality_score = self._calculate_quality_score(metrics)

        except Exception as exc:  # pragma: no cover - defensive guard
            logger.error("Extended metrics collection failed: %s", exc)
            logger.error(traceback.format_exc())
            metrics.errors.append(f"Collection failed: {exc!s}")

        return metrics

    # Intentionally complex for robust async coverage collection with multiple fallback paths
    # manifestguard-ignore-next-line: COMPLEXITY
    async def _collect_coverage_metrics(self, progress: Callable | None = None) -> CoverageMetrics:
        """Collect test coverage data from pytest/coverage (non-blocking via asyncio)."""
        return await collect_coverage_metrics(self.workspace_root, progress=progress)

    async def _collect_dependency_metrics(
        self, *, deep_analysis_mode: bool = True
    ) -> DependencyMetrics:
        """Collect dependency health data."""
        installed_packages = await self._get_installed_packages_snapshot()
        return await collect_dependency_metrics(
            self.workspace_root,
            deep_analysis_mode=deep_analysis_mode,
            installed_packages=installed_packages,
        )

    # Intentionally complex for comprehensive security scanning with inline-suppression support
    # manifestguard-ignore-next-line: COMPLEXITY
    async def _collect_security_metrics(self) -> SecurityMetrics:
        """Collect security risk indicators via static analysis"""
        return await asyncio.to_thread(_collect_security_metrics, self.workspace_root)

    async def _collect_sbom_metrics(self) -> SBOMMetrics:
        """Collect SBOM completeness data."""
        installed_packages = await self._get_installed_packages_snapshot()
        return await collect_sbom_metrics(self.workspace_root, installed_packages=installed_packages)

    async def _get_installed_packages_snapshot(self) -> list[dict[str, str]]:
        """Return installed packages snapshot for this run.

        This de-duplicates `pip list --format=json` between dependency and SBOM
        collection. The snapshot is best-effort; failures return an empty list.
        """

        async def _collect() -> list[dict[str, str]]:
            from .venv_packages_snapshot import get_venv_packages  # noqa: PLC0415

            try:
                return await asyncio.to_thread(
                    get_venv_packages,
                    Path(sys.executable),
                    timeout_seconds=15,
                )
            except Exception:
                return []

        if self._installed_packages_task is None:
            self._installed_packages_task = asyncio.create_task(_collect())
        return await self._installed_packages_task

    async def _collect_packaging_metrics(self) -> PackagingMetrics:
        """Collect packaging quality indicators."""
        return await collect_packaging_metrics(self.workspace_root)

    async def _collect_policy_metrics(self) -> PolicyMetrics:
        """Collect policy enforcement status."""
        return await collect_policy_metrics(self.workspace_root)

    async def _collect_license_metrics(self) -> LicenseMetrics:
        """Collect license consistency data"""
        def _build_license_metrics() -> LicenseMetrics:
            metrics = LicenseMetrics()

            license_files = ["LICENSE", "LICENSE.txt", "LICENSE.md"]
            metrics.license_file_missing = not any(
                (self.workspace_root / filename).exists() for filename in license_files
            )
            return metrics

        return await asyncio.to_thread(_build_license_metrics)

    def _read_complexity_settings_from_manifest(self) -> tuple[int, bool, str, int, int]:
        return _read_complexity_settings_from_manifest(self.workspace_root)

    async def _collect_complexity_metrics(self) -> ComplexityMetrics:
        """Collect cyclomatic complexity metrics using AST-based analyzer."""
        return await asyncio.to_thread(_collect_complexity_metrics, self.workspace_root)

    async def _collect_bugfix_metrics(self) -> BugfixMetrics:
        """Collect bugfix tracking metrics from git commit history.

        Analyzes commit messages since the start of the current month to detect
        bugfixes and calculate bugs per day (BPD) metric.

        Returns:
            BugfixMetrics with bugfix counts, BPD, and categorization

        """
        return await asyncio.to_thread(_collect_bugfix_metrics, self.workspace_root)

    def _calculate_coverage_penalty(self, coverage_percent: float) -> float:
        """Calculate coverage penalty (0-40 points).

        Args:
            coverage_percent: Unit test coverage percentage

        Returns:
            Penalty score (0-40)

        """
        if coverage_percent >= 80:
            return 0.0
        return (80 - coverage_percent) / 80 * 40

    def _calculate_security_penalty(self, metrics: ExtendedTestMetrics) -> float:
        """Calculate security penalty (0-30 points).

        Args:
            metrics: ExtendedTestMetrics with security data

        Returns:
            Penalty score (0-30)

        """
        penalty = 0.0

        if metrics.dependency.vulnerable_critical > 0:
            penalty += 30
        elif metrics.dependency.vulnerable_high > 0:
            penalty += min(20, metrics.dependency.vulnerable_high * 5)

        if metrics.security.unsafe_exec_count > 0:
            penalty += min(10, metrics.security.unsafe_exec_count * 2)

        if metrics.security.hardcoded_secrets > 0:
            penalty += min(10, metrics.security.hardcoded_secrets * 3)

        return min(30, penalty)

    def _calculate_dependency_penalty(self, outdated_count: int) -> float:
        """Calculate dependency penalty (0-15 points).

        Args:
            outdated_count: Number of outdated dependencies

        Returns:
            Penalty score (0-15)

        """
        if outdated_count > 20:
            return 15.0
        if outdated_count > 10:
            return 10.0
        if outdated_count > 5:
            return 5.0
        return 0.0

    def _calculate_quality_score(self, metrics: ExtendedTestMetrics) -> float:
        """Calculate overall quality score (0-100) based on weighted metrics.

        Scoring Formula:
            Base: 100 points
            - Coverage penalty: 0-40 points (weight: 40%)
            - Security penalty: 0-30 points (weight: 30%)
            - Dependency penalty: 0-15 points (weight: 15%)
            - Complexity penalty: 0-10 points (weight: 10%)
            - Test failures penalty: 0-5 points (weight: 5%)

        Args:
            metrics: ExtendedTestMetrics with all collected data

        Returns:
            float: Quality score 0.0-100.0

        Examples:
            >>> # Perfect project: 100%
            >>> metrics = ExtendedTestMetrics(...)
            >>> metrics.coverage.unit_percent = 90
            >>> metrics.security.unsafe_exec_count = 0
            >>> score = collector._calculate_quality_score(metrics)
            >>> score >= 95.0
            True

            >>> # Critical issues: <50%
            >>> metrics.security.unsafe_exec_count = 5
            >>> metrics.dependency.vulnerable_critical = 2
            >>> score = collector._calculate_quality_score(metrics)
            >>> score < 50.0
            True

        """
        score = 100.0

        # Apply penalties
        if metrics.coverage.unit_measured:
            score -= self._calculate_coverage_penalty(metrics.coverage.unit_percent)
        score -= self._calculate_security_penalty(metrics)
        score -= self._calculate_dependency_penalty(metrics.dependency.outdated_count)

        # Complexity penalty (10% weight)
        if metrics.complexity and metrics.complexity.violations_count > 0:
            score -= min(10, metrics.complexity.violations_count * 2)

        # Test failures penalty (5% weight)
        if metrics.coverage.failing_tests > 0:
            score -= 5

        # Bonuses
        if metrics.coverage.unit_measured and metrics.coverage.unit_percent >= 90:
            score += 5
        if metrics.packaging.has_py_typed:
            score += 2

        return round(max(0.0, min(100.0, score)), 1)


def export_metrics_history(
    workspace_root: Path,
    metrics: "ExtendedTestMetrics",
    mgpy_version: str | None = None,
    scan_space_summary: Any | None = None,
) -> None:
    """Export metrics history for dashboards.

    Kept here for backwards-compatible import path:
    `from manifestguard.extended.metrics import export_metrics_history`.
    """
    _export_metrics_history(workspace_root, metrics, mgpy_version, scan_space_summary)
