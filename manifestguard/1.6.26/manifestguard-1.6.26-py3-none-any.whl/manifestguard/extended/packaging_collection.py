"""Packaging quality collection used by extended metrics."""

from __future__ import annotations

import asyncio
import logging
from pathlib import Path
from typing import TYPE_CHECKING

from .filesystem_safety import safe_rglob

if TYPE_CHECKING:
    from .metrics import PackagingMetrics

logger = logging.getLogger(__name__)


def _collect_packaging_metrics_sync(workspace_root: Path) -> PackagingMetrics:
    """Collect packaging quality indicators (best-effort)."""
    from .metrics import PackagingMetrics  # noqa: PLC0415 - avoid circular import

    metrics = PackagingMetrics()

    try:
        src_dir = workspace_root / "src"
        if src_dir.exists():
            py_typed = safe_rglob(src_dir, "py.typed", max_files=1)
            metrics.has_py_typed = len(py_typed) > 0

        readme_files = ["README.md", "README.rst", "README.txt"]
        metrics.readme_present = any((workspace_root / r).exists() for r in readme_files)

        license_files = ["LICENSE", "LICENSE.txt", "LICENSE.md"]
        metrics.license_present = any(
            (workspace_root / filename).exists() for filename in license_files
        )

        pyproject = workspace_root / "pyproject.toml"
        if pyproject.exists():
            content = pyproject.read_text(encoding="utf-8")
            if "classifiers" not in content:
                metrics.missing_classifiers.append("No classifiers defined in pyproject.toml")

    except Exception as exc:
        logger.debug("Packaging metrics collection failed: %s", exc)

    return metrics


async def collect_packaging_metrics(workspace_root: Path) -> PackagingMetrics:
    """Collect packaging quality indicators (best-effort)."""
    return await asyncio.to_thread(_collect_packaging_metrics_sync, workspace_root)
