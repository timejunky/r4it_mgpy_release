from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any

from manifestguard.validation.inline_markers import is_line_suppressed

from .complexity import ComplexityAnalyzer

logger = logging.getLogger(__name__)


def _coerce_int(value: Any, default: int) -> int:
    return int(value) if isinstance(value, int) else default


def _coerce_bool(value: Any, default: bool) -> bool:
    return bool(value) if isinstance(value, bool) else default


def _coerce_nonempty_str(value: Any, default: str) -> str:
    if isinstance(value, str) and value:
        return str(value)
    return default


def _coerce_pos_int(value: Any, default: int) -> int:
    if isinstance(value, int) and value > 0:
        return int(value)
    return default


def _select_complexity_config(raw: dict[str, Any]) -> dict[str, Any]:
    checks = raw.get("checks")
    if isinstance(checks, dict) and isinstance(checks.get("complexity"), dict):
        return checks.get("complexity") or {}
    if isinstance(raw.get("complexity"), dict):
        return raw.get("complexity") or {}
    return {}


def read_complexity_settings_from_manifest(
    workspace_root: Path,
) -> tuple[int, bool, str, int, int]:
    threshold = 10
    include_tests = False
    engine = "mgpy-analyzer"
    # File-length thresholds (LOC-based):
    # - "high" once high threshold exceeded
    # - "critical" once critical threshold exceeded
    # Defaults tuned for AI reviewability:
    # In practice, assistant quality often starts degrading around ~600 LOC,
    # is usually still acceptable around ~800 LOC, and becomes notably risky
    # beyond ~1200 LOC in complex modules.
    # These are heuristics (not hard limits) and are fully configurable.
    max_file_lines_high = 600
    max_file_lines_critical = 1200
    try:
        config_path = workspace_root / "manifestguard.json"
        if not config_path.exists():
            return (threshold, include_tests, engine, max_file_lines_high, max_file_lines_critical)

        raw_obj = json.loads(config_path.read_text(encoding="utf-8"))
        if not isinstance(raw_obj, dict):
            return (threshold, include_tests, engine, max_file_lines_high, max_file_lines_critical)

        cc = _select_complexity_config(raw_obj)

        threshold = _coerce_int(cc.get("threshold"), threshold)
        include_tests = _coerce_bool(cc.get("includeTests"), include_tests)
        engine = _coerce_nonempty_str(cc.get("engine"), engine)

        # Backward-compatible alias: maxFileLines == high threshold.
        max_file_lines_high = _coerce_pos_int(cc.get("maxFileLines"), max_file_lines_high)
        max_file_lines_high = _coerce_pos_int(cc.get("maxFileLinesHigh"), max_file_lines_high)
        max_file_lines_critical = _coerce_pos_int(
            cc.get("maxFileLinesCritical"),
            max_file_lines_critical,
        )

        if max_file_lines_critical < max_file_lines_high:
            max_file_lines_critical = max_file_lines_high
    except Exception:
        pass
    return (threshold, include_tests, engine, max_file_lines_high, max_file_lines_critical)


def normalize_complexity_engine(engine: str | None) -> str:
    normalized = (engine or "mgpy-analyzer").strip().lower()
    if normalized == "mgpy":
        normalized = "mgpy-analyzer"
    if normalized not in {"mgpy-analyzer", "radon"}:
        normalized = "mgpy-analyzer"
    return normalized


def run_complexity_analysis(
    *,
    analyzer: ComplexityAnalyzer,
    threshold: int,
    include_tests: bool,
    engine: str,
    max_file_lines_high: int,
) -> tuple[Any, str]:
    try:
        result = analyzer.analyze(
            threshold=threshold,
            include_tests=include_tests,
            engine=engine,
            max_file_lines=max_file_lines_high,
        )
        return (result, engine)
    except ImportError as exc:
        logger.warning(
            f"Complexity engine '{engine}' unavailable: {exc}. Falling back to mgpy-analyzer.",
        )
        engine = "mgpy-analyzer"
        result = analyzer.analyze(
            threshold=threshold,
            include_tests=include_tests,
            engine=engine,
            max_file_lines=max_file_lines_high,
        )
        return (result, engine)


def filter_complexity_violations_by_suppression(
    workspace_root: Path,
    violations: list[Any],
) -> list[Any]:
    try:
        filtered: list[Any] = []
        for violation in violations:
            full_path = (workspace_root / violation.file_path).resolve()
            if not is_line_suppressed(full_path, violation.line_number, "COMPLEXITY"):
                filtered.append(violation)
        return filtered
    except Exception:
        return list(violations)


def serialize_top_complexity_violations(violations: list[Any]) -> list[dict[str, Any]]:
    top_5 = sorted(violations, key=lambda v: v.complexity, reverse=True)[:5]
    return [
        {
            "function": v.function_name,
            "file": v.file_path,
            "line": v.line_number,
            "complexity": v.complexity,
            "rank": v.rank,
        }
        for v in top_5
    ]


def populate_complexity_metrics(
    *,
    metrics_data: Any,
    result: Any,
    filtered_violations: list[Any],
    engine: str,
) -> None:
    metrics_data.violations_count = len(filtered_violations)
    metrics_data.average_complexity = result.average_complexity
    metrics_data.max_complexity = result.max_complexity
    metrics_data.files_scanned = result.files_scanned
    metrics_data.threshold = result.threshold
    metrics_data.engine = getattr(result, "engine", engine)
    metrics_data.engine_version = getattr(result, "engine_version", None)
    metrics_data.top_violations = serialize_top_complexity_violations(filtered_violations)

    # Optional: file-size hotspots (LOC-based). Keep best-effort and tolerant of older payloads.
    metrics_data.max_file_lines_threshold = getattr(result, "max_file_lines_threshold", None)
    metrics_data.max_file_lines_observed = int(getattr(result, "max_file_lines_observed", 0) or 0)

    oversized_files = list(getattr(result, "oversized_files", []) or [])
    metrics_data.oversized_files_count = len(oversized_files)

    # Serialize a small, safe subset for reporting.
    top = sorted(
        oversized_files,
        key=lambda x: int(getattr(x, "line_count", 0) or 0),
        reverse=True,
    )[:10]
    metrics_data.oversized_files = [
        {
            "file": getattr(f, "file_path", ""),
            "lines": int(getattr(f, "line_count", 0) or 0),
            "threshold": int(getattr(f, "threshold", 0) or 0),
        }
        for f in top
        if getattr(f, "file_path", None)
    ]


def collect_complexity_metrics(workspace_root: Path):
    """Collect cyclomatic complexity metrics using AST-based analyzer."""

    # Import lazily to avoid circular imports at module load time.
    from .metrics import ComplexityMetrics  # noqa: PLC0415

    metrics_data = ComplexityMetrics()

    threshold, include_tests, engine_raw, max_file_lines_high, _max_file_lines_critical = (
        read_complexity_settings_from_manifest(workspace_root)
    )
    engine = normalize_complexity_engine(engine_raw)

    try:
        analyzer = ComplexityAnalyzer(workspace_root)
        result, engine = run_complexity_analysis(
            analyzer=analyzer,
            threshold=threshold,
            include_tests=include_tests,
            engine=engine,
            max_file_lines_high=max_file_lines_high,
        )

        filtered_violations = filter_complexity_violations_by_suppression(
            workspace_root,
            list(result.violations),
        )

        populate_complexity_metrics(
            metrics_data=metrics_data,
            result=result,
            filtered_violations=filtered_violations,
            engine=engine,
        )

        logger.info(
            f"Complexity analysis: {metrics_data.violations_count} violations, "
            f"avg: {metrics_data.average_complexity:.1f}, max: {metrics_data.max_complexity}",
        )

    except Exception as exc:  # pragma: no cover - best-effort
        logger.debug(f"Complexity metrics collection failed: {exc}")

    return metrics_data
