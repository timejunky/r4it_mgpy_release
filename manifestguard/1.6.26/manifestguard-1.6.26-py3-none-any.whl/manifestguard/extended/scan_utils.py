"""Shared file-scanning helpers for extended metrics.

This module centralizes ignore-pattern loading and path-skip decisions so that
individual analyzers (typing/docs/style/security) can stay small and focused.
"""

from __future__ import annotations

import logging
from pathlib import Path

logger = logging.getLogger(__name__)


def load_ignore_patterns(workspace_root: Path) -> set[str]:
    """Load ignore patterns from common ignore files.

    Sources:
    - built-in defaults (venv, caches, node_modules, etc.)
    - .gitignore, .vsignore, .cvsignore, .svnignore, .hgignore
    """
    patterns: set[str] = set()

    default_patterns = [
        "__pycache__",
        "*.pyc",
        "*.pyo",
        "*.pyd",
        ".Python",
        "build/",
        "develop-eggs/",
        "dist/",
        "downloads/",
        "eggs/",
        ".eggs/",
        "lib/",
        "lib64/",
        "parts/",
        "sdist/",
        "var/",
        "wheels/",
        "*.egg-info/",
        ".installed.cfg",
        "*.egg",
        "venv/",
        ".venv/",
        "ENV/",
        "env/",
        "site-packages/",
        ".git/",
        ".svn/",
        ".cvs/",
        ".hg/",
        "node_modules/",
        ".pytest_cache/",
        ".coverage",
        "htmlcov/",
        ".tox/",
        ".mypy_cache/",
        ".ruff_cache/",

        # GFVS leak report artifacts (expected to contain absolute paths as telemetry)
        "gistfactor-leak-check.json",
        "gistfactor-leak-check-overview.json",
        "gistfactor-leak-capture.json",
        "gistfactor-leak-capture-overview.json",
    ]
    patterns.update(default_patterns)

    ignore_files = [".gitignore", ".vsignore", ".cvsignore", ".svnignore", ".hgignore"]

    for ignore_file_name in ignore_files:
        ignore_file = workspace_root / ignore_file_name
        if not ignore_file.exists():
            continue

        try:
            content = ignore_file.read_text(encoding="utf-8")
            for raw_line in content.split("\n"):
                stripped = raw_line.strip()
                if stripped and not stripped.startswith("#"):
                    patterns.add(stripped)
        except UnicodeDecodeError as exc:
            logger.debug(
                "Could not read %s due to decode error: %s",
                ignore_file_name,
                exc,
            )
        except Exception as exc:  # pragma: no cover - defensive guard
            logger.debug("Could not read %s: %s", ignore_file_name, exc)

    return patterns


def _pattern_matches_path(pattern: str, path: Path, path_str: str, rel_path: str) -> bool:
    # Direct substring match
    if pattern in path_str or pattern in rel_path:
        return True

    # Directory pattern (ends with /)
    if pattern.endswith("/"):
        needle = pattern.rstrip("/")
        return needle in path_str or needle in rel_path

    # Extension pattern (*.ext)
    if pattern.startswith("*."):
        return path.suffix == pattern[1:]

    # Wildcard suffix (*pattern)
    if pattern.startswith("*"):
        return path.name.endswith(pattern[1:])

    # Prefix wildcard (pattern*)
    if pattern.endswith("*"):
        return path.name.startswith(pattern[:-1])

    return False


def should_skip_path(path: Path, patterns: set[str], workspace_root: Path) -> bool:
    """Return True if path should be skipped based on ignore patterns."""
    path_str = str(path)

    try:
        rel_path = str(path.relative_to(workspace_root))
    except ValueError:
        rel_path = path_str

    return any(_pattern_matches_path(p, path, path_str, rel_path) for p in patterns)
