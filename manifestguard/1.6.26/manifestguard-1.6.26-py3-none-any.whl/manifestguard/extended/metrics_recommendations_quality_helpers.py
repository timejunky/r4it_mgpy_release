from __future__ import annotations

from pathlib import Path

from .documentation_coverage import analyze_documentation
from .scan_utils import load_ignore_patterns, should_skip_path
from .style_checks import check_pep8_violations, check_style_consistency
from .typing_coverage import analyze_type_hints
from .weak_crypto_check import check_weak_crypto


class _MetricsRecommendationsQualityHelpersMixin:
    def _load_ignore_patterns(self) -> set[str]:
        """Load ignore patterns for file scanning."""
        return load_ignore_patterns(self.workspace_root)

    def _should_skip_path(self, path: Path, patterns: set[str]) -> bool:
        """Return True if a path should be skipped based on ignore patterns."""
        return should_skip_path(path, patterns, self.workspace_root)

    def _analyze_type_hints(self) -> dict:
        """Analyze type hint coverage using AST parsing (best-effort)."""
        return analyze_type_hints(self.workspace_root)

    def _analyze_documentation(self) -> dict:
        """Analyze documentation coverage (docstrings) (best-effort)."""
        return analyze_documentation(self.workspace_root)

    def _check_pep8_violations(self) -> dict:
        """Check PEP 8 style violations (best-effort)."""
        return check_pep8_violations(self.workspace_root)

    def _check_style_consistency(self) -> dict:
        """Check code style consistency (best-effort)."""
        return check_style_consistency(self.workspace_root)

    def _check_weak_crypto(self) -> dict:
        """Check for weak cryptographic algorithms (best-effort)."""
        return check_weak_crypto(self.workspace_root)
