from __future__ import annotations

import json
from collections.abc import Iterable
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .complexity_models import ComplexityMetrics


def serialize_complexity_metrics(
    metrics: ComplexityMetrics,
    recommendations: Iterable[str],
) -> dict[str, Any]:
    """Serialize metrics and recommendations into JSON-friendly structure."""
    top_functions = [
        {
            "rank": idx + 1,
            "name": violation.function_name,
            "file": violation.file_path,
            "line": violation.line_number,
            "complexity": violation.complexity,
            "grade": violation.rank,
            "threshold": violation.threshold,
        }
        for idx, violation in enumerate(
            sorted(metrics.violations, key=lambda item: item.complexity, reverse=True),
        )
    ]

    return {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "source": "manifestguard.extended.complexity",
        "complexity": {
            "violations": metrics.violations_count,
            "files_scanned": metrics.files_scanned,
            "max_complexity": metrics.max_complexity,
            "avg_complexity": metrics.average_complexity,
            "average_complexity": metrics.average_complexity,
            "threshold": metrics.threshold,
            "total_functions": metrics.total_functions,
            "engine": metrics.engine,
            "engineVersion": metrics.engine_version,
            "top_functions": top_functions,
            "maxFileLinesThreshold": metrics.max_file_lines_threshold,
            "maxFileLinesObserved": metrics.max_file_lines_observed,
            "oversizedFiles": [
                {
                    "file": f.file_path,
                    "lines": f.line_count,
                    "threshold": f.threshold,
                }
                for f in sorted(metrics.oversized_files, key=lambda x: x.line_count, reverse=True)[:10]
            ],
        },
        "recommendations": list(recommendations),
    }


def write_metrics_file(payload: dict[str, Any], output_path: Path) -> Path:
    """Write metrics payload to disk and return the path."""
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    return output_path
