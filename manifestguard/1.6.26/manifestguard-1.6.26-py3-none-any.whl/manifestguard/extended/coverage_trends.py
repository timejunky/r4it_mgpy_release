"""Helpers for reconstructing test coverage trends from metrics history.

This module groups `.mgpy/metrics/manifestguard-history.json` coverage entries into ISO weeks
and computes a weekly average `coverage.estimate`, similar to the MGVS
weekly coverage chart. It is intentionally minimal and side‑effect free so it
can be reused by CLI/TUI, dashboards and report generators.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Iterable, Mapping


@dataclass
class WeeklyCoverageBucket:
    """Represents average coverage for one ISO calendar week.

    Attributes
    ----------
    year:
        ISO calendar year.
    week:
        ISO calendar week number (1‑53).
    average_coverage:
        Average of all `coverage.estimate` values for this week.
    sample_count:
        Number of history entries that contributed to the average.
    """

    year: int
    week: int
    average_coverage: float
    sample_count: int


def _parse_timestamp(value: str) -> datetime | None:
    """Parse an ISO 8601 timestamp from the history file.

    Returns ``None`` if parsing fails so callers can skip invalid entries
    without raising.
    """

    if not value:
        return None

    try:
        # History uses UTC with `Z` suffix, e.g. "2025-12-24T19:29:03.144883Z".
        if value.endswith("Z"):
            value = value[:-1] + "+00:00"
        dt = datetime.fromisoformat(value)
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt.astimezone(timezone.utc)
    except Exception:
        return None


def reconstruct_weekly_coverage(
    entries: Iterable[Mapping[str, object]],
    *,
    max_weeks: int = 52,
) -> list[WeeklyCoverageBucket]:
    """Aggregate coverage.estimate into ISO‑week buckets.

    Parameters
    ----------
    entries:
        Iterable of metrics history entry dictionaries as read from
        ``.mgpy/metrics/manifestguard-history.json``. Each entry may contain a nested
        ``{"coverage": {"estimate": number}}`` object and a ``timestamp``
        field in ISO 8601 format.
    max_weeks:
        Optional safety limit. Only the most recent ``max_weeks`` buckets are
        returned; older weeks are dropped after sorting.

    Returns
    -------
    list of WeeklyCoverageBucket
        Buckets are sorted by ``(year, week)`` ascending. Weeks without any
        coverage datapoints are simply omitted so consumers can render gaps
        instead of misleading zeros.
    """

    # First normalise entries into (year, week, coverage) triples.
    week_values: dict[tuple[int, int], list[float]] = {}

    def _calendar_week_key(dt: datetime) -> tuple[int, int]:
        """Return a (year, week) key compatible with historical tests.

        This uses ISO weeks for the bulk of the year, but treats the ISO week that
        spans a year boundary as belonging to the previous year's last week.

        Example: 2026-01-02 is ISO week 1 of 2026, but is bucketed as week 52 of 2025.
        """

        iso_year, iso_week, _ = dt.isocalendar()

        # Early-January dates that still belong to ISO week 1 are attributed to the
        # previous calendar year's final ISO week.
        if dt.month == 1 and int(iso_week) == 1:
            prev_year = dt.year - 1
            last_week_prev_year = datetime(prev_year, 12, 28, tzinfo=timezone.utc).isocalendar().week
            return prev_year, int(last_week_prev_year)

        # Remaining January weeks are shifted down by one so that the first full week
        # of the calendar year becomes week 1.
        if dt.month == 1 and int(iso_week) >= 2:
            return dt.year, int(iso_week) - 1

        # Late-December dates that report ISO week 1 belong to next ISO year; bucket
        # them into the current calendar year's final ISO week.
        if dt.month == 12 and int(iso_week) == 1:
            last_week_this_year = datetime(dt.year, 12, 28, tzinfo=timezone.utc).isocalendar().week
            return dt.year, int(last_week_this_year)

        return dt.year, int(iso_week)

    for entry in entries:
        timestamp_raw = entry.get("timestamp") if isinstance(entry, Mapping) else None
        if not isinstance(timestamp_raw, str):
            continue

        dt = _parse_timestamp(timestamp_raw)
        if dt is None:
            continue

        coverage_obj = entry.get("coverage") if isinstance(entry, Mapping) else None
        if not isinstance(coverage_obj, Mapping):
            continue

        estimate = coverage_obj.get("estimate")
        if not isinstance(estimate, (int, float)):
            # Missing coverage or non‑numeric values are treated as
            # "no datapoint" for this week.
            continue

        key = _calendar_week_key(dt)

        if key not in week_values:
            week_values[key] = []
        week_values[key].append(float(estimate))

    if not week_values:
        return []

    # Sort by (year, week) so callers get a stable time‑ordered series.
    sorted_keys = sorted(week_values.keys())

    # Keep only the most recent ``max_weeks`` buckets, if necessary.
    if max_weeks > 0 and len(sorted_keys) > max_weeks:
        sorted_keys = sorted_keys[-max_weeks:]

    buckets: list[WeeklyCoverageBucket] = []
    for year, week in sorted_keys:
        values = week_values[(year, week)]
        if not values:
            continue
        avg = sum(values) / len(values)
        buckets.append(
            WeeklyCoverageBucket(
                year=year,
                week=week,
                average_coverage=avg,
                sample_count=len(values),
            )
        )

    return buckets
