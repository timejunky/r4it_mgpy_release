from __future__ import annotations

import contextlib
import time
from dataclasses import dataclass
from pathlib import Path

from manifestguard.core.config import ConfigurationService
from manifestguard.validation import DependencyConflictChecker
from manifestguard.validation import DependencyLicensePolicyValidator
from manifestguard.validation import DependencyPolicyValidator
from manifestguard.validation import EntryPointValidator
from manifestguard.validation import LicenseGuardrailValidator
from manifestguard.validation import PyprojectValidator
from manifestguard.validation import RequirementsValidator
from manifestguard.validation import SetupPyValidator
from manifestguard.validation import ValidationResult
from manifestguard.validation.inline_markers import filter_result_with_inline_markers


@dataclass
class ValidationRuntimeMetrics:
    result: ValidationResult
    manifest_parse_ms: float
    rule_engine_ms: float


def run_manifest_validation_with_metrics(workspace_root: Path) -> ValidationRuntimeMetrics:
    """Run manifest validation and capture coarse timing buckets for reporting."""
    combined_result = ValidationResult()

    manifest_parse_ms = 0.0
    rule_engine_ms = 0.0

    config_start = time.perf_counter()
    try:
        cfg = ConfigurationService(workspace_root).get_config()
        dependency_rules = cfg.dependency_rules or {}
    except Exception:
        dependency_rules = {}
    manifest_parse_ms += (time.perf_counter() - config_start) * 1000

    manifest_validators = [
        PyprojectValidator(workspace_root),
        SetupPyValidator(workspace_root),
        RequirementsValidator(workspace_root),
        EntryPointValidator(workspace_root),
    ]
    rule_validators = [
        LicenseGuardrailValidator(workspace_root),
        DependencyConflictChecker(workspace_root),
        DependencyPolicyValidator(workspace_root, config=dependency_rules),
        DependencyLicensePolicyValidator(workspace_root, config=dependency_rules),
    ]

    for validator in manifest_validators:
        start = time.perf_counter()
        result = validator.validate()
        manifest_parse_ms += (time.perf_counter() - start) * 1000
        combined_result.merge(result)

    for validator in rule_validators:
        start = time.perf_counter()
        result = validator.validate()
        rule_engine_ms += (time.perf_counter() - start) * 1000
        combined_result.merge(result)

    filter_start = time.perf_counter()
    with contextlib.suppress(Exception):
        combined_result = filter_result_with_inline_markers(combined_result)
    rule_engine_ms += (time.perf_counter() - filter_start) * 1000

    return ValidationRuntimeMetrics(
        result=combined_result,
        manifest_parse_ms=round(manifest_parse_ms, 3),
        rule_engine_ms=round(rule_engine_ms, 3),
    )