"""Dependency policy enforcement (allowlist/denylist).

This validator is intentionally only active when dependencyRules are configured.

Config format (manifestguard.json -> dependencyRules):

{
  "dependencyRules": {
    "allowlist": ["requests", "pydantic"],
    "denylist": ["django"],
    "includeOptionalDependencies": true,
    "includeRequirementsFiles": true,
    "includeSetupPy": true,
    "allowlistSeverity": "warning",
    "denylistSeverity": "error"
  }
}
"""

from __future__ import annotations

import ast
import logging
from collections.abc import Iterable
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from packaging.requirements import InvalidRequirement, Requirement

from .base import DiagnosticSeverity, ManifestValidator, ValidationResult

logger = logging.getLogger(__name__)


def _load_pyproject_toml(pyproject_path: Path) -> dict[str, Any] | None:
    try:
        import sys  # noqa: PLC0415 - version check for tomllib availability

        if sys.version_info >= (3, 11):
            import tomllib  # noqa: PLC0415 - version-specific import (3.11+)
        else:
            import tomli as tomllib  # noqa: PLC0415 - backport for <3.11

        with pyproject_path.open("rb") as handle:
            data = tomllib.load(handle)
    except Exception:
        return None

    return data if isinstance(data, dict) else None


def _iter_pyproject_dependency_strings(
    project: dict[str, Any],
    *,
    include_optional: bool,
) -> Iterable[str]:
    deps = project.get("dependencies")
    if isinstance(deps, list):
        for raw in deps:
            if isinstance(raw, str):
                yield raw

    if not include_optional:
        return

    optional = project.get("optional-dependencies")
    if not isinstance(optional, dict):
        return

    for _group, items in optional.items():
        if not isinstance(items, list):
            continue
        for raw in items:
            if isinstance(raw, str):
                yield raw


@dataclass(frozen=True)
class _DeclaredDependency:
    name: str
    requirement: str
    file_path: Path
    line: int | None = None


class DependencyPolicyValidator(ManifestValidator):
    """Enforce declared dependency policies.

    Diagnostic Codes:
    - POL-DEP-001: Allowlist violation (dependency not allowed)
    - POL-DEP-002: Denylist violation (dependency explicitly blocked)
    """

    def validate(self) -> ValidationResult:
        result = ValidationResult()

        rules = self.config or {}
        allowlist = _normalize_list(rules.get("allowlist"))
        denylist = _normalize_list(rules.get("denylist"))

        if not allowlist and not denylist:
            return result

        include_optional = bool(rules.get("includeOptionalDependencies", True))
        include_requirements = bool(rules.get("includeRequirementsFiles", True))
        include_setup_py = bool(rules.get("includeSetupPy", True))

        allow_severity = _parse_severity(
            rules.get("allowlistSeverity"), default=DiagnosticSeverity.WARNING
        )
        deny_severity = _parse_severity(
            rules.get("denylistSeverity"), default=DiagnosticSeverity.ERROR
        )

        declared = list(
            self._collect_declared_dependencies(
                include_optional=include_optional,
                include_requirements=include_requirements,
                include_setup_py=include_setup_py,
            )
        )

        seen: set[tuple[str, str, str, int | None]] = set()
        for dep in declared:
            dep_name = dep.name

            if denylist and dep_name in denylist:
                key = ("POL-DEP-002", dep_name, str(dep.file_path), dep.line)
                if key in seen:
                    continue
                seen.add(key)
                result.add_diagnostic(
                    self._create_diagnostic(
                        code="POL-DEP-002",
                        message=(
                            f"Dependency '{dep_name}' is blocked by denylist policy "
                            f"({dep.file_path.name}{_fmt_line(dep.line)})."
                        ),
                        severity=deny_severity,
                        file_path=dep.file_path,
                        line=dep.line,
                        fix_suggestion="Remove the dependency or replace it with an allowed alternative.",
                        data={"dependency": dep_name, "policy": "denylist"},
                    )
                )
                continue

            if allowlist and dep_name not in allowlist:
                key = ("POL-DEP-001", dep_name, str(dep.file_path), dep.line)
                if key in seen:
                    continue
                seen.add(key)
                result.add_diagnostic(
                    self._create_diagnostic(
                        code="POL-DEP-001",
                        message=(
                            f"Dependency '{dep_name}' is not allowed by allowlist policy "
                            f"({dep.file_path.name}{_fmt_line(dep.line)})."
                        ),
                        severity=allow_severity,
                        file_path=dep.file_path,
                        line=dep.line,
                        fix_suggestion="Add the dependency to allowlist or remove it from manifests.",
                        data={"dependency": dep_name, "policy": "allowlist"},
                    )
                )

        return result

    def _collect_declared_dependencies(
        self,
        *,
        include_optional: bool,
        include_requirements: bool,
        include_setup_py: bool,
    ) -> Iterable[_DeclaredDependency]:
        yield from self._collect_from_pyproject(include_optional=include_optional)

        if include_requirements:
            yield from self._collect_from_requirements_files()

        if include_setup_py:
            yield from self._collect_from_setup_py()

    def _collect_from_pyproject(self, *, include_optional: bool) -> Iterable[_DeclaredDependency]:
        pyproject_path = self.project_root / "pyproject.toml"
        if not pyproject_path.exists():
            return

        data = _load_pyproject_toml(pyproject_path)
        if not data:
            return

        project = data.get("project")
        if not isinstance(project, dict):
            return

        for raw in _iter_pyproject_dependency_strings(project, include_optional=include_optional):
            req = _parse_requirement(raw)
            if req is None:
                continue
            yield _DeclaredDependency(
                name=req.name.lower(),
                requirement=raw,
                file_path=pyproject_path,
                line=None,
            )

    def _collect_from_requirements_files(self) -> Iterable[_DeclaredDependency]:
        files = [
            "requirements.txt",
            "requirements-dev.txt",
            "requirements-test.txt",
        ]

        for filename in files:
            path = self.project_root / filename
            if not path.exists():
                continue

            try:
                lines = path.read_text(encoding="utf-8").splitlines()
            except Exception as e:
                logger.debug(f"Failed to read {filename}: {e}")
                continue

            for line_no, line in enumerate(lines, start=1):
                stripped = line.strip()
                if not stripped or stripped.startswith("#"):
                    continue
                if stripped.startswith("-"):
                    continue

                req = _parse_requirement(stripped)
                if req is None:
                    continue

                yield _DeclaredDependency(
                    name=req.name.lower(),
                    requirement=stripped,
                    file_path=path,
                    line=line_no,
                )

    def _collect_from_setup_py(self) -> Iterable[_DeclaredDependency]:
        setup_path = self.project_root / "setup.py"
        if not setup_path.exists():
            return

        try:
            content = setup_path.read_text(encoding="utf-8")
            tree = ast.parse(content, filename=str(setup_path))
        except Exception:
            return

        install_requires: list[str] = []
        for node in ast.walk(tree):
            if not isinstance(node, ast.Call):
                continue
            func_name = _get_call_name(node.func)
            if func_name != "setup":
                continue
            for keyword in node.keywords:
                if keyword.arg != "install_requires":
                    continue
                value = _extract_string_list(keyword.value)
                if value:
                    install_requires.extend(value)

        for raw in install_requires:
            req = _parse_requirement(raw)
            if req is None:
                continue
            yield _DeclaredDependency(
                name=req.name.lower(),
                requirement=raw,
                file_path=setup_path,
                line=None,
            )


def _parse_requirement(raw: str) -> Requirement | None:
    try:
        return Requirement(raw)
    except InvalidRequirement:
        return None


def _normalize_list(value: Any) -> set[str]:
    if not value:
        return set()
    if not isinstance(value, list):
        return set()
    out: set[str] = set()
    for item in value:
        if isinstance(item, str) and item.strip():
            out.add(item.strip().lower())
    return out


def _parse_severity(value: Any, *, default: DiagnosticSeverity) -> DiagnosticSeverity:
    if isinstance(value, str):
        v = value.strip().lower()
        for sev in DiagnosticSeverity:
            if sev.value == v:
                return sev
    return default


def _fmt_line(line: int | None) -> str:
    return f":{line}" if line else ""


def _get_call_name(node: ast.expr) -> str | None:
    if isinstance(node, ast.Name):
        return node.id
    if isinstance(node, ast.Attribute):
        return node.attr
    return None


def _extract_string_list(node: ast.expr) -> list[str]:
    if isinstance(node, (ast.List, ast.Tuple)):
        out: list[str] = []
        for el in node.elts:
            if isinstance(el, ast.Constant) and isinstance(el.value, str):
                out.append(el.value)
        return out
    return []
