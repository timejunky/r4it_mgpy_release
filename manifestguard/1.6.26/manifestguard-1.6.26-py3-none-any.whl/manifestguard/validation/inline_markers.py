"""Inline ignore markers for diagnostics.

Supported comment directives (TOML/Python/requirements use '#'):

- "# manifestguard-ignore-line: CODE1, CODE2" → ignores listed codes for that line
- "# manifestguard-ignore-next-line: CODE" → ignores listed codes on the following line

Special values "all" or "*" ignore any diagnostic code for the targeted line.

This module provides helpers to parse markers once per file and filter
`Diagnostic` items accordingly. Intended to be used as a post-processing step
on `ValidationResult`.
"""

from __future__ import annotations

import re
from collections.abc import Iterable
from dataclasses import dataclass
from pathlib import Path

from .base import Diagnostic, ValidationResult

_RE_IGNORE_LINE = re.compile(r"#\s*manifestguard-ignore-line\s*:\s*(?P<codes>.+)", re.IGNORECASE)
_RE_IGNORE_NEXT = re.compile(
    r"#\s*manifestguard-ignore-next-line\s*:\s*(?P<codes>.+)", re.IGNORECASE
)


@dataclass
class _FileMarkers:
    # Maps line number to codes ignored on that line
    ignore_on_line: dict[int, set[str]]


def _normalize_codes(raw: str) -> set[str]:
    parts = [p.strip() for p in raw.split(",") if p.strip()]
    codes = {part.upper() for part in parts}
    # also support whitespace-separated single code lists
    if not codes and raw.strip():
        codes = {raw.strip().upper()}
    return codes


def _parse_markers_for_file(path: Path) -> _FileMarkers:
    ignore_on_line: dict[int, set[str]] = {}
    try:
        with path.open("r", encoding="utf-8", errors="replace") as fh:
            for idx, line in enumerate(fh, start=1):
                m_line = _RE_IGNORE_LINE.search(line)
                if m_line:
                    codes = _normalize_codes(m_line.group("codes"))
                    ignore_on_line[idx] = codes
                    continue

                m_next = _RE_IGNORE_NEXT.search(line)
                if m_next:
                    codes = _normalize_codes(m_next.group("codes"))
                    ignore_on_line[idx + 1] = codes
    except Exception:
        # Best-effort: if file can't be read, no inline ignores apply
        pass
    return _FileMarkers(ignore_on_line=ignore_on_line)


class InlineMarkerFilter:
    """Caches parsed markers and filters diagnostics accordingly."""

    def __init__(self) -> None:
        self._cache: dict[Path, _FileMarkers] = {}

    def _get_markers(self, path: Path) -> _FileMarkers:
        if path not in self._cache:
            self._cache[path] = _parse_markers_for_file(path)
        return self._cache[path]

    def is_suppressed(self, diag: Diagnostic) -> bool:
        if diag.line is None:
            return False
        path = diag.file_path
        markers = self._get_markers(path)
        codes = markers.ignore_on_line.get(diag.line)
        if not codes:
            return False
        if "ALL" in codes or "*" in codes:
            return True
        return diag.code.upper() in codes

    def filter_diagnostics(self, diagnostics: Iterable[Diagnostic]) -> list[Diagnostic]:
        result: list[Diagnostic] = []
        for d in diagnostics:
            if not self.is_suppressed(d):
                result.append(d)
        return result

    def is_suppressed_line_code(self, path: Path, line: int, code: str) -> bool:
        if line is None:
            return False  # type: ignore[unreachable]
        markers = self._get_markers(path)
        codes = markers.ignore_on_line.get(line)
        if not codes:
            return False
        if "ALL" in codes or "*" in codes:
            return True
        return code.upper() in codes


def filter_result_with_inline_markers(result: ValidationResult) -> ValidationResult:
    """Return a copy of ValidationResult with inline-ignored diagnostics removed."""
    filt = InlineMarkerFilter()
    filtered_diags = filt.filter_diagnostics(result.diagnostics)
    if len(filtered_diags) == len(result.diagnostics):
        return result

    new_result = ValidationResult()
    new_result.diagnostics = filtered_diags
    new_result.validated_files = list(result.validated_files)
    new_result.metadata = dict(result.metadata)
    suppressed = len(result.diagnostics) - len(filtered_diags)
    new_result.metadata["inlineSuppressedCount"] = (
        new_result.metadata.get("inlineSuppressedCount", 0) + suppressed
    )
    return new_result


# Convenience API for non-Diagnostic usages (e.g., complexity hotspots)
_FILTER = InlineMarkerFilter()


def is_line_suppressed(path: Path, line: int, code: str) -> bool:
    """Check if a given file line suppresses the provided diagnostic code.

    Args:
        path: Absolute or workspace-relative path to source file
        line: 1-based line number
        code: Diagnostic/rule code (e.g., 'EP-001', 'COMPLEXITY')

    """
    try:
        return _FILTER.is_suppressed_line_code(Path(path), line, code)
    except Exception:
        return False
