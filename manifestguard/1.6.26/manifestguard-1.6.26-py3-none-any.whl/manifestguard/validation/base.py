"""Base Classes for Manifest Validation

Defines the core data structures and abstract base class for all validators.
Inspired by VS Code Extension DiagnosticSeverity and LSP protocol.
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any


class DiagnosticSeverity(str, Enum):
    """Diagnostic severity levels (VS Code Extension analog)

    Maps to VS Code DiagnosticSeverity:
    - ERROR (0) = Critical issues that must be fixed
    - WARNING (1) = Potential problems
    - INFO (2) = Informational messages
    - HINT (3) = Subtle suggestions
    """

    ERROR = "error"
    WARNING = "warning"
    INFO = "info"
    HINT = "hint"


@dataclass
class Diagnostic:
    """Validation diagnostic (VS Code Extension analog)

    Represents a single validation issue found in a manifest file.

    Attributes:
        code: Unique diagnostic code (e.g., "EP-001", "DEP-002")
        message: Human-readable description
        severity: Error/Warning/Info/Hint
        file_path: Path to the file with the issue
        line: Line number (1-based, optional)
        column: Column number (1-based, optional)
        source: Source of diagnostic (e.g., "manifestguard.pyproject")
        related_info: Additional context (e.g., conflicting files)
        fix_suggestion: Optional QuickFix suggestion

    Example:
        >>> Diagnostic(
        ...     code="EP-001",
        ...     message="Entry point 'my_cli' targets non-existent module 'my_package.cli'",
        ...     severity=DiagnosticSeverity.ERROR,
        ...     file_path=Path("pyproject.toml"),
        ...     line=15,
        ...     source="manifestguard.entry_points"
        ... )

    """

    code: str
    message: str
    severity: DiagnosticSeverity
    file_path: Path
    line: int | None = None
    column: int | None = None
    source: str = "manifestguard"
    related_info: list[str] = field(default_factory=list)
    fix_suggestion: str | None = None
    data: dict[str, Any] | None = None


@dataclass
class ValidationResult:
    """Result of manifest validation

    Aggregates all diagnostics and provides summary statistics.

    Attributes:
        diagnostics: List of all diagnostics found
        is_valid: True if no errors found
        error_count: Number of error-level diagnostics
        warning_count: Number of warning-level diagnostics
        info_count: Number of info-level diagnostics
        validated_files: List of files that were validated
        metadata: Additional validation metadata

    Example:
        >>> result = ValidationResult(
        ...     diagnostics=[diag1, diag2],
        ...     validated_files=[Path("pyproject.toml"), Path("setup.py")]
        ... )
        >>> print(f"Valid: {result.is_valid}, Errors: {result.error_count}")

    """

    diagnostics: list[Diagnostic] = field(default_factory=list)
    validated_files: list[Path] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)

    @property
    def is_valid(self) -> bool:
        """True if no error-level diagnostics"""
        return self.error_count == 0

    @property
    def error_count(self) -> int:
        """Count of error-level diagnostics"""
        return sum(1 for d in self.diagnostics if d.severity == DiagnosticSeverity.ERROR)

    @property
    def warning_count(self) -> int:
        """Count of warning-level diagnostics"""
        return sum(1 for d in self.diagnostics if d.severity == DiagnosticSeverity.WARNING)

    @property
    def info_count(self) -> int:
        """Count of info-level diagnostics"""
        return sum(1 for d in self.diagnostics if d.severity == DiagnosticSeverity.INFO)

    @property
    def hint_count(self) -> int:
        """Count of hint-level diagnostics"""
        return sum(1 for d in self.diagnostics if d.severity == DiagnosticSeverity.HINT)

    def add_diagnostic(self, diagnostic: Diagnostic) -> None:
        """Add a diagnostic to the result"""
        self.diagnostics.append(diagnostic)

    def merge(self, other: "ValidationResult") -> None:
        """Merge another ValidationResult into this one"""
        self.diagnostics.extend(other.diagnostics)
        self.validated_files.extend(other.validated_files)
        self.metadata.update(other.metadata)


class ManifestValidator(ABC):
    """Abstract base class for manifest validators

    All manifest validators (pyproject.toml, setup.py, requirements.txt)
    inherit from this class and implement the validate() method.

    Attributes:
        project_root: Root directory of the project
        config: Optional configuration dictionary

    Example:
        >>> class MyValidator(ManifestValidator):
        ...     def validate(self) -> ValidationResult:
        ...         result = ValidationResult()
        ...         # ... perform validation ...
        ...         return result

    """

    def __init__(self, project_root: Path, config: dict[str, Any] | None = None):
        """Initialize validator

        Args:
            project_root: Root directory of the project
            config: Optional configuration dictionary

        """
        self.project_root = Path(project_root)
        self.config = config or {}

    @abstractmethod
    def validate(self) -> ValidationResult:
        """Perform validation

        Returns:
            ValidationResult with all diagnostics

        """
        raise NotImplementedError("Subclasses must implement validate()")

    def _create_diagnostic(
        self,
        code: str,
        message: str,
        severity: DiagnosticSeverity,
        file_path: Path,
        line: int | None = None,
        column: int | None = None,
        fix_suggestion: str | None = None,
        data: dict[str, Any] | None = None,
    ) -> Diagnostic:
        """Helper method to create diagnostics with consistent source

        Args:
            code: Diagnostic code
            message: Diagnostic message
            severity: Severity level
            file_path: File with the issue
            line: Line number (optional)
            column: Column number (optional)
            fix_suggestion: Fix suggestion (optional)

        Returns:
            Diagnostic instance

        """
        return Diagnostic(
            code=code,
            message=message,
            severity=severity,
            file_path=file_path,
            line=line,
            column=column,
            source=f"manifestguard.{self.__class__.__name__.lower()}",
            fix_suggestion=fix_suggestion,
            data=data,
        )
