"""requirements.txt Validator

Validates requirements.txt files for PEP 440 compliance and detects issues.
"""

import re
from pathlib import Path
from re import Pattern
from typing import Any

from packaging.requirements import InvalidRequirement, Requirement

from .base import DiagnosticSeverity, ManifestValidator, ValidationResult


class RequirementsValidator(ManifestValidator):
    """Validator for requirements.txt files

    Checks:
    1. File syntax (valid PEP 440 specifiers)
    2. Pinned vs unpinned versions
    3. Invalid version specifiers
    4. Duplicate dependencies
    5. Comments and formatting

    Diagnostic Codes:
    - REQ-001: requirements.txt not found
    - REQ-002: Invalid syntax
    - REQ-003: Invalid version specifier (PEP 440)
    - REQ-004: Duplicate dependency
    - REQ-005: Unpinned version (warning)
    - REQ-006: Invalid URL dependency

    Example:
        >>> validator = RequirementsValidator(Path("/project"))
        >>> result = validator.validate()
        >>> print(f"Found {result.error_count} errors")

    """

    # PEP 440 version specifier pattern (simplified)
    VERSION_PATTERN: Pattern = re.compile(
        r"^([a-zA-Z0-9\-_.]+)"  # Package name
        r"(?:\[([^\]]+)\])?"  # Optional extras
        r"(?:\s*([<>=!~]+)\s*([0-9.*]+(?:[.][0-9.*]+)*))?",  # Version specifier
    )

    # URL dependency pattern
    URL_PATTERN: Pattern = re.compile(
        r"^(https?|git\+https?|git\+ssh)://",
    )

    def __init__(self, project_root: Path, config: dict[str, Any] | None = None):
        """Initialize requirements.txt validator

        Args:
            project_root: Root directory containing requirements.txt
            config: Optional configuration

        """
        super().__init__(project_root, config)
        self.requirements_files = [
            "requirements.txt",
            "requirements-dev.txt",
            "requirements-test.txt",
        ]

    def validate(self) -> ValidationResult:
        """Validate all requirements.txt files

        Returns:
            ValidationResult with all diagnostics

        """
        result = ValidationResult()

        for req_file in self.requirements_files:
            req_path = self.project_root / req_file
            if req_path.exists():
                result.validated_files.append(req_path)
                self._validate_file(req_path, result)

        return result

    def _validate_file(self, file_path: Path, result: ValidationResult) -> None:
        """Validate a single requirements file

        Args:
            file_path: Path to requirements file
            result: ValidationResult to add diagnostics to

        """
        try:
            lines = file_path.read_text(encoding="utf-8").splitlines()
        except Exception as e:
            result.add_diagnostic(
                self._create_diagnostic(
                    code="REQ-001",
                    message=f"Error reading {file_path.name}: {e}",
                    severity=DiagnosticSeverity.ERROR,
                    file_path=file_path,
                ),
            )
            return

        seen_packages: dict[str, int] = {}

        for line_num, line in enumerate(lines, start=1):
            # Skip empty lines and comments
            stripped = line.strip()
            if not stripped or stripped.startswith("#"):
                continue

            # Skip options (-r, -e, --index-url, etc.)
            if stripped.startswith("-"):
                continue

            # Validate line
            self._validate_line(stripped, line_num, file_path, result, seen_packages)

    def _validate_line(
        self,
        line: str,
        line_num: int,
        file_path: Path,
        result: ValidationResult,
        seen_packages: dict[str, int],
    ) -> None:
        """Validate a single requirement line

        Args:
            line: Requirement line
            line_num: Line number (1-based)
            file_path: Path to requirements file
            result: ValidationResult to add diagnostics to
            seen_packages: Dictionary tracking seen package names

        """
        # Check for URL dependencies
        if self.URL_PATTERN.match(line):
            # URL dependencies are valid but warn if no version tracking
            if "@" not in line:
                result.add_diagnostic(
                    self._create_diagnostic(
                        code="REQ-006",
                        message=f"URL dependency without version/commit: {line}",
                        severity=DiagnosticSeverity.WARNING,
                        file_path=file_path,
                        line=line_num,
                        fix_suggestion="Pin to specific commit: url@git+https://...#egg=package",
                    ),
                )
            return

        try:
            requirement = Requirement(line)
        except InvalidRequirement as exc:
            result.add_diagnostic(
                self._create_diagnostic(
                    code="REQ-002",
                    message=f"Invalid requirement syntax: {line} ({exc})",
                    severity=DiagnosticSeverity.ERROR,
                    file_path=file_path,
                    line=line_num,
                    fix_suggestion="Use valid PEP 508 requirement, e.g. package>=1.0.0",
                ),
            )
            return

        package_name = requirement.name.lower()

        # Check for duplicates
        if package_name in seen_packages:
            result.add_diagnostic(
                self._create_diagnostic(
                    code="REQ-004",
                    message=f"Duplicate dependency '{package_name}' (also on line {seen_packages[package_name]})",
                    severity=DiagnosticSeverity.ERROR,
                    file_path=file_path,
                    line=line_num,
                    fix_suggestion="Remove duplicate entry",
                ),
            )
        seen_packages[package_name] = line_num

        # Check if version is pinned
        if not requirement.specifier:
            result.add_diagnostic(
                self._create_diagnostic(
                    code="REQ-005",
                    message=f"Unpinned dependency '{package_name}' (no version specified)",
                    severity=DiagnosticSeverity.WARNING,
                    file_path=file_path,
                    line=line_num,
                    fix_suggestion=f"Pin version: {package_name}==X.Y.Z or use >= operator",
                ),
            )
        else:
            for spec in requirement.specifier:
                if spec.operator == "==" and spec.version.endswith("*"):
                    result.add_diagnostic(
                        self._create_diagnostic(
                            code="REQ-003",
                            message=f"Wildcard version not recommended: {line}",
                            severity=DiagnosticSeverity.WARNING,
                            file_path=file_path,
                            line=line_num,
                            fix_suggestion="Use specific version or >= operator",
                        ),
                    )
