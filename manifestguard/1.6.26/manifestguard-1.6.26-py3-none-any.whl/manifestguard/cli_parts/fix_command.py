from __future__ import annotations

import json
import sys
from datetime import datetime
from pathlib import Path
from typing import Any

import click

from manifestguard import __version__
from manifestguard.i18n import t
from manifestguard.quickfix import (
    BackupContext,
    QuickFixAction,
    apply_quickfix,
    get_quickfixes,
    preview_quickfix,
)
from manifestguard.quickfix.backup import create_snapshot
from manifestguard.validation.base import Diagnostic


def _format_relative_path(base: Path, path: Path) -> str:
    try:
        return str(path.relative_to(base))
    except ValueError:
        return str(path)


@click.command(name="fix")
@click.option("--auto", is_flag=True, help=t("cli.options.auto", module="cli"))
@click.option("--dry-run", is_flag=True, help=t("cli.options.dry_run", module="cli"))
@click.option(
    "--apply",
    "apply_code",
    type=str,
    default=None,
    help="Apply fixes for specific diagnostic code (e.g., EP-001)",
)
@click.option(
    "--list",
    "list_fixes",
    is_flag=True,
    help="List all available quick fixes without applying",
)
def fix(auto: bool, dry_run: bool, apply_code: str | None, list_fixes: bool) -> None:
    """Fix manifest issues by applying available quick fixes."""
    from manifestguard.cli import _resolve_workspace_root
    from manifestguard.cli import _run_manifest_validation

    workspace_root = _resolve_workspace_root()

    _enforce_fix_command_license(list_fixes=list_fixes, dry_run=dry_run)

    validation_result = _run_manifest_validation(workspace_root)

    quickfix_groups, quickfix_count = _collect_quickfix_groups(
        workspace_root, validation_result.diagnostics
    )

    if _handle_list_or_empty_quickfixes(
        workspace_root=workspace_root,
        quickfix_groups=quickfix_groups,
        quickfix_count=quickfix_count,
        auto=auto,
        list_fixes=list_fixes,
    ):
        return

    quickfix_groups = _filter_quickfix_groups_by_code(
        quickfix_groups=quickfix_groups,
        apply_code=apply_code,
    )
    if not quickfix_groups:
        return

    _run_quickfix_apply_flow(
        workspace_root=workspace_root,
        quickfix_groups=quickfix_groups,
        quickfix_count=quickfix_count,
        auto=auto,
        dry_run=dry_run,
        apply_code=apply_code,
    )


def _handle_list_or_empty_quickfixes(
    *,
    workspace_root: Path,
    quickfix_groups: list,
    quickfix_count: int,
    auto: bool,
    list_fixes: bool,
) -> bool:
    if not quickfix_groups:
        _notify_no_quickfixes(auto)
        return True

    if list_fixes:
        _print_available_quickfixes(
            workspace_root=workspace_root,
            quickfix_groups=quickfix_groups,
            quickfix_count=quickfix_count,
        )
        return True

    return False


def _run_quickfix_apply_flow(
    *,
    workspace_root: Path,
    quickfix_groups: list,
    quickfix_count: int,
    auto: bool,
    dry_run: bool,
    apply_code: str | None,
) -> None:
    snapshot_path = _maybe_create_workspace_snapshot(workspace_root, dry_run=dry_run)

    with BackupContext.create(workspace_root) as backup_ctx:
        _print_fix_run_header(dry_run=dry_run, quickfix_count=quickfix_count)

        applied_any, applied_operations = _apply_quickfix_groups_with_backup(
            quickfix_groups=quickfix_groups,
            workspace_root=workspace_root,
            auto=auto,
            dry_run=dry_run,
            backup_ctx=backup_ctx,
        )

        _finalize_fix_apply_flow(
            workspace_root=workspace_root,
            applied_any=applied_any,
            applied_operations=applied_operations,
            auto=auto,
            dry_run=dry_run,
            apply_code=apply_code,
            quickfix_count=quickfix_count,
            backup_dir=backup_ctx.backup_dir,
            snapshot_path=snapshot_path,
        )


def _finalize_fix_apply_flow(
    *,
    workspace_root: Path,
    applied_any: bool,
    applied_operations: list,
    auto: bool,
    dry_run: bool,
    apply_code: str | None,
    quickfix_count: int,
    backup_dir: Path,
    snapshot_path: Path | None,
) -> None:
    if dry_run:
        click.echo(f"\n{t('quickfix.dry_run', module='core')}")
        return

    if not applied_any:
        click.echo(f"\n❌ {t('cli.fix.cancelled', module='cli')}")
        return

    _write_quickfix_manifest(
        workspace_root,
        applied_operations,
        auto=auto,
        apply_code=apply_code,
        quickfix_count=quickfix_count,
        backup_dir=backup_dir,
        snapshot_path=snapshot_path,
    )
    click.echo(f"\n✅ {t('cli.fix.applied', module='cli')}")
    click.echo(f"   Backups stored in: {backup_dir}")


def _enforce_fix_command_license(*, list_fixes: bool, dry_run: bool) -> None:
    from manifestguard.cli import _has_license_feature, _license_tier_label

    if list_fixes or dry_run:
        if not _has_license_feature("quickfix_suggestions"):
            click.echo("🔒 QuickFix suggestions require a Pro (or higher) license.")
            click.echo(f"   Current: {_license_tier_label()}.")
            raise SystemExit(0)
        return

    if not _has_license_feature("quickfix_apply"):
        click.echo("🔒 Applying QuickFix patches requires a Team (or higher) license.")
        click.echo(f"   Current: {_license_tier_label()}.")
        raise SystemExit(3)


def _print_available_quickfixes(
    *,
    workspace_root: Path,
    quickfix_groups: list[tuple[Diagnostic, list[QuickFixAction]]],
    quickfix_count: int,
) -> None:
    click.echo(f"🔧 Available Quick Fixes ({quickfix_count} total):\n")
    for diagnostic, actions in quickfix_groups:
        for action in actions:
            location = _format_relative_path(workspace_root, diagnostic.file_path)
            click.echo(f"  [{diagnostic.code}] {action.title}")
            click.echo(f"    Location: {location}")
            click.echo(f"    Message: {diagnostic.message}")
            click.echo()


def _filter_quickfix_groups_by_code(
    *,
    quickfix_groups: list[tuple[Diagnostic, list[QuickFixAction]]],
    apply_code: str | None,
) -> list[tuple[Diagnostic, list[QuickFixAction]]]:
    if not apply_code:
        return quickfix_groups

    filtered = [(d, a) for d, a in quickfix_groups if d.code == apply_code]
    if not filtered:
        click.echo(f"❌ No quick fixes available for diagnostic code: {apply_code}")
        return []

    click.echo(f"🔧 Applying fixes for diagnostic code: {apply_code}")
    return filtered


def _maybe_create_workspace_snapshot(workspace_root: Path, *, dry_run: bool) -> Path | None:
    if dry_run:
        return None

    try:
        snapshot_path = create_snapshot(workspace_root)
        click.echo(f"🛟 Workspace snapshot saved: {snapshot_path}")
        return snapshot_path
    except Exception as e:  # pragma: no cover - best-effort safety
        click.echo(f"⚠️  Failed to create workspace snapshot: {e}", err=True)
        return None


def _print_fix_run_header(*, dry_run: bool, quickfix_count: int) -> None:
    if not dry_run:
        click.echo(f"🔧 {t('cli.fix.applying', module='cli')}...")
        click.echo(f"   {quickfix_count} quick fix(es) available.")
        return
    click.echo("🔍 Dry-run mode: No changes will be made.")
    click.echo(f"   {quickfix_count} quick fix(es) available.")


def _apply_quickfix_groups_with_backup(
    *,
    quickfix_groups: list[tuple[Diagnostic, list[QuickFixAction]]],
    workspace_root: Path,
    auto: bool,
    dry_run: bool,
    backup_ctx: BackupContext,
) -> tuple[bool, list[dict[str, Any]]]:
    applied_any = False
    applied_operations: list[dict[str, Any]] = []

    for diagnostic, actions in quickfix_groups:
        if not dry_run and diagnostic.file_path.exists():
            try:
                backup_ctx.backup_file(diagnostic.file_path)
            except Exception as e:
                click.echo(f"⚠️  Backup failed for {diagnostic.file_path.name}: {e}", err=True)

        applied = _apply_quickfix_group(
            diagnostic,
            actions,
            workspace_root,
            auto,
            dry_run,
        )

        if not dry_run and applied and actions:
            applied_operations.append(_serialize_quickfix_operation(diagnostic, actions[0]))

        applied_any = applied_any or applied

    return applied_any, applied_operations


def _serialize_quickfix_operation(
    diagnostic: Diagnostic,
    action: QuickFixAction,
) -> dict[str, Any]:
    return {
        "diagnostic": {
            "code": diagnostic.code,
            "message": diagnostic.message,
            "severity": diagnostic.severity.value,
            "file": str(diagnostic.file_path),
            "line": diagnostic.line,
            "source": diagnostic.source,
        },
        "action": {
            "identifier": action.identifier,
            "title": action.title,
            "description": action.description,
        },
    }


def _collect_quickfix_groups(
    workspace_root: Path,
    diagnostics: list[Diagnostic],
) -> tuple[list[tuple[Diagnostic, list[QuickFixAction]]], int]:
    groups: list[tuple[Diagnostic, list[QuickFixAction]]] = []
    quickfix_count = 0

    for diagnostic in diagnostics:
        actions = get_quickfixes(workspace_root, diagnostic)
        if not actions:
            continue
        groups.append((diagnostic, actions))
        quickfix_count += len(actions)

    return groups, quickfix_count


def _write_quickfix_manifest(
    workspace_root: Path,
    operations: list[dict[str, Any]],
    *,
    auto: bool,
    apply_code: str | None,
    quickfix_count: int,
    backup_dir: Path,
    snapshot_path: Path | None,
) -> None:
    """Persist an audit manifest for applied QuickFix operations."""

    if not operations:
        return

    try:
        quickfix_dir = workspace_root / ".manifestguard" / "quickfix"
        quickfix_dir.mkdir(parents=True, exist_ok=True)

        mode = "auto" if auto else "interactive"
        label_parts: list[str] = []
        if apply_code:
            label_parts.append(apply_code)
        label_parts.append(mode)
        label = "-".join(label_parts)

        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        manifest_name = f"{timestamp}-{label}.json"
        manifest_path = quickfix_dir / manifest_name

        manifest = {
            "schema": "https://ready-4-it.github.io/schemas/manifestguard-quickfix-manifest.json",
            "tool": "manifestguard",
            "version": __version__,
            "timestamp": datetime.now().isoformat(),
            "workspace_root": str(workspace_root),
            "mode": mode,
            "apply_code": apply_code,
            "quickfix_count": quickfix_count,
            "applied_count": len(operations),
            "backup_dir": str(backup_dir),
            "snapshot": str(snapshot_path) if snapshot_path else None,
            "operations": operations,
        }

        with manifest_path.open("w", encoding="utf-8") as handle:
            json.dump(manifest, handle, indent=2)

    except Exception as e:  # pragma: no cover - best-effort logging only
        click.echo(f"⚠️  Failed to write QuickFix manifest: {e}", err=True)


def _notify_no_quickfixes(auto: bool) -> None:
    click.echo(t("cli.fix.none_available", module="cli"))
    if auto:
        click.echo("Auto-fix mode enabled (no quick fixes available).")
    else:
        click.echo(t("cli.fix.hint", module="cli"))


def _apply_quickfix_group(
    diagnostic: Diagnostic,
    actions: list[QuickFixAction],
    workspace_root: Path,
    auto: bool,
    dry_run: bool,
) -> bool:
    action = actions[0]
    click.echo(f"\n[{diagnostic.code}] {diagnostic.message}")
    click.echo(f"   ↳ {_format_relative_path(workspace_root, diagnostic.file_path)}")
    click.echo(f"   💡 {action.title}")

    should_apply = auto or click.confirm(t("cli.fix.confirm", module="cli"), default=False)
    if not should_apply:
        return False

    result = preview_quickfix(action, workspace_root) if dry_run else apply_quickfix(action, workspace_root)

    click.echo(f"   {result.message}")
    return result.applied
