from __future__ import annotations

import asyncio
from pathlib import Path
from typing import Any

import click

from manifestguard.i18n import t, t_format


@click.command()
@click.option("--list", "list_all", is_flag=True, help="List all baselines")
@click.option("--compare", type=str, help="Compare current metrics to baseline label")
@click.option("--trend", is_flag=True, help="Show trend report")
@click.option(
    "--save-label",
    type=str,
    help=(
        "Run extended tests once and save metrics as named baseline "
        "(e.g. gui-refactor-pre, gui-refactor-post)"
    ),
)
def baseline(list_all: bool, compare: str | None, trend: bool, save_label: str | None) -> None:
    """Manage metric baselines for trend analysis."""
    from manifestguard.cli import _resolve_workspace_root
    import manifestguard.cli as mgcli

    workspace_root = _resolve_workspace_root()
    # Tests monkeypatch `manifestguard.cli.BaselineManager`, so we resolve it from there.
    baseline_mgr = mgcli.BaselineManager(workspace_root)

    if list_all:
        _baseline_handle_list(baseline_mgr)
        return
    if compare:
        _baseline_handle_compare(baseline_mgr, compare, workspace_root)
        return
    if trend:
        _baseline_handle_trend(baseline_mgr)
        return
    if save_label:
        _baseline_handle_save_label(baseline_mgr, save_label, workspace_root)
        return

    _baseline_show_help()


def _baseline_handle_list(baseline_mgr: Any) -> None:
    baselines = baseline_mgr.list_baselines()
    if not baselines:
        click.echo(t("cli.baseline_mgmt.no_baselines", module="cli"))
        return
    click.echo(t("cli.baseline_mgmt.available_title", module="cli") + "\n")
    for baseline_item in baselines:
        click.echo(f"  • {baseline_item['label']}: {baseline_item['timestamp']}")


def _baseline_show_comparison(comparison: dict[str, Any], compare_label: str) -> None:
    click.echo(
        "\n"
        + t_format("cli.baseline_mgmt.comparison_title", label=compare_label, module="cli")
        + "\n",
    )

    regressions = comparison.get("regressions") or []
    if regressions:
        click.echo(t("cli.baseline_mgmt.regressions_title", module="cli"))
        for reg in regressions:
            severity = reg.get("severity")
            if severity in ["critical", "high", "medium", "low"]:
                emoji = t(f"cli.baseline_mgmt.severity.{severity}", module="cli")
            else:
                emoji = t("cli.baseline_mgmt.severity.low", module="cli")
            click.echo(
                f"  {emoji} {reg['metric']}: {reg['baseline']} → {reg['current']} (Δ {reg['delta']:+.1f})",
            )
    else:
        click.echo(t("cli.baseline_mgmt.no_regressions", module="cli"))

    improvements = comparison.get("improvements") or []
    if improvements:
        click.echo("\n" + t("cli.baseline_mgmt.improvements_title", module="cli"))
        for imp in improvements:
            click.echo(
                f"  ⬆️ {imp['metric']}: {imp['baseline']} → {imp['current']} (Δ {imp['delta']:+.1f})",
            )


def _baseline_handle_compare(
    baseline_mgr: Any,
    compare_label: str,
    workspace_root: Path,
) -> None:
    import manifestguard.cli as mgcli

    runner = mgcli.ExtendedTestRunner(workspace_root)
    current_metrics = asyncio.run(runner.run())
    if not current_metrics:
        click.echo(t("cli.baseline_mgmt.current_metrics_failed", module="cli"))
        return

    comparison = baseline_mgr.compare_to_baseline(current_metrics, compare_label)
    if not comparison:
        click.echo(
            t_format("cli.baseline_mgmt.baseline_not_found", label=compare_label, module="cli")
        )
        return

    _baseline_show_comparison(comparison, compare_label)


def _baseline_handle_trend(baseline_mgr: BaselineManager) -> None:
    trend_report = baseline_mgr.generate_trend_report()
    if trend_report.get("baselines_count") == 0:
        click.echo(t("cli.baseline_mgmt.no_baselines_for_trend", module="cli"))
        return

    trend_title = t_format(
        "cli.baseline_mgmt.trend_title",
        count=trend_report["baselines_count"],
        module="cli",
    )
    click.echo("\n" + trend_title + "\n")

    trends = trend_report.get("trends") or {}
    cov_trend = trends.get("coverage") or []
    if cov_trend:
        latest_cov = cov_trend[0]["value"]
        oldest_cov = cov_trend[-1]["value"]
        cov_delta = latest_cov - oldest_cov
        cov_msg = t_format(
            "cli.baseline_mgmt.coverage_trend",
            old=oldest_cov,
            new=latest_cov,
            delta=cov_delta,
            module="cli",
        )
        click.echo(f"  {cov_msg}")

    vuln_trend = trends.get("vulnerabilities") or []
    if vuln_trend:
        latest_vuln = vuln_trend[0]["value"]
        oldest_vuln = vuln_trend[-1]["value"]
        vuln_delta = latest_vuln - oldest_vuln
        icon = _baseline_trend_icon(vuln_delta)
        trend_msg = t_format(
            "cli.baseline_mgmt.vuln_trend",
            old=oldest_vuln,
            new=latest_vuln,
            delta=vuln_delta,
            icon=icon,
            module="cli",
        )
        click.echo(f"  {trend_msg}")


def _baseline_trend_icon(delta: float) -> str:
    if delta > 0:
        return t("cli.baseline_mgmt.trend_icon.up", module="cli")
    if delta < 0:
        return t("cli.baseline_mgmt.trend_icon.down", module="cli")
    return t("cli.baseline_mgmt.trend_icon.neutral", module="cli")


def _baseline_handle_save_label(
    baseline_mgr: Any,
    save_label: str,
    workspace_root: Path,
) -> None:
    import manifestguard.cli as mgcli

    runner = mgcli.ExtendedTestRunner(workspace_root)
    metrics = asyncio.run(runner.run())
    if not metrics:
        click.echo(t("cli.baseline_mgmt.current_metrics_failed", module="cli"))
        return

    path = baseline_mgr.save_baseline(metrics, label=save_label)
    click.echo(
        t_format(
            "cli.baseline_mgmt.saved_named_baseline",
            label=save_label,
            path=path,
            module="cli",
        ),
    )


def _baseline_show_help() -> None:
    click.echo(t("cli.baseline_mgmt.title", module="cli") + "\n")
    click.echo(t("cli.baseline_mgmt.help_list", module="cli"))
    click.echo(t("cli.baseline_mgmt.help_compare", module="cli"))
    click.echo(t("cli.baseline_mgmt.help_trend", module="cli"))
