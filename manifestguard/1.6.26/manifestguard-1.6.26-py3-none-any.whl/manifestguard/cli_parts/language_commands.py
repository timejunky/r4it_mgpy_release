from __future__ import annotations

import click

from manifestguard.core.user_settings import (
    load_user_settings,
    save_user_settings,
    user_settings_path,
)
from manifestguard.i18n import (
    SUPPORTED_LANGUAGES,
    get_current_language,
    get_current_language_source,
    set_language,
    t,
)




def _normalize_lang_option(lang: str | None) -> str | None:
    if lang is None:
        return None
    value = lang.strip().lower()
    if not value:
        return None
    return value


@click.command(
    name="set-language",
    help=t("cli.help.set_language", module="cli"),
)
@click.argument("lang", required=False, type=click.Choice(SUPPORTED_LANGUAGES, case_sensitive=False))
@click.option(
    "--unset",
    is_flag=True,
    help=t("cli.options.lang_unset", module="cli"),
)
def set_language_command(lang: str | None, unset: bool) -> None:
    """Persist the preferred CLI language in per-user settings."""

    if unset:
        settings = load_user_settings()
        if "language" in settings:
            settings.pop("language", None)
            save_user_settings(settings)
        click.echo(f"Cleared language preference in: {user_settings_path()}")
        return

    if not lang:
        raise click.UsageError("Provide a language code (e.g. 'de') or use --unset")

    lang_norm = _normalize_lang_option(lang)
    if not lang_norm:
        raise click.UsageError("Provide a language code (e.g. 'de') or use --unset")

    settings = load_user_settings()
    settings["language"] = lang_norm
    save_user_settings(settings)
    set_language(lang_norm, source="user-settings")
    click.echo(f"Saved language preference '{lang_norm}' to: {user_settings_path()}")


@click.command(name="languages")
def languages_command() -> None:
    """Show supported languages and the currently active CLI language."""

    current = get_current_language()
    source = get_current_language_source()
    supported = ", ".join(SUPPORTED_LANGUAGES)

    click.echo(f"Current language: {current} (source: {source})")
    click.echo(f"Supported languages: {supported}")

    settings_path = user_settings_path()
    settings = load_user_settings()
    persisted = settings.get("language")
    if persisted:
        click.echo(f"User preference: {persisted} ({settings_path})")
    else:
        click.echo(f"User preference: <unset> ({settings_path})")
