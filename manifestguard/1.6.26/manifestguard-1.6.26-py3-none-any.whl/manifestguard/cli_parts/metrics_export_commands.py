from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any

import click


@click.command("export-metrics")
@click.option(
    "--format",
    "format_",
    type=click.Choice(["json"], case_sensitive=False),
    default="json",
    help="Export format (currently only JSON supported)",
)
@click.option(
    "--output",
    "-o",
    type=click.Path(),
    default=None,
    help="Output file path (default: print to stdout)",
)
@click.option(
    "--pretty/--compact",
    default=True,
    help="Pretty-print JSON with indentation (default: enabled)",
)
def export_metrics_cmd(format_: str, output: str | None, pretty: bool) -> None:
    """Export quality metrics in structured format for dashboards (TODO-016)."""
    try:
        # Note: tests patch `manifestguard.cli.run_extended_tests`, so we must
        # import from there (not directly from extended.runner).
        from manifestguard.cli import _build_quality_slice, run_extended_tests

        workspace_root = Path.cwd()
        metrics = run_extended_tests(workspace_root)
        if not metrics:
            click.echo("❌ Extended tests failed or is disabled")
            sys.exit(1)

        telemetry_dict: dict[str, Any] = _build_quality_slice(metrics, workspace_root)

        json_output = (
            json.dumps(telemetry_dict, indent=2, ensure_ascii=False)
            if pretty
            else json.dumps(telemetry_dict, ensure_ascii=False)
        )

        if output:
            output_path = Path(output)
            output_path.write_text(json_output, encoding="utf-8")
            click.echo(f"✅ Metrics exported to: {output_path}")
        else:
            click.echo(json_output)

    except Exception as e:
        click.echo(f"❌ Metrics export failed: {e}", err=True)
        import traceback

        traceback.print_exc()
        sys.exit(1)


@click.command("reconstruct-metrics")
@click.option(
    "--starting-point",
    type=click.Choice(["sinceLastReconstruct", "lastYear", "fixedDate"], case_sensitive=False),
    default="sinceLastReconstruct",
    show_default=True,
    help="How far back to reconstruct Git-derived metrics.",
)
@click.option(
    "--fixed-date-iso",
    type=str,
    default=None,
    help="Fixed cutoff (ISO-8601) when --starting-point=fixedDate (e.g. 2026-01-01T00:00:00Z).",
)
@click.option(
    "--allow-widening",
    is_flag=True,
    help="Allow widening reconstruction window further back than existing reconstructCutoffIso.",
)
@click.option(
    "--window-days",
    type=int,
    default=30,
    show_default=True,
    help="Sliding window size (days) used per history entry.",
)
@click.option(
    "--path",
    "path_filter",
    type=click.Path(path_type=Path),
    default=None,
    help="Optional repo sub-path to limit git analysis (e.g. src/).",
)
@click.option(
    "--json",
    "output_json",
    is_flag=True,
    help="Output result as JSON.",
)
def reconstruct_metrics(
    starting_point: str,
    fixed_date_iso: str | None,
    allow_widening: bool,
    window_days: int,
    path_filter: Path | None,
    output_json: bool,
) -> None:
    """Reconstruct repo-derived metrics into `.mgpy/metrics/manifestguard-history.json`.

    Updates existing history entries by computing Git-based metrics (bugfixes/BPD
    + repo activity) in a sliding window ending at each entry timestamp.
    """

    from manifestguard.cli import _resolve_workspace_root
    from manifestguard.extended.metrics_history_reconstruct import (
        reconstruct_metrics_history_from_repo_history,
    )

    workspace_root = _resolve_workspace_root()

    try:
        result = reconstruct_metrics_history_from_repo_history(
            workspace_root=workspace_root,
            starting_point=starting_point,
            fixed_date_iso=fixed_date_iso,
            allow_widening=allow_widening,
            window_days=window_days,
            path_filter=path_filter,
        )
    except Exception as exc:
        if output_json:
            click.echo(json.dumps({"success": False, "error": str(exc)}, indent=2))
        else:
            click.echo(f"❌ Reconstruction failed: {exc}")
        sys.exit(1)

    if output_json:
        click.echo(json.dumps({"success": True, **result}, indent=2))
        return

    click.echo("✅ Reconstructed repo-derived metrics")
    click.echo(f"   History: {result.get('historyFile')}")
    if result.get("backupFile"):
        click.echo(f"   Backup: {result.get('backupFile')}")
    click.echo(f"   Updated entries: {result.get('updatedEntries')}")
    click.echo(f"   Cutoff: {result.get('effectiveCutoffIso')}")
    if result.get("wideningBlocked"):
        click.echo("   Note: widening blocked (use --allow-widening to override)")
    click.echo(f"   Window: {result.get('windowDays')} days")
    if result.get("pathFilter"):
        click.echo(f"   Path filter: {result.get('pathFilter')}")
