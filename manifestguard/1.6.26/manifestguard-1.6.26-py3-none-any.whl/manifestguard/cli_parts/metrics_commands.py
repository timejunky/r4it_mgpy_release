from __future__ import annotations

import asyncio
import json
import subprocess
import sys
from datetime import datetime
from pathlib import Path
from typing import Any

import click

from manifestguard import __version__
from manifestguard.extended.complexity import (
    ComplexityAnalyzer,
    serialize_complexity_metrics,
    write_metrics_file,
)
from manifestguard.extended.coverage_metrics import format_coverage_metric_for_display
from manifestguard.extended.coverage_weekly import (
    export_weekly_summary_json,
    format_weekly_summary,
    reconstruct_weekly_coverage,
)
from manifestguard.extended.metrics_history_export import (
    add_coverage_metric_to_history,
    resolve_history_file_path,
)
from manifestguard.i18n import t, t_format


from .baseline_commands import baseline
from .venv_health_commands import venv_health_track, venv_health_weekly
from .metrics_export_commands import export_metrics_cmd, reconstruct_metrics


@click.command("complexity")
@click.option(
    "--threshold",
    type=int,
    default=10,
    show_default=True,
    help="Complexity threshold for reporting violations",
)
@click.option(
    "--include-tests",
    is_flag=True,
    help="Include tests/ directory in the analysis",
)
@click.option(
    "--min-rank",
    type=click.Choice(["A", "B", "C", "D", "E", "F"], case_sensitive=False),
    default="A",
    show_default=True,
    help="Minimum rank (A-F) to include in violations",
)
@click.option(
    "--output",
    type=click.Path(),
    default=str(Path(".manifestguard") / "metrics.json"),
    show_default=True,
    help="Path to metrics JSON output file",
)
@click.option(
    "--fail-on-violation",
    is_flag=True,
    help="Exit with non-zero status when violations are found",
)
def complexity(
    threshold: int,
    include_tests: bool,
    min_rank: str,
    output: str,
    fail_on_violation: bool,
) -> None:
    """Run cyclomatic complexity analysis only."""
    from manifestguard.cli import _resolve_workspace_root

    workspace_root = _resolve_workspace_root()
    analyzer = ComplexityAnalyzer(workspace_root)
    metrics = analyzer.analyze(
        threshold=threshold,
        include_tests=include_tests,
        min_rank=min_rank,
    )

    recommendations = analyzer.get_recommendations(metrics)
    payload = serialize_complexity_metrics(metrics, recommendations)

    output_path = Path(output)
    write_metrics_file(payload, output_path)

    click.echo(
        t_format(
            "cli.complexity.metrics_written",
            path=output_path,
            violations=metrics.violations_count,
            module="cli",
        )
    )

    if fail_on_violation and metrics.violations_count > 0:
        sys.exit(1)




@click.group("worker")
def worker_group() -> None:
    """Run worker-tool checks via stable JSON + exit-code contracts.

    This group dispatches to dedicated worker commands like
    ``venv-wizard-preflight`` while keeping the group itself free
    of additional side effects.
    """


@worker_group.command("venv-wizard-preflight")
@click.option(
    "--project-root",
    type=click.Path(exists=True, file_okay=False, path_type=Path),
    default=None,
    help="Project root directory to run in (default: current directory)",
)
@click.option(
    "--python",
    "python_exe",
    type=click.Path(),
    default=None,
    help="Python executable to run venv_wizard with (default: current interpreter)",
)
@click.option(
    "--workspace",
    type=click.Path(),
    default=None,
    help="Workspace folder forwarded to venv_wizard --workspace",
)
@click.option(
    "--auto-fix",
    is_flag=True,
    help="Forward --auto-fix to venv_wizard (off by default)",
)
@click.option(
    "--timeout",
    "timeout_seconds",
    type=float,
    default=30.0,
    show_default=True,
    help="Timeout in seconds",
)
@click.option(
    "--json",
    "output_json",
    is_flag=True,
    help="Print the raw JSON payload returned by the worker tool",
)
@click.option(
    "--output-format",
    type=click.Choice(["summary", "json", "markdown", "html"], case_sensitive=False),
    default="summary",
    help="Output format (default: summary)",
)
@click.option(
    "--output",
    "-o",
    type=click.Path(path_type=Path),
    help="Write report to file (default: stdout)",
)
def worker_venv_wizard_preflight(
    project_root: Path | None,
    python_exe: str | None,
    workspace: str | None,
    auto_fix: bool,
    timeout_seconds: float,
    output_json: bool,
    output_format: str,
    output: Path | None,
) -> None:
    """Run vwpy (venv_wizard) preflight."""
    from manifestguard.orchestration.venv_wizard_adapter import (
        run_venv_wizard_preflight,
        summarize_health_payload,
    )
    from manifestguard.reporting.worker_export import (
        format_worker_result_html,
        format_worker_result_markdown,
    )

    if output_json:
        output_format = "json"

    resolved_project_root = project_root or Path.cwd()
    resolved_python = python_exe or sys.executable

    try:
        result = run_venv_wizard_preflight(
            python_exe=resolved_python,
            project_root=resolved_project_root,
            workspace=workspace,
            auto_fix=auto_fix,
            timeout_seconds=timeout_seconds,
        )
    except subprocess.TimeoutExpired:
        if output_format == "json":
            click.echo(
                json.dumps(
                    {
                        "tool": "venv_wizard",
                        "command": "preflight",
                        "success": False,
                        "error": "timeout",
                        "timeoutSeconds": timeout_seconds,
                    },
                    indent=2,
                )
            )
        else:
            click.echo(f"❌ venv_wizard preflight timed out after {timeout_seconds:.1f}s")
        sys.exit(124)

    if output_format == "json":
        if result.payload is None:
            output_text = json.dumps(
                {
                    "tool": "venv_wizard",
                    "command": "preflight",
                    "success": False,
                    "error": "invalid_json",
                    "exitCode": result.exit_code,
                    "stdout": result.stdout,
                    "stderr": result.stderr,
                },
                indent=2,
            )
        else:
            output_text = json.dumps(result.payload, indent=2)

    elif output_format == "markdown":
        output_text = format_worker_result_markdown(result, tool_name="Venv Wizard Preflight")

    elif output_format == "html":
        output_text = format_worker_result_html(result, tool_name="Venv Wizard Preflight")

    else:
        summary = summarize_health_payload(result.payload)
        status = summary["status"]
        lines = [
            "vwpy preflight (venv_wizard)",
            f"  status: {status}",
            f"  children: {summary['managedChildren']} total | "
            f"{summary['running']} running | "
            f"{summary['zombie']} zombie | "
            f"{summary['dead']} dead | "
            f"{summary['unknown']} unknown",
            f"  warnings: {summary['warnings']}",
        ]

        if result.payload is None:
            lines.append("  ❌ invalid JSON from worker tool")

        output_text = "\n".join(lines)

    if output:
        output.write_text(output_text, encoding="utf-8")
        click.echo(f"✅ Report written to: {output}")
    else:
        click.echo(output_text)

    if result.payload is None:
        sys.exit(1)
    sys.exit(0 if result.exit_code == 0 else 1)


@click.command("coverage-track")
@click.option(
    "--coverage-file",
    type=click.Path(exists=True, path_type=Path),
    help="Path to coverage.json (default: ./coverage.json)",
)
@click.option(
    "--workspace-root",
    type=click.Path(exists=True, file_okay=False, path_type=Path),
    help="Workspace root directory (default: current directory)",
)
@click.option(
    "--json",
    "output_json",
    is_flag=True,
    help="Output in JSON format",
)
def coverage_track(
    coverage_file: Path | None,
    workspace_root: Path | None,
    output_json: bool,
) -> None:
    """Track test coverage from coverage.json to metrics history."""
    if workspace_root is None:
        workspace_root = Path.cwd()

    if coverage_file is None:
        coverage_file = workspace_root / "coverage.json"

    if not coverage_file.exists():
        if output_json:
            click.echo(
                json.dumps(
                    {
                        "success": False,
                        "error": "coverage_file_not_found",
                        "message": f"Coverage file not found: {coverage_file}",
                    },
                    indent=2,
                )
            )
        else:
            click.echo(f"❌ Coverage file not found: {coverage_file}")
            click.echo("\n💡 Generate coverage.json with: pytest --cov --cov-report=json")
        sys.exit(2)

    try:
        success = add_coverage_metric_to_history(
            workspace_root=workspace_root,
            coverage_file=coverage_file,
            mgpy_version=__version__,
        )

        if not success:
            if output_json:
                click.echo(
                    json.dumps(
                        {
                            "success": False,
                            "error": "coverage_tracking_failed",
                            "message": "Failed to add coverage metric to history",
                        },
                        indent=2,
                    )
                )
            else:
                click.echo("❌ Failed to track coverage metrics")
            sys.exit(1)

        from manifestguard.extended.coverage_metrics import extract_coverage_from_file

        coverage_metric = extract_coverage_from_file(coverage_file)

        if output_json:
            click.echo(
                json.dumps(
                    {
                        "success": True,
                        "coverage_file": str(coverage_file),
                        "workspace_root": str(workspace_root),
                        "metric": coverage_metric,
                    },
                    indent=2,
                )
            )
        else:
            click.echo("✅ Coverage metric tracked successfully")
            click.echo(f"\n📊 {format_coverage_metric_for_display(coverage_metric)}")
            history_path = resolve_history_file_path(workspace_root, create_if_missing=False)
            if history_path:
                click.echo(f"\n📁 History: {history_path}")

    except Exception as e:
        if output_json:
            click.echo(
                json.dumps(
                    {"success": False, "error": "exception", "message": str(e)},
                    indent=2,
                )
            )
        else:
            click.echo(f"❌ Error tracking coverage: {e}")
        sys.exit(1)


@click.command("coverage-weekly")
@click.option(
    "--history-file",
    type=click.Path(exists=True, path_type=Path),
    help="Path to metrics history file (default: auto-resolve from .mgpy/metrics/ or legacy)",
)
@click.option(
    "--output",
    type=click.Path(path_type=Path),
    help="Export weekly summary to JSON file",
)
@click.option(
    "--json",
    "output_json",
    is_flag=True,
    help="Output in JSON format to console",
)
def coverage_weekly(
    history_file: Path | None,
    output: Path | None,
    output_json: bool,
) -> None:
    """Reconstruct weekly coverage aggregates from metrics history."""
    if history_file is None:
        from manifestguard.extended.metrics_history_export import resolve_history_file_path
        history_file = resolve_history_file_path(Path.cwd())

    if not history_file.exists():
        if output_json:
            click.echo(
                json.dumps(
                    {
                        "success": False,
                        "error": "history_file_not_found",
                        "message": f"History file not found: {history_file}",
                    },
                    indent=2,
                )
            )
        else:
            click.echo(f"❌ History file not found: {history_file}")
            click.echo("\n💡 Generate metrics history with: manifestguard coverage-track")
        sys.exit(2)

    try:
        weekly_aggregates = reconstruct_weekly_coverage(history_file)

        if not weekly_aggregates:
            if output_json:
                click.echo(
                    json.dumps(
                        {
                            "success": True,
                            "weekly_aggregates": {},
                            "message": "No weekly coverage data found in history",
                        },
                        indent=2,
                    )
                )
            else:
                click.echo("⚠️  No weekly coverage data found in history")
            return

        if output:
            export_weekly_summary_json(weekly_aggregates, output)
            if not output_json:
                click.echo(f"✅ Weekly summary exported to: {output}")

        if output_json:
            from manifestguard.extended.coverage_weekly import calculate_multi_week_trend

            multi_trend = calculate_multi_week_trend(weekly_aggregates)
            click.echo(
                json.dumps(
                    {
                        "success": True,
                        "history_file": str(history_file),
                        "weekly_aggregates": weekly_aggregates,
                        "multi_week_trend": multi_trend,
                        "summary": {
                            "total_weeks": len(weekly_aggregates),
                            "weeks": sorted(weekly_aggregates.keys()),
                        },
                    },
                    indent=2,
                )
            )
        else:
            click.echo(format_weekly_summary(weekly_aggregates))
            click.echo(f"\n📁 History: {history_file}")

    except Exception as e:
        if output_json:
            click.echo(
                json.dumps(
                    {"success": False, "error": "exception", "message": str(e)},
                    indent=2,
                )
            )
        else:
            click.echo(f"❌ Error reconstructing weekly coverage: {e}")
        sys.exit(1)



def register(cli: click.Group) -> None:
    cli.add_command(complexity)
    cli.add_command(baseline)
    cli.add_command(worker_group)
    cli.add_command(coverage_track)
    cli.add_command(coverage_weekly)
    cli.add_command(venv_health_weekly)
    cli.add_command(venv_health_track)
    cli.add_command(export_metrics_cmd)
    cli.add_command(reconstruct_metrics)
