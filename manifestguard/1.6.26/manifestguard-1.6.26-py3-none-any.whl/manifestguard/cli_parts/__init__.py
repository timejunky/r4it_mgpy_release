"""CLI command modules split from `manifestguard.cli`.

This package exists to keep per-file LOC under the internal limit while keeping
`manifestguard.cli` as the primary import location for tests and entrypoints.
"""
