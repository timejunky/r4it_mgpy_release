"""Pydantic models for API contracts (F-019)

This module provides:
- Request/response validation
- OpenAPI schema generation
- Type-safe API contracts
- Automatic documentation
"""

from .base import BaseResponse, ErrorResponse, SuccessResponse
from .config import ConfigRequest, ConfigResponse, ConfigTemplate
from .environment import (
    EnvironmentCreate,
    EnvironmentListResponse,
    EnvironmentResponse,
    EnvironmentUpdate,
)
from .metrics import (
    CoverageMetrics,
    DependencyMetrics,
    MetricsReport,
    MetricsResponse,
    SecurityMetrics,
)
from .validation import (
    DiagnosticModel,
    DiagnosticSeverity,
    ValidationRequest,
    ValidationResponse,
    ValidationResult,
)

__all__ = [
    # Base
    "BaseResponse",
    # Config
    "ConfigRequest",
    "ConfigResponse",
    "ConfigTemplate",
    # Metrics
    "CoverageMetrics",
    "DependencyMetrics",
    "DiagnosticModel",
    "DiagnosticSeverity",
    # Environment
    "EnvironmentCreate",
    "EnvironmentListResponse",
    "EnvironmentResponse",
    "EnvironmentUpdate",
    "ErrorResponse",
    "MetricsReport",
    "MetricsResponse",
    "SecurityMetrics",
    "SuccessResponse",
    # Validation
    "ValidationRequest",
    "ValidationResponse",
    "ValidationResult",
]
