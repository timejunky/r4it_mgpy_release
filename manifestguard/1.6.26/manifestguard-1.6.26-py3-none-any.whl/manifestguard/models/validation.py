"""Validation API models
"""

from enum import Enum
from pathlib import Path

from pydantic import BaseModel, ConfigDict, Field, field_validator


class DiagnosticSeverity(str, Enum):
    """Diagnostic severity levels"""

    ERROR = "error"
    WARNING = "warning"
    INFO = "info"


class DiagnosticModel(BaseModel):
    """Diagnostic message model"""

    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "code": "PYP-001",
                "severity": "error",
                "message": "pyproject.toml not found in project root",
                "file": "pyproject.toml",
                "line": None,
                "column": None,
                "suggestion": "Create pyproject.toml with [project] section",
            },
        }
    )

    code: str = Field(..., description="Diagnostic code (e.g., PYP-001)")
    severity: DiagnosticSeverity = Field(..., description="Severity level")
    message: str = Field(..., description="Diagnostic message")
    file: str | None = Field(None, description="File path")
    line: int | None = Field(None, ge=1, description="Line number")
    column: int | None = Field(None, ge=1, description="Column number")
    suggestion: str | None = Field(None, description="Fix suggestion")


class ValidationRequest(BaseModel):
    """Request model for manifest validation"""

    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "project_path": "/path/to/project",
                "strict": False,
                "include_warnings": True,
            },
        }
    )

    project_path: str = Field(..., description="Path to project root")
    strict: bool = Field(False, description="Enable strict validation mode")
    include_warnings: bool = Field(True, description="Include warnings in results")

    @field_validator("project_path")
    @classmethod
    def path_must_exist(cls, v: str) -> str:
        """Validate that project path exists"""
        path = Path(v)
        if not path.exists():
            raise ValueError(f"Project path does not exist: {v}")
        if not path.is_dir():
            raise ValueError(f"Project path is not a directory: {v}")
        return str(path.resolve())


class ValidationResult(BaseModel):
    """Validation result summary"""

    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "is_valid": False,
                "errors": 1,
                "warnings": 2,
                "infos": 3,
                "diagnostics": [
                    {
                        "code": "PYP-001",
                        "severity": "error",
                        "message": "pyproject.toml not found",
                        "file": "pyproject.toml",
                        "line": None,
                        "column": None,
                        "suggestion": "Create pyproject.toml",
                    },
                ],
            },
        }
    )

    is_valid: bool = Field(..., description="Overall validation result")
    errors: int = Field(..., ge=0, description="Number of errors")
    warnings: int = Field(..., ge=0, description="Number of warnings")
    infos: int = Field(..., ge=0, description="Number of info messages")
    diagnostics: list[DiagnosticModel] = Field(..., description="Diagnostic messages")


class ValidationResponse(BaseModel):
    """Response model for validation endpoint"""

    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "success": True,
                "result": {
                    "is_valid": False,
                    "errors": 1,
                    "warnings": 0,
                    "infos": 0,
                    "diagnostics": [],
                },
                "project_path": "/path/to/project",
            },
        }
    )

    success: bool = Field(..., description="Whether validation completed")
    result: ValidationResult = Field(..., description="Validation result")
    project_path: str = Field(..., description="Validated project path")
