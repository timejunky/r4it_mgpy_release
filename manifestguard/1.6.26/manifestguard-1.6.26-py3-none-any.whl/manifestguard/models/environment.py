"""Environment API models
"""

from datetime import datetime

from pydantic import BaseModel, ConfigDict, Field, field_validator


class EnvironmentCreate(BaseModel):
    """Request model for creating an environment"""

    model_config = ConfigDict(
        json_schema_extra={
            "example": {"name": "production", "description": "Production environment"},
        }
    )

    name: str = Field(..., min_length=1, max_length=100, description="Environment name")
    description: str | None = Field(
        None,
        max_length=500,
        description="Environment description",
    )

    @field_validator("name")
    @classmethod
    def name_must_be_valid(cls, v: str) -> str:
        """Validate environment name"""
        if not v.strip():
            raise ValueError("Name cannot be empty or whitespace")
        if any(c in v for c in ["<", ">", "&", '"', "'"]):
            raise ValueError("Name contains invalid characters")
        return v.strip()


class EnvironmentUpdate(BaseModel):
    """Request model for updating an environment"""

    model_config = ConfigDict(
        json_schema_extra={
            "example": {"description": "Updated description"},
        }
    )

    name: str | None = Field(
        None,
        min_length=1,
        max_length=100,
        description="Environment name",
    )
    description: str | None = Field(
        None,
        max_length=500,
        description="Environment description",
    )

    @field_validator("name")
    @classmethod
    def name_must_be_valid(cls, v: str | None) -> str | None:
        """Validate environment name if provided"""
        if v is None:
            return v
        if not v.strip():
            raise ValueError("Name cannot be empty or whitespace")
        if any(c in v for c in ["<", ">", "&", '"', "'"]):
            raise ValueError("Name contains invalid characters")
        return v.strip()


class EnvironmentResponse(BaseModel):
    """Response model for a single environment"""

    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "id": "env-123",
                "name": "production",
                "description": "Production environment",
                "created_at": "2025-11-28T10:00:00Z",
                "updated_at": "2025-11-28T10:00:00Z",
            },
        }
    )

    id: str = Field(..., description="Environment ID")
    name: str = Field(..., description="Environment name")
    description: str | None = Field(None, description="Environment description")
    created_at: datetime = Field(..., description="Creation timestamp")
    updated_at: datetime = Field(..., description="Last update timestamp")


class EnvironmentListResponse(BaseModel):
    """Response model for listing environments"""

    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "environments": [
                    {
                        "id": "env-123",
                        "name": "production",
                        "description": "Production environment",
                        "created_at": "2025-11-28T10:00:00Z",
                        "updated_at": "2025-11-28T10:00:00Z",
                    },
                ],
                "total": 1,
            },
        }
    )

    environments: list[EnvironmentResponse] = Field(..., description="List of environments")
    total: int = Field(..., ge=0, description="Total number of environments")
