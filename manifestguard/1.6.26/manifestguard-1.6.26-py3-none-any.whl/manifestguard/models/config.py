"""Configuration API models
"""

from typing import Any

from pydantic import BaseModel, ConfigDict, Field


class ConfigRequest(BaseModel):
    """Request model for config generation"""

    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "project_path": "/path/to/project",
                "merge_existing": True,
                "include_ai_recommendations": False,
            },
        }
    )

    project_path: str = Field(..., description="Path to project root")
    merge_existing: bool = Field(False, description="Merge with existing config")
    include_ai_recommendations: bool = Field(False, description="Include AI recommendations")


class ConfigTemplate(BaseModel):
    """Configuration template model"""

    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "access_level": "balanced",
                "rules": {"PYP-001": True, "PYP-002": True},
                "severity_overrides": {"PYP-003": "warning"},
                "monorepo": {"roots": ["packages/"]},
            },
        }
    )

    access_level: str = Field("balanced", description="Access level (strict/balanced/permissive)")
    rules: dict[str, Any] = Field(default_factory=dict, description="Rule configuration")
    severity_overrides: dict[str, str] = Field(
        default_factory=dict,
        description="Severity overrides",
    )
    monorepo: dict[str, list[str]] | None = Field(None, description="Monorepo configuration")


class ConfigResponse(BaseModel):
    """Response model for config generation"""

    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "success": True,
                "config": {
                    "access_level": "balanced",
                    "rules": {},
                    "severity_overrides": {},
                },
                "recommendations": [
                    "Consider enabling strict mode for production",
                    "Add severity override for PYP-003",
                ],
                "merged": False,
            },
        }
    )

    success: bool = Field(..., description="Whether config generation succeeded")
    config: ConfigTemplate = Field(..., description="Generated configuration")
    recommendations: list[str] = Field(
        default_factory=list, description="Configuration recommendations"
    )
    merged: bool = Field(False, description="Whether config was merged with existing")
