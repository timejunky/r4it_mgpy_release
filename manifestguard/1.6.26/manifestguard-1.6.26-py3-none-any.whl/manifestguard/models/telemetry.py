"""Telemetry schema models for ManifestGuard metrics export.

This module defines the canonical telemetry schema (v1.0) for exporting
ManifestGuard metrics to downstream dashboards (MGVS, Web UI, CI/CD).

Schema Version: 1.0.0
Spec: TODO-018 (Q1 2026)
"""

from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field


class RuffTelemetry(BaseModel):
    """Ruff linter/formatter telemetry.
    
    Captures Ruff version, issue counts, and rule-level breakdowns.
    Used for quality tracking and dashboard visualization.
    """

    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "issueCount": 0,
                "warningCount": 0,
                "version": "0.1.14",
                "source": "venv",
                "byRule": {
                    "E501": 5,
                    "F401": 2,
                    "PLC0415": 0,
                },
            },
        }
    )

    issueCount: int = Field(0, ge=0, description="Total Ruff violations")
    warningCount: int = Field(0, ge=0, description="Total Ruff warnings")
    version: str | None = Field(None, description="Ruff version (e.g. '0.1.14')")
    source: Literal["venv", "system", "none"] = Field(
        "none", description="Ruff installation source"
    )
    byRule: dict[str, int] = Field(
        default_factory=dict, description="Issue count per rule (e.g. E501: 5)"
    )


class RadonTelemetry(BaseModel):
    """Radon complexity analyzer telemetry (legacy).
    
    Note: Radon is being phased out in favor of mgpy-analyzer (ADR-012).
    This schema is maintained for backwards compatibility.
    """

    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "version": "6.0.1",
                "source": "venv",
            },
        }
    )

    version: str | None = Field(None, description="Radon version")
    source: Literal["venv", "system", "none"] = Field(
        "none", description="Radon installation source"
    )


class ComplexityHotspot(BaseModel):
    """Single complexity hotspot (function/method).
    
    Represents a high-complexity function that exceeds the threshold.
    """

    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "file": "src/myapp/utils.py",
                "name": "process_data",
                "line": 42,
                "value": 15,
            },
        }
    )

    file: str = Field(..., description="File path (relative to project root)")
    name: str = Field(..., description="Function/method name")
    line: int = Field(..., ge=1, description="Line number (1-indexed)")
    value: int = Field(..., ge=1, description="Cyclomatic complexity value")


class ComplexityTelemetry(BaseModel):
    """Complexity analysis telemetry.
    
    Captures average complexity, violations, and top hotspots.
    Supports both mgpy-analyzer (default) and Radon (legacy).
    """

    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "avg": 4.2,
                "violations": 3,
                "threshold": 10,
                "functionsAboveThreshold": 3,
                "hotspots": [
                    {
                        "file": "src/myapp/utils.py",
                        "name": "process_data",
                        "line": 42,
                        "value": 15,
                    }
                ],
                "engine": "mgpy-analyzer",
                "engineVersion": "1.5.31",
            },
        }
    )

    avg: float = Field(..., ge=0, description="Average complexity across all functions")
    violations: int = Field(
        ..., ge=0, description="Functions above threshold (legacy alias)"
    )
    threshold: int = Field(..., ge=1, description="Complexity threshold")
    functionsAboveThreshold: int = Field(
        ..., ge=0, description="Functions exceeding threshold"
    )
    hotspots: list[ComplexityHotspot] = Field(
        default_factory=list, description="Top 5 complexity hotspots"
    )
    engine: Literal["mgpy-analyzer", "radon"] = Field(
        "mgpy-analyzer", description="Complexity analyzer engine"
    )
    engineVersion: str | None = Field(None, description="Engine version")


class CoverageTelemetry(BaseModel):
    """Test coverage telemetry.
    
    Captures line/branch coverage percentages and absolute counts.
    """

    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "line": 85.5,
                "branch": 78.2,
                "totalLines": 1000,
                "coveredLines": 855,
                "missingLines": 145,
                "source": "pytest-cov",
            },
        }
    )

    line: float = Field(..., ge=0, le=100, description="Line coverage percentage")
    branch: float | None = Field(None, ge=0, le=100, description="Branch coverage percentage")
    totalLines: int = Field(..., ge=0, description="Total lines of code")
    coveredLines: int = Field(..., ge=0, description="Covered lines")
    missingLines: int = Field(..., ge=0, description="Missing coverage lines")
    source: Literal["pytest-cov", "coverage.py", "other"] = Field(
        "pytest-cov", description="Coverage tool source"
    )


class SecurityTelemetry(BaseModel):
    """Security analysis telemetry.
    
    Captures security issues by severity and SAST-lite metrics.
    """

    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "highSeverity": 0,
                "mediumSeverity": 2,
                "lowSeverity": 5,
                "score": 92.0,
                "hardcodedSecrets": 0,
                "weakCrypto": 1,
                "insecureDeserialization": 0,
            },
        }
    )

    highSeverity: int = Field(0, ge=0, description="High severity issues")
    mediumSeverity: int = Field(0, ge=0, description="Medium severity issues")
    lowSeverity: int = Field(0, ge=0, description="Low severity issues")
    score: float = Field(100.0, ge=0, le=100, description="Security score (0-100)")
    hardcodedSecrets: int = Field(0, ge=0, description="Potential hardcoded secrets")
    weakCrypto: int = Field(0, ge=0, description="Weak cryptography usage")
    insecureDeserialization: int = Field(0, ge=0, description="Unsafe pickle/yaml usage")


class DuplicationTelemetry(BaseModel):
    """Code duplication telemetry.
    
    Captures exact and near-duplicate code blocks (ADR-013).
    """

    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "exactDuplicates": 3,
                "nearDuplicates": 7,
                "threshold": 5,
                "duplicatedLines": 45,
                "totalLines": 1000,
            },
        }
    )

    exactDuplicates: int = Field(0, ge=0, description="Exact duplicate code blocks")
    nearDuplicates: int = Field(0, ge=0, description="Near-duplicate code blocks (token-based)")
    threshold: int = Field(5, ge=1, description="Minimum lines for duplication detection")
    duplicatedLines: int = Field(0, ge=0, description="Total duplicated lines")
    totalLines: int = Field(0, ge=0, description="Total project lines")


class DummyRecognitionTelemetry(BaseModel):
    """Dummy/stub code recognition telemetry.
    
    Captures TODO/FIXME markers, NotImplemented, no-op functions (ADR-015).
    """

    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "markers": 12,
                "notImplemented": 3,
                "noOp": 2,
                "catchIgnore": 1,
                "testArtifacts": 5,
                "suppressed": 2,
            },
        }
    )

    markers: int = Field(0, ge=0, description="TODO/FIXME/HACK markers")
    notImplemented: int = Field(0, ge=0, description="NotImplementedError raises")
    noOp: int = Field(0, ge=0, description="No-op/constant-return functions")
    catchIgnore: int = Field(0, ge=0, description="Catch-and-ignore patterns")
    testArtifacts: int = Field(0, ge=0, description="Test placeholder code")
    suppressed: int = Field(0, ge=0, description="Suppressed dummy code (allowlist)")


class QualityTelemetry(BaseModel):
    """Aggregated quality telemetry (main export schema).
    
    This is the top-level schema exported to dashboards and CI/CD.
    Combines all analyzer telemetry into a single JSON payload.
    
    Schema Version: 1.0.0
    """

    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "schemaVersion": "1.0.0",
                "timestamp": "2026-01-17T12:34:56Z",
                "projectName": "my-project",
                "projectVersion": "1.0.0",
                "manifestguardVersion": "1.5.31",
                "ruff": {
                    "issueCount": 0,
                    "warningCount": 0,
                    "version": "0.1.14",
                    "source": "venv",
                    "byRule": {},
                },
                "complexity": {
                    "avg": 4.2,
                    "violations": 3,
                    "threshold": 10,
                    "functionsAboveThreshold": 3,
                    "hotspots": [],
                    "engine": "mgpy-analyzer",
                    "engineVersion": "1.5.31",
                },
                "coverage": {
                    "line": 85.5,
                    "branch": 78.2,
                    "totalLines": 1000,
                    "coveredLines": 855,
                    "missingLines": 145,
                    "source": "pytest-cov",
                },
                "security": {
                    "highSeverity": 0,
                    "mediumSeverity": 2,
                    "lowSeverity": 5,
                    "score": 92.0,
                    "hardcodedSecrets": 0,
                    "weakCrypto": 1,
                    "insecureDeserialization": 0,
                },
                "duplication": {
                    "exactDuplicates": 3,
                    "nearDuplicates": 7,
                    "threshold": 5,
                    "duplicatedLines": 45,
                    "totalLines": 1000,
                },
                "dummyRecognition": {
                    "markers": 12,
                    "notImplemented": 3,
                    "noOp": 2,
                    "catchIgnore": 1,
                    "testArtifacts": 5,
                    "suppressed": 2,
                },
                "qualityScore": 87.5,
                "radon": {
                    "version": "6.0.1",
                    "source": "venv",
                },
            },
        }
    )

    schemaVersion: str = Field("1.0.0", description="Telemetry schema version (semver)")
    timestamp: str = Field(..., description="ISO 8601 timestamp (UTC)")
    projectName: str = Field(..., description="Project name")
    projectVersion: str | None = Field(None, description="Project version (from manifest)")
    manifestguardVersion: str = Field(..., description="ManifestGuard version")

    ruff: RuffTelemetry = Field(..., description="Ruff linter telemetry")
    complexity: ComplexityTelemetry | None = Field(None, description="Complexity telemetry")
    coverage: CoverageTelemetry | None = Field(None, description="Coverage telemetry")
    security: SecurityTelemetry | None = Field(None, description="Security telemetry")
    duplication: DuplicationTelemetry | None = Field(None, description="Duplication telemetry")
    dummyRecognition: DummyRecognitionTelemetry | None = Field(
        None, description="Dummy code recognition telemetry"
    )

    qualityScore: float | None = Field(None, ge=0, le=100, description="Overall quality score")
    radon: RadonTelemetry | None = Field(None, description="Radon telemetry (legacy)")


# Convenience re-exports
__all__ = [
    "QualityTelemetry",
    "RuffTelemetry",
    "ComplexityTelemetry",
    "ComplexityHotspot",
    "CoverageTelemetry",
    "SecurityTelemetry",
    "DuplicationTelemetry",
    "DummyRecognitionTelemetry",
    "RadonTelemetry",
]
