"""GUI state + repo/project management mixin.

This is extracted from `manifestguard.gui` to keep the main GUI module smaller.
It contains:
- per-user gui.json persistence
- project catalog handling
- repo settings scoping (userwide vs per-project)
- theme handling
"""

from __future__ import annotations

import json
import os
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import cast

from PySide6.QtGui import QColor, QPalette
from PySide6.QtWidgets import (
    QApplication,
    QCheckBox,
    QComboBox,
    QFileDialog,
    QLineEdit,
    QMessageBox,
    QWidget,
)

from manifestguard.core.safe_json_writer import write_json_file_sync
from manifestguard.gui_support import detect_git_origin_url


class GuiStateMixin:
    def _gui_state_path(self) -> Path:
        """Return per-user GUI state path (not workspace/project config)."""
        if sys.platform == "win32":
            app_data = os.environ.get("APPDATA")
            base_dir = (
                Path(app_data) / "manifestguard" if app_data else Path.home() / ".manifestguard"
            )
        else:
            xdg = os.environ.get("XDG_CONFIG_HOME")
            base_dir = Path(xdg) / "manifestguard" if xdg else Path.home() / ".config" / "manifestguard"

        base_dir.mkdir(parents=True, exist_ok=True)
        return base_dir / "gui.json"

    def _load_gui_state(self) -> dict:
        path = self._gui_state_path()
        try:
            if not path.exists():
                return {}
            raw = json.loads(path.read_text(encoding="utf-8"))
            if not isinstance(raw, dict):
                return {}
            migrated = self._migrate_gui_state(raw)
            if migrated is not raw:
                self._save_gui_state(migrated)
            return migrated
        except Exception:
            return {}

    def _save_gui_state(self, state: dict) -> None:
        path = self._gui_state_path()
        try:
            write_json_file_sync(path, state, prettify=True, indent=2, line_ending="lf")
        except Exception:
            return

    @staticmethod
    def _is_multi_project_state(state: dict) -> bool:
        projects = state.get("projects")
        active = state.get("activeProjectRoot")
        return isinstance(projects, list) and isinstance(active, str)

    def _maybe_add_project_root(self, out: list[dict], root_str: str) -> None:
        root_str = (root_str or "").strip()
        if not root_str:
            return
        try:
            root = Path(root_str).expanduser().resolve()
        except Exception:
            return
        if not root.exists() or not root.is_dir():
            return
        out.append(self._create_project_record(root))

    @staticmethod
    def _dedupe_projects_by_root(records: list[dict]) -> list[dict]:
        dedup: dict[str, dict] = {}
        for rec in records:
            r = rec.get("root")
            if isinstance(r, str) and r:
                dedup[r] = rec
        return list(dedup.values())

    @staticmethod
    def _migrate_legacy_key(state: dict, *, target_key: str, legacy_keys: list[str]) -> None:
        if state.get(target_key):
            return
        for k in legacy_keys:
            v = state.get(k)
            if isinstance(v, str) and v:
                state[target_key] = v
                return

    def _migrate_gui_state(self, state: dict) -> dict:
        """Migrate legacy single-project GUI state into a multi-project catalog.

        This only touches per-user GUI state (gui.json). It does not write to projects.
        """

        if not isinstance(state, dict):
            return {}

        if self._is_multi_project_state(state):
            return state

        migrated = dict(state)

        migrated_projects: list[dict] = []
        legacy_root = migrated.get("projectRoot")
        if isinstance(legacy_root, str):
            self._maybe_add_project_root(migrated_projects, legacy_root)

        legacy_ws = migrated.get("validationWorkspace")
        if isinstance(legacy_ws, str):
            self._maybe_add_project_root(migrated_projects, legacy_ws)

        migrated["projects"] = self._dedupe_projects_by_root(migrated_projects)

        active = migrated.get("activeProjectRoot")
        if not (isinstance(active, str) and active):
            migrated["activeProjectRoot"] = (
                migrated["projects"][0]["root"] if migrated.get("projects") else ""
            )

        # Keep legacy key in sync for backward compatibility.
        active_root = migrated.get("activeProjectRoot")
        if isinstance(active_root, str) and active_root:
            migrated["projectRoot"] = active_root

        # Repo settings legacy migrations (best-effort)
        self._migrate_legacy_key(
            migrated,
            target_key="user_repo_root",
            legacy_keys=["userRepoRoot", "userRepo", "user_repo"],
        )
        self._migrate_legacy_key(
            migrated,
            target_key="wheel_repo_path",
            legacy_keys=["wheelRepositoryPath", "wheelRepoPath", "wheel_repo"],
        )
        self._migrate_legacy_key(
            migrated,
            target_key="remote_origin_url",
            legacy_keys=["remoteOriginUrl", "remoteOrigin", "originUrl"],
        )

        return migrated

    def _get_manifestguard_json_path(self) -> Path | None:
        root = self._get_active_project_root()
        if root is None:
            return None
        return root / "manifestguard.json"

    def _merge_manifestguard_json_settings(self, *, updates: dict) -> None:
        path = self._get_manifestguard_json_path()
        if path is None:
            return
        try:
            current: dict = {}
            if path.exists():
                raw = json.loads(path.read_text(encoding="utf-8"))
                if isinstance(raw, dict):
                    current = raw

            merged = dict(current)
            merged.update(updates)
            write_json_file_sync(path, merged, prettify=True, indent=2, line_ending="lf")
        except Exception:
            return

    def _load_repo_settings(self) -> None:
        state = self._load_gui_state()

        scope = self._get_repo_settings_scope(state)
        self._repo_settings_scope_current = scope
        if hasattr(self, "repo_settings_scope_combo"):
            combo = cast(QComboBox, getattr(self, "repo_settings_scope_combo"))
            for i in range(combo.count()):
                if combo.itemData(i) == scope:
                    combo.blockSignals(True)
                    combo.setCurrentIndex(i)
                    combo.blockSignals(False)
                    break

        repo_state = self._get_effective_repo_settings_state(state, scope)
        if hasattr(self, "user_repo_root_edit"):
            cast(QLineEdit, getattr(self, "user_repo_root_edit")).setText(
                str(repo_state.get("user_repo_root") or "")
            )
        if hasattr(self, "wheel_repo_path_edit"):
            cast(QLineEdit, getattr(self, "wheel_repo_path_edit")).setText(
                str(repo_state.get("wheel_repo_path") or "")
            )
        if hasattr(self, "remote_origin_url_edit"):
            cast(QLineEdit, getattr(self, "remote_origin_url_edit")).setText(
                str(repo_state.get("remote_origin_url") or "")
            )

        if hasattr(self, "preflight_capture_packages_checkbox"):
            cast(QCheckBox, getattr(self, "preflight_capture_packages_checkbox")).setChecked(
                bool(state.get("preflight_capture_packages", False))
            )
        if hasattr(self, "preflight_packages_write_full_checkbox"):
            cast(QCheckBox, getattr(self, "preflight_packages_write_full_checkbox")).setChecked(
                bool(state.get("preflight_packages_write_full_snapshot", True))
            )

        if hasattr(self, "wheel_backfill_enabled_checkbox"):
            cast(QCheckBox, getattr(self, "wheel_backfill_enabled_checkbox")).setChecked(
                bool(state.get("wheel_backfill_enabled", False))
            )

        # Best-effort: auto-fill origin URL (and default wheel repo path) if empty.
        self._maybe_autofill_repo_fields(persist=True)

    def _save_repo_settings(
        self,
        *,
        scope_override: str | None = None,
        update_scope_value: bool = True,
    ) -> None:
        state = self._load_gui_state()

        scope = scope_override or self._get_repo_settings_scope_from_ui(state)
        if update_scope_value:
            state["repo_settings_scope"] = scope
            self._repo_settings_scope_current = scope

        repo_updates: dict[str, str] = {}
        if hasattr(self, "user_repo_root_edit"):
            repo_updates["user_repo_root"] = cast(
                QLineEdit, getattr(self, "user_repo_root_edit")
            ).text().strip()
        if hasattr(self, "wheel_repo_path_edit"):
            repo_updates["wheel_repo_path"] = cast(
                QLineEdit, getattr(self, "wheel_repo_path_edit")
            ).text().strip()
        if hasattr(self, "remote_origin_url_edit"):
            repo_updates["remote_origin_url"] = cast(
                QLineEdit, getattr(self, "remote_origin_url_edit")
            ).text().strip()

        if scope == "project":
            active_root = self._get_active_project_root_str()
            if active_root:
                self._set_project_repo_settings_state(state, active_root, repo_updates)
            else:
                # No active project -> fall back to user-wide.
                state.update(repo_updates)
        else:
            state.update(repo_updates)

        if hasattr(self, "preflight_capture_packages_checkbox"):
            state["preflight_capture_packages"] = bool(
                cast(QCheckBox, getattr(self, "preflight_capture_packages_checkbox")).isChecked()
            )
        if hasattr(self, "preflight_packages_write_full_checkbox"):
            state["preflight_packages_write_full_snapshot"] = bool(
                cast(QCheckBox, getattr(self, "preflight_packages_write_full_checkbox")).isChecked()
            )

        if hasattr(self, "wheel_backfill_enabled_checkbox"):
            state["wheel_backfill_enabled"] = bool(
                cast(QCheckBox, getattr(self, "wheel_backfill_enabled_checkbox")).isChecked()
            )
        self._save_gui_state(state)

    def _on_toggle_wheel_backfill(self, _state: int) -> None:
        # One-time consent gate: once accepted, never ask again.
        saved = self._load_gui_state()
        enabled = bool(
            cast(QCheckBox, getattr(self, "wheel_backfill_enabled_checkbox")).isChecked()
        )
        if not enabled:
            self._save_repo_settings()
            return

        if bool(saved.get("wheel_backfill_consent", False)):
            self._save_repo_settings()
            return

        msg = (
            "Enable automatic wheel backfill?\n\n"
            "When enabled, ManifestGuard will download missing wheels for newly added/changed packages "
            "into your shared wheel repository. This may access package indexes/network depending on your pip config.\n\n"
            "This confirmation is asked only once."
        )
        result = QMessageBox.question(cast(QWidget, self), "Enable Wheel Backfill", msg)
        if result != QMessageBox.StandardButton.Yes:
            # Revert
            checkbox = cast(QCheckBox, getattr(self, "wheel_backfill_enabled_checkbox"))
            checkbox.blockSignals(True)
            checkbox.setChecked(False)
            checkbox.blockSignals(False)
            self._save_repo_settings()
            return

        saved["wheel_backfill_consent"] = True
        saved["wheel_backfill_enabled"] = True
        self._save_gui_state(saved)
        self._save_repo_settings()

    def _get_repo_settings_scope(self, state: dict) -> str:
        raw = state.get("repo_settings_scope")
        return raw if raw in {"userwide", "project"} else "userwide"

    def _get_repo_settings_scope_from_ui(self, state: dict) -> str:
        if hasattr(self, "repo_settings_scope_combo"):
            combo = cast(QComboBox, getattr(self, "repo_settings_scope_combo"))
            value = combo.currentData()
            if value in {"userwide", "project"}:
                return str(value)
        return self._get_repo_settings_scope(state)

    def _get_effective_repo_settings_state(self, state: dict, scope: str) -> dict:
        if scope != "project":
            return state

        active_root = self._get_active_project_root_str()
        if not active_root:
            return state

        projects = state.get("projects")
        if not isinstance(projects, list):
            return state

        for rec in projects:
            if not isinstance(rec, dict):
                continue
            if rec.get("root") != active_root:
                continue
            repo_state = rec.get("repoSettings")
            return repo_state if isinstance(repo_state, dict) else {}

        return {}

    def _set_project_repo_settings_state(self, state: dict, active_root: str, updates: dict) -> None:
        projects = state.get("projects")
        if not isinstance(projects, list):
            projects = []

        found = False
        for rec in projects:
            if not isinstance(rec, dict):
                continue
            if rec.get("root") != active_root:
                continue
            repo_state = rec.get("repoSettings")
            if not isinstance(repo_state, dict):
                repo_state = {}
                rec["repoSettings"] = repo_state
            repo_state.update(updates)
            found = True
            break

        if not found:
            # Ensure the project exists in the catalog.
            rec = self._create_project_record(Path(active_root))
            rec["repoSettings"] = dict(updates)
            projects.append(rec)

        state["projects"] = projects

    def _maybe_autofill_repo_fields(self, *, persist: bool) -> None:
        if not (hasattr(self, "remote_origin_url_edit") and hasattr(self, "user_repo_root_edit")):
            return

        origin_current = self._get_line_edit_text("remote_origin_url_edit")
        user_repo_root = self._get_line_edit_text("user_repo_root_edit")

        candidate = self._resolve_repo_root_candidate(user_repo_root)

        changed = False

        if self._should_autofill_origin(origin_current, candidate):
            self._autofill_origin_url(candidate)
            changed = True

        if self._should_autofill_wheel_repo_path(user_repo_root):
            if self._autofill_wheel_repo_path(user_repo_root):
                changed = True

        if changed and persist:
            self._save_repo_settings()

    def _get_line_edit_text(self, attr_name: str) -> str:
        if not hasattr(self, attr_name):
            return ""
        widget = getattr(self, attr_name)
        if not isinstance(widget, QLineEdit):
            return ""
        return widget.text().strip()

    def _set_line_edit_text(self, attr_name: str, value: str) -> None:
        if not hasattr(self, attr_name):
            return
        widget = getattr(self, attr_name)
        if not isinstance(widget, QLineEdit):
            return
        widget.setText(value)

    def _resolve_repo_root_candidate(self, user_repo_root: str) -> Path | None:
        candidate: Path | None = None
        if user_repo_root:
            try:
                candidate = Path(user_repo_root).expanduser().resolve()
            except Exception:
                candidate = None
        if candidate is None or not candidate.exists() or not candidate.is_dir():
            candidate = self._get_active_project_root()
        return candidate

    def _should_autofill_origin(self, origin_current: str, candidate: Path | None) -> bool:
        return not origin_current and candidate is not None

    def _autofill_origin_url(self, candidate: Path | None) -> None:
        if candidate is None:
            return
        url = detect_git_origin_url(candidate, timeout_seconds=2)
        if url:
            self._set_line_edit_text("remote_origin_url_edit", url)

    def _should_autofill_wheel_repo_path(self, user_repo_root: str) -> bool:
        if not hasattr(self, "wheel_repo_path_edit"):
            return False
        if not user_repo_root:
            return False
        current = self._get_line_edit_text("wheel_repo_path_edit")
        return not current

    def _autofill_wheel_repo_path(self, user_repo_root: str) -> bool:
        try:
            default_wheels = str((Path(user_repo_root) / "wheels").resolve())
            self._set_line_edit_text("wheel_repo_path_edit", default_wheels)
            return True
        except Exception:
            return False

    def _on_repo_settings_scope_changed(self, _index: int) -> None:
        # Persist current field values into the *previous* scope, then switch scope.
        state = self._load_gui_state()
        old_scope = getattr(self, "_repo_settings_scope_current", self._get_repo_settings_scope(state))
        new_scope = self._get_repo_settings_scope_from_ui(state)
        if new_scope == old_scope:
            return

        # Save current edits into the old scope without flipping the stored scope yet.
        self._save_repo_settings(scope_override=old_scope, update_scope_value=False)

        # Now persist the new scope selection and reload fields from that scope.
        state = self._load_gui_state()
        state["repo_settings_scope"] = new_scope
        self._save_gui_state(state)
        self._load_repo_settings()

    def _browse_folder_into(self, line_edit: QLineEdit) -> None:
        start_dir = line_edit.text().strip() or str(Path.cwd())
        folder = QFileDialog.getExistingDirectory(cast(QWidget, self), "Select folder", start_dir)
        if folder:
            line_edit.setText(folder)
            if getattr(self, "user_repo_root_edit", None) is line_edit:
                self._maybe_autofill_repo_fields(persist=True)

    def _get_user_repo_root(self) -> Path | None:
        state = self._load_gui_state()
        scope = self._get_repo_settings_scope(state)
        repo_state = self._get_effective_repo_settings_state(state, scope)
        raw = (repo_state.get("user_repo_root") or "").strip()
        if not raw:
            return None
        try:
            p = Path(raw).expanduser().resolve()
        except Exception:
            return None
        return p if p.exists() and p.is_dir() else None

    def _now_iso(self) -> str:
        return datetime.now(timezone.utc).isoformat(timespec="seconds")

    def _create_project_record(self, root: Path) -> dict:
        return {
            "root": str(root),
            "displayName": root.name or str(root),
            "pinned": False,
            "lastUsedAt": self._now_iso(),
            "lastReport": "manifestguard-report.json",
            "lastExtended": True,
            "repoSettings": {},
        }

    def _get_projects(self) -> list[dict]:
        state = self._load_gui_state()
        projects = state.get("projects")
        if not isinstance(projects, list):
            return []
        out: list[dict] = []
        for item in projects:
            if isinstance(item, dict) and isinstance(item.get("root"), str):
                out.append(item)
        return out

    def _save_projects(self, projects: list[dict], *, active_root: str | None = None) -> None:
        state = self._load_gui_state()
        state["projects"] = projects
        if isinstance(active_root, str):
            state["activeProjectRoot"] = active_root
            state["projectRoot"] = active_root
        self._save_gui_state(state)

    def _normalize_root(self, root: Path | str) -> str:
        try:
            path = root if isinstance(root, Path) else Path(str(root))
            return str(path.expanduser().resolve())
        except Exception:
            return str(root)

    def _get_active_project_root_str(self) -> str:
        state = self._load_gui_state()
        raw = state.get("activeProjectRoot") or state.get("projectRoot") or state.get("validationWorkspace")
        if isinstance(raw, str):
            return raw
        return ""

    def _get_active_project_root(self) -> Path | None:
        raw = (self._get_active_project_root_str() or "").strip()
        if not raw:
            return None
        try:
            root = Path(raw).expanduser().resolve()
        except Exception:
            return None
        if not root.exists() or not root.is_dir():
            return None
        return root

    def _set_active_project_root(self, root: Path) -> None:
        root_str = self._normalize_root(root)

        projects = self._get_projects()
        existing = None
        for rec in projects:
            if rec.get("root") == root_str:
                existing = rec
                break

        if existing is None:
            projects.append(self._create_project_record(Path(root_str)))
        else:
            existing["lastUsedAt"] = self._now_iso()

        self._save_projects(self._sorted_projects(projects), active_root=root_str)
        self._refresh_project_selector_ui()
        self._apply_active_project_to_views()

    def _sorted_projects(self, projects: list[dict]) -> list[dict]:
        def key(rec: dict) -> tuple:
            pinned = bool(rec.get("pinned", False))
            name = str(rec.get("displayName") or "").lower()
            root = str(rec.get("root") or "").lower()
            return (not pinned, name, root)

        return sorted(projects, key=key)

    def _get_active_project_record(self) -> dict | None:
        active = self._get_active_project_root_str()
        if not active:
            return None
        for rec in self._get_projects():
            if rec.get("root") == active:
                return rec
        return None

    def _resolve_project_relative_path(self, root: Path, maybe_rel: str) -> Path:
        raw = (maybe_rel or "").strip()
        if not raw:
            return root / "manifestguard-report.json"
        p = Path(raw).expanduser()
        if p.is_absolute():
            return p
        return (root / p).resolve()

    def _fill_text_field(self, widget_name: str, text: str) -> None:
        """Set text on a named QLineEdit widget if it exists."""
        if hasattr(self, widget_name):
            cast(QLineEdit, getattr(self, widget_name)).setText(text)

    def _apply_record_fields_to_views(self, rec: dict, root: Path) -> None:
        """Populate report/extended fields from a project record."""
        last_report = rec.get("lastReport")
        if isinstance(last_report, str) and last_report:
            self._fill_text_field("validation_report_edit", last_report)
            if hasattr(self, "dashboard_report_path_edit"):
                resolved = str(self._resolve_project_relative_path(root, last_report))
                cast(QLineEdit, getattr(self, "dashboard_report_path_edit")).setText(resolved)
        if hasattr(self, "validation_extended_checkbox"):
            last_ext = rec.get("lastExtended")
            if isinstance(last_ext, bool):
                cast(QCheckBox, getattr(self, "validation_extended_checkbox")).setChecked(last_ext)

    def _apply_active_project_to_views(self) -> None:
        root = self._get_active_project_root()
        if root is None:
            return

        self._fill_text_field("project_root_edit", str(root))
        self._fill_text_field("validation_workspace_edit", str(root))

        rec = self._get_active_project_record() or {}
        self._apply_record_fields_to_views(rec, root)

        if hasattr(self, "repo_settings_scope_combo"):
            state = self._load_gui_state()
            if self._get_repo_settings_scope(state) == "project":
                self._load_repo_settings()
            else:
                self._maybe_autofill_repo_fields(persist=True)

    def _refresh_project_selector_ui(self) -> None:
        if not hasattr(self, "project_selector_combo"):
            return

        combo = cast(QComboBox, getattr(self, "project_selector_combo"))
        projects = self._sorted_projects(self._get_projects())
        active = self._get_active_project_root_str()

        combo.blockSignals(True)
        combo.clear()
        idx_to_select = -1

        for _idx, rec in enumerate(projects):
            root = rec.get("root")
            name = rec.get("displayName")
            if not isinstance(root, str) or not root:
                continue
            label = str(name) if name else Path(root).name
            if rec.get("pinned"):
                label = f"📌 {label}"
            combo.addItem(label, root)
            if root == active:
                idx_to_select = combo.count() - 1

        if idx_to_select >= 0:
            combo.setCurrentIndex(idx_to_select)

        combo.blockSignals(False)

    def _toggle_dark_mode(self, state: int) -> None:
        self._dark_mode = bool(state)
        self._apply_theme()
        saved = self._load_gui_state()
        saved["darkMode"] = self._dark_mode
        self._save_gui_state(saved)

    def _apply_theme(self) -> None:
        app = QApplication.instance()
        if app is None:
            return

        qt_app = cast(QApplication, app)

        if not self._dark_mode:
            qt_app.setPalette(QApplication.style().standardPalette())
            cast(QWidget, self).setStyleSheet("")
            return

        palette = QPalette()
        palette.setColor(QPalette.ColorRole.Window, QColor(30, 30, 30))
        palette.setColor(QPalette.ColorRole.WindowText, QColor(212, 212, 212))
        palette.setColor(QPalette.ColorRole.Base, QColor(37, 37, 38))
        palette.setColor(QPalette.ColorRole.AlternateBase, QColor(45, 45, 48))
        palette.setColor(QPalette.ColorRole.ToolTipBase, QColor(37, 37, 38))
        palette.setColor(QPalette.ColorRole.ToolTipText, QColor(212, 212, 212))
        palette.setColor(QPalette.ColorRole.Text, QColor(212, 212, 212))
        palette.setColor(QPalette.ColorRole.Button, QColor(60, 60, 60))
        palette.setColor(QPalette.ColorRole.ButtonText, QColor(212, 212, 212))
        palette.setColor(QPalette.ColorRole.Highlight, QColor(0, 122, 204))
        palette.setColor(QPalette.ColorRole.HighlightedText, QColor(255, 255, 255))
        qt_app.setPalette(palette)

        cast(QWidget, self).setStyleSheet(
            "QGroupBox { font-weight: bold; }"
            "QTextEdit { font-family: Consolas, 'Courier New', monospace; }"
        )
