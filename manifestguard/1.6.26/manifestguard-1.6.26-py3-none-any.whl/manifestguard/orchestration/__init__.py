"""Cross-tool orchestration helpers.

mgpy acts as orchestration + display layer; worker tools remain autark and expose
stable JSON + exit-code contracts.
"""
