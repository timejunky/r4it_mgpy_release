"""Export formatters for worker results (venv-wizard preflight, etc.)."""

from __future__ import annotations

from datetime import datetime
from typing import Any

from manifestguard.orchestration.worker_runner import WorkerRunResult


def _status_to_emoji(status: str) -> str:
    if status == "ok":
        return "✅"
    if status == "warning":
        return "⚠️"
    return "❌"


def _iter_warning_messages(warnings: Any) -> list[str]:
    if not isinstance(warnings, list):
        return []
    out: list[str] = []
    for item in warnings:
        if isinstance(item, dict):
            out.append(str(item.get("message", str(item))))
        else:
            out.append(str(item))
    return out


def _managed_status_counts(managed: Any) -> tuple[int, int, int, int]:
    if not isinstance(managed, list):
        return (0, 0, 0, 0)
    running = 0
    zombie = 0
    dead = 0
    for child in managed:
        if not isinstance(child, dict):
            continue
        st = child.get("status")
        if st == "running":
            running += 1
        elif st == "zombie":
            zombie += 1
        elif st == "dead":
            dead += 1
    return (len(managed), running, zombie, dead)


def format_worker_result_markdown(result: WorkerRunResult, *, tool_name: str = "Worker") -> str:
    """Format a worker run result as Markdown.
    
    Args:
        result: Worker run result to format
        tool_name: Display name for the tool (e.g., "Venv Wizard Preflight")
    
    Returns:
        Markdown-formatted worker result report
    """
    lines = [
        f"# {tool_name} Report",
        "",
        f"**Command:** `{' '.join(result.cmd)}`  ",
        f"**Working Directory:** `{result.cwd}`  ",
        f"**Exit Code:** {result.exit_code}  ",
        f"**Duration:** {result.duration_seconds:.2f}s  ",
        "",
    ]
    
    # Status summary
    if result.exit_code == 0:
        lines.append("✅ **Status:** Success")
    elif result.exit_code == 124:
        lines.append("⏱️ **Status:** Timeout")
    else:
        lines.append(f"❌ **Status:** Failed (exit code {result.exit_code})")
    
    lines.append("")
    
    # Payload section
    if result.payload:
        lines.append("## Results")
        lines.append("")
        lines.append("```json")
        import json
        lines.append(json.dumps(result.payload, indent=2, ensure_ascii=False))
        lines.append("```")
        lines.append("")
    
    # Stderr warnings
    if result.stderr and result.stderr.strip():
        lines.append("## Warnings / Errors")
        lines.append("")
        lines.append("```")
        lines.append(result.stderr.strip())
        lines.append("```")
        lines.append("")
    
    # Raw stdout (if no payload or additional output)
    if result.stdout and (not result.payload or len(result.stdout.strip()) > len(str(result.payload))):
        lines.append("## Raw Output")
        lines.append("")
        lines.append("```")
        lines.append(result.stdout.strip())
        lines.append("```")
        lines.append("")
    
    return "\n".join(lines)


def format_worker_result_html(result: WorkerRunResult, *, tool_name: str = "Worker") -> str:
    """Format a worker run result as HTML.
    
    Args:
        result: Worker run result to format
        tool_name: Display name for the tool
    
    Returns:
        HTML-formatted worker result report (offline-safe, no CDN)
    """
    # Status badge
    if result.exit_code == 0:
        status_badge = '<span style="background:#22c55e;color:white;padding:2px 8px;border-radius:4px;font-weight:bold;">✅ Success</span>'
    elif result.exit_code == 124:
        status_badge = '<span style="background:#f59e0b;color:white;padding:2px 8px;border-radius:4px;font-weight:bold;">⏱️ Timeout</span>'
    else:
        status_badge = f'<span style="background:#ef4444;color:white;padding:2px 8px;border-radius:4px;font-weight:bold;">❌ Failed ({result.exit_code})</span>'
    
    # Build HTML
    html_lines = [
        "<!DOCTYPE html>",
        "<html>",
        "<head>",
        "  <meta charset='utf-8'>",
        f"  <title>{tool_name} Report</title>",
        "  <style>",
        "    body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; max-width: 1200px; margin: 40px auto; padding: 0 20px; }",
        "    h1 { color: #1f2937; border-bottom: 2px solid #e5e7eb; padding-bottom: 10px; }",
        "    h2 { color: #374151; margin-top: 30px; }",
        "    .metadata { background: #f3f4f6; padding: 15px; border-radius: 8px; margin: 20px 0; }",
        "    .metadata dt { font-weight: bold; color: #6b7280; display: inline-block; width: 180px; }",
        "    .metadata dd { display: inline; margin-left: 10px; }",
        "    .metadata dt::after { content: ':'; }",
        "    pre { background: #1f2937; color: #f3f4f6; padding: 15px; border-radius: 8px; overflow-x: auto; }",
        "    code { font-family: 'Courier New', monospace; font-size: 14px; }",
        "  </style>",
        "</head>",
        "<body>",
        f"  <h1>{tool_name} Report</h1>",
        "",
        "  <div class='metadata'>",
        f"    <dl>",
        f"      <dt>Command</dt><dd><code>{' '.join(result.cmd)}</code></dd><br>",
        f"      <dt>Working Directory</dt><dd><code>{result.cwd}</code></dd><br>",
        f"      <dt>Exit Code</dt><dd>{result.exit_code}</dd><br>",
        f"      <dt>Duration</dt><dd>{result.duration_seconds:.2f}s</dd><br>",
        f"      <dt>Status</dt><dd>{status_badge}</dd>",
        f"    </dl>",
        "  </div>",
        "",
    ]
    
    # Payload section
    if result.payload:
        import json
        payload_json = json.dumps(result.payload, indent=2, ensure_ascii=False)
        html_lines.extend([
            "  <h2>Results</h2>",
            "  <pre><code>",
            payload_json,
            "  </code></pre>",
            "",
        ])
    
    # Stderr warnings
    if result.stderr and result.stderr.strip():
        html_lines.extend([
            "  <h2>Warnings / Errors</h2>",
            "  <pre><code>",
            result.stderr.strip(),
            "  </code></pre>",
            "",
        ])
    
    # Raw stdout (if substantial)
    if result.stdout and (not result.payload or len(result.stdout.strip()) > len(str(result.payload))):
        html_lines.extend([
            "  <h2>Raw Output</h2>",
            "  <pre><code>",
            result.stdout.strip(),
            "  </code></pre>",
            "",
        ])
    
    html_lines.extend([
        "</body>",
        "</html>",
    ])
    
    return "\n".join(html_lines)


def format_venv_wizard_preflight_summary(payload: dict[str, Any] | None) -> str:
    """Format venv-wizard preflight payload as human-readable summary.
    
    Args:
        payload: Preflight check JSON payload
    
    Returns:
        Formatted text summary
    """
    if not payload or not isinstance(payload, dict):
        return "⚠️  No preflight data available"
    
    status = str(payload.get("status", "unknown") or "unknown")
    status_emoji = _status_to_emoji(status)

    lines = [f"{status_emoji} Status: {status.upper()}"]

    warning_messages = _iter_warning_messages(payload.get("warnings", []))
    if warning_messages:
        lines.append(f"⚠️  Warnings: {len(warning_messages)}")
        for msg in warning_messages[:3]:
            lines.append(f"   • {msg}")
        if len(warning_messages) > 3:
            lines.append(f"   ... and {len(warning_messages) - 3} more")

    total, running, zombie, dead = _managed_status_counts(payload.get("managed_children", []))
    if total:
        lines.append(f"🔧 Managed Processes: {total} total")
        if running:
            lines.append(f"   ✓ Running: {running}")
        if zombie:
            lines.append(f"   ⚠️  Zombie: {zombie}")
        if dead:
            lines.append(f"   ✗ Dead: {dead}")
    
    return "\n".join(lines)


__all__ = [
    "format_worker_result_markdown",
    "format_worker_result_html",
    "format_venv_wizard_preflight_summary",
]
