"""SARIF report builder for ManifestGuard.

This provides a minimal SARIF v2.1.0 representation of mgpy findings
suitable for consumption by external tools (e.g. code scanning). The
initial focus is static manifest/packaging diagnostics; extended
metrics are attached as run-level properties when available.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

from manifestguard import __version__
from manifestguard.validation.base import Diagnostic, DiagnosticSeverity, ValidationResult


def _severity_to_level(severity: DiagnosticSeverity) -> str:
    """Map ManifestGuard diagnostic severity to SARIF result level."""

    if severity == DiagnosticSeverity.ERROR:
        return "error"
    if severity == DiagnosticSeverity.WARNING:
        return "warning"
    if severity == DiagnosticSeverity.INFO:
        return "note"
    # Hints and everything else are treated as "note" in SARIF
    return "note"


def _diagnostic_to_result(base_uri: Path, diagnostic: Diagnostic) -> dict[str, Any]:
    """Convert a single Diagnostic into a SARIF result object."""

    rel_path = diagnostic.file_path
    try:
        rel_path = diagnostic.file_path.relative_to(base_uri)
    except Exception:
        rel_path = diagnostic.file_path

    location: dict[str, Any] = {
        "physicalLocation": {
            "artifactLocation": {"uri": rel_path.as_posix()},
        }
    }

    region: dict[str, Any] = {}
    if diagnostic.line is not None:
        region["startLine"] = diagnostic.line
    if diagnostic.column is not None:
        region["startColumn"] = diagnostic.column
    if region:
        location["physicalLocation"]["region"] = region

    return {
        "ruleId": diagnostic.code,
        "level": _severity_to_level(diagnostic.severity),
        "message": {"text": diagnostic.message},
        "locations": [location],
        "properties": {
            "source": diagnostic.source,
            "related_info": diagnostic.related_info,
        },
    }


def build_sarif_report(
    workspace_root: Path,
    validation: ValidationResult | None,
    metrics: Any | None = None,
) -> dict[str, Any]:
    """Build a SARIF 2.1.0 report for ManifestGuard findings.

    Args:
        workspace_root: Project root used as base URI for locations.
        validation: ValidationResult containing manifest diagnostics.
        metrics: Optional extended metrics object; attached as properties.
    """

    workspace_root = Path(workspace_root).resolve()

    results: list[dict[str, Any]] = []
    if validation is not None:
        for diagnostic in validation.diagnostics:
            results.append(_diagnostic_to_result(workspace_root, diagnostic))

    run_properties: dict[str, Any] = {"workspace_root": str(workspace_root)}
    if metrics is not None:
        try:
            # Best-effort attachment of extended metrics; callers can
            # pass any object exposing to_dict().
            to_dict = getattr(metrics, "to_dict", None)
            if callable(to_dict):
                run_properties["extendedMetrics"] = to_dict()
        except Exception:
            # Non-fatal: SARIF remains valid without extended metrics
            pass

    return {
        "version": "2.1.0",
        "$schema": "https://json.schemastore.org/sarif-2.1.0.json",
        "runs": [
            {
                "tool": {
                    "driver": {
                        "name": "ManifestGuard (mgpy)",
                        "informationUri": "https://ready-4-it.de/manifestguard",
                        "version": __version__,
                    }
                },
                "originalUriBaseIds": {
                    "PROJECT_ROOT": {"uri": workspace_root.as_posix() + "/"}
                },
                "results": results,
                "properties": run_properties,
            }
        ],
    }
