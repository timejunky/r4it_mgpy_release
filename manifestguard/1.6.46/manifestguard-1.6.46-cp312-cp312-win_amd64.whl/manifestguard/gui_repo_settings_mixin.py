"""Repo-settings mixin for ManifestGuard GUI state."""
from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING, Any, cast

from PySide6.QtWidgets import (
    QCheckBox,
    QComboBox,
    QFileDialog,
    QLineEdit,
    QMessageBox,
    QWidget,
)

from manifestguard.gui_support import detect_git_origin_url


class GuiRepoSettingsMixin:
    if TYPE_CHECKING:
        def __getattr__(self, name: str) -> Any: ...

    def _load_repo_settings(self) -> None:
        state = self._load_gui_state()

        scope = self._get_repo_settings_scope(state)
        self._repo_settings_scope_current = scope
        if hasattr(self, "repo_settings_scope_combo"):
            combo = cast(QComboBox, getattr(self, "repo_settings_scope_combo"))
            for i in range(combo.count()):
                if combo.itemData(i) == scope:
                    combo.blockSignals(True)
                    combo.setCurrentIndex(i)
                    combo.blockSignals(False)
                    break

        repo_state = self._get_effective_repo_settings_state(state, scope)
        if hasattr(self, "user_repo_root_edit"):
            cast(QLineEdit, getattr(self, "user_repo_root_edit")).setText(
                str(repo_state.get("user_repo_root") or "")
            )
        if hasattr(self, "wheel_repo_path_edit"):
            cast(QLineEdit, getattr(self, "wheel_repo_path_edit")).setText(
                str(repo_state.get("wheel_repo_path") or "")
            )
        if hasattr(self, "remote_origin_url_edit"):
            cast(QLineEdit, getattr(self, "remote_origin_url_edit")).setText(
                str(repo_state.get("remote_origin_url") or "")
            )

        if hasattr(self, "preflight_capture_packages_checkbox"):
            cast(QCheckBox, getattr(self, "preflight_capture_packages_checkbox")).setChecked(
                bool(state.get("preflight_capture_packages", False))
            )
        if hasattr(self, "preflight_packages_write_full_checkbox"):
            cast(QCheckBox, getattr(self, "preflight_packages_write_full_checkbox")).setChecked(
                bool(state.get("preflight_packages_write_full_snapshot", True))
            )

        if hasattr(self, "wheel_backfill_enabled_checkbox"):
            cast(QCheckBox, getattr(self, "wheel_backfill_enabled_checkbox")).setChecked(
                bool(state.get("wheel_backfill_enabled", False))
            )

        self._maybe_autofill_repo_fields(persist=True)

    def _save_repo_settings(
        self,
        *,
        scope_override: str | None = None,
        update_scope_value: bool = True,
    ) -> None:
        state = self._load_gui_state()

        scope = scope_override or self._get_repo_settings_scope_from_ui(state)
        if update_scope_value:
            state["repo_settings_scope"] = scope
            self._repo_settings_scope_current = scope

        repo_updates: dict[str, str] = {}
        if hasattr(self, "user_repo_root_edit"):
            repo_updates["user_repo_root"] = cast(
                QLineEdit, getattr(self, "user_repo_root_edit")
            ).text().strip()
        if hasattr(self, "wheel_repo_path_edit"):
            repo_updates["wheel_repo_path"] = cast(
                QLineEdit, getattr(self, "wheel_repo_path_edit")
            ).text().strip()
        if hasattr(self, "remote_origin_url_edit"):
            repo_updates["remote_origin_url"] = cast(
                QLineEdit, getattr(self, "remote_origin_url_edit")
            ).text().strip()

        if scope == "project":
            active_root = self._get_active_project_root_str()
            if active_root:
                self._set_project_repo_settings_state(state, active_root, repo_updates)
            else:
                state.update(repo_updates)
        else:
            state.update(repo_updates)

        if hasattr(self, "preflight_capture_packages_checkbox"):
            state["preflight_capture_packages"] = bool(
                cast(QCheckBox, getattr(self, "preflight_capture_packages_checkbox")).isChecked()
            )
        if hasattr(self, "preflight_packages_write_full_checkbox"):
            state["preflight_packages_write_full_snapshot"] = bool(
                cast(QCheckBox, getattr(self, "preflight_packages_write_full_checkbox")).isChecked()
            )

        if hasattr(self, "wheel_backfill_enabled_checkbox"):
            state["wheel_backfill_enabled"] = bool(
                cast(QCheckBox, getattr(self, "wheel_backfill_enabled_checkbox")).isChecked()
            )
        self._save_gui_state(state)

    def _on_toggle_wheel_backfill(self, _state: int) -> None:
        saved = self._load_gui_state()
        enabled = bool(
            cast(QCheckBox, getattr(self, "wheel_backfill_enabled_checkbox")).isChecked()
        )
        if not enabled:
            self._save_repo_settings()
            return

        if bool(saved.get("wheel_backfill_consent", False)):
            self._save_repo_settings()
            return

        msg = (
            "Enable automatic wheel backfill?\n\n"
            "When enabled, ManifestGuard will download missing wheels for newly added/changed packages "
            "into your shared wheel repository. This may access package indexes/network depending on your pip config.\n\n"
            "This confirmation is asked only once."
        )
        result = QMessageBox.question(cast(QWidget, self), "Enable Wheel Backfill", msg)
        if result != QMessageBox.StandardButton.Yes:
            checkbox = cast(QCheckBox, getattr(self, "wheel_backfill_enabled_checkbox"))
            checkbox.blockSignals(True)
            checkbox.setChecked(False)
            checkbox.blockSignals(False)
            self._save_repo_settings()
            return

        saved["wheel_backfill_consent"] = True
        saved["wheel_backfill_enabled"] = True
        self._save_gui_state(saved)
        self._save_repo_settings()

    def _get_repo_settings_scope(self, state: dict) -> str:
        raw = state.get("repo_settings_scope")
        return raw if raw in {"userwide", "project"} else "userwide"

    def _get_repo_settings_scope_from_ui(self, state: dict) -> str:
        if hasattr(self, "repo_settings_scope_combo"):
            combo = cast(QComboBox, getattr(self, "repo_settings_scope_combo"))
            value = combo.currentData()
            if value in {"userwide", "project"}:
                return str(value)
        return self._get_repo_settings_scope(state)

    def _get_effective_repo_settings_state(self, state: dict, scope: str) -> dict:
        if scope != "project":
            return state

        active_root = self._get_active_project_root_str()
        if not active_root:
            return state

        projects = state.get("projects")
        if not isinstance(projects, list):
            return state

        for rec in projects:
            if not isinstance(rec, dict):
                continue
            if rec.get("root") != active_root:
                continue
            repo_state = rec.get("repoSettings")
            return repo_state if isinstance(repo_state, dict) else {}

        return {}

    def _set_project_repo_settings_state(self, state: dict, active_root: str, updates: dict) -> None:
        projects = state.get("projects")
        if not isinstance(projects, list):
            projects = []

        found = False
        for rec in projects:
            if not isinstance(rec, dict):
                continue
            if rec.get("root") != active_root:
                continue
            repo_state = rec.get("repoSettings")
            if not isinstance(repo_state, dict):
                repo_state = {}
                rec["repoSettings"] = repo_state
            repo_state.update(updates)
            found = True
            break

        if not found:
            rec = self._create_project_record(Path(active_root))
            rec["repoSettings"] = dict(updates)
            projects.append(rec)

        state["projects"] = projects

    def _maybe_autofill_repo_fields(self, *, persist: bool) -> None:
        if not (hasattr(self, "remote_origin_url_edit") and hasattr(self, "user_repo_root_edit")):
            return

        origin_current = self._get_line_edit_text("remote_origin_url_edit")
        user_repo_root = self._get_line_edit_text("user_repo_root_edit")

        candidate = self._resolve_repo_root_candidate(user_repo_root)

        changed = False

        if self._should_autofill_origin(origin_current, candidate):
            self._autofill_origin_url(candidate)
            changed = True

        if self._should_autofill_wheel_repo_path(user_repo_root):
            if self._autofill_wheel_repo_path(user_repo_root):
                changed = True

        if changed and persist:
            self._save_repo_settings()

    def _get_line_edit_text(self, attr_name: str) -> str:
        if not hasattr(self, attr_name):
            return ""
        widget = getattr(self, attr_name)
        if not isinstance(widget, QLineEdit):
            return ""
        return widget.text().strip()

    def _set_line_edit_text(self, attr_name: str, value: str) -> None:
        if not hasattr(self, attr_name):
            return
        widget = getattr(self, attr_name)
        if not isinstance(widget, QLineEdit):
            return
        widget.setText(value)

    def _resolve_repo_root_candidate(self, user_repo_root: str) -> Path | None:
        candidate: Path | None = None
        if user_repo_root:
            try:
                candidate = Path(user_repo_root).expanduser().resolve()
            except Exception:
                candidate = None
        if candidate is None or not candidate.exists() or not candidate.is_dir():
            candidate = self._get_active_project_root()
        return candidate

    def _should_autofill_origin(self, origin_current: str, candidate: Path | None) -> bool:
        return not origin_current and candidate is not None

    def _autofill_origin_url(self, candidate: Path | None) -> None:
        if candidate is None:
            return
        url = detect_git_origin_url(candidate, timeout_seconds=2)
        if url:
            self._set_line_edit_text("remote_origin_url_edit", url)

    def _should_autofill_wheel_repo_path(self, user_repo_root: str) -> bool:
        if not hasattr(self, "wheel_repo_path_edit"):
            return False
        if not user_repo_root:
            return False
        current = self._get_line_edit_text("wheel_repo_path_edit")
        return not current

    def _autofill_wheel_repo_path(self, user_repo_root: str) -> bool:
        try:
            default_wheels = str((Path(user_repo_root) / "wheels").resolve())
            self._set_line_edit_text("wheel_repo_path_edit", default_wheels)
            return True
        except Exception:
            return False

    def _on_repo_settings_scope_changed(self, _index: int) -> None:
        state = self._load_gui_state()
        old_scope = getattr(self, "_repo_settings_scope_current", self._get_repo_settings_scope(state))
        new_scope = self._get_repo_settings_scope_from_ui(state)
        if new_scope == old_scope:
            return

        self._save_repo_settings(scope_override=old_scope, update_scope_value=False)

        state = self._load_gui_state()
        state["repo_settings_scope"] = new_scope
        self._save_gui_state(state)
        self._load_repo_settings()

    def _browse_folder_into(self, line_edit: QLineEdit) -> None:
        start_dir = line_edit.text().strip() or str(Path.cwd())
        folder = QFileDialog.getExistingDirectory(cast(QWidget, self), "Select folder", start_dir)
        if folder:
            line_edit.setText(folder)
            if getattr(self, "user_repo_root_edit", None) is line_edit:
                self._maybe_autofill_repo_fields(persist=True)

    def _get_user_repo_root(self) -> Path | None:
        state = self._load_gui_state()
        scope = self._get_repo_settings_scope(state)
        repo_state = self._get_effective_repo_settings_state(state, scope)
        raw = (repo_state.get("user_repo_root") or "").strip()
        if not raw:
            return None
        try:
            p = Path(raw).expanduser().resolve()
        except Exception:
            return None
        return p if p.exists() and p.is_dir() else None
