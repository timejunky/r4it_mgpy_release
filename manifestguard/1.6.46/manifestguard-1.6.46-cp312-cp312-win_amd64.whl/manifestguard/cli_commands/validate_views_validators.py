"""ViewValidator subclasses for validate-views guardrail rules (VV-001 to VV-007).

Extracted from validate_views.py to keep module size manageable.
"""

from __future__ import annotations

import ast
import json
import re
from abc import ABC, abstractmethod
from dataclasses import dataclass
from pathlib import Path


@dataclass
class Violation:
    """Represents a single validate-views violation."""
    rule: str
    file: Path
    line: int
    column: int
    message: str
    severity: str  # ERROR or WARNING

    def __str__(self) -> str:
        """Format violation for console output (CI-friendly)."""
        rel_path = self.file.as_posix()
        return f"{rel_path}:{self.line}:{self.column} {self.rule} {self.message}"


class ViewValidator(ABC):
    """Base class for view validation rules."""

    def __init__(self, target_dirs: list[Path], ignore_patterns: list[str]):
        self.target_dirs = target_dirs
        self.ignore_patterns = ignore_patterns
        self.violations: list[Violation] = []

    def should_ignore(self, file_path: Path) -> bool:
        """Check if file should be ignored based on patterns."""
        file_str = file_path.as_posix()
        for pattern in self.ignore_patterns:
            if pattern.endswith("/**"):
                prefix = pattern[:-3]
                if prefix in file_str:
                    return True
            elif pattern in file_str:
                return True
        return False

    @abstractmethod
    def validate(self) -> list[Violation]:
        """Run validation and return violations."""
        ...


class TUIScreenRegistrationValidator(ViewValidator):
    """VV-001: Ensure all TUI screen classes are registered in router."""

    TUI_BASE_NAMES: frozenset[str] = frozenset({"Screen", "Layout", "Panel"})
    _REGISTRATION_PATTERN = r"register(?:_screen|_view)\s*\(\s*['\"]([\w-]+)['\"]"

    def __init__(self, target_dirs: list[Path], ignore_patterns: list[str]):
        super().__init__(target_dirs, ignore_patterns)

    def find_screen_classes(self, file_path: Path) -> list[tuple[str, int]]:
        """Find all TUI view subclasses in a Python file."""
        try:
            content = file_path.read_text(encoding="utf-8")
            tree = ast.parse(content, filename=str(file_path))
        except (SyntaxError, UnicodeDecodeError):
            return []

        screens = []
        for node in ast.walk(tree):
            if isinstance(node, ast.ClassDef):
                for base in node.bases:
                    base_name: str | None = None
                    if isinstance(base, ast.Name):
                        base_name = base.id
                    elif isinstance(base, ast.Attribute):
                        base_name = base.attr
                    if base_name in self.TUI_BASE_NAMES:
                        screens.append((node.name, node.lineno))
                        break
        return screens

    def find_registrations(self, file_path: Path) -> set[str]:
        """Find all registered screen IDs in router files."""
        try:
            content = file_path.read_text(encoding="utf-8")
        except (UnicodeDecodeError, FileNotFoundError):
            return set()
        matches = re.findall(self._REGISTRATION_PATTERN, content, re.IGNORECASE)
        return set(matches)

    def _collect_screen_files(self) -> list[Path]:
        files: list[Path] = []
        for target_dir in self.target_dirs:
            if not target_dir.exists():
                continue
            for py_file in target_dir.rglob("*.py"):
                if not self.should_ignore(py_file):
                    files.append(py_file)
        return files

    def _collect_registered_ids(self) -> set[str]:
        registered: set[str] = set()
        for target_dir in self.target_dirs:
            if not target_dir.exists():
                continue
            for py_file in target_dir.rglob("*.py"):
                if "router" in py_file.stem.lower() or "registry" in py_file.stem.lower():
                    registered.update(self.find_registrations(py_file))
        return registered

    @staticmethod
    def _screen_kebab_id(class_name: str) -> str:
        snake = re.sub(r"(?<!^)(?=[A-Z])", "_", class_name).lower().replace("_screen", "")
        return snake.replace("_", "-")

    def validate(self) -> list[Violation]:
        self.violations = []
        all_screens: list[tuple[Path, str, int]] = [
            (fp, name, line)
            for fp in self._collect_screen_files()
            for name, line in self.find_screen_classes(fp)
        ]
        registered_ids = self._collect_registered_ids()
        for file_path, screen_name, line_no in all_screens:
            screen_id_kebab = self._screen_kebab_id(screen_name)
            screen_id_snake = screen_id_kebab.replace("-", "_")
            if screen_id_snake not in registered_ids and screen_id_kebab not in registered_ids:
                self.violations.append(Violation(
                    rule="VV-001",
                    file=file_path,
                    line=line_no,
                    column=1,
                    message=f"TUI screen '{screen_name}' not registered in router (expected ID: '{screen_id_kebab}')",
                    severity="WARNING",
                ))
        return self.violations


class JupyterHTMLHygieneValidator(ViewValidator):
    """VV-004: Detect raw HTML with inline styles or event handlers in Jupyter notebooks."""

    _RE_INLINE_STYLE = re.compile(r'\bstyle\s*=', re.IGNORECASE)
    _RE_EVENT_HANDLER = re.compile(r'\bon[a-z]{2,}\s*=', re.IGNORECASE)
    _RE_HTML_CALL = re.compile(r'HTML\s*\(\s*(["\'][^\'"]*["\']|f["\'][^\'"]*["\'])', re.DOTALL)

    def _scan_python_file(self, file_path: Path) -> list[Violation]:
        violations: list[Violation] = []
        try:
            lines = file_path.read_text(encoding="utf-8").splitlines()
        except (UnicodeDecodeError, OSError):
            return violations
        for lineno, line in enumerate(lines, start=1):
            if "HTML(" not in line:
                continue
            if self._RE_INLINE_STYLE.search(line):
                violations.append(Violation(
                    rule="VV-004", file=file_path, line=lineno,
                    column=line.index("HTML(") + 1,
                    message="IPython.display.HTML() call contains inline style",
                    severity="WARNING",
                ))
            elif self._RE_EVENT_HANDLER.search(line):
                violations.append(Violation(
                    rule="VV-004", file=file_path, line=lineno,
                    column=line.index("HTML(") + 1,
                    message="IPython.display.HTML() call contains inline event handler",
                    severity="WARNING",
                ))
        return violations

    def _scan_notebook(self, file_path: Path) -> list[Violation]:
        violations: list[Violation] = []
        try:
            nb = json.loads(file_path.read_text(encoding="utf-8"))
        except Exception:
            return violations
        cells = nb.get("cells") or []
        for cell_idx, cell in enumerate(cells):
            source_lines = cell.get("source") or []
            if isinstance(source_lines, str):
                source_lines = source_lines.splitlines()
            if not source_lines or source_lines[0].strip() not in ("%%html", "%%HTML"):
                continue
            for line_offset, line in enumerate(source_lines[1:], start=2):
                if self._RE_INLINE_STYLE.search(line):
                    violations.append(Violation(
                        rule="VV-004", file=file_path, line=cell_idx + line_offset, column=1,
                        message=f"%%html cell (cell #{cell_idx + 1}) contains inline style",
                        severity="WARNING",
                    ))
                elif self._RE_EVENT_HANDLER.search(line):
                    violations.append(Violation(
                        rule="VV-004", file=file_path, line=cell_idx + line_offset, column=1,
                        message=f"%%html cell (cell #{cell_idx + 1}) contains inline event handler",
                        severity="WARNING",
                    ))
        return violations

    def validate(self) -> list[Violation]:
        self.violations = []
        for target_dir in self.target_dirs:
            if not target_dir.exists():
                continue
            for py_file in target_dir.rglob("*.py"):
                if not self.should_ignore(py_file):
                    self.violations.extend(self._scan_python_file(py_file))
            for nb_file in target_dir.rglob("*.ipynb"):
                if not self.should_ignore(nb_file):
                    self.violations.extend(self._scan_notebook(nb_file))
        return self.violations


class HTMLInlineStyleValidator(ViewValidator):
    """VV-002: Detect inline styles in HTML (CSP violation risk)."""

    def __init__(self, target_dirs: list[Path], ignore_patterns: list[str]):
        super().__init__(target_dirs, ignore_patterns)
        self.patterns = [
            (r"<style[^>]*>", "Inline <style> block detected (CSP violation risk)"),
            (r'style\s*=\s*["\']', "Inline style attribute detected (CSP violation risk)"),
            (r'\.style\.cssText\s*=', "cssText assignment detected (CSP violation risk)"),
        ]

    def validate(self) -> list[Violation]:
        self.violations = []
        for target_dir in self.target_dirs:
            if not target_dir.exists():
                continue
            for pattern in ["*.html", "*.htm", "*.jinja2", "*.j2", "*.mako"]:
                for file_path in target_dir.rglob(pattern):
                    if self.should_ignore(file_path):
                        continue
                    self._check_file(file_path)
            for py_file in target_dir.rglob("*.py"):
                if self.should_ignore(py_file):
                    continue
                self._check_python_html(py_file)
        return self.violations

    def _check_file(self, file_path: Path):
        try:
            content = file_path.read_text(encoding="utf-8")
        except (UnicodeDecodeError, FileNotFoundError):
            return
        lines = content.splitlines()
        for line_no, line in enumerate(lines, start=1):
            for pattern, message in self.patterns:
                if re.search(pattern, line, re.IGNORECASE):
                    self.violations.append(Violation(
                        rule="VV-002", file=file_path, line=line_no, column=1,
                        message=message, severity="ERROR",
                    ))

    def _check_python_html(self, file_path: Path):
        try:
            content = file_path.read_text(encoding="utf-8")
        except (UnicodeDecodeError, FileNotFoundError):
            return
        lines = content.splitlines()
        for line_no, line in enumerate(lines, start=1):
            for pattern, message in self.patterns:
                if re.search(pattern, line, re.IGNORECASE):
                    self.violations.append(Violation(
                        rule="VV-002", file=file_path, line=line_no, column=1,
                        message=message, severity="ERROR",
                    ))


class HTMLInlineEventHandlerValidator(ViewValidator):
    """VV-003: Detect inline event handlers in HTML (XSS risk)."""

    def __init__(self, target_dirs: list[Path], ignore_patterns: list[str]):
        super().__init__(target_dirs, ignore_patterns)
        self.event_handlers = [
            "onclick", "onload", "onerror", "onmouseover", "onmouseout",
            "onkeydown", "onkeyup", "onchange", "onsubmit", "onfocus", "onblur",
        ]
        self.patterns = [
            (rf'{handler}\s*=\s*["\']', f"Inline {handler} handler detected (XSS risk)")
            for handler in self.event_handlers
        ]

    def validate(self) -> list[Violation]:
        self.violations = []
        for target_dir in self.target_dirs:
            if not target_dir.exists():
                continue
            for pattern in ["*.html", "*.htm", "*.jinja2", "*.j2", "*.mako"]:
                for file_path in target_dir.rglob(pattern):
                    if self.should_ignore(file_path):
                        continue
                    self._check_file(file_path)
            for py_file in target_dir.rglob("*.py"):
                if self.should_ignore(py_file):
                    continue
                self._check_python_html(py_file)
        return self.violations

    def _check_file(self, file_path: Path):
        try:
            content = file_path.read_text(encoding="utf-8")
        except (UnicodeDecodeError, FileNotFoundError):
            return
        lines = content.splitlines()
        for line_no, line in enumerate(lines, start=1):
            for pattern, message in self.patterns:
                if re.search(pattern, line, re.IGNORECASE):
                    self.violations.append(Violation(
                        rule="VV-003", file=file_path, line=line_no, column=1,
                        message=message, severity="ERROR",
                    ))

    def _check_python_html(self, file_path: Path):
        try:
            content = file_path.read_text(encoding="utf-8")
        except (UnicodeDecodeError, FileNotFoundError):
            return
        lines = content.splitlines()
        for line_no, line in enumerate(lines, start=1):
            if "<" in line and ">" in line:
                for pattern, message in self.patterns:
                    if re.search(pattern, line, re.IGNORECASE):
                        self.violations.append(Violation(
                            rule="VV-003", file=file_path, line=line_no, column=1,
                            message=message, severity="ERROR",
                        ))


class TemplateInheritanceValidator(ViewValidator):
    """VV-005: Detect Django/Flask template orphan blocks."""

    _RE_EXTENDS = re.compile(r"\{%-?\s*extends\b", re.IGNORECASE)
    _RE_BLOCK = re.compile(r"\{%-?\s*block\s+\w+", re.IGNORECASE)

    def validate(self) -> list[Violation]:
        self.violations = []
        for target_dir in self.target_dirs:
            if not target_dir.exists():
                continue
            for html_file in target_dir.rglob("*.html"):
                if self.should_ignore(html_file):
                    continue
                try:
                    content = html_file.read_text(encoding="utf-8")
                except (UnicodeDecodeError, OSError):
                    continue
                if self._RE_BLOCK.search(content) and not self._RE_EXTENDS.search(content):
                    for line_no, line in enumerate(content.splitlines(), start=1):
                        if self._RE_BLOCK.search(line):
                            self.violations.append(Violation(
                                rule="VV-005", file=html_file, line=line_no, column=1,
                                message="Template defines {% block %} without {% extends %} (orphan block)",
                                severity="WARNING",
                            ))
                            break
        return self.violations


class PickleDeserializationValidator(ViewValidator):
    """VV-006: Detect unsafe pickle deserialization outside tests/."""

    _RE_PICKLE = re.compile(r"\bpickle\.(loads?)\s*\(")

    def validate(self) -> list[Violation]:
        self.violations = []
        for target_dir in self.target_dirs:
            if not target_dir.exists():
                continue
            for py_file in target_dir.rglob("*.py"):
                if self.should_ignore(py_file):
                    continue
                if "tests" in py_file.parts:
                    continue
                try:
                    lines = py_file.read_text(encoding="utf-8").splitlines()
                except (UnicodeDecodeError, OSError):
                    continue
                for line_no, line in enumerate(lines, start=1):
                    m = self._RE_PICKLE.search(line)
                    if m:
                        self.violations.append(Violation(
                            rule="VV-006", file=py_file, line=line_no,
                            column=m.start() + 1,
                            message=(
                                f"Unsafe pickle deserialization: pickle.{m.group(1)}() "
                                "detected outside tests/"
                            ),
                            severity="ERROR",
                        ))
        return self.violations


class AsyncioMisuseValidator(ViewValidator):
    """VV-007: Detect deprecated asyncio loop access outside tests/."""

    _RE_GET_EVENT_LOOP = re.compile(r"\basyncio\.get_event_loop\s*\(")
    _RE_RUN_UNTIL_COMPLETE = re.compile(r"\bloop\.run_until_complete\s*\(")

    def validate(self) -> list[Violation]:
        self.violations = []
        for target_dir in self.target_dirs:
            if not target_dir.exists():
                continue
            for py_file in target_dir.rglob("*.py"):
                if self.should_ignore(py_file):
                    continue
                if "tests" in py_file.parts:
                    continue
                try:
                    lines = py_file.read_text(encoding="utf-8").splitlines()
                except (UnicodeDecodeError, OSError):
                    continue
                for line_no, line in enumerate(lines, start=1):
                    m = self._RE_GET_EVENT_LOOP.search(line)
                    if m:
                        self.violations.append(Violation(
                            rule="VV-007", file=py_file, line=line_no,
                            column=m.start() + 1,
                            message=(
                                "Deprecated asyncio.get_event_loop() detected outside tests/; "
                                "prefer asyncio.run() or asyncio.get_running_loop()"
                            ),
                            severity="WARNING",
                        ))
                    m2 = self._RE_RUN_UNTIL_COMPLETE.search(line)
                    if m2:
                        self.violations.append(Violation(
                            rule="VV-007", file=py_file, line=line_no,
                            column=m2.start() + 1,
                            message=(
                                "Bare loop.run_until_complete() detected outside tests/; "
                                "prefer asyncio.run() at the entry point"
                            ),
                            severity="WARNING",
                        ))
        return self.violations
