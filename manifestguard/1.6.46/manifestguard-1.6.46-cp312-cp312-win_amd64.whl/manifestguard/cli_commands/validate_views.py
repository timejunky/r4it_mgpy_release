"""
validate-views: View registration and HTML hygiene validation for mgpy.

This module implements Phase P0-P4 of the validate-views guardrail:
- VV-001: TUI screen registration check (extends to Rich Layout/Panel + Textual attribute bases)
- VV-002: HTML inline style detection
- VV-003: HTML inline event handler detection
- VV-004: Jupyter notebook HTML hygiene (%%html magic, IPython.display.HTML)
- VV-005: Template inheritance orphan-block detection
- VV-006: Unsafe pickle deserialization outside tests/
- VV-007: Deprecated asyncio loop access patterns outside tests/

Config file: .validateviewsrc (JSON) at workspace root — supports per-project rule overrides
and inheritance via an extends key.
Based on concept.validate-views.en.md, adapted for Python/mgpy context.
"""

import json
import re
from pathlib import Path
import sys

from manifestguard.cli_commands.validate_views_validators import (
    AsyncioMisuseValidator,
    HTMLInlineEventHandlerValidator,
    HTMLInlineStyleValidator,
    JupyterHTMLHygieneValidator,
    PickleDeserializationValidator,
    TemplateInheritanceValidator,
    TUIScreenRegistrationValidator,
    ViewValidator,
    Violation,
)


def _dedupe_strings(values: list[object]) -> list[str]:
    """Return unique string values while preserving first-seen order."""
    result: list[str] = []
    for value in values:
        if isinstance(value, str) and value not in result:
            result.append(value)
    return result


def _merge_validateviewsrc(base: dict, override: dict) -> dict:
    """Merge base and child .validateviewsrc payloads."""
    merged: dict[str, object] = {}

    base_rules = base.get("rules") if isinstance(base.get("rules"), dict) else {}
    override_rules = override.get("rules") if isinstance(override.get("rules"), dict) else {}
    if base_rules or override_rules:
        merged["rules"] = {**base_rules, **override_rules}

    base_ignore = _dedupe_strings(list(base.get("ignore") or []))
    override_ignore = _dedupe_strings(list(override.get("ignore") or []))
    if base_ignore or override_ignore:
        merged["ignore"] = _dedupe_strings(base_ignore + override_ignore)

    base_target_dirs = _dedupe_strings(list(base.get("target_dirs") or []))
    override_target_dirs = _dedupe_strings(list(override.get("target_dirs") or []))
    if override_target_dirs:
        merged["target_dirs"] = override_target_dirs
    elif base_target_dirs:
        merged["target_dirs"] = base_target_dirs

    return merged


def _load_validateviewsrc_file(rc_path: Path, seen: set[Path] | None = None) -> dict:
    """Load a .validateviewsrc file, optionally following an extends chain."""
    seen = seen or set()
    try:
        resolved_path = rc_path.resolve()
    except OSError:
        resolved_path = rc_path

    if resolved_path in seen or not rc_path.is_file():
        return {}

    seen.add(resolved_path)

    try:
        raw = json.loads(rc_path.read_text(encoding="utf-8"))
    except Exception:
        return {}

    if not isinstance(raw, dict):
        return {}

    base_config: dict = {}
    extends_value = raw.get("extends")
    extends_paths: list[str] = []
    if isinstance(extends_value, str):
        extends_paths = [extends_value]
    elif isinstance(extends_value, list):
        extends_paths = [value for value in extends_value if isinstance(value, str)]

    for extends_path in extends_paths:
        parent_path = Path(extends_path)
        if not parent_path.is_absolute():
            parent_path = rc_path.parent / parent_path
        base_config = _merge_validateviewsrc(
            base_config,
            _load_validateviewsrc_file(parent_path, seen),
        )

    child_config = {key: value for key, value in raw.items() if key != "extends"}
    return _merge_validateviewsrc(base_config, child_config)


def _load_validateviewsrc(workspace_root: Path | None = None) -> dict:
    """Load .validateviewsrc config from the workspace root (JSON).

    Supported keys:
    - ``rules``: dict of rule-ID → "on" | "off" (string) or ``true`` / ``false``
    - ``ignore``: list of additional glob patterns to ignore
    - ``target_dirs``: list of directory paths to scan

    Returns an empty dict when the file is absent or unparseable.
    """
    root = workspace_root or Path.cwd()
    rc_path = root / ".validateviewsrc"
    return _load_validateviewsrc_file(rc_path)


def run_validate_views(
    target_dirs: list[str] | None = None,
    ignore_patterns: list[str] | None = None,
    enabled_rules: set[str] | None = None,
    workspace_root: Path | None = None,
) -> dict[str, list[Violation]]:
    """
    Run all validate-views checks.

    Per-project config is read from ``.validateviewsrc`` (JSON) in *workspace_root*.
    CLI / caller arguments take precedence over config-file values.

    Args:
        target_dirs: Directories to scan (default: from .validateviewsrc or built-in list).
        ignore_patterns: Glob patterns to ignore (merged with .validateviewsrc ignore list).
        enabled_rules: Explicit rule-ID allow-set; applied after .validateviewsrc rules.
        workspace_root: Project root used to locate .validateviewsrc (default: cwd).

    Returns:
        Dict mapping rule ID to list of violations.
    """
    rc = _load_validateviewsrc(workspace_root)

    if target_dirs is None:
        rc_dirs = rc.get("target_dirs")
        target_dirs = list(rc_dirs) if isinstance(rc_dirs, list) else [
            "src/manifestguard/extended/tui",
            "src/templates",
            "src/manifestguard/reporters",
        ]

    default_ignore = ["tests/**", "docs/**", "examples/**", "__pycache__/**"]
    rc_ignore = rc.get("ignore") or []
    if ignore_patterns is None:
        ignore_patterns = default_ignore + [p for p in rc_ignore if p not in default_ignore]
    else:
        ignore_patterns = list(ignore_patterns) + [p for p in rc_ignore if p not in ignore_patterns]

    root = workspace_root or Path.cwd()
    target_paths = []
    for target_dir in target_dirs:
        target_path = Path(target_dir)
        if not target_path.is_absolute():
            target_path = root / target_path
        target_paths.append(target_path)

    # Build enabled-rules set from .validateviewsrc then apply caller override.
    rc_rules: dict[str, object] = rc.get("rules") or {}
    rc_disabled: set[str] = {
        rule_id
        for rule_id, val in rc_rules.items()
        if str(val).lower() in ("off", "false", "0")
    }

    validators = [
        TUIScreenRegistrationValidator(target_paths, ignore_patterns),
        HTMLInlineStyleValidator(target_paths, ignore_patterns),
        HTMLInlineEventHandlerValidator(target_paths, ignore_patterns),
        JupyterHTMLHygieneValidator(target_paths, ignore_patterns),
        TemplateInheritanceValidator(target_paths, ignore_patterns),
        PickleDeserializationValidator(target_paths, ignore_patterns),
        AsyncioMisuseValidator(target_paths, ignore_patterns),
    ]

    results: dict[str, list[Violation]] = {}
    for validator in validators:
        violations = validator.validate()
        if violations:
            rule_id = violations[0].rule
            results[rule_id] = violations

    # Remove rules disabled in .validateviewsrc
    if rc_disabled:
        results = {k: v for k, v in results.items() if k not in rc_disabled}

    # Caller-supplied allow-set has final say
    if enabled_rules:
        results = {k: v for k, v in results.items() if k in enabled_rules}

    return results


def format_violations(violations: dict[str, list[Violation]]) -> str:
    """Format violations for console output."""
    if not violations:
        return "✓ No validate-views violations found."

    output_lines = []
    total = 0

    for rule_id in sorted(violations.keys()):
        for violation in violations[rule_id]:
            output_lines.append(str(violation))
            total += 1

    # Add summary
    output_lines.append("")
    output_lines.append("Summary:")
    for rule_id in sorted(violations.keys()):
        count = len(violations[rule_id])
        rule_name = {
            "VV-001": "TUI Registration",
            "VV-002": "HTML Inline Style",
            "VV-003": "HTML Inline Event Handler",
            "VV-004": "Jupyter HTML Hygiene",
            "VV-005": "Template Inheritance",
            "VV-006": "Pickle Deserialization",
            "VV-007": "Asyncio Misuse",
        }.get(rule_id, rule_id)
        output_lines.append(f"  {rule_id} ({rule_name}): {count} violation{'s' if count != 1 else ''}")
    output_lines.append(f"  Total: {total} violation{'s' if total != 1 else ''}")
    output_lines.append("")

    return "\n".join(output_lines)


def main():
    """CLI entry point for validate-views."""
    results = run_validate_views()
    output = format_violations(results)
    print(output)

    # Exit with code 2 if violations found (standard for linting tools)
    sys.exit(2 if results else 0)


if __name__ == "__main__":
    main()
