"""Built-in InterfaceDiscovery command definitions."""

from __future__ import annotations

BUILTIN_INTERFACE_DATA: list[dict] = [
    {
        "name": "check",
        "description": "Validate manifest files with optional extended analysis",
        "category": "validation",
        "parameters": [
            {
                "name": "file",
                "type": "Path",
                "default": "pyproject.toml",
                "required": False,
                "description": "Path to manifest file",
            },
            {
                "name": "extended",
                "type": "bool",
                "default": True,
                "required": False,
                "description": "Run extended test mode",
            },
            {
                "name": "report",
                "type": "Path",
                "default": None,
                "required": False,
                "description": "Save metrics to JSON report",
            },
        ],
        "examples": [
            {
                "command": "manifestguard check",
                "description": "Check pyproject.toml in current directory",
            },
            {
                "command": "manifestguard check setup.py --report metrics.json",
                "description": "Check setup.py and save report",
            },
        ],
    },
    {
        "name": "fix",
        "description": "Fix detected issues automatically",
        "category": "remediation",
        "parameters": [
            {
                "name": "auto",
                "type": "bool",
                "default": False,
                "required": False,
                "description": "Apply fixes without confirmation",
            },
        ],
        "examples": [
            {"command": "manifestguard fix", "description": "Interactive fix mode"},
            {"command": "manifestguard fix --auto", "description": "Auto-fix all issues"},
        ],
    },
    {
        "name": "sbom",
        "description": "Generate Software Bill of Materials",
        "category": "security",
        "parameters": [
            {
                "name": "format",
                "type": "str",
                "default": "spdx",
                "required": False,
                "description": "SBOM format (spdx, cyclonedx)",
            },
            {
                "name": "output",
                "type": "Path",
                "default": "sbom.json",
                "required": False,
                "description": "Output file path",
            },
        ],
        "examples": [
            {
                "command": "manifestguard sbom",
                "description": "Generate SPDX SBOM",
            },
            {
                "command": "manifestguard sbom --format cyclonedx --output bill.json",
                "description": "CycloneDX format",
            },
        ],
    },
    {
        "name": "baseline",
        "description": "Manage metric baselines for trend analysis",
        "category": "analysis",
        "parameters": [
            {
                "name": "list",
                "type": "bool",
                "default": False,
                "required": False,
                "description": "List all baselines",
            },
            {
                "name": "compare",
                "type": "str",
                "default": None,
                "required": False,
                "description": "Compare to baseline label",
            },
            {
                "name": "trend",
                "type": "bool",
                "default": False,
                "required": False,
                "description": "Show trend report",
            },
        ],
        "examples": [
            {
                "command": "manifestguard baseline --list",
                "description": "List all saved baselines",
            },
            {
                "command": "manifestguard baseline --compare v1.0",
                "description": "Compare against v1.0 baseline",
            },
        ],
    },
    {
        "name": "list-interfaces",
        "description": "List all available CLI commands and options (AI Interface Discovery)",
        "category": "meta",
        "parameters": [],
        "examples": [
            {
                "command": "manifestguard list-interfaces",
                "description": "Show all interfaces as JSON",
            },
        ],
    },
    {
        "name": "list-tests",
        "description": "List all available test categories and checks",
        "category": "meta",
        "parameters": [
            {
                "name": "json",
                "type": "bool",
                "default": False,
                "required": False,
                "description": "Output as JSON",
            },
        ],
        "examples": [
            {"command": "manifestguard list-tests", "description": "Show all tests"},
            {"command": "manifestguard list-tests --json", "description": "JSON output"},
        ],
    },
    {
        "name": "show-config",
        "description": "Show effective configuration with defaults",
        "category": "configuration",
        "parameters": [
            {
                "name": "json",
                "type": "bool",
                "default": False,
                "required": False,
                "description": "Output as JSON",
            },
        ],
        "examples": [
            {"command": "manifestguard show-config", "description": "Show config"},
            {"command": "manifestguard show-config --json", "description": "JSON format"},
        ],
    },
]
