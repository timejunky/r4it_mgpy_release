"""Configuration merge/compare helpers for Quick Check."""

from typing import Any

from .quick_check_models import ConfigTemplate


def merge_configs(
    existing: dict[str, Any],
    template: ConfigTemplate,
    preserve_user: bool = True,
) -> dict[str, Any]:
    merged: dict[str, Any] = existing.copy()

    _ensure_extended_field(merged)
    _merge_recommended_tests(merged, existing, template)
    _merge_settings(merged, template)
    _merge_named_config(merged, "complexity", template.complexity, preserve_user)
    _merge_named_config(merged, "coverage", template.coverage, preserve_user)

    return merged


def compare_configs(config_a: dict[str, Any], config_b: dict[str, Any]) -> dict[str, Any]:
    added = [key for key in config_b if key not in config_a]
    removed = [key for key in config_a if key not in config_b]
    changed = [
        key
        for key in config_a
        if key in config_b and config_a[key] != config_b[key]
    ]
    return {
        "added": added,
        "removed": removed,
        "changed": changed,
    }


def _ensure_extended_field(merged: dict[str, Any]) -> None:
    if "extended" not in merged:
        merged["extended"] = False


def _merge_recommended_tests(
    merged: dict[str, Any],
    existing: dict[str, Any],
    template: ConfigTemplate,
) -> None:
    existing_tests: set[str] = set(existing.get("recommended_tests", []))
    template_tests: set[str] = set(template.recommended_tests)
    merged["recommended_tests"] = sorted(existing_tests | template_tests)


def _merge_settings(merged: dict[str, Any], template: ConfigTemplate) -> None:
    if "settings" not in merged:
        merged["settings"] = {}

    for key, value in template.settings.items():
        if key not in merged["settings"]:
            merged["settings"][key] = value


def _merge_named_config(
    merged: dict[str, Any],
    key: str,
    template_values: dict[str, Any] | None,
    preserve_user: bool,
) -> None:
    if not template_values:
        return

    if key not in merged or not preserve_user:
        merged[key] = template_values
        return

    if isinstance(merged.get(key), dict):
        for cfg_key, cfg_value in template_values.items():
            if cfg_key not in merged[key]:
                merged[key][cfg_key] = cfg_value
