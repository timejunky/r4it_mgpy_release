"""AI guidance helpers for Quick Check."""

from typing import Any

from .quick_check_models import ProjectInfo, TestRecommendation


def generate_ai_recommendations(
    project_info: ProjectInfo,
    test_recommendations: list[TestRecommendation],
) -> list[dict[str, Any]]:
    recommendations: list[dict[str, Any]] = []
    recommendations.extend(_ai_packaging_guidance(project_info, test_recommendations))
    recommendations.extend(_ai_coverage_guidance(project_info))
    recommendations.extend(_ai_security_guidance(project_info))
    return recommendations


def _ai_packaging_guidance(
    project_info: ProjectInfo,
    test_recommendations: list[TestRecommendation],
) -> list[dict[str, Any]]:
    if not _is_application_project(project_info):
        return []

    if not _is_packaging_enabled(test_recommendations):
        return []

    project_name = project_info.root_path.name if project_info.root_path else "This project"
    return [
        {
            "id": "packaging",
            "name": "Packaging Check",
            "priority": "LOW",
            "enabled": False,
            "reason": (
                f"{project_name} appears to be an application, not a distributable package. "
                "Packaging tests may not be relevant."
            ),
        }
    ]


def _is_application_project(project_info: ProjectInfo) -> bool:
    return bool({"application", "cli"} & project_info.detected_features)


def _is_packaging_enabled(test_recommendations: list[TestRecommendation]) -> bool:
    return any(
        recommendation.id == "packaging" and recommendation.enabled
        for recommendation in test_recommendations
    )


def _ai_coverage_guidance(project_info: ProjectInfo) -> list[dict[str, Any]]:
    if "tests" in project_info.detected_features:
        return []
    return [
        {
            "id": "coverage",
            "name": "Test Coverage",
            "priority": "HIGH",
            "enabled": True,
            "reason": "No test directory detected. Consider adding unit tests to improve code quality.",
        }
    ]


def _ai_security_guidance(project_info: ProjectInfo) -> list[dict[str, Any]]:
    if "dependencies" not in project_info.detected_features:
        return []
    return [
        {
            "id": "security",
            "name": "Dependency Security",
            "priority": "HIGH",
            "enabled": True,
            "reason": "Regular security audits recommended for projects with external dependencies.",
        }
    ]
