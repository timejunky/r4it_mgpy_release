"""Quick Check API - ADR-010 Implementation

Provides fast project analysis and test recommendations for Python projects.
Analog to VS Extension QuickCheck API.

Usage:
    from manifestguard.api import QuickCheck

    qc = QuickCheck()
    info = qc.detect_project_type(".")
    tests = qc.recommend_tests(info)
    config = qc.generate_config_template(tests)

Author: Nejat Philip Eryigit
Copyright: (c) 2025 ready-4-it.com
License: Proprietary
"""

import json
import logging
from collections.abc import Callable
from pathlib import Path
from typing import Any

import tomllib

from manifestguard import CONFIG_SCHEMA_VERSION
from manifestguard.api.quick_check_ai import generate_ai_recommendations as build_ai_recommendations
from manifestguard.api.quick_check_config_ops import (
    compare_configs as compare_config_dicts,
    merge_configs as merge_config_dicts,
)
from manifestguard.api.quick_check_i18n import apply_i18n_hardcoded_gui_strings_settings
from manifestguard.api.quick_check_i18n import apply_i18n_hardcoded_cli_strings_settings
from manifestguard.api.quick_check_models import (
    ConfigTemplate,
    ProjectInfo,
    ProjectType,
    RecommendationPriority,
    TestRecommendation,
)
from manifestguard.api.quick_check_recommendations_mixin import _QuickCheckRecommendationsMixin

logger = logging.getLogger(__name__)


class QuickCheck(_QuickCheckRecommendationsMixin):
    """Quick Check API - Zentrale Klasse für Projekt-Analyse

    ADR-010 Analog Implementation:
    1. detect_project_type() - Like detectProjectType()
    2. recommend_tests() - Like generateTestRecommendations()
    3. generate_config_template() - Like generateConfigTemplate()
    4. merge_configs() - Like mergeConfigs()

    Python Translation Strategy:
    - Use pathlib instead of path module
    - Use tomllib (3.11+) for TOML parsing
    - Use configparser for setup.cfg
    - Use ast module for setup.py (safe, no exec)
    """

    def __init__(self):
        """Initialize QuickCheck API"""
        self.cache: dict[str, Any] = {}

    def detect_project_type(self, project_path: str | Path) -> ProjectInfo:
        """Detect Python project type from manifest files

        Detection Order (VS Extension analog):
        1. pyproject.toml (check for [tool.poetry])
        2. Pipfile (Pipenv)
        3. environment.yml (Conda)
        4. setup.py (legacy)
        5. requirements.txt (minimal)

        Args:
            project_path: Path to project root

        Returns:
            ProjectInfo with detected type and features

        Example:
            >>> qc = QuickCheck()
            >>> info = qc.detect_project_type(".")
            >>> print(info.project_type)
            ProjectType.PYPROJECT_TOML

        """
        path = Path(project_path).resolve()
        detectors: list[tuple[str, Callable[[Path, Path], ProjectInfo]]] = [
            ("pyproject.toml", self._analyze_pyproject),
            ("Pipfile", self._analyze_pipfile),
            ("environment.yml", self._analyze_conda),
            ("setup.py", self._analyze_setup_py),
            ("requirements.txt", self._analyze_requirements),
        ]

        detected = self._run_detection_strategies(path, detectors)
        if detected:
            return detected

        return ProjectInfo(project_type=ProjectType.UNKNOWN, root_path=path)

    def _run_detection_strategies(
        self,
        root: Path,
        detectors: list[tuple[str, Callable[[Path, Path], ProjectInfo]]],
    ) -> ProjectInfo | None:
        for manifest_name, analyzer in detectors:
            manifest_path = root / manifest_name
            if manifest_path.exists():
                return analyzer(root, manifest_path)
        return None

    def _analyze_pyproject(self, root: Path, manifest: Path) -> ProjectInfo:
        """Analyze pyproject.toml project"""
        info = ProjectInfo(
            project_type=ProjectType.PYPROJECT_TOML,
            root_path=root,
            manifest_path=manifest,
        )

        try:
            data = self._load_pyproject_data(manifest)
            info.project_type = self._detect_project_type(data)
            project = data.get("project", {})

            self._extract_python_version(project, info)
            self._extract_dependencies(project, info)
            self._detect_cli_features(project, info)
            self._detect_test_features(root, info)

        except Exception:
            pass

        return info

    def _load_pyproject_data(self, manifest: Path) -> dict[str, Any]:
        """Load and parse pyproject.toml"""
        with manifest.open("rb") as f:
            return tomllib.load(f)

    def _detect_project_type(self, data: dict) -> ProjectType:
        """Detect if Poetry or standard pyproject.toml"""
        if "tool" in data and "poetry" in data["tool"]:
            return ProjectType.POETRY
        return ProjectType.PYPROJECT_TOML

    def _extract_python_version(self, project: dict, info: ProjectInfo) -> None:
        """Extract Python version requirement"""
        requires_python = project.get("requires-python")
        if requires_python:
            info.python_version = requires_python

    def _extract_dependencies(self, project: dict, info: ProjectInfo) -> None:
        """Extract project dependencies"""
        deps = project.get("dependencies", [])
        info.dependencies = [str(d) for d in deps]

        if any("pytest" in str(d).lower() for d in info.dependencies):
            info.detected_features.add("pytest")

    def _detect_cli_features(self, project: dict, info: ProjectInfo) -> None:
        """Detect CLI and GUI features"""
        if project.get("scripts") or project.get("gui-scripts"):
            info.has_cli = True
            info.detected_features.add("cli")

        if project.get("gui-scripts"):
            info.has_gui = True
            info.detected_features.add("gui")

    def _detect_test_features(self, root: Path, info: ProjectInfo) -> None:
        """Detect test directories"""
        if (root / "tests").exists() or (root / "test").exists():
            info.has_tests = True
            info.detected_features.add("tests")

    def _analyze_pipfile(self, root: Path, manifest: Path) -> ProjectInfo:
        """Analyze Pipfile project"""
        return ProjectInfo(
            project_type=ProjectType.PIPENV,
            root_path=root,
            manifest_path=manifest,
            detected_features={"pipenv"},
        )

    def _analyze_conda(self, root: Path, manifest: Path) -> ProjectInfo:
        """Analyze Conda environment.yml"""
        return ProjectInfo(
            project_type=ProjectType.CONDA,
            root_path=root,
            manifest_path=manifest,
            detected_features={"conda"},
        )

    def _analyze_setup_py(self, root: Path, manifest: Path) -> ProjectInfo:
        """Analyze setup.py project (legacy)"""
        return ProjectInfo(
            project_type=ProjectType.SETUP_PY,
            root_path=root,
            manifest_path=manifest,
            detected_features={"legacy"},
        )

    def _analyze_requirements(self, root: Path, manifest: Path) -> ProjectInfo:
        """Analyze requirements.txt project"""
        info = ProjectInfo(
            project_type=ProjectType.REQUIREMENTS,
            root_path=root,
            manifest_path=manifest,
        )

        # Read dependencies
        try:
            with manifest.open(encoding="utf-8") as f:
                info.dependencies = [
                    line.strip() for line in f if line.strip() and not line.startswith("#")
                ]
        except Exception:
            pass

        return info

    def generate_config_template(
        self,
        project_info: ProjectInfo,
        recommendations: list[TestRecommendation],
    ) -> ConfigTemplate:
        """Generate manifestguard.json configuration template."""
        enabled_tests = self._collect_enabled_tests(recommendations)

        template = ConfigTemplate(
            version=CONFIG_SCHEMA_VERSION,
            enabled=True,
            recommended_tests=enabled_tests,
            settings={},
        )

        self._apply_complexity_settings(template, enabled_tests)
        self._apply_coverage_settings(template, project_info, enabled_tests)
        self._apply_project_defaults(template, project_info)
        apply_i18n_hardcoded_gui_strings_settings(template, project_info)
        apply_i18n_hardcoded_cli_strings_settings(template, project_info)

        return template

    def _collect_enabled_tests(self, recommendations: list[TestRecommendation]) -> list[str]:
        return [recommendation.id for recommendation in recommendations if recommendation.enabled]

    def _apply_complexity_settings(
        self, template: ConfigTemplate, enabled_tests: list[str]
    ) -> None:
        if "complexity" not in enabled_tests:
            return

        template.complexity = {
            "threshold": 10,
            "includeTests": False,
            # LOC-based oversized-file thresholds (defaults tuned for AI reviewability)
            "maxFileLinesHigh": 600,
            "maxFileLinesCritical": 1200,
        }

    def _apply_coverage_settings(
        self,
        template: ConfigTemplate,
        project_info: ProjectInfo,
        enabled_tests: list[str],
    ) -> None:
        if "coverage" not in enabled_tests:
            return

        include_paths = self._detect_source_paths(project_info)
        template.coverage = {
            "threshold": 80,
            "fail_under": 70,
            "include": include_paths if include_paths else [],
            "exclude": self._default_coverage_excludes(),
        }

    def _default_coverage_excludes(self) -> list[str]:
        return [
            "tests/**",
            "**/__pycache__/**",
            "**/*.pyc",
            ".venv/**",
            "venv/**",
            "build/**",
            "dist/**",
        ]

    def _apply_project_defaults(self, template: ConfigTemplate, project_info: ProjectInfo) -> None:
        manifest_files = {
            ProjectType.PYPROJECT_TOML: "pyproject.toml",
            ProjectType.SETUP_PY: "setup.py",
        }

        manifest_file = manifest_files.get(project_info.project_type)
        if manifest_file:
            template.settings["manifest_file"] = manifest_file

    def _detect_source_paths(self, project_info: ProjectInfo) -> list[str]:
        """Detect source code directories for coverage include paths"""
        use_provided_root = bool(project_info.root_path and project_info.root_path.exists())
        project_root = project_info.root_path if use_provided_root else Path.cwd()
        project_name = project_root.name if use_provided_root else None

        # Try common source directories first
        source_paths = self._check_common_source_dirs(project_root, project_name)
        if source_paths:
            return source_paths

        # Fallback: scan for top-level Python packages
        return self._scan_toplevel_packages(project_root)

    def _check_common_source_dirs(self, project_root: Path, project_name: str | None) -> list[str]:
        """Check common source directory patterns"""
        source_paths: list[str] = []
        common_dirs: list[str | None] = ["src", "lib", project_name]

        for dirname in common_dirs:
            if not dirname:
                continue

            dir_path = project_root / dirname
            if dir_path.is_dir() and self._contains_python_files(dir_path):
                source_paths.append(f"{dirname}/**/*.py")

        return source_paths

    def _contains_python_files(self, directory: Path) -> bool:
        """Check if directory contains Python files"""
        return any(directory.rglob("*.py"))

    def _scan_toplevel_packages(self, project_root: Path) -> list[str]:
        """Scan for top-level Python packages"""
        source_paths: list[str] = []

        for item in project_root.iterdir():
            if self._is_valid_package_dir(item):
                source_paths.append(f"{item.name}/**/*.py")

        return source_paths

    def _is_valid_package_dir(self, item: Path) -> bool:
        """Check if directory is a valid Python package"""
        if not item.is_dir():
            return False
        if item.name.startswith((".", "_", "test", "doc", "example")):
            return False
        return (item / "__init__.py").exists()

    def generate_ai_recommendations(
        self,
        project_info: ProjectInfo,
        test_recommendations: list[TestRecommendation],
    ) -> list[dict[str, Any]]:
        """Generate optional AI-backed suggestions for project configuration."""
        return build_ai_recommendations(project_info, test_recommendations)

    def merge_configs(
        self,
        existing: dict[str, Any],
        template: ConfigTemplate,
        preserve_user: bool = True,
    ) -> dict[str, Any]:
        """Merge existing config with new template

        VS Extension Analog: mergeConfigs()

        Merge Strategy:
        - preserve_user=True: Keep user customizations (thresholds, settings)
        - preserve_user=False: Overwrite with template defaults
        - Always preserve: version, enabled, custom fields
        - Always merge: recommended_tests (union)

        Args:
            existing: Existing manifestguard.json content
            template: ConfigTemplate from generate_config_template()
            preserve_user: Keep user customizations (default: True)

        Returns:
            Merged configuration dictionary

        Example:
            >>> qc = QuickCheck()
            >>> existing = {"version": "1.0", "enabled": True}
            >>> template = qc.generate_config_template(info, tests)
            >>> merged = qc.merge_configs(existing, template, preserve_user=True)
            >>> print(merged["recommended_tests"])
            ['manifest_check', 'coverage', 'security']

        """
        return merge_config_dicts(existing, template, preserve_user=preserve_user)

    def compare_configs(
        self,
        config_a: dict[str, Any],
        config_b: dict[str, Any],
    ) -> dict[str, Any]:
        """Compare two configurations and return differences

        VS Extension Analog: compareConfig()

        Returns:
            Dictionary with added, removed, and changed fields

        Example:
            >>> qc = QuickCheck()
            >>> diff = qc.compare_configs(old_config, new_config)
            >>> print(diff["added"])
            ['complexity', 'coverage']

        """
        return compare_config_dicts(config_a, config_b)
