"""QuickCheck recommendations mixin — test recommendation generation and prioritization."""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any

from .quick_check_models import (
    ProjectInfo,
    ProjectType,
    RecommendationPriority,
    TestRecommendation,
)

logger = logging.getLogger(__name__)


class _QuickCheckRecommendationsMixin:
    """Mixin: recommend_tests and all recommendation/priority helpers."""

    def recommend_tests(self, project_info: ProjectInfo) -> list[TestRecommendation]:
        """Generate prioritized test recommendations for a project."""
        optional_recommendations: list[TestRecommendation | None] = [
            self._dependency_recommendation(project_info),
            self._sbom_recommendation(project_info),
        ]

        core_recommendations: list[TestRecommendation] = [
            self._manifest_recommendation(project_info),
            self._coverage_recommendation(project_info),
            self._security_recommendation(),
            self._packaging_recommendation(),
            self._complexity_recommendation(),
            self._baseline_recommendation(),
        ]

        all_recommendations: list[TestRecommendation] = [
            *core_recommendations,
            *(rec for rec in optional_recommendations if rec is not None),
        ]

        metrics_snapshot = self._load_latest_metrics(project_info.root_path)
        if metrics_snapshot:
            self._apply_metric_context(all_recommendations, metrics_snapshot)

        return sorted(all_recommendations, key=self._priority_sort_key)

    def _manifest_recommendation(self, project_info: ProjectInfo) -> TestRecommendation:
        return TestRecommendation(
            id="manifest_check",
            name="Manifest Check",
            description="Validate manifest file structure and metadata",
            priority=RecommendationPriority.HIGH,
            reason=f"Essential validation for {project_info.project_type.value} project",
        )

    def _coverage_recommendation(self, project_info: ProjectInfo) -> TestRecommendation:
        has_test_support = project_info.has_tests or "pytest" in project_info.detected_features
        priority = (
            RecommendationPriority.HIGH if has_test_support else RecommendationPriority.MEDIUM
        )
        reason = (
            "Project has test infrastructure"
            if has_test_support
            else "No tests detected - set up test infrastructure first"
        )
        return TestRecommendation(
            id="coverage",
            name="Coverage Analysis",
            description="Measure test coverage and identify untested code",
            priority=priority,
            reason=reason,
        )

    def _dependency_recommendation(self, project_info: ProjectInfo) -> TestRecommendation | None:
        if not project_info.dependencies:
            return None
        return TestRecommendation(
            id="dependencies",
            name="Dependency Check",
            description="Check for outdated or vulnerable dependencies",
            priority=RecommendationPriority.HIGH,
            reason=f"Project has {len(project_info.dependencies)} dependencies",
        )

    def _security_recommendation(self) -> TestRecommendation:
        return TestRecommendation(
            id="security",
            name="Security Scan",
            description="Detect unsafe code patterns (eval/exec, secrets)",
            priority=RecommendationPriority.HIGH,
            reason="Security is critical for all projects",
        )

    def _sbom_recommendation(self, project_info: ProjectInfo) -> TestRecommendation | None:
        if project_info.project_type not in {ProjectType.PYPROJECT_TOML, ProjectType.POETRY}:
            return None
        return TestRecommendation(
            id="sbom",
            name="SBOM Generation",
            description="Generate Software Bill of Materials",
            priority=RecommendationPriority.MEDIUM,
            reason="Modern project with clear dependency management",
        )

    def _packaging_recommendation(self) -> TestRecommendation:
        return TestRecommendation(
            id="packaging",
            name="Packaging Check",
            description="Validate package metadata and structure",
            priority=RecommendationPriority.MEDIUM,
            reason="Ensure proper package configuration",
        )

    def _complexity_recommendation(self) -> TestRecommendation:
        return TestRecommendation(
            id="complexity",
            name="Code Complexity",
            description="Measure cyclomatic complexity with radon",
            priority=RecommendationPriority.LOW,
            reason="Monitor code maintainability",
        )

    def _baseline_recommendation(self) -> TestRecommendation:
        return TestRecommendation(
            id="baseline_comparison",
            name="Baseline Comparison",
            description="Compare metrics against stored baseline",
            priority=RecommendationPriority.LOW,
            reason="Track quality trends over time",
        )

    def _load_latest_metrics(self, root_path: Path) -> dict[str, Any] | None:
        candidates: list[Path] = [
            root_path / "manifestguard-report.json",
            root_path / ".manifestguard" / "manifestguard-report.json",
            root_path / "report.json",
        ]

        for report_path in candidates:
            if not report_path.exists():
                continue
            try:
                with report_path.open(encoding="utf-8") as handle:
                    data = json.load(handle)
            except Exception as e:
                logger.debug(f"Failed to read report {report_path}: {e}")
                continue

            extended = data.get("extended") if isinstance(data, dict) else None
            if isinstance(extended, dict):
                return extended

        return None

    def _apply_metric_context(
        self,
        recommendations: list[TestRecommendation],
        metrics_snapshot: dict[str, Any],
    ) -> None:
        metric_data: dict[str, Any] = (
            metrics_snapshot.get("metrics", {}) if isinstance(metrics_snapshot, dict) else {}
        )
        rec_map: dict[str, TestRecommendation] = {rec.id: rec for rec in recommendations}

        coverage_data = metric_data.get("coverage", {})
        self._adjust_coverage_priority(rec_map.get("coverage"), coverage_data)

        dependency_data = metric_data.get("dependency", {})
        self._adjust_dependency_priority(rec_map.get("dependencies"), dependency_data)

        security_data = metric_data.get("security", {})
        self._adjust_security_priority(rec_map.get("security"), security_data)

        packaging_data = metric_data.get("packaging", {})
        self._adjust_manifest_priority(rec_map.get("manifest_check"), packaging_data)

    def _adjust_coverage_priority(
        self,
        recommendation: TestRecommendation | None,
        coverage_data: dict[str, Any],
    ) -> None:
        if not recommendation or not isinstance(coverage_data, dict):
            return

        if coverage_data.get("unit_measured") is False:
            return

        coverage_percent = coverage_data.get("unit_percent")
        if coverage_percent is None:
            return

        if coverage_percent >= 90:
            self._downgrade_priority(recommendation, RecommendationPriority.LOW)
        elif coverage_percent >= 70:
            self._downgrade_priority(recommendation, RecommendationPriority.MEDIUM)

    def _adjust_dependency_priority(
        self,
        recommendation: TestRecommendation | None,
        dependency_data: dict[str, Any],
    ) -> None:
        if not recommendation or not isinstance(dependency_data, dict):
            return

        critical = dependency_data.get("vulnerable_critical", 0)
        high = dependency_data.get("vulnerable_high", 0)
        outdated = dependency_data.get("outdated_count", 0)

        if critical or high:
            return

        if outdated == 0:
            self._downgrade_priority(recommendation, RecommendationPriority.LOW)
        elif outdated <= 10:
            self._downgrade_priority(recommendation, RecommendationPriority.MEDIUM)

    def _adjust_security_priority(
        self,
        recommendation: TestRecommendation | None,
        security_data: dict[str, Any],
    ) -> None:
        if not recommendation or not isinstance(security_data, dict):
            return

        issues = [
            security_data.get("unsafe_exec_count", 0),
            security_data.get("hardcoded_secrets", 0),
            security_data.get("hardcoded_paths", 0),
        ]
        if any(value for value in issues):
            return

        if security_data.get("weak_crypto") or security_data.get("insecure_permissions"):
            return

        self._downgrade_priority(recommendation, RecommendationPriority.LOW)

    def _adjust_manifest_priority(
        self,
        recommendation: TestRecommendation | None,
        packaging_data: dict[str, Any],
    ) -> None:
        if not recommendation or not isinstance(packaging_data, dict):
            return

        has_gaps = (
            packaging_data.get("missing_classifiers")
            or not packaging_data.get("readme_present", False)
            or not packaging_data.get("license_present", False)
            or not packaging_data.get("version_consistency", True)
        )

        if has_gaps:
            return

        self._downgrade_priority(recommendation, RecommendationPriority.MEDIUM)

    def _downgrade_priority(
        self,
        recommendation: TestRecommendation,
        target_priority: RecommendationPriority,
    ) -> None:
        priority_order = {
            RecommendationPriority.HIGH: 0,
            RecommendationPriority.MEDIUM: 1,
            RecommendationPriority.LOW: 2,
        }

        current_rank = priority_order.get(recommendation.priority)
        target_rank = priority_order.get(target_priority)

        if current_rank is None or target_rank is None:
            return

        if target_rank >= current_rank:
            recommendation.priority = target_priority

    def _priority_sort_key(self, recommendation: TestRecommendation) -> tuple[int, str]:
        priority_order = {
            RecommendationPriority.HIGH: 0,
            RecommendationPriority.MEDIUM: 1,
            RecommendationPriority.LOW: 2,
        }
        return priority_order[recommendation.priority], recommendation.id
