"""Shared models for Quick Check API."""

from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any


class ProjectType(Enum):
    """Python project types based on manifest files."""

    PYPROJECT_TOML = "pyproject.toml"
    POETRY = "poetry"
    PIPENV = "pipenv"
    CONDA = "conda"
    SETUP_PY = "setup.py"
    REQUIREMENTS = "requirements.txt"
    UNKNOWN = "unknown"


class RecommendationPriority(Enum):
    """Test recommendation priority levels."""

    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"


@dataclass
class ProjectInfo:
    """Project information from detection."""

    project_type: ProjectType
    root_path: Path
    manifest_path: Path | None = None
    detected_features: set[str] = field(default_factory=set)
    has_tests: bool = False
    has_cli: bool = False
    has_gui: bool = False
    dependencies: list[str] = field(default_factory=list)
    python_version: str | None = None


@dataclass
class TestRecommendation:
    """Test recommendation with priority and reasoning."""

    __test__ = False
    id: str
    name: str
    description: str
    priority: RecommendationPriority
    reason: str
    enabled: bool = True


@dataclass
class ConfigTemplate:
    """ManifestGuard configuration template."""

    version: str
    enabled: bool
    recommended_tests: list[str]
    settings: dict[str, Any] = field(default_factory=dict)
    complexity: dict[str, Any] | None = None
    coverage: dict[str, Any] | None = None
