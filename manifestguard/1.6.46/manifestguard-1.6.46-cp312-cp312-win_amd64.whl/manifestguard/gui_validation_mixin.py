"""Validation + init-config runner mixin for ManifestGuard GUI."""
from __future__ import annotations

import sys
from pathlib import Path
from typing import TYPE_CHECKING, Any

from PySide6.QtWidgets import (
    QFileDialog,
    QMessageBox,
)

if TYPE_CHECKING:
    pass


class GuiValidationMixin:
    if TYPE_CHECKING:
        def __getattr__(self, name: str) -> Any: ...

    def _run_init_config(self, *, open_after: bool) -> None:
        root = self._selected_project_root()
        if root is None:
            QMessageBox.warning(self, "Missing Project Folder", "Please select a project folder.")  # type: ignore[arg-type]
            return

        if self._is_thread_running("_init_config_thread"):
            QMessageBox.information(self, "Already Running", "init-config is already running.")  # type: ignore[arg-type]
            return

        self._init_config_open_after = bool(open_after)
        self.config_output.clear()
        self._append_config_output("Starting init-config...")

        self.btn_init_config.setEnabled(False)
        self.btn_cancel_init_config.setEnabled(True)

        cmd = [
            sys.executable,
            "-m",
            "manifestguard",
            "init-config",
            "--merge",
            "--output",
            "manifestguard.json",
        ]

        from manifestguard.gui_workers import CommandWorker as _CommandWorker

        self._init_config_worker = _CommandWorker(cwd=root, cmd=cmd)
        self._start_worker_thread(
            thread_attr="_init_config_thread",
            worker_attr="_init_config_worker",
            worker=self._init_config_worker,
            on_output=self._append_config_output,
            on_finished=self._on_init_config_finished,
        )

    def _cancel_init_config(self) -> None:
        self._cancel_worker("_init_config_worker")

    def _prepare_validation_run(self, headline: str) -> tuple[Path, Path, bool] | None:
        workspace_root = self._get_active_project_root()
        if workspace_root is None:
            QMessageBox.warning(self, "Missing Project Folder", "Please select a project.")  # type: ignore[arg-type]
            return None

        if not workspace_root.exists() or not workspace_root.is_dir():
            QMessageBox.warning(
                self, "Invalid Project Folder", f"Not a directory: {workspace_root}"  # type: ignore[arg-type]
            )
            return None

        report_raw = (self.validation_report_edit.text() or "").strip() or "manifestguard-report.json"
        report_path = Path(report_raw)
        if not report_path.is_absolute():
            report_path = (workspace_root / report_path).resolve()

        try:
            report_path.parent.mkdir(parents=True, exist_ok=True)
        except Exception as e:
            QMessageBox.critical(
                self,  # type: ignore[arg-type]
                "Report Path Error",
                f"Cannot create report directory: {report_path.parent}\n\n{e}",
            )
            return None

        extended = bool(self.validation_extended_checkbox.isChecked())

        state = self._load_gui_state()
        state.update({"validationExtended": extended})
        self._save_gui_state(state)

        projects = self._get_projects()
        active = self._get_active_project_root_str()
        for rec in projects:
            if rec.get("root") != active:
                continue
            try:
                rel = report_path.resolve().relative_to(workspace_root.resolve())
                rec["lastReport"] = rel.as_posix()
            except Exception:
                rec["lastReport"] = str(report_path)
            rec["lastExtended"] = extended
            rec["lastUsedAt"] = self._now_iso()
            break
        self._save_projects(self._sorted_projects(projects), active_root=active)

        self.validation_output.clear()
        self._append_validation_output(headline)
        self._set_validation_running(True)

        return workspace_root, report_path, extended

    def _on_init_config_finished(self, exit_code: int) -> None:
        self.btn_init_config.setEnabled(True)
        self.btn_cancel_init_config.setEnabled(False)

        if exit_code == 0:
            self._append_config_output("\n✅ init-config succeeded.")
            state = self._load_gui_state()
            root = self._selected_project_root()
            if root is not None:
                state["projectRoot"] = str(root)
                self._save_gui_state(state)
            if getattr(self, "_init_config_open_after", False) and root is not None:
                self._open_path_in_os(root / "manifestguard.json")
        else:
            self._append_config_output(f"\n❌ init-config failed (exit code {exit_code}).")

    def _browse_validation_report(self) -> None:
        start_dir = self.validation_workspace_edit.text() or str(Path.cwd())
        suggested_name = self.validation_report_edit.text() or "manifestguard-report.json"
        file_path, _ = QFileDialog.getSaveFileName(
            self,  # type: ignore[arg-type]
            "Select Report File",
            str(Path(start_dir) / suggested_name),
            "JSON (*.json);;All Files (*)",
        )
        if file_path:
            self.validation_report_edit.setText(file_path)

    def _append_validation_output(self, text: str) -> None:
        self.validation_output.append(text)

    def _run_validation(self) -> None:
        prepared = self._prepare_validation_run("Starting ManifestGuard validation...")
        if prepared is None:
            return
        workspace_root, report_path, extended = prepared

        from manifestguard.gui_workers import ValidationWorker as _ValidationWorker

        self._validation_worker = _ValidationWorker(
            workspace_root=workspace_root,
            extended=extended,
            report_path=report_path,
        )
        self._start_worker_thread(
            thread_attr="_validation_thread",
            worker_attr="_validation_worker",
            worker=self._validation_worker,
            on_output=self._append_validation_output,
            on_finished=self._on_validation_finished,
        )

    def _run_preflight_and_validation(self) -> None:
        prepared = self._prepare_validation_run("Starting vwpy preflight + validation...")
        if prepared is None:
            return
        workspace_root, report_path, extended = prepared

        from manifestguard.gui_workers import PreflightAndValidationWorker as _PreflightAndValidationWorker

        self._validation_worker = _PreflightAndValidationWorker(
            workspace_root=workspace_root,
            extended=extended,
            report_path=report_path,
            preflight_timeout_seconds=30.0,
        )
        self._start_worker_thread(
            thread_attr="_validation_thread",
            worker_attr="_validation_worker",
            worker=self._validation_worker,
            on_output=self._append_validation_output,
            on_finished=self._on_validation_finished,
        )

    def _cancel_validation(self) -> None:
        self._cancel_worker("_validation_worker")

    def _on_validation_finished(self, exit_code: int) -> None:
        self._set_validation_running(False)

        if exit_code == 0:
            self._append_validation_output("\n✅ Validation succeeded.")
            root = self._get_active_project_root()
            rec = self._get_active_project_record() or {}
            last_report = rec.get("lastReport")
            if root is not None and isinstance(last_report, str) and hasattr(self, "dashboard_report_path_edit"):
                self.dashboard_report_path_edit.setText(
                    str(self._resolve_project_relative_path(root, last_report))
                )
            self._open_dashboard("report")
        else:
            self._append_validation_output(f"\n❌ Validation failed (exit code {exit_code}).")

    def _set_validation_running(self, running: bool) -> None:
        if hasattr(self, "btn_validate"):
            self.btn_validate.setEnabled(not running)
        if hasattr(self, "btn_preflight_validate"):
            self.btn_preflight_validate.setEnabled(not running)
        if hasattr(self, "btn_cancel_validation"):
            self.btn_cancel_validation.setEnabled(running)
