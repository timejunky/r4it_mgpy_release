from __future__ import annotations

import contextlib
import importlib.metadata as md
import json
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from manifestguard import __version__
from manifestguard.licensing import LicensingClient
from manifestguard.licensing.feature_limits import FEATURE_LIMITS
from manifestguard.models.telemetry import (
    ComplexityHotspot,
    ComplexityTelemetry,
    QualityTelemetry,
    RuffTelemetry,
)


def _security_attr_int(obj: Any, name: str) -> int:
    try:
        return int(getattr(obj, name, 0) or 0)
    except Exception:
        return 0


def _security_attr_list(obj: Any, name: str) -> list[Any]:
    if obj is None:
        return []
    return list(getattr(obj, name, []) or [])


def summarize_security_findings(security: Any) -> dict[str, Any]:
    """Return a compact summary of security findings for gating and display."""
    weak_crypto_files = _security_attr_list(security, "weak_crypto")
    insecure_perm_files = _security_attr_list(security, "insecure_permissions")
    wheel_findings = _security_attr_list(security, "wheel_content_findings")

    summary = {
        "unsafe_exec": _security_attr_int(security, "unsafe_exec_count"),
        "hardcoded_secrets": _security_attr_int(security, "hardcoded_secrets"),
        "hardcoded_paths": _security_attr_int(security, "hardcoded_paths"),
        "subprocess_shell_true": _security_attr_int(security, "subprocess_shell_true"),
        "unsafe_deserialization": _security_attr_int(security, "unsafe_deserialization"),
        "tls_verify_disabled": _security_attr_int(security, "tls_verify_disabled"),
        "insecure_tempfile": _security_attr_int(security, "insecure_tempfile"),
        "weak_crypto_files": len(weak_crypto_files),
        "insecure_permissions_files": len(insecure_perm_files),
        "wheel_content_issues": _security_attr_int(security, "wheel_content_issues"),
        "examples": {
            "weak_crypto": weak_crypto_files[:3],
            "insecure_permissions": insecure_perm_files[:3],
            "wheel": wheel_findings[:3],
        },
    }

    numeric_keys = {
        "unsafe_exec",
        "hardcoded_secrets",
        "hardcoded_paths",
        "subprocess_shell_true",
        "unsafe_deserialization",
        "tls_verify_disabled",
        "insecure_tempfile",
        "weak_crypto_files",
        "insecure_permissions_files",
        "wheel_content_issues",
    }
    summary["has_findings"] = any(summary.get(key, 0) for key in numeric_keys) or bool(
        wheel_findings
    )
    return summary


def _build_complexity_hotspots(comp: Any) -> list[ComplexityHotspot]:
    hotspots: list[ComplexityHotspot] = []
    for v in getattr(comp, "top_violations", [])[:5]:
        if not isinstance(v, dict):
            continue
        file_path = v.get("file")
        func_name = v.get("function") or v.get("name")
        line_num = v.get("line")
        complexity_val = v.get("complexity") or v.get("value")
        if file_path and func_name and line_num and complexity_val:
            hotspots.append(
                ComplexityHotspot(
                    file=file_path,
                    name=func_name,
                    line=line_num,
                    value=complexity_val,
                )
            )
    return hotspots


def _normalize_complexity_engine(comp: Any) -> tuple[str, str | None]:
    engine = (getattr(comp, "engine", "mgpy-analyzer") or "mgpy-analyzer").strip().lower()
    if engine == "mgpy" or engine not in {"mgpy-analyzer", "radon"}:
        engine = "mgpy-analyzer"
    engine_version = getattr(comp, "engine_version", None)
    if engine == "mgpy-analyzer" and not engine_version:
        engine_version = __version__
    return engine, engine_version


def get_ruff_info() -> dict[str, Any]:
    """Best-effort Ruff telemetry including optional radon version."""
    info: dict[str, Any] = {
        "issueCount": 0,
        "warningCount": 0,
        "version": None,
        "source": "none",
        "byRule": {},
        "radonVersion": None,
    }
    try:
        try:
            info["version"] = md.version("ruff")
            info["source"] = "venv"
        except Exception:
            pass
        with contextlib.suppress(Exception):
            info["radonVersion"] = md.version("radon")
    except Exception:
        try:
            import ruff  # noqa: PLC0415

            info["version"] = getattr(ruff, "__version__", None)
            info["source"] = "venv"
        except Exception:
            pass
        try:
            import radon  # noqa: PLC0415

            info["radonVersion"] = getattr(radon, "__version__", None)
        except Exception:
            pass
    return info


def build_quality_slice(metrics: Any, workspace_root: Path) -> dict[str, Any]:
    """Construct quality telemetry slice with Ruff and complexity data."""
    ruff_info = get_ruff_info()

    ruff_telemetry = RuffTelemetry(
        issueCount=ruff_info.get("issueCount", 0),
        warningCount=ruff_info.get("warningCount", 0),
        version=ruff_info.get("version"),
        source=ruff_info.get("source", "none"),
        byRule=ruff_info.get("byRule", {}),
    )

    complexity_telemetry: ComplexityTelemetry | None = None
    comp = getattr(metrics, "complexity", None)
    if comp:
        engine, engine_version = _normalize_complexity_engine(comp)
        functions_above = getattr(comp, "violations_count", 0)
        complexity_telemetry = ComplexityTelemetry(
            avg=round(getattr(comp, "average_complexity", 0.0), 1),
            violations=functions_above,
            threshold=getattr(comp, "threshold", 10),
            functionsAboveThreshold=functions_above,
            hotspots=_build_complexity_hotspots(comp),
            engine=engine,
            engineVersion=engine_version,
        )

    quality_score = getattr(metrics, "quality_score", None)
    quality_telemetry = QualityTelemetry(
        timestamp=datetime.now(timezone.utc).isoformat(),
        projectName=str(workspace_root.name),
        manifestguardVersion=__version__,
        ruff=ruff_telemetry,
        complexity=complexity_telemetry,
        qualityScore=round(float(quality_score), 1) if isinstance(quality_score, (int, float)) else None,
    )

    return json.loads(quality_telemetry.model_dump_json(exclude_none=True, by_alias=False))


def has_license_feature(feature: str) -> bool:
    """Return True if current license enables a feature (best-effort)."""
    try:
        client = LicensingClient.get_instance()

        def _status_allows() -> bool:
            status = client.get_status()
            status_name = getattr(status.code, "name", "")
            if status_name not in {"OK", "UPDATE_ENTITLEMENT_EXPIRED"}:
                return False
            if not status.payload:
                return False

            raw_tier = status.payload.get("tier") or status.payload.get("plan") or "community"
            normalized_tier = client._normalized_tier(raw_tier)
            limits = FEATURE_LIMITS.get(normalized_tier, FEATURE_LIMITS["community"])
            value = limits.get(feature, False)
            return bool(value) if isinstance(value, (int, bool)) else False

        if _status_allows():
            return True

        time.sleep(0.1)
        if _status_allows():
            return True

        return client.has_feature(feature)
    except Exception:
        return False


def license_tier_label() -> str:
    """Return a short tier label for UX messages (best-effort)."""
    try:
        client = LicensingClient.get_instance()
        status = client.get_status()
        if not status.payload:
            return "community"

        tier = status.payload.get("tier") or status.payload.get("plan") or "community"
        return client._normalized_tier(tier)
    except Exception:
        return "community"
