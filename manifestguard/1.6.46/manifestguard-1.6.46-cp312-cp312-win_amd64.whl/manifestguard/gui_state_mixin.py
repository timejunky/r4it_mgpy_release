"""GUI state + repo/project management mixin.

This is extracted from `manifestguard.gui` to keep the main GUI module smaller.
It contains:
- per-user gui.json persistence
- project catalog handling
- repo settings scoping (userwide vs per-project)
- theme handling
"""

from __future__ import annotations

import json
import os
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import cast

from PySide6.QtGui import QColor, QPalette
from PySide6.QtWidgets import (
    QApplication,
    QCheckBox,
    QComboBox,
    QLineEdit,
    QWidget,
)

from manifestguard.core.safe_json_writer import write_json_file_sync
from manifestguard.gui_repo_settings_mixin import GuiRepoSettingsMixin


class GuiStateMixin(GuiRepoSettingsMixin):
    def _gui_state_path(self) -> Path:
        """Return per-user GUI state path (not workspace/project config)."""
        if sys.platform == "win32":
            app_data = os.environ.get("APPDATA")
            base_dir = (
                Path(app_data) / "manifestguard" if app_data else Path.home() / ".manifestguard"
            )
        else:
            xdg = os.environ.get("XDG_CONFIG_HOME")
            base_dir = Path(xdg) / "manifestguard" if xdg else Path.home() / ".config" / "manifestguard"

        base_dir.mkdir(parents=True, exist_ok=True)
        return base_dir / "gui.json"

    def _load_gui_state(self) -> dict:
        path = self._gui_state_path()
        try:
            if not path.exists():
                return {}
            raw = json.loads(path.read_text(encoding="utf-8"))
            if not isinstance(raw, dict):
                return {}
            migrated = self._migrate_gui_state(raw)
            if migrated is not raw:
                self._save_gui_state(migrated)
            return migrated
        except Exception:
            return {}

    def _save_gui_state(self, state: dict) -> None:
        path = self._gui_state_path()
        try:
            write_json_file_sync(path, state, prettify=True, indent=2, line_ending="lf")
        except Exception:
            return

    @staticmethod
    def _is_multi_project_state(state: dict) -> bool:
        projects = state.get("projects")
        active = state.get("activeProjectRoot")
        return isinstance(projects, list) and isinstance(active, str)

    def _maybe_add_project_root(self, out: list[dict], root_str: str) -> None:
        root_str = (root_str or "").strip()
        if not root_str:
            return
        try:
            root = Path(root_str).expanduser().resolve()
        except Exception:
            return
        if not root.exists() or not root.is_dir():
            return
        out.append(self._create_project_record(root))

    @staticmethod
    def _dedupe_projects_by_root(records: list[dict]) -> list[dict]:
        dedup: dict[str, dict] = {}
        for rec in records:
            r = rec.get("root")
            if isinstance(r, str) and r:
                dedup[r] = rec
        return list(dedup.values())

    @staticmethod
    def _migrate_legacy_key(state: dict, *, target_key: str, legacy_keys: list[str]) -> None:
        if state.get(target_key):
            return
        for k in legacy_keys:
            v = state.get(k)
            if isinstance(v, str) and v:
                state[target_key] = v
                return

    def _migrate_gui_state(self, state: dict) -> dict:
        """Migrate legacy single-project GUI state into a multi-project catalog.

        This only touches per-user GUI state (gui.json). It does not write to projects.
        """

        if not isinstance(state, dict):
            return {}

        if self._is_multi_project_state(state):
            return state

        migrated = dict(state)

        migrated_projects: list[dict] = []
        legacy_root = migrated.get("projectRoot")
        if isinstance(legacy_root, str):
            self._maybe_add_project_root(migrated_projects, legacy_root)

        legacy_ws = migrated.get("validationWorkspace")
        if isinstance(legacy_ws, str):
            self._maybe_add_project_root(migrated_projects, legacy_ws)

        migrated["projects"] = self._dedupe_projects_by_root(migrated_projects)

        active = migrated.get("activeProjectRoot")
        if not (isinstance(active, str) and active):
            migrated["activeProjectRoot"] = (
                migrated["projects"][0]["root"] if migrated.get("projects") else ""
            )

        # Keep legacy key in sync for backward compatibility.
        active_root = migrated.get("activeProjectRoot")
        if isinstance(active_root, str) and active_root:
            migrated["projectRoot"] = active_root

        # Repo settings legacy migrations (best-effort)
        self._migrate_legacy_key(
            migrated,
            target_key="user_repo_root",
            legacy_keys=["userRepoRoot", "userRepo", "user_repo"],
        )
        self._migrate_legacy_key(
            migrated,
            target_key="wheel_repo_path",
            legacy_keys=["wheelRepositoryPath", "wheelRepoPath", "wheel_repo"],
        )
        self._migrate_legacy_key(
            migrated,
            target_key="remote_origin_url",
            legacy_keys=["remoteOriginUrl", "remoteOrigin", "originUrl"],
        )

        return migrated

    def _get_manifestguard_json_path(self) -> Path | None:
        root = self._get_active_project_root()
        if root is None:
            return None
        return root / "manifestguard.json"

    def _merge_manifestguard_json_settings(self, *, updates: dict) -> None:
        path = self._get_manifestguard_json_path()
        if path is None:
            return
        try:
            current: dict = {}
            if path.exists():
                raw = json.loads(path.read_text(encoding="utf-8"))
                if isinstance(raw, dict):
                    current = raw

            merged = dict(current)
            merged.update(updates)
            write_json_file_sync(path, merged, prettify=True, indent=2, line_ending="lf")
        except Exception:
            return
    def _now_iso(self) -> str:
        return datetime.now(timezone.utc).isoformat(timespec="seconds")

    def _create_project_record(self, root: Path) -> dict:
        return {
            "root": str(root),
            "displayName": root.name or str(root),
            "pinned": False,
            "lastUsedAt": self._now_iso(),
            "lastReport": "manifestguard-report.json",
            "lastExtended": True,
            "repoSettings": {},
        }

    def _get_projects(self) -> list[dict]:
        state = self._load_gui_state()
        projects = state.get("projects")
        if not isinstance(projects, list):
            return []
        out: list[dict] = []
        for item in projects:
            if isinstance(item, dict) and isinstance(item.get("root"), str):
                out.append(item)
        return out

    def _save_projects(self, projects: list[dict], *, active_root: str | None = None) -> None:
        state = self._load_gui_state()
        state["projects"] = projects
        if isinstance(active_root, str):
            state["activeProjectRoot"] = active_root
            state["projectRoot"] = active_root
        self._save_gui_state(state)

    def _normalize_root(self, root: Path | str) -> str:
        try:
            path = root if isinstance(root, Path) else Path(str(root))
            return str(path.expanduser().resolve())
        except Exception:
            return str(root)

    def _get_active_project_root_str(self) -> str:
        state = self._load_gui_state()
        raw = state.get("activeProjectRoot") or state.get("projectRoot") or state.get("validationWorkspace")
        if isinstance(raw, str):
            return raw
        return ""

    def _get_active_project_root(self) -> Path | None:
        raw = (self._get_active_project_root_str() or "").strip()
        if not raw:
            return None
        try:
            root = Path(raw).expanduser().resolve()
        except Exception:
            return None
        if not root.exists() or not root.is_dir():
            return None
        return root

    def _set_active_project_root(self, root: Path) -> None:
        root_str = self._normalize_root(root)

        projects = self._get_projects()
        existing = None
        for rec in projects:
            if rec.get("root") == root_str:
                existing = rec
                break

        if existing is None:
            projects.append(self._create_project_record(Path(root_str)))
        else:
            existing["lastUsedAt"] = self._now_iso()

        self._save_projects(self._sorted_projects(projects), active_root=root_str)
        self._refresh_project_selector_ui()
        self._apply_active_project_to_views()

    def _sorted_projects(self, projects: list[dict]) -> list[dict]:
        def key(rec: dict) -> tuple:
            pinned = bool(rec.get("pinned", False))
            name = str(rec.get("displayName") or "").lower()
            root = str(rec.get("root") or "").lower()
            return (not pinned, name, root)

        return sorted(projects, key=key)

    def _get_active_project_record(self) -> dict | None:
        active = self._get_active_project_root_str()
        if not active:
            return None
        for rec in self._get_projects():
            if rec.get("root") == active:
                return rec
        return None

    def _resolve_project_relative_path(self, root: Path, maybe_rel: str) -> Path:
        raw = (maybe_rel or "").strip()
        if not raw:
            return root / "manifestguard-report.json"
        p = Path(raw).expanduser()
        if p.is_absolute():
            return p
        return (root / p).resolve()

    def _fill_text_field(self, widget_name: str, text: str) -> None:
        """Set text on a named QLineEdit widget if it exists."""
        if hasattr(self, widget_name):
            cast(QLineEdit, getattr(self, widget_name)).setText(text)

    def _apply_record_fields_to_views(self, rec: dict, root: Path) -> None:
        """Populate report/extended fields from a project record."""
        last_report = rec.get("lastReport")
        if isinstance(last_report, str) and last_report:
            self._fill_text_field("validation_report_edit", last_report)
            if hasattr(self, "dashboard_report_path_edit"):
                resolved = str(self._resolve_project_relative_path(root, last_report))
                cast(QLineEdit, getattr(self, "dashboard_report_path_edit")).setText(resolved)
        if hasattr(self, "validation_extended_checkbox"):
            last_ext = rec.get("lastExtended")
            if isinstance(last_ext, bool):
                cast(QCheckBox, getattr(self, "validation_extended_checkbox")).setChecked(last_ext)

    def _apply_active_project_to_views(self) -> None:
        root = self._get_active_project_root()
        if root is None:
            return

        self._fill_text_field("project_root_edit", str(root))
        self._fill_text_field("validation_workspace_edit", str(root))

        rec = self._get_active_project_record() or {}
        self._apply_record_fields_to_views(rec, root)

        if hasattr(self, "repo_settings_scope_combo"):
            state = self._load_gui_state()
            if self._get_repo_settings_scope(state) == "project":
                self._load_repo_settings()
            else:
                self._maybe_autofill_repo_fields(persist=True)

    def _refresh_project_selector_ui(self) -> None:
        if not hasattr(self, "project_selector_combo"):
            return

        combo = cast(QComboBox, getattr(self, "project_selector_combo"))
        projects = self._sorted_projects(self._get_projects())
        active = self._get_active_project_root_str()

        combo.blockSignals(True)
        combo.clear()
        idx_to_select = -1

        for _idx, rec in enumerate(projects):
            root = rec.get("root")
            name = rec.get("displayName")
            if not isinstance(root, str) or not root:
                continue
            label = str(name) if name else Path(root).name
            if rec.get("pinned"):
                label = f"📌 {label}"
            combo.addItem(label, root)
            if root == active:
                idx_to_select = combo.count() - 1

        if idx_to_select >= 0:
            combo.setCurrentIndex(idx_to_select)

        combo.blockSignals(False)

    def _toggle_dark_mode(self, state: int) -> None:
        self._dark_mode = bool(state)
        self._apply_theme()
        saved = self._load_gui_state()
        saved["darkMode"] = self._dark_mode
        self._save_gui_state(saved)

    def _apply_theme(self) -> None:
        app = QApplication.instance()
        if app is None:
            return

        qt_app = cast(QApplication, app)

        if not self._dark_mode:
            qt_app.setPalette(QApplication.style().standardPalette())
            cast(QWidget, self).setStyleSheet("")
            return

        palette = QPalette()
        palette.setColor(QPalette.ColorRole.Window, QColor(30, 30, 30))
        palette.setColor(QPalette.ColorRole.WindowText, QColor(212, 212, 212))
        palette.setColor(QPalette.ColorRole.Base, QColor(37, 37, 38))
        palette.setColor(QPalette.ColorRole.AlternateBase, QColor(45, 45, 48))
        palette.setColor(QPalette.ColorRole.ToolTipBase, QColor(37, 37, 38))
        palette.setColor(QPalette.ColorRole.ToolTipText, QColor(212, 212, 212))
        palette.setColor(QPalette.ColorRole.Text, QColor(212, 212, 212))
        palette.setColor(QPalette.ColorRole.Button, QColor(60, 60, 60))
        palette.setColor(QPalette.ColorRole.ButtonText, QColor(212, 212, 212))
        palette.setColor(QPalette.ColorRole.Highlight, QColor(0, 122, 204))
        palette.setColor(QPalette.ColorRole.HighlightedText, QColor(255, 255, 255))
        qt_app.setPalette(palette)

        cast(QWidget, self).setStyleSheet(
            "QGroupBox { font-weight: bold; }"
            "QTextEdit { font-family: Consolas, 'Courier New', monospace; }"
        )
