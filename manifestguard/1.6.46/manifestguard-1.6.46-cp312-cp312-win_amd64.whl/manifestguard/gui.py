"""GUI for ManifestGuard Python.

Qt-based graphical user interface with 4-tab AI configuration panel.
Based on R4IT shared AI configuration pattern.

Tabs:
- ⚙️ Config: Basic AI settings & tooling advisor
- 🤖 Models: Provider selection, model management, API keys
- 📖 Guide: Usage documentation & troubleshooting
- 🔬 Advanced: Expert features & automation
"""

from __future__ import annotations

import json
import os
import subprocess
import sys
import webbrowser
from datetime import datetime, timezone
from importlib.util import find_spec
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    pass

try:
    from PySide6.QtCore import QObject, QThread, Qt, Signal
    from PySide6.QtGui import QColor, QPalette
    from PySide6.QtWidgets import (
        QApplication,
        QCheckBox,
        QComboBox,
        QGroupBox,
        QHBoxLayout,
        QInputDialog,
        QLabel,
        QLineEdit,
        QFileDialog,
        QMainWindow,
        QMessageBox,
        QPushButton,
        QSplitter,
        QSpinBox,
        QStackedWidget,
        QTabWidget,
        QTextEdit,
        QTreeWidget,
        QTreeWidgetItem,
        QVBoxLayout,
        QWidget,
    )
except ImportError as e:
    # Keep this path dependency-free: i18n is stdlib-only.
    from manifestguard.i18n import t_format

    print(
        t_format(
            "gui.pyside_missing",
            module="gui",
            original_error=str(e),
        ),
        file=sys.stderr,
    )
    sys.exit(1)

from manifestguard import get_runtime_version
from manifestguard.ai.shared_preferences import get_shared_preferences
from manifestguard.core.safe_json_writer import write_json_file_sync
from manifestguard.gui_dashboard_stats import build_dashboard_stats_html
from manifestguard.gui_support import detect_git_origin_url
from manifestguard.gui_ai_mixin import GuiAIMixin
from manifestguard.gui_dashboard_mixin import GuiDashboardMixin
from manifestguard.gui_project_mixin import GuiProjectMixin
from manifestguard.gui_state_mixin import GuiStateMixin
from manifestguard.gui_validation_mixin import GuiValidationMixin
from manifestguard.gui_workers import (
    CommandSequenceWorker as _CommandSequenceWorker,
    CommandWorker as _CommandWorker,
    PreflightAndValidationWorker as _PreflightAndValidationWorker,
    PreflightCrossAIWorker as _PreflightCrossAIWorker,
    ProjectDiscoveryWorker as _ProjectDiscoveryWorker,
    ValidationWorker as _ValidationWorker,
)


class ManifestGuardGUI(GuiStateMixin, GuiDashboardMixin, GuiAIMixin, GuiProjectMixin, GuiValidationMixin, QMainWindow):
    """Main window for ManifestGuard GUI."""

    def __init__(self) -> None:
        super().__init__()
        self._runtime_version = get_runtime_version()
        self.setWindowTitle(f"ManifestGuard v{self._runtime_version}")
        self.resize(1000, 700)

        # Set window icon if logo exists
        logo_path = Path(__file__).parent.parent.parent / "docs" / "images" / "logo.png"
        if logo_path.exists():
            from PySide6.QtGui import QIcon
            self.setWindowIcon(QIcon(str(logo_path)))

        gui_state = self._load_gui_state()
        self._dark_mode = bool(gui_state.get("darkMode", False))

        # Last preflight reports for cross-venv comparison
        self._preflight_last_reports: dict[str, dict] = {}

        # Central widget with tabs
        central_widget = QWidget()
        main_layout = QVBoxLayout(central_widget)

        # Header
        header_layout = QHBoxLayout()
        title_label = QLabel(f"ManifestGuard v{self._runtime_version}")
        title_label.setStyleSheet("font-size: 16pt; font-weight: bold;")
        header_layout.addWidget(title_label)
        header_layout.addStretch()

        self.dark_mode_checkbox = QCheckBox("Dark Mode")
        self.dark_mode_checkbox.setChecked(self._dark_mode)
        self.dark_mode_checkbox.stateChanged.connect(self._toggle_dark_mode)
        header_layout.addWidget(self.dark_mode_checkbox)
        main_layout.addLayout(header_layout)

        # Main tabs
        self.tabs = QTabWidget()
        self.tabs.addTab(self._create_dashboard_tab(), "📊 Dashboard")
        self.tabs.addTab(self._create_validation_tab(), "✅ Validation")
        self.tabs.addTab(self._create_ai_tab(), "🤖 AI Assistant")
        self.tabs.addTab(self._create_settings_tab(), "⚙️ Settings")

        main_layout.addWidget(self.tabs)

        self.setCentralWidget(central_widget)

        self._apply_theme()

        # Load initial settings
        self._load_ai_settings()
        self._load_repo_settings()

    def _create_validation_tab(self) -> QWidget:
        """Validation controls tab."""
        widget = QWidget()
        layout = QVBoxLayout(widget)

        info = QLabel(
            "<h2>✅ Validation</h2>"
            "<p><b>Note:</b> Validation and reports live in the <b>Dashboard</b> workflow (MGVS-style).</p>"
            "<ul>"
            "<li>Dashboard → Control (run checks)</li>"
            "<li>Dashboard → Report (open JSON report)</li>"
            "</ul>"
        )
        info.setWordWrap(True)
        layout.addWidget(info)

        buttons = QHBoxLayout()
        btn_open_control = QPushButton("Open Dashboard → Control")
        btn_open_control.clicked.connect(lambda: self._open_dashboard("control"))
        buttons.addWidget(btn_open_control)

        btn_open_report = QPushButton("Open Dashboard → Report")
        btn_open_report.clicked.connect(lambda: self._open_dashboard("report"))
        buttons.addWidget(btn_open_report)

        buttons.addStretch()
        layout.addLayout(buttons)

        layout.addStretch()

        return widget

    def _create_settings_tab(self) -> QWidget:
        """Settings tab for repo-scoped GUI preferences and preflight defaults."""
        widget = QWidget()
        layout = QVBoxLayout(widget)

        info = QLabel(
            "<h2>⚙️ Settings</h2>"
            "<p>Configure shared repository paths and GUI defaults used by dashboard tools.</p>"
            "<p>These values are stored in your per-user GUI state and can optionally be scoped per project.</p>"
        )
        info.setWordWrap(True)
        layout.addWidget(info)

        scope_group = QGroupBox("Settings Scope")
        scope_layout = QHBoxLayout(scope_group)
        scope_layout.addWidget(QLabel("Apply repo settings to:"))
        self.repo_settings_scope_combo = QComboBox()
        self.repo_settings_scope_combo.addItem("User-wide", "userwide")
        self.repo_settings_scope_combo.addItem("Active project only", "project")
        self.repo_settings_scope_combo.currentIndexChanged.connect(self._on_repo_settings_scope_changed)
        scope_layout.addWidget(self.repo_settings_scope_combo)
        scope_layout.addStretch()
        layout.addWidget(scope_group)

        repo_group = QGroupBox("Repository Paths")
        repo_layout = QVBoxLayout(repo_group)

        def add_path_row(label_text: str, attr_name: str, button_text: str = "Browse…") -> None:
            row = QHBoxLayout()
            row.addWidget(QLabel(label_text))
            edit = QLineEdit()
            setattr(self, attr_name, edit)
            row.addWidget(edit, 1)
            button = QPushButton(button_text)
            button.clicked.connect(lambda _checked=False, line_edit=edit: self._browse_folder_into(line_edit))
            row.addWidget(button)
            repo_layout.addLayout(row)

        add_path_row("User repo root", "user_repo_root_edit")
        add_path_row("Wheel repository", "wheel_repo_path_edit")

        origin_row = QHBoxLayout()
        origin_row.addWidget(QLabel("Remote origin URL"))
        self.remote_origin_url_edit = QLineEdit()
        origin_row.addWidget(self.remote_origin_url_edit, 1)
        btn_detect_origin = QPushButton("Detect")
        btn_detect_origin.clicked.connect(lambda: self._maybe_autofill_repo_fields(persist=True))
        origin_row.addWidget(btn_detect_origin)
        repo_layout.addLayout(origin_row)

        buttons_row = QHBoxLayout()
        btn_reload_repo_settings = QPushButton("Reload")
        btn_reload_repo_settings.clicked.connect(self._load_repo_settings)
        buttons_row.addWidget(btn_reload_repo_settings)

        btn_save_repo_settings = QPushButton("Save")
        btn_save_repo_settings.clicked.connect(self._save_repo_settings)
        buttons_row.addWidget(btn_save_repo_settings)
        buttons_row.addStretch()
        repo_layout.addLayout(buttons_row)

        layout.addWidget(repo_group)

        preflight_group = QGroupBox("Preflight / Package Capture")
        preflight_layout = QVBoxLayout(preflight_group)

        self.preflight_capture_packages_checkbox = QCheckBox(
            "Capture installed packages after VENV preflight"
        )
        self.preflight_capture_packages_checkbox.stateChanged.connect(
            lambda _state: self._save_repo_settings()
        )
        preflight_layout.addWidget(self.preflight_capture_packages_checkbox)

        self.preflight_packages_write_full_checkbox = QCheckBox(
            "Write full package snapshots in addition to timeline deltas"
        )
        self.preflight_packages_write_full_checkbox.stateChanged.connect(
            lambda _state: self._save_repo_settings()
        )
        preflight_layout.addWidget(self.preflight_packages_write_full_checkbox)

        self.wheel_backfill_enabled_checkbox = QCheckBox(
            "Enable automatic wheel backfill for missing packages"
        )
        self.wheel_backfill_enabled_checkbox.stateChanged.connect(self._on_toggle_wheel_backfill)
        preflight_layout.addWidget(self.wheel_backfill_enabled_checkbox)

        hint = QLabel(
            "These options are used by the dashboard preflight and package-history workflow. "
            "Wheel backfill is gated by a one-time confirmation."
        )
        hint.setWordWrap(True)
        preflight_layout.addWidget(hint)

        layout.addWidget(preflight_group)
        layout.addStretch()

        return widget

    def _browse_validation_workspace(self) -> None:
        # Legacy entrypoint: treat as “Add/Select project”.
        self._add_project_via_dialog()

    def _browse_project_root(self) -> None:
        # Legacy entrypoint: treat as “Add/Select project”.
        self._add_project_via_dialog()

    def _selected_project_root(self) -> Path | None:
        return self._get_active_project_root()

    def _on_active_project_changed(self, index: int) -> None:
        if index < 0:
            return
        if not hasattr(self, "project_selector_combo"):
            return
        root_str = self.project_selector_combo.currentData()
        if not isinstance(root_str, str) or not root_str:
            return
        try:
            root = Path(root_str).expanduser().resolve()
        except Exception:
            return
        if not root.exists() or not root.is_dir():
            QMessageBox.warning(self, "Missing Folder", f"Folder does not exist: {root}")
            return
        self._set_active_project_root(root)


    def _show_about_dialog(self) -> None:
        """Display About dialog with logo and version information."""
        from PySide6.QtGui import QPixmap

        runtime_version = get_runtime_version()
        
        msg = QMessageBox(self)
        msg.setWindowTitle("About ManifestGuard")
        
        # Load logo if available
        logo_path = Path(__file__).parent.parent.parent / "docs" / "images" / "logo.png"
        if logo_path.exists():
            pixmap = QPixmap(str(logo_path))
            # Scale down to reasonable size (max 200px wide)
            if pixmap.width() > 200:
                pixmap = pixmap.scaledToWidth(200, Qt.TransformationMode.SmoothTransformation)
            msg.setIconPixmap(pixmap)
        else:
            msg.setIcon(QMessageBox.Icon.Information)
        
        msg.setText(
            f"<h2>ManifestGuard</h2>"
            f"<p><b>Version:</b> {runtime_version}</p>"
            f"<p><b>Author:</b> Nejat Philip Eryigit</p>"
            f"<p><b>Website:</b> <a href='https://www.ready-4-it.com'>www.ready-4-it.com</a></p>"
            f"<p><b>Repository:</b> <a href='https://github.com/timejunky/r4it_manifest_guard_py'>GitHub</a></p>"
            f"<p>Python Package Manifest Validation Tool</p>"
        )
        msg.setTextFormat(Qt.TextFormat.RichText)
        msg.setStandardButtons(QMessageBox.StandardButton.Ok)
        msg.exec()


def main():
    """Launch ManifestGuard GUI."""
    app = QApplication(sys.argv)
    window = ManifestGuardGUI()
    window.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
