"""LicensingClient activation-status mixin — device fingerprint and activation lifecycle."""

from __future__ import annotations

import hashlib
import platform
import re
import time
from typing import Any

from packaging.version import InvalidVersion, Version

from . import validator as entitlement_validator
from .client_models import LicenseStatus, LicenseStatusCode


class _LicensingClientActivationMixin:
    """Mixin: device fingerprint, activation storage, and status assessment.

    Expects the host class to provide:
        self._get_or_create_device_salt() -> str          [from persistence mixin]
        self._get_persisted_activation() -> dict | None   [from persistence mixin]
        self._set_persisted_activation(obj)               [from persistence mixin]
        self._delete_persisted_activation()               [from persistence mixin]
        self._set_persisted_token(token)                  [from persistence mixin]
        self.verify_token(token) -> LicenseStatus         [in LicensingClient]
    """

    def get_device_hash(self) -> str:
        """Return a stable, salted SHA-256 device fingerprint (64 hex chars).

        Compatible with CRM CLI ``--device-hash`` parameter.
        Combines hostname, OS platform, and a per-user salt stored in
        ``~/.manifestguard/device.salt`` (created on first call).
        """
        salt = self._get_or_create_device_salt()
        components = "|".join([
            platform.node(),      # hostname
            platform.system(),    # OS name (Windows / Linux / Darwin)
            platform.machine(),   # CPU architecture
            salt,
        ])
        return hashlib.sha256(components.encode("utf-8")).hexdigest()

    def _device_hash_mismatch_status(
        self, activation_obj: dict[str, Any]
    ) -> LicenseStatus | None:
        expected_hash = str(activation_obj.get("device_hash") or "").strip()
        if not expected_hash:
            return None

        current_hash = self.get_device_hash()
        if expected_hash == current_hash:
            return None

        return LicenseStatus(
            code=LicenseStatusCode.DEVICE_LIMIT,
            message="Activation object is bound to a different device",
            payload=activation_obj,
            warnings=[],
        )

    def _safe_version(self, raw: Any) -> Version | None:
        text = str(raw or "").strip()
        if not text:
            return None

        match = re.search(r"\d+(?:\.\d+){0,3}", text)
        if not match:
            return None

        try:
            return Version(match.group(0))
        except InvalidVersion:
            return None

    def _current_runtime_version(self) -> Version | None:
        try:
            from manifestguard import get_runtime_version

            return self._safe_version(get_runtime_version())
        except Exception:
            return None

    def _is_last_eligible_version_available(self, activation_obj: dict[str, Any]) -> bool:
        current = self._current_runtime_version()
        last_eligible = self._safe_version(activation_obj.get("lastEligibleVersion"))
        if current is None or last_eligible is None:
            return False
        return current <= last_eligible

    def _merge_activation_payload(
        self,
        activation_obj: dict[str, Any],
        token_payload: dict[str, Any] | None,
    ) -> dict[str, Any]:
        payload = dict(token_payload or {})

        if activation_obj.get("licenseId") and not payload.get("sub"):
            payload["sub"] = activation_obj["licenseId"]
        if activation_obj.get("plan") and not payload.get("tier"):
            payload["tier"] = activation_obj["plan"]
        if activation_obj.get("tier"):
            payload["tier"] = activation_obj["tier"]
        if isinstance(activation_obj.get("features"), dict):
            payload["features"] = activation_obj["features"]
        if activation_obj.get("maxActivations") is not None:
            payload["maxActivations"] = activation_obj["maxActivations"]
        if activation_obj.get("lastEligibleVersion"):
            payload["lastEligibleVersion"] = activation_obj["lastEligibleVersion"]
        if activation_obj.get("updateEntitlementUntil") is not None:
            payload["updateEntitlementUntil"] = activation_obj["updateEntitlementUntil"]

        return payload

    def _status_from_activation(self, activation_obj: dict[str, Any]) -> LicenseStatus:
        activation_key = str(
            activation_obj.get("activation_key") or activation_obj.get("token") or ""
        ).strip()
        token_payload: dict[str, Any] | None = None
        trial = False

        if activation_key:
            token_status = self.verify_token(activation_key)
            if token_status.code in {
                LicenseStatusCode.INVALID_FORMAT,
                LicenseStatusCode.BAD_SIGNATURE,
                LicenseStatusCode.PRODUCT_MISMATCH,
                LicenseStatusCode.TIME_WINDOW,
                LicenseStatusCode.EXPIRED,
                LicenseStatusCode.TIME_ROLLBACK_BLOCKED,
                LicenseStatusCode.MAX_DEVICES_EXCEEDED,
                LicenseStatusCode.DEVICE_LIMIT,
                LicenseStatusCode.RENEWAL_BLOCKED,
            }:
                return token_status
            token_payload = token_status.payload
            trial = token_status.trial

        device_hash_status = self._device_hash_mismatch_status(activation_obj)
        if device_hash_status is not None:
            device_hash_status.trial = trial
            return device_hash_status

        payload = self._merge_activation_payload(activation_obj, token_payload)

        try:
            expiry = entitlement_validator._to_epoch_seconds(
                activation_obj.get("updateEntitlementUntil")
            )
        except ValueError:
            expiry = 0

        baseline = activation_obj.get("_baseline", {})
        if expiry and isinstance(baseline, dict):
            try:
                cap = int(baseline.get("max_expires_at", 0) or 0)
            except Exception:
                cap = 0
            if cap > 0:
                expiry = min(expiry, cap)

        if expiry:
            now = int(time.time())
            skew = entitlement_validator.DEFAULT_SKEW_SECONDS
            if now > (expiry + skew):
                if self._is_last_eligible_version_available(activation_obj):
                    return LicenseStatus(
                        code=LicenseStatusCode.UPDATE_ENTITLEMENT_EXPIRED,
                        message=(
                            "Update entitlement expired. Current installation is still within "
                            "the last eligible version window."
                        ),
                        payload=payload,
                        warnings=[],
                        trial=trial,
                        expires_at=expiry,
                    )
                return LicenseStatus(
                    code=LicenseStatusCode.UPDATE_ENTITLEMENT_EXPIRED,
                    message=(
                        "Update entitlement expired and the installed version is newer than "
                        "the last eligible version."
                    ),
                    payload=payload,
                    warnings=[],
                    trial=trial,
                    expires_at=expiry,
                )

        return LicenseStatus(
            code=LicenseStatusCode.OK,
            message="Activation object valid",
            payload=payload,
            warnings=[],
            trial=trial,
            expires_at=expiry or None,
        )

    def _activation_allows_paid_features(self, activation_obj: dict[str, Any]) -> bool:
        if self.is_update_entitled():
            return True
        return self._is_last_eligible_version_available(activation_obj)

    def is_update_entitled(self, now: int | None = None, skew_seconds: int = entitlement_validator.DEFAULT_SKEW_SECONDS) -> bool:
        act = self.get_activation()
        if not act:
            return False
        status = self._status_from_activation(act)
        if status.code not in {
            LicenseStatusCode.OK,
            LicenseStatusCode.UPDATE_ENTITLEMENT_EXPIRED,
        }:
            return False
        return entitlement_validator.is_update_entitled(act, now=now, skew_seconds=skew_seconds)

    def store_activation(self, activation_obj: dict[str, Any]) -> LicenseStatus:
        """Persist activation object and establish baseline per ADR-0001/ADR-0011.

        activation_obj: expected fields include `activation_key` and optional
        `updateEntitlementUntil`, `maxActivations`, `licenseId` / `sub`, `lastEligibleVersion`.
        """
        now = int(time.time())
        activation_key = str(
            activation_obj.get("activation_key") or activation_obj.get("token") or ""
        ).strip()

        if activation_key:
            token_status = self.verify_token(activation_key)
            if token_status.code in {
                LicenseStatusCode.INVALID_FORMAT,
                LicenseStatusCode.BAD_SIGNATURE,
                LicenseStatusCode.PRODUCT_MISMATCH,
            }:
                return token_status

        device_hash_status = self._device_hash_mismatch_status(activation_obj)
        if device_hash_status is not None:
            return device_hash_status

        if activation_key:
            self._set_persisted_token(activation_key)

        existing = self._get_persisted_activation()
        # If first activation for this licenseId, set baseline
        license_id = activation_obj.get("licenseId") or activation_obj.get("sub")

        if existing is None:
            # establish baseline
            baseline_first = now
            ue = activation_obj.get("updateEntitlementUntil")
            try:
                ue_epoch = entitlement_validator._to_epoch_seconds(ue) if ue is not None else None
            except Exception:
                ue_epoch = None

            if ue_epoch is None:
                baseline_max = baseline_first + 365 * 24 * 3600
            else:
                baseline_max = min(ue_epoch, baseline_first + 365 * 24 * 3600)

            activation_obj.setdefault("_baseline", {})
            activation_obj["_baseline"]["first_activation"] = baseline_first
            activation_obj["_baseline"]["max_expires_at"] = baseline_max
            self._set_persisted_activation(activation_obj)
            return LicenseStatus(code=LicenseStatusCode.OK, message="Activation stored", payload=activation_obj, expires_at=baseline_max)

        # If existing exists, enforce baseline cap per licenseId
        existing_baseline = existing.get("_baseline", {})
        if existing_baseline:
            # If new activation attempts to extend beyond baseline cap, reject
            try:
                ue_epoch = entitlement_validator._to_epoch_seconds(activation_obj.get("updateEntitlementUntil")) if activation_obj.get("updateEntitlementUntil") is not None else None
            except Exception:
                ue_epoch = None

            cap = int(existing_baseline.get("max_expires_at", 0))
            if ue_epoch is not None and ue_epoch > cap:
                return LicenseStatus(code=LicenseStatusCode.RENEWAL_BLOCKED, message="Activation would exceed baseline cap", payload=activation_obj)

        # Replace stored activation
        # carry forward baseline if present
        if existing_baseline:
            activation_obj.setdefault("_baseline", {})
            activation_obj["_baseline"]["first_activation"] = existing_baseline.get("first_activation")
            activation_obj["_baseline"]["max_expires_at"] = existing_baseline.get("max_expires_at")

        self._set_persisted_activation(activation_obj)
        effective_expiry = None
        try:
            ue_epoch = entitlement_validator._to_epoch_seconds(activation_obj.get("updateEntitlementUntil")) if activation_obj.get("updateEntitlementUntil") is not None else None
            if ue_epoch is not None:
                if activation_obj.get("_baseline"):
                    effective_expiry = min(ue_epoch, int(activation_obj["_baseline"].get("max_expires_at", ue_epoch)))
                else:
                    effective_expiry = ue_epoch
        except Exception:
            effective_expiry = None

        return LicenseStatus(code=LicenseStatusCode.OK, message="Activation stored", payload=activation_obj, expires_at=effective_expiry)

    def get_activation(self) -> dict[str, Any] | None:
        """Return persisted activation object if present."""
        # Prefer environment override? Not for activation objects - always persisted.
        return self._get_persisted_activation()

    def remove_activation(self) -> None:
        self._delete_persisted_activation()
