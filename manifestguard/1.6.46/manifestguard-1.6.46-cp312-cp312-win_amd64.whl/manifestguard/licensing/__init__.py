"""ManifestGuard Licensing Module

Implements license verification for ManifestGuard Python package.
Based on Ed25519 signature verification (SCVS model).

Tiers:
- Community: Free (basic validation, 20 rules)
- Pro: $299/year (custom rules, CI/CD, SBOM, max 2 devices)
- Team: $799/year (dashboard, SSO, unlimited devices)
- Enterprise: $12k/year (self-hosted, SLA)
"""

from .client import (
    DeviceActivation,
    LicenseStatus,
    LicenseStatusCode,
    LicensingClient,
)
from .feature_limits import FEATURE_LIMITS

__all__ = [
    "FEATURE_LIMITS",
    "DeviceActivation",
    "LicenseStatus",
    "LicenseStatusCode",
    "LicensingClient",
]
