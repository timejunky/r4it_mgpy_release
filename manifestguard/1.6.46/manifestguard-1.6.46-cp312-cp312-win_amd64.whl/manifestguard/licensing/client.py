"""ManifestGuard License Client (Step 1.3 - GREEN Phase)

Ed25519 signature-based license verification.
Singleton pattern ensures only one client instance exists.
"""

from __future__ import annotations

import time
from pathlib import Path
from typing import Any, ClassVar

from packaging.version import InvalidVersion, Version

from . import validator as entitlement_validator

try:
    import nacl.encoding
    import nacl.exceptions
    import nacl.signing

    NACL_AVAILABLE = True
except ImportError:
    NACL_AVAILABLE = False

from .jwt_utils import parse_token_payload, validate_token_expiry, verify_token_signature

try:
    import keyring

    KEYRING_AVAILABLE = True
except ImportError:
    KEYRING_AVAILABLE = False

# Re-export models so existing callers can still import from this module.
from .client_models import (  # noqa: F401
    DeviceActivation,
    LicenseStatus,
    LicenseStatusCode,
    _canonicalize_rfc8785,
)
from .client_persistence_mixin import _LicensingClientPersistenceMixin
from .client_activation_mixin import _LicensingClientActivationMixin
from .client_features_mixin import _LicensingClientFeaturesMixin


class LicensingClient(
    _LicensingClientPersistenceMixin,
    _LicensingClientActivationMixin,
    _LicensingClientFeaturesMixin,
):
    """Singleton License Client for ManifestGuard

    Usage:
        client = LicensingClient.get_instance()
        status = client.assess_status()
    """

    _instance: LicensingClient | None = None

    # Ed25519 Public Keys (for signature verification)
    # Key rotation: Add new keys, keep old keys for grace period
    PUBLIC_KEYS: ClassVar[dict[str, str]] = {
        "2025-11-0001": "o7y9E0nFjYX4JpscVt4dk+7crW1eQV3hCweLuVU2u1s=",  # Product dev key
        "crm-mgpy-dev-0001": "kz7/OrzrFtj8qJdR1o1Fjb/uXJZQ3i/BsxEhoyV/hvI=",  # CRM dev bridge key
        "dev-v1": "kz7/OrzrFtj8qJdR1o1Fjb/uXJZQ3i/BsxEhoyV/hvI=",  # Legacy CRM dev bridge key id
    }

    def __init__(self):
        """Private constructor - use get_instance()"""
        if LicensingClient._instance is not None:
            raise RuntimeError("Use LicensingClient.get_instance() instead")

        self.product_id = "manifestguard-python"
        self.app_name = "manifestguard"
        self._scope_root: Path | None = None

    @property
    def scope_root(self) -> Path | None:
        """Per-project scope root for isolated license storage.

        When set, ``_license_token_file_path()`` returns
        ``scope_root / ".mgpy" / "license.enc"`` instead of the global
        ``~/.manifestguard/license.token`` path. Useful for multi-project
        desktop workflows where each workspace may carry its own license token.
        """
        return self._scope_root

    @scope_root.setter
    def scope_root(self, value: "Path | str | None") -> None:
        self._scope_root = Path(value).resolve() if value is not None else None

    @classmethod
    def get_instance(cls) -> "LicensingClient":
        """Get singleton instance

        Returns:
            LicensingClient instance

        """
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    def _accepted_product_ids(self) -> set[str]:
        return {self.product_id, "manifestguard-py", "mgpy"}

    def _license_token_file_path(self) -> Path:
        # When scope_root is set, use per-project token path (.mgpy/license.enc).
        # Otherwise fall back to the user-wide path (~/.manifestguard/license.token).
        if self._scope_root is not None:
            return self._scope_root / ".mgpy" / "license.enc"
        return Path.home() / ".manifestguard" / "license.token"

    def _activation_file_path(self) -> Path:
        # Per-user activation object (persisted JSON)
        return Path.home() / ".manifestguard" / "activation.json"

    def _device_salt_file_path(self) -> Path:
        return Path.home() / ".manifestguard" / "device.salt"

    def _parse_token(self, token: str) -> dict[str, Any]:
        """Parse R4IT.payload.signature token — delegates to jwt_utils."""
        return parse_token_payload(token)

    def _verify_signature(self, token: str, public_key_b64: str) -> bool:
        """Verify Ed25519 signature — delegates to jwt_utils."""
        return verify_token_signature(token, public_key_b64)

    def _validate_time_window(
        self,
        payload: dict[str, Any],
    ) -> tuple[bool, LicenseStatusCode | None, str]:
        """Validate license time window (iat <= now <= exp).

        For perpetual licenses (maintenance_until present):
        - When now > exp but now < maintenance_until: returns UPDATE_ENTITLEMENT_EXPIRED
          (extension runs but update entitlement has lapsed).
        - When now > maintenance_until as well: returns EXPIRED.

        Args:
            payload: License token payload

        Returns:
            Tuple of (is_valid, status_code, message)
            - is_valid: True if time window is valid
            - status_code: LicenseStatusCode if invalid
            - message: Error message if invalid

        """
        now = int(time.time())
        iat = payload.get("iat", 0)
        exp = payload.get("exp", 0)

        if now < iat:
            return False, LicenseStatusCode.TIME_WINDOW, f"License not yet valid (starts at {iat})"

        if now > exp:
            maintenance_until = payload.get("maintenance_until")
            if maintenance_until is not None:
                try:
                    from manifestguard.licensing import validator as entitlement_validator
                    maintenance_epoch = entitlement_validator._to_epoch_seconds(maintenance_until)
                except Exception:
                    maintenance_epoch = int(maintenance_until) if isinstance(maintenance_until, (int, float)) else 0
                if maintenance_epoch > 0 and now < maintenance_epoch:
                    # Perpetual license: update entitlement lapsed, but product still runs
                    return False, LicenseStatusCode.UPDATE_ENTITLEMENT_EXPIRED, (
                        f"Update entitlement expired at {exp}. "
                        f"Maintenance window ends at {maintenance_epoch}. "
                        "Renew to restore updates."
                    )
            return False, LicenseStatusCode.EXPIRED, f"License expired at {exp}"

        return True, None, ""

    def verify_token(self, token: str) -> LicenseStatus:
        """Verify license token (Step 2.2 - GREEN Phase)

        Validates:
        - Token format (R4IT.payload.signature)
        - Signature verification (Ed25519)
        - Time window (iat <= now <= exp)
        - Product ID match

        Args:
            token: License token string

        Returns:
            LicenseStatus with validation result

        """
        # Step 1: Parse token format
        try:
            payload = self._parse_token(token)
        except ValueError as e:
            return LicenseStatus(
                code=LicenseStatusCode.INVALID_FORMAT,
                message=f"Invalid token format: {e}",
                payload=None,
            )

        # Step 2: Get key_id and public key
        # Note: Generator uses "kid" (key ID), not "key_id"
        key_id = payload.get("kid") or payload.get("key_id")
        if not key_id or key_id not in self.PUBLIC_KEYS:
            return LicenseStatus(
                code=LicenseStatusCode.BAD_SIGNATURE,
                message=f"Unknown key ID: {key_id}",
                payload=payload,
                warnings=[],
            )

        public_key_b64 = self.PUBLIC_KEYS[key_id]

        # Step 3: Verify signature
        if not self._verify_signature(token, public_key_b64):
            return LicenseStatus(
                code=LicenseStatusCode.BAD_SIGNATURE,
                message="Signature verification failed",
                payload=payload,
                warnings=[],
            )

        # Step 4: Validate product ID
        product_id = str(payload.get("product_id") or payload.get("product") or "").strip().lower()
        if product_id not in self._accepted_product_ids():
            return LicenseStatus(
                code=LicenseStatusCode.PRODUCT_MISMATCH,
                message=f"Product mismatch: expected a ManifestGuard token, got '{product_id}'",
                payload=payload,
                warnings=[],
            )

        # Step 5: Validate time window (refactored)
        is_valid, error_code, error_message = self._validate_time_window(payload)
        if not is_valid:
            exp = payload.get("exp", 0)
            # error_code should never be None here, but provide fallback
            status_code = error_code if error_code is not None else LicenseStatusCode.INVALID_FORMAT
            return LicenseStatus(
                code=status_code,
                message=error_message,
                payload=payload,
                warnings=[],
                expires_at=exp,
            )

        # Step 6: Success - return OK status
        trial = payload.get("trial", False)
        exp = payload.get("exp", 0)

        return LicenseStatus(
            code=LicenseStatusCode.OK,
            message="License valid",
            payload=payload,
            warnings=[],
            trial=trial,
            expires_at=exp,
        )

    def get_token(self) -> str | None:
        """Get stored license token from keyring (Week 2 - Step 3)

        Returns:
            Token string if stored, None otherwise

        """
        env_token = self._get_env_token()
        if env_token:
            return env_token
        return self._get_persisted_token()

    def remove_token(self) -> None:
        """Remove stored license token from keyring (Week 2 - Step 5)

        Used for license deactivation.
        """
        self._delete_persisted_token()

    def get_status(self) -> LicenseStatus:
        """Best-effort current license status.

        Never raises; callers should handle MISSING/INVALID codes.
        """
        try:
            activation = self.get_activation()
        except Exception:
            activation = None
        if activation:
            return self._status_from_activation(activation)

        try:
            token = self.get_token()
        except Exception:
            token = None
        if not token:
            return LicenseStatus(
                code=LicenseStatusCode.MISSING,
                message="No license activated",
                payload=None,
                warnings=[],
                trial=False,
                expires_at=None,
            )
        return self.verify_token(token)

    def activate(self, token: str) -> bool:
        """Activate a license token (store it if valid)."""
        status = self.store_token(token)
        return status.code == LicenseStatusCode.OK

    def deactivate(self) -> None:
        """Deactivate current license (remove persisted token)."""
        self.remove_token()
        self.remove_activation()
