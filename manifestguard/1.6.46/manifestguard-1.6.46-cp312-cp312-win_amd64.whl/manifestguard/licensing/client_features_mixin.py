"""LicensingClient features mixin — renewal policy, token storage, and feature limits."""

from __future__ import annotations

import time as _time
from typing import Any

from .client_models import LicenseStatus, LicenseStatusCode
from .feature_limits import FEATURE_LIMITS
from .jwt_utils import validate_token_expiry


class _LicensingClientFeaturesMixin:
    """Mixin: renewal policy, store_token, tier normalization, and feature limit resolution.

    Expects the host class to provide:
        self.verify_token(token) -> LicenseStatus           [in LicensingClient]
        self.get_token() -> str | None                      [in LicensingClient]
        self.get_device_hash() -> str                       [from activation mixin]
        self.get_activation() -> dict | None                [from activation mixin]
        self._status_from_activation(obj) -> LicenseStatus  [from activation mixin]
        self._activation_allows_paid_features(obj) -> bool  [from activation mixin]
        self._get_persisted_token() -> str | None           [from persistence mixin]
        self._set_persisted_token(token)                    [from persistence mixin]
    """

    def _check_renewal_policy(
        self,
        token: str,
        new_payload: dict[str, Any],
        new_status: LicenseStatus,
        existing_token: str,
    ) -> LicenseStatus | None:
        """Check renewal rules against an existing persisted token.

        Returns a LicenseStatus if the operation is complete (blocked or already
        stored for the "replace invalid" path).  Returns None when the renewal
        check passes — the caller is then responsible for persisting the token.

        Renewal rules:
        - Duplicate token: BLOCK
        - Existing token invalid/unparseable: replace silently + return OK
        - Different order (sub): BLOCK (with downgrade hint when applicable)
        - Same order + equal-or-earlier expiration: BLOCK
        - Same order + later expiration: PASS (return None)
        """
        new_order = new_payload.get("sub")
        new_exp = int(new_payload.get("exp", 0))

        def _fmt_exp(ts: Any) -> str:
            try:
                tts = int(ts)
                if tts <= 0:
                    return "unknown"
                return _time.strftime("%Y-%m-%d", _time.localtime(tts))
            except Exception:
                return "unknown"

        def _is_trial(payload: dict[str, Any] | None) -> bool:
            if not payload:
                return False
            if bool(payload.get("trial")):
                return True
            plan = str(payload.get("plan") or "").strip().lower()
            tier = str(payload.get("tier") or "").strip().lower()
            return plan == "trial" or tier == "trial"

        # Block duplicate token.
        if existing_token == token:
            return LicenseStatus(
                code=LicenseStatusCode.RENEWAL_BLOCKED,
                message="Duplicate token - already activated",
                payload=new_payload,
                warnings=[],
            )

        # Parse existing token; replace silently if it has become invalid.
        existing_status = self.verify_token(existing_token)
        if existing_status.code != LicenseStatusCode.OK:
            self._set_persisted_token(token)
            return LicenseStatus(
                code=LicenseStatusCode.OK,
                message="License stored successfully (replaced invalid)",
                payload=new_payload,
                warnings=[],
                trial=new_status.trial,
                expires_at=new_exp,
            )

        existing_payload = existing_status.payload
        if existing_payload is None:
            self._set_persisted_token(token)
            return LicenseStatus(code=LicenseStatusCode.OK, message="License activated")

        existing_order = existing_payload.get("sub")
        existing_exp = int(existing_payload.get("exp", 0))

        # Block different order/subscription.
        if new_order != existing_order:
            now = int(_time.time())
            try:
                existing_active = existing_exp > now
            except Exception:
                existing_active = False

            new_is_trial = _is_trial(new_payload)
            existing_is_trial = _is_trial(existing_payload)
            existing_plan = str(
                existing_payload.get("plan") or existing_payload.get("tier") or ""
            ).strip().lower()
            new_plan = str(new_payload.get("plan") or new_payload.get("tier") or "").strip().lower()

            if existing_active and not existing_is_trial and new_is_trial:
                return LicenseStatus(
                    code=LicenseStatusCode.RENEWAL_BLOCKED,
                    message=(
                        "Downgrade blocked: an active license is already stored and valid until "
                        f"{_fmt_exp(existing_exp)} (plan: {existing_plan or 'unknown'}). "
                        "A trial token cannot replace an active paid license. "
                        "If you really want to switch, run 'manifestguard license deactivate' first. "
                        f"(existing sub: {existing_order}, new sub: {new_order}; new plan: {new_plan or 'trial'})"
                    ),
                    payload=new_payload,
                    warnings=[],
                )

            return LicenseStatus(
                code=LicenseStatusCode.RENEWAL_BLOCKED,
                message=(
                    "Different order/subscription - not a renewal "
                    f"(existing sub: {existing_order}, new sub: {new_order})"
                ),
                payload=new_payload,
                warnings=[],
            )

        # Block downgrade (equal or earlier expiration).
        if new_exp <= existing_exp:
            return LicenseStatus(
                code=LicenseStatusCode.RENEWAL_BLOCKED,
                message=(
                    "Downgrade blocked: new expiration is not later than the existing license "
                    f"(existing: {_fmt_exp(existing_exp)}, new: {_fmt_exp(new_exp)})"
                ),
                payload=new_payload,
                warnings=[],
            )

        # Renewal check passed: caller stores and returns OK.
        return None

    def store_token(self, token: str) -> LicenseStatus:
        """Store license token with renewal validation.

        Renewal rules:
        - Same order (sub) + later expiration: ALLOW
        - Duplicate token: BLOCK
        - Different order: BLOCK
        - Earlier expiration: BLOCK
        - Invalid token: BLOCK
        - Device-hash mismatch in token payload: BLOCK
        """
        new_status = self.verify_token(token)
        if new_status.code != LicenseStatusCode.OK:
            return new_status

        new_payload = new_status.payload
        if new_payload is None:
            return LicenseStatus(
                code=LicenseStatusCode.INVALID_FORMAT, message="Token payload is missing"
            )

        new_exp = int(new_payload.get("exp", 0))

        # Reject tokens bound to a different device.
        token_device_hash = new_payload.get("device_hash")
        if token_device_hash:
            if token_device_hash != self.get_device_hash():
                return LicenseStatus(
                    code=LicenseStatusCode.DEVICE_LIMIT,
                    message="Token was issued for a different device",
                )

        existing_token = self._get_persisted_token()

        if existing_token is None:
            self._set_persisted_token(token)
            return LicenseStatus(
                code=LicenseStatusCode.OK,
                message="License stored successfully",
                payload=new_payload,
                warnings=[],
                trial=new_status.trial,
                expires_at=new_exp,
            )

        policy_result = self._check_renewal_policy(token, new_payload, new_status, existing_token)
        if policy_result is not None:
            return policy_result

        # Renewal allowed: same order + later expiration.
        self._set_persisted_token(token)
        return LicenseStatus(
            code=LicenseStatusCode.OK,
            message="License renewed successfully",
            payload=new_payload,
            warnings=[],
            trial=new_status.trial,
            expires_at=new_exp,
        )

    def _normalized_tier(self, raw_tier: Any) -> str:
        from .tier_utils import normalize_tier
        return normalize_tier(raw_tier)

    def _resolve_feature_base(self) -> dict[str, Any]:
        """Resolve the effective feature dict for the current license state.

        Returns the merged feature limits for the active tier.  Activation-level
        feature overrides (explicit ``features`` dict) are merged via
        :meth:`_merge_activation_features`.  Falls back to ``community`` for any
        invalid / missing credential.
        """
        activation = self.get_activation()
        if activation:
            st = self._status_from_activation(activation)
            if st.code not in {
                LicenseStatusCode.OK,
                LicenseStatusCode.UPDATE_ENTITLEMENT_EXPIRED,
            }:
                return FEATURE_LIMITS["community"]
            if (
                isinstance(activation.get("features"), dict)
                and self._activation_allows_paid_features(activation)
            ):
                return self._merge_activation_features(activation)
            tier = self._normalized_tier(activation.get("tier") or activation.get("plan"))
            return FEATURE_LIMITS.get(tier, FEATURE_LIMITS["community"])

        token = self.get_token()
        if token is None:
            return FEATURE_LIMITS["community"]
        st = self.verify_token(token)
        if st.code != LicenseStatusCode.OK or st.payload is None:
            return FEATURE_LIMITS["community"]
        if not validate_token_expiry(st.payload):
            return FEATURE_LIMITS["community"]
        tier = self._normalized_tier(
            st.payload.get("tier") or st.payload.get("plan") or "community"
        )
        return FEATURE_LIMITS.get(tier, FEATURE_LIMITS["community"])

    def _merge_activation_features(self, activation: dict[str, Any]) -> dict[str, Any]:
        """Merge activation payload into tier-baseline feature limits.

        Activation features override tier defaults; `maxActivations` overrides
        `max_devices`.  Returns a new dict (does not mutate either source).
        """
        tier = self._normalized_tier(activation.get("tier") or activation.get("plan"))
        merged = dict(FEATURE_LIMITS.get(tier, FEATURE_LIMITS["community"]))
        merged.update(activation.get("features") or {})
        if activation.get("maxActivations") is not None:
            merged["max_devices"] = activation["maxActivations"]
        return merged

    def has_feature(self, feature: str) -> bool:
        """Check if current license has access to a feature

        Args:
            feature: Feature name to check (e.g., "dashboard", "self_hosted")

        Returns:
            True if feature is available, False otherwise

        """
        value = self._resolve_feature_base().get(feature, False)
        return bool(value) if isinstance(value, (int, bool)) else False

    def get_feature_limits(self) -> dict[str, Any]:
        """Get feature limits for current license."""
        return self._resolve_feature_base()
