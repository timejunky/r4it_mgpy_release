"""LicensingClient persistence mixin — file/keyring I/O helpers."""

from __future__ import annotations

import contextlib
import json
import os
import secrets
from typing import Any

try:
    import keyring

    KEYRING_AVAILABLE = True
except ImportError:
    KEYRING_AVAILABLE = False


class _LicensingClientPersistenceMixin:
    """Mixin: device salt, token file, and activation file I/O.

    Expects the host class to provide:
        self.app_name: str
        self._device_salt_file_path() -> Path
        self._activation_file_path() -> Path
        self._license_token_file_path() -> Path
        self._parse_token(token: str) -> dict
        self._accepted_product_ids() -> set
    """

    def _get_or_create_device_salt(self) -> str:
        path = self._device_salt_file_path()
        path.parent.mkdir(parents=True, exist_ok=True)
        try:
            if path.exists():
                salt = path.read_text(encoding="utf-8").strip()
                if salt:
                    return salt
        except Exception:
            pass
        salt = secrets.token_hex(16)
        try:
            tmp = path.with_suffix(path.suffix + ".tmp")
            tmp.write_text(salt, encoding="utf-8")
            tmp.replace(path)
        except Exception:
            pass
        return salt

    def _get_persisted_activation(self) -> dict[str, Any] | None:
        if KEYRING_AVAILABLE:
            try:
                raw = keyring.get_password(self.app_name, "activation")
                if raw:
                    if (
                        os.getenv("MANIFESTGUARD_LICENSE_NOFILE", "").strip().lower()
                        != "true"
                    ):
                        path = self._activation_file_path()
                        if not path.exists():
                            with contextlib.suppress(Exception):
                                path.parent.mkdir(parents=True, exist_ok=True)
                                path.write_text(raw, encoding="utf-8")
                    return json.loads(raw)
            except Exception:
                pass

        path = self._activation_file_path()
        try:
            if not path.exists():
                return None
            text = path.read_text(encoding="utf-8").strip()
            if not text:
                return None
            return json.loads(text)
        except Exception:
            return None

    def _set_persisted_activation(self, activation_obj: dict[str, Any]) -> None:
        raw = json.dumps(activation_obj, ensure_ascii=False)
        if KEYRING_AVAILABLE:
            with contextlib.suppress(Exception):
                keyring.set_password(self.app_name, "activation", raw)

        if os.getenv("MANIFESTGUARD_LICENSE_NOFILE", "").strip().lower() == "true":
            return

        path = self._activation_file_path()
        path.parent.mkdir(parents=True, exist_ok=True)
        tmp = path.with_suffix(path.suffix + ".tmp")
        tmp.write_text(raw, encoding="utf-8")
        tmp.replace(path)

    def _delete_persisted_activation(self) -> None:
        if KEYRING_AVAILABLE:
            with contextlib.suppress(Exception):
                keyring.delete_password(self.app_name, "activation")

        path = self._activation_file_path()
        with contextlib.suppress(Exception):
            if path.exists():
                path.unlink()

    def _get_env_token(self) -> str | None:
        explicit_token = os.getenv("MANIFESTGUARD_ACTIVATION_KEY_PY", "").strip()
        if explicit_token:
            return explicit_token

        for key in (
            "MANIFESTGUARD_ACTIVATION_KEY",
            "MANIFESTGUARD_LICENSE_TOKEN",
            "MANIFESTGUARD_LICENSE",
        ):
            value = os.getenv(key, "").strip()
            if value and self._is_compatible_env_override_token(value):
                return value
        return None

    def _is_compatible_env_override_token(self, token: str) -> bool:
        try:
            payload = self._parse_token(token)
        except ValueError:
            return False

        accepted_products = self._accepted_product_ids()
        product_id = str(payload.get("product_id", "")).strip().lower()
        if product_id in accepted_products:
            return True

        product = str(payload.get("product", "")).strip().lower()
        return product in accepted_products

    def _read_token_file(self) -> str | None:
        path = self._license_token_file_path()
        try:
            if not path.exists():
                return None
            token = path.read_text(encoding="utf-8").strip()
            return token or None
        except Exception:
            return None

    def _write_token_file(self, token: str) -> None:
        path = self._license_token_file_path()
        path.parent.mkdir(parents=True, exist_ok=True)
        # Best-effort atomic write.
        tmp = path.with_suffix(path.suffix + ".tmp")
        tmp.write_text(token, encoding="utf-8")
        tmp.replace(path)

    def _delete_token_file(self) -> None:
        path = self._license_token_file_path()
        with contextlib.suppress(Exception):
            if path.exists():
                path.unlink()

    def _get_persisted_token(self) -> str | None:
        # Keyring preferred; file is fallback.
        if KEYRING_AVAILABLE:
            try:
                token = keyring.get_password(self.app_name, "license")
                if token:
                    # One-time migration: if a license was activated when only
                    # keyring persistence existed, ensure the user-wide fallback
                    # file is created so other environments can see it.
                    if (
                        os.getenv("MANIFESTGUARD_LICENSE_NOFILE", "").strip().lower()
                        != "true"
                    ):
                        path = self._license_token_file_path()
                        if not path.exists():
                            with contextlib.suppress(Exception):
                                self._write_token_file(token)

                    return token
            except Exception:
                pass
        return self._read_token_file()

    def _set_persisted_token(self, token: str) -> None:
        # User-wide persistence goal:
        # - Always try keyring when available (secure store)
        # - Also write a per-user fallback file so other Python environments
        #   without a working keyring backend can still see the activation.
        #
        # Opt-out: MANIFESTGUARD_LICENSE_NOFILE=true
        if KEYRING_AVAILABLE:
            with contextlib.suppress(Exception):
                keyring.set_password(self.app_name, "license", token)

        if os.getenv("MANIFESTGUARD_LICENSE_NOFILE", "").strip().lower() == "true":
            return

        self._write_token_file(token)

    def _delete_persisted_token(self) -> None:
        if KEYRING_AVAILABLE:
            with contextlib.suppress(Exception):
                keyring.delete_password(self.app_name, "license")
        self._delete_token_file()
