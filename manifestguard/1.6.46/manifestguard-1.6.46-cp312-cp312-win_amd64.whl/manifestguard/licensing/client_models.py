"""LicensingClient shared models — status codes, dataclasses, and RFC-8785 helper."""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Any

import rfc8785  # type: ignore


def _canonicalize_rfc8785(obj: dict[str, Any]) -> str:
    """RFC8785 canonical JSON serialization.

    Args:
        obj: Dictionary to canonicalize

    Returns:
        Canonical JSON string

    """
    return rfc8785.dumps(obj).decode("utf8")


class LicenseStatusCode(Enum):
    """License validation status codes"""

    OK = "ok"
    MISSING = "missing"
    EXPIRED = "expired"
    TIME_WINDOW = "time_window"  # License not yet active (iat > now)
    INVALID_FORMAT = "invalid_format"  # Token format invalid
    BAD_SIGNATURE = "bad_signature"  # Signature verification failed
    PRODUCT_MISMATCH = "product_mismatch"
    TIME_ROLLBACK_BLOCKED = "time_rollback_blocked"
    MAX_DEVICES_EXCEEDED = "max_devices_exceeded"
    RENEWAL_BLOCKED = "renewal_blocked"
    DEVICE_LIMIT = "device_limit"  # Device activation limit reached
    UPDATE_ENTITLEMENT_EXPIRED = "update_entitlement_expired"  # Perpetual: token.exp passed but maintenance_until still valid


@dataclass
class LicenseStatus:
    """License status result"""

    code: LicenseStatusCode
    message: str
    payload: dict[str, Any] | None = None
    warnings: list[str] | None = None
    trial: bool = False
    expires_at: int | None = None


@dataclass
class DeviceActivation:
    """Device activation record"""

    device_hash: str
    activated_at: int
    last_seen: int
