"""Page-builder methods for the ManifestGuard GUI dashboard (Show and Preflight pages)."""
from __future__ import annotations

from typing import TYPE_CHECKING, Any

from PySide6.QtWidgets import (
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QTextEdit,
    QTreeWidget,
    QVBoxLayout,
    QWidget,
)


class GuiDashboardPagesMixin:
    if TYPE_CHECKING:
        def __getattr__(self, name: str) -> Any: ...

    def _create_dashboard_show_page(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)

        header = QLabel(
            "<h2>👁️ Show</h2>"
            "<p>Quick commands and views for the <b>active project</b>. "
            "All actions run mgpy CLI commands with streamed output.</p>"
        )
        header.setWordWrap(True)
        layout.addWidget(header)

        tools = QGroupBox("Tools (active project)")
        tools_layout = QVBoxLayout(tools)

        btn_row = QHBoxLayout()

        self.btn_tools_run_all = QPushButton("Run All (Quick)")
        self.btn_tools_run_all.setToolTip("Runs: check → complexity → coverage-weekly")
        self.btn_tools_run_all.clicked.connect(self._run_tool_run_all_quick)
        btn_row.addWidget(self.btn_tools_run_all)

        self.btn_tools_run_all_basic = QPushButton("Run All (Basic)")
        self.btn_tools_run_all_basic.setToolTip("Runs: check (no --extended) → complexity → coverage-weekly")
        self.btn_tools_run_all_basic.clicked.connect(self._run_tool_run_all_basic)
        btn_row.addWidget(self.btn_tools_run_all_basic)

        self.btn_tools_run_all_extended = QPushButton("Run All (Extended)")
        self.btn_tools_run_all_extended.setToolTip("Runs: check --extended → complexity → coverage-weekly")
        self.btn_tools_run_all_extended.clicked.connect(self._run_tool_run_all_extended)
        btn_row.addWidget(self.btn_tools_run_all_extended)

        self.btn_tools_pytest = QPushButton("Run Pytest")
        self.btn_tools_pytest.setToolTip("Runs: python -m pytest (if installed)")
        self.btn_tools_pytest.clicked.connect(self._run_tool_pytest)
        btn_row.addWidget(self.btn_tools_pytest)

        self.btn_tools_complexity = QPushButton("Run Complexity")
        self.btn_tools_complexity.clicked.connect(self._run_tool_complexity)
        btn_row.addWidget(self.btn_tools_complexity)

        self.btn_tools_baseline_trend = QPushButton("Baseline Trend")
        self.btn_tools_baseline_trend.clicked.connect(self._run_tool_baseline_trend)
        btn_row.addWidget(self.btn_tools_baseline_trend)

        self.btn_tools_validate_views = QPushButton("Validate Views")
        self.btn_tools_validate_views.clicked.connect(self._run_tool_validate_views)
        btn_row.addWidget(self.btn_tools_validate_views)

        btn_row.addStretch()

        self.btn_tools_cancel = QPushButton("Cancel")
        self.btn_tools_cancel.setEnabled(False)
        self.btn_tools_cancel.clicked.connect(self._cancel_tools_command)
        btn_row.addWidget(self.btn_tools_cancel)

        tools_layout.addLayout(btn_row)

        btn_row2 = QHBoxLayout()

        self.btn_tools_coverage_track = QPushButton("Coverage Track")
        self.btn_tools_coverage_track.setToolTip("Tracks coverage.json into .mgpy/metrics/manifestguard-history.json")
        self.btn_tools_coverage_track.clicked.connect(self._run_tool_coverage_track)
        btn_row2.addWidget(self.btn_tools_coverage_track)

        self.btn_tools_coverage_weekly = QPushButton("Coverage Weekly")
        self.btn_tools_coverage_weekly.setToolTip("Reconstruct weekly aggregates from metrics history (.mgpy/metrics/)")
        self.btn_tools_coverage_weekly.clicked.connect(self._run_tool_coverage_weekly)
        btn_row2.addWidget(self.btn_tools_coverage_weekly)

        btn_row2.addStretch()
        tools_layout.addLayout(btn_row2)

        open_row = QHBoxLayout()
        btn_open_manifestguard_dir = QPushButton("Open .manifestguard Folder")
        btn_open_manifestguard_dir.clicked.connect(self._open_manifestguard_dir)
        open_row.addWidget(btn_open_manifestguard_dir)

        btn_open_history = QPushButton("Open Metrics History")
        btn_open_history.clicked.connect(self._open_history_file)
        open_row.addWidget(btn_open_history)

        btn_open_metrics = QPushButton("Open metrics.json")
        btn_open_metrics.clicked.connect(self._open_complexity_metrics_file)
        open_row.addWidget(btn_open_metrics)

        open_row.addStretch()
        tools_layout.addLayout(open_row)

        layout.addWidget(tools)

        self.tools_output = QTextEdit()
        self.tools_output.setReadOnly(True)
        self.tools_output.setPlaceholderText("Run a tool to see output...")
        layout.addWidget(self.tools_output)

        self._tools_run_buttons = [
            self.btn_tools_run_all,
            self.btn_tools_pytest,
            self.btn_tools_complexity,
            self.btn_tools_baseline_trend,
            self.btn_tools_validate_views,
            self.btn_tools_coverage_track,
            self.btn_tools_coverage_weekly,
        ]

        layout.addStretch()
        return page

    def _create_dashboard_preflight_page(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)

        header = QLabel(
            "<h2>🧪 Preflight VENV</h2>"
            "<p>Select virtual environments from the active project and run the venv-wizard preflight in sequence.</p>"
        )
        header.setWordWrap(True)
        layout.addWidget(header)

        controls = QGroupBox("Venvs")
        controls_layout = QVBoxLayout(controls)

        self.preflight_tree = QTreeWidget()
        self.preflight_tree.setHeaderLabels(["Run", "Venv Path"])
        self.preflight_tree.setColumnWidth(0, 80)
        controls_layout.addWidget(self.preflight_tree)

        btn_row = QHBoxLayout()
        btn_add = QPushButton("Detect Venvs")
        btn_add.clicked.connect(self._detect_and_populate_venvs)
        btn_row.addWidget(btn_add)

        btn_up = QPushButton("Move Up")
        btn_up.clicked.connect(self._preflight_move_up)
        btn_row.addWidget(btn_up)

        btn_down = QPushButton("Move Down")
        btn_down.clicked.connect(self._preflight_move_down)
        btn_row.addWidget(btn_down)

        btn_row.addStretch()
        controls_layout.addLayout(btn_row)

        layout.addWidget(controls)

        actions = QHBoxLayout()
        self.btn_preflight_run = QPushButton("Run Selected")
        self.btn_preflight_run.clicked.connect(self._preflight_run_selected)
        actions.addWidget(self.btn_preflight_run)

        self.btn_preflight_compare = QPushButton("Compare All")
        self.btn_preflight_compare.setToolTip("Run AI cross-venv comparison for the last preflight results")
        self.btn_preflight_compare.setEnabled(False)
        self.btn_preflight_compare.clicked.connect(self._preflight_compare_last)
        actions.addWidget(self.btn_preflight_compare)

        self.btn_preflight_cancel = QPushButton("Cancel")
        self.btn_preflight_cancel.setEnabled(False)
        self.btn_preflight_cancel.clicked.connect(self._cancel_tools_command)
        actions.addWidget(self.btn_preflight_cancel)

        actions.addStretch()
        layout.addLayout(actions)

        self.preflight_output = QTextEdit()
        self.preflight_output.setReadOnly(True)
        self.preflight_output.setPlaceholderText("Preflight run output...")
        layout.addWidget(self.preflight_output)

        return page
