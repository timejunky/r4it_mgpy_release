from __future__ import annotations

import re
from pathlib import Path

from .dummy_recognition_models import DummyCodeFinding, DummyEvidence


def _pos_to_line_col(text: str, index: int) -> tuple[int, int]:
    # 1-based line/col
    line = text.count("\n", 0, index) + 1
    last_nl = text.rfind("\n", 0, index)
    col0 = index if last_nl == -1 else index - last_nl - 1
    return line, col0 + 1


_TEST_ARTIFACT_PATTERNS: list[tuple[str, re.Pattern[str]]] = [
    ("print-test", re.compile(r"print\s*\(\s*['\"]test", re.IGNORECASE)),
    ("breakpoint", re.compile(r"\bbreakpoint\s*\(\s*\)")),
    ("pdb", re.compile(r"pdb\.set_trace\s*\(\s*\)")),
    ("sleep-long", re.compile(r"\bsleep\s*\(\s*\d{4,}\s*\)")),
    ("sk-test", re.compile(r"['\"]sk-test-[a-zA-Z0-9]+['\"]")),
    ("dummy-token", re.compile(r"['\"]dummy[_-]?token['\"]", re.IGNORECASE)),
    ("test-key", re.compile(r"['\"]test[_-]?key['\"]", re.IGNORECASE)),
    ("test-mode", re.compile(r"TEST_MODE")),
]


def detect_test_artifacts(source_text: str, file_path: Path) -> list[DummyCodeFinding]:
    # The detector modules themselves legitimately contain strings that look like
    # test artifacts (e.g. "dummy-token", "test-key") as detection patterns.
    # To keep results focused on target projects, we skip flagging these files.
    if file_path.stem.startswith("dummy_recognition"):
        return []

    findings: list[DummyCodeFinding] = []
    for _name, pattern in _TEST_ARTIFACT_PATTERNS:
        for match in pattern.finditer(source_text):
            line, col = _pos_to_line_col(source_text, match.start())
            findings.append(
                DummyCodeFinding(
                    code="DUMMY-030",
                    severity="warn",
                    confidence=65,
                    message=f'Test/debug artifact found in runtime code: "{match.group(0)}"',
                    file=str(file_path),
                    line=line,
                    column=col,
                    symbol=None,
                    evidence=DummyEvidence(
                        pattern="test-artifact", notes=[f"Match: {match.group(0)}"]
                    ),
                    remediation="Remove debug/test code from production sources or move to test files.",
                ),
            )
    return findings
