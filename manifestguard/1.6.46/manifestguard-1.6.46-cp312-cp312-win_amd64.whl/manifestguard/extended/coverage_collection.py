"""Async coverage collection used by extended metrics."""

from __future__ import annotations

import asyncio
import configparser
import contextlib
import json
import logging
import os
import re
import subprocess
import sys
import time
from collections.abc import Awaitable, Callable
from pathlib import Path
from typing import TYPE_CHECKING
from .coverage_file_readers import (
    _coverage_json_has_meaningful_datapoint,
    _read_coverage_json_covered_lines,
    _read_coverage_json_totals,
    _read_unit_percent_from_coverage_json,
    _read_unit_percent_from_coverage_xml,
)

if TYPE_CHECKING:
    from .metrics import CoverageMetrics

logger = logging.getLogger(__name__)
_PREFER_EXISTING_COVERAGE_MAX_AGE_SECONDS = 3600


RunCmd = Callable[..., Awaitable[tuple[int, str, str]]]


def _resolve_project_python_executable(
    workspace_root: Path, *, python_override: str | None = None
) -> str:
    """Resolve Python executable for running project tests/coverage.

    Resolution order:
     1. Explicit ``python_override`` parameter (validated: path must exist).
     2. ``sys.executable`` — reuse the exact interpreter that launched mgpy.

    Pass via CLI: ``--project-python path/to/python.exe``
    """

    if python_override:
        try:
            override_path = Path(python_override)
            if override_path.exists():
                return str(override_path)
        except Exception:
            pass

    return sys.executable


def _build_pytest_env(workspace_root: Path) -> dict[str, str]:
    existing_pythonpath = os.environ.get("PYTHONPATH", "")
    src_path = str(workspace_root / "src")

    mgpy_import_root = ""
    try:
        import manifestguard  # noqa: PLC0415

        mgpy_import_root = str(Path(manifestguard.__file__).resolve().parent.parent)
    except Exception:
        mgpy_import_root = ""

    pythonpath_parts: list[str] = [src_path]
    if mgpy_import_root:
        pythonpath_parts.append(mgpy_import_root)
    if existing_pythonpath:
        pythonpath_parts.append(existing_pythonpath)

    pythonpath = os.pathsep.join([p for p in pythonpath_parts if p])
    return {
        **os.environ,
        "PYTHONPATH": pythonpath,
    }


def _pytest_addopts_enable_cov(addopts: object) -> bool:
    if isinstance(addopts, str):
        addopts_text = addopts
    elif isinstance(addopts, (list, tuple)):
        addopts_text = " ".join(str(item) for item in addopts)
    else:
        return False

    return bool(re.search(r"(^|\s)--cov(?:[-=\s]|$)", addopts_text))


def _read_pyproject_pytest_addopts(pyproject_path: Path) -> object | None:
    if not pyproject_path.exists():
        return None

    try:
        import tomllib  # noqa: PLC0415
    except ModuleNotFoundError:
        try:
            import tomli as tomllib  # type: ignore[import-not-found]  # noqa: PLC0415
        except ModuleNotFoundError:
            return None

    try:
        with pyproject_path.open("rb") as handle:
            data = tomllib.load(handle)
    except Exception:
        return None

    return data.get("tool", {}).get("pytest", {}).get("ini_options", {}).get("addopts")


def _read_ini_pytest_addopts(config_path: Path, *sections: str) -> str | None:
    if not config_path.exists():
        return None

    parser = configparser.ConfigParser()
    try:
        parser.read(config_path, encoding="utf-8")
    except Exception:
        return None

    for section in sections:
        if parser.has_option(section, "addopts"):
            try:
                return parser.get(section, "addopts")
            except Exception:
                return None

    return None


def _should_disable_pytest_cov(workspace_root: Path) -> bool:
    if _pytest_addopts_enable_cov(os.environ.get("PYTEST_ADDOPTS", "")):
        return True

    pyproject_addopts = _read_pyproject_pytest_addopts(workspace_root / "pyproject.toml")
    if _pytest_addopts_enable_cov(pyproject_addopts):
        return True

    config_candidates = (
        (workspace_root / "pytest.ini", ("pytest",)),
        (workspace_root / "tox.ini", ("pytest",)),
        (workspace_root / "setup.cfg", ("tool:pytest",)),
    )
    for config_path, sections in config_candidates:
        if _pytest_addopts_enable_cov(_read_ini_pytest_addopts(config_path, *sections)):
            return True

    return False


def _pytest_cov_suppression_args(workspace_root: Path) -> tuple[str, ...]:
    if _should_disable_pytest_cov(workspace_root):
        return ("--no-cov",)
    return ()


def _existing_coverage_max_age_seconds() -> int:
    raw = os.environ.get(
        "MANIFESTGUARD_EXTENDED_REUSE_COVERAGE_MAX_AGE_SECONDS",
        str(_PREFER_EXISTING_COVERAGE_MAX_AGE_SECONDS),
    )
    try:
        value = int(raw)
    except Exception:
        return _PREFER_EXISTING_COVERAGE_MAX_AGE_SECONDS
    return max(0, value)


def _is_fresh_file(path: Path, max_age_seconds: int) -> bool:
    try:
        age_s = time.time() - path.stat().st_mtime
    except OSError:
        return False
    return age_s <= float(max_age_seconds)


def _try_recent_existing_coverage_percent(
    workspace_root: Path,
    total_tests: int | None,
) -> float | None:
    """Return recent coverage percent from existing artifacts, if meaningful."""
    max_age = _existing_coverage_max_age_seconds()
    if max_age <= 0:
        return None

    coverage_json = workspace_root / "coverage.json"
    if coverage_json.exists() and _is_fresh_file(coverage_json, max_age):
        percent = _read_unit_percent_from_coverage_json(coverage_json)
        if percent is not None and _coverage_json_has_meaningful_datapoint(coverage_json, total_tests):
            return percent

    coverage_xml = workspace_root / "coverage.xml"
    if coverage_xml.exists() and _is_fresh_file(coverage_xml, max_age):
        return _read_unit_percent_from_coverage_xml(coverage_xml)

    return None


def _parse_collected_test_count(output: str) -> int | None:
    match = re.search(r"collected\s+(\d+)\s+items", output)
    if not match:
        match = re.search(r"(\d+)\s+tests\s+collected", output)
    if not match:
        return None
    try:
        return int(match.group(1))
    except Exception:
        return None


def _try_parse_progress_total(line: str) -> int | None:
    if not line.startswith("[MG-PROGRESS] TOTAL "):
        return None
    try:
        return int(line.split()[-1])
    except Exception:
        return None


def _try_parse_progress_run(line: str) -> tuple[int, int, int | None] | None:
    if not line.startswith("[MG-PROGRESS] RUN "):
        return None
    try:
        parts = line.split()
        cur_total = parts[3] if len(parts) > 3 else parts[2]
        eta = int(parts[-1]) if len(parts) > 2 and parts[-2] == "ETA" else None
        cur_str, total_str = cur_total.split("/")
        return (int(cur_str), int(total_str), eta)
    except Exception:
        return None


def _maybe_report_total_tests(
    metrics: "CoverageMetrics", total_tests: int | None, progress: Callable | None
) -> None:
    if total_tests is None:
        return
    if getattr(metrics, "total_tests", None) == total_tests:
        return
    metrics.total_tests = total_tests
    if progress:
        progress(f"Discovered {total_tests} tests")


async def _spawn_pytest_with_cov(
    *,
    workspace_root: Path,
    env: dict[str, str],
    python_executable: str,
) -> asyncio.subprocess.Process:
    pytest_cov_suppression_args = _pytest_cov_suppression_args(workspace_root)
    # CREATE_NEW_PROCESS_GROUP isolates the child from the parent's console group
    # (prevents ConPTY CTRL_C_EVENT propagation on Windows from causing spurious
    # KeyboardInterrupt in the parent process).
    extra: dict = (
        {"creationflags": subprocess.CREATE_NEW_PROCESS_GROUP}
        if sys.platform == "win32"
        else {}
    )
    return await asyncio.create_subprocess_exec(
        python_executable,
        "-m",
        "coverage",
        "run",
        "-m",
        "pytest",
        "-q",
        *pytest_cov_suppression_args,
        "-p",
        "manifestguard.pytest_progress",
        cwd=str(workspace_root),
        env=env,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.STDOUT,
        **extra,
    )


async def _drain_progress_output(
    *,
    proc: asyncio.subprocess.Process,
    metrics: "CoverageMetrics",
    progress: Callable | None,
) -> None:
    assert proc.stdout is not None
    async for raw in proc.stdout:
        line = raw.decode(errors="ignore").strip()

        total = _try_parse_progress_total(line)
        if total is not None:
            _maybe_report_total_tests(metrics, total, progress)
            continue

        run_progress = _try_parse_progress_run(line)
        if run_progress is None:
            continue

        cur, total, eta = run_progress
        msg = f"Tests {cur}/{total}"
        if eta is not None:
            msg += f" (ETA {eta}s)"
        if progress:
            progress(msg)


async def _kill_proc(proc: asyncio.subprocess.Process) -> None:
    with contextlib.suppress(Exception):
        proc.kill()
    with contextlib.suppress(Exception):
        await proc.wait()


async def _communicate_with_timeout(
    proc: asyncio.subprocess.Process,
    *,
    timeout: float,
) -> tuple[int, str, str]:
    """Read subprocess output with robust timeout/cancel cleanup.

    On Windows/Proactor, not awaiting process termination after kill can leave
    transports pending until interpreter shutdown, which then emits
    "event loop is closed" warnings.
    """
    try:
        stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=timeout)
    except asyncio.TimeoutError:
        await _kill_proc(proc)
        with contextlib.suppress(Exception):
            await proc.communicate()
        return (1, "", "Timeout")
    except asyncio.CancelledError:
        await _kill_proc(proc)
        with contextlib.suppress(Exception):
            await proc.communicate()
        raise

    rc = proc.returncode if proc.returncode is not None else 1
    return (rc, stdout.decode(errors="ignore"), stderr.decode(errors="ignore"))


async def _run_pytest_collect_only(
    run_cmd: RunCmd,
    *,
    workspace_root: Path,
    progress: Callable | None,
    metrics: "CoverageMetrics",
    python_executable: str,
) -> None:
    pytest_cov_suppression_args = _pytest_cov_suppression_args(workspace_root)
    rc, out, _ = await run_cmd(
        python_executable,
        "-m",
        "pytest",
        "--collect-only",
        "-q",
        *pytest_cov_suppression_args,
        timeout=60,
    )
    if rc != 0:
        return

    total = _parse_collected_test_count(out)
    if total is None:
        return

    metrics.total_tests = total
    if progress:
        progress(f"Discovered {total} tests")


async def _maybe_collect_unit_percent_from_existing_coverage(
    run_cmd: RunCmd,
    *,
    workspace_root: Path,
    python_executable: str,
) -> float | None:
    rc, _, _ = await run_cmd(
        python_executable,
        "-m",
        "coverage",
        "json",
        "-o",
        "coverage.json",
        timeout=60,
    )

    coverage_json = workspace_root / "coverage.json"
    if rc == 0 and coverage_json.exists():
        return _read_unit_percent_from_coverage_json(coverage_json)
    if coverage_json.exists():
        return _read_unit_percent_from_coverage_json(coverage_json)
    return None


async def _run_coverage_with_progress(
    *,
    workspace_root: Path,
    metrics: "CoverageMetrics",
    progress: Callable | None,
    python_executable: str,
) -> int:
    try:
        env = _build_pytest_env(workspace_root)
        proc = await _spawn_pytest_with_cov(
            workspace_root=workspace_root,
            env=env,
            python_executable=python_executable,
        )

        drain_task = asyncio.create_task(
            _drain_progress_output(proc=proc, metrics=metrics, progress=progress)
        )

        timeout_seconds = float(
            os.environ.get("MANIFESTGUARD_EXTENDED_COVERAGE_TIMEOUT", "1800")
        )
        try:
            await asyncio.wait_for(proc.wait(), timeout=timeout_seconds)
        except asyncio.TimeoutError:
            await _kill_proc(proc)
            return 1
        except asyncio.CancelledError:
            await _kill_proc(proc)
            raise
        finally:
            if not drain_task.done():
                drain_task.cancel()
            with contextlib.suppress(Exception):
                await drain_task

        return proc.returncode or 0
    except asyncio.CancelledError:
        raise
    except Exception:
        return 1


async def collect_coverage_metrics(
    workspace_root: Path,
    progress: Callable | None = None,
    *,
    python_override: str | None = None,
) -> CoverageMetrics:
    """Collect test coverage data from pytest/coverage (best-effort).

    Returns a CoverageMetrics instance (imported lazily to avoid cycles).
    """

    from .metrics import CoverageMetrics  # noqa: PLC0415 - avoid circular import

    metrics = CoverageMetrics()
    python_executable = _resolve_project_python_executable(workspace_root, python_override=python_override)

    async def _run_cmd(*args: str, timeout: float = 30.0) -> tuple[int, str, str]:
        try:
            env = _build_pytest_env(workspace_root)
            # CREATE_NEW_PROCESS_GROUP prevents ConPTY Ctrl+C signal propagation.
            extra: dict = (
                {"creationflags": subprocess.CREATE_NEW_PROCESS_GROUP}
                if sys.platform == "win32"
                else {}
            )
            proc = await asyncio.create_subprocess_exec(
                *args,
                cwd=str(workspace_root),
                env=env,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                **extra,
            )
            return await _communicate_with_timeout(proc, timeout=timeout)
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            return (1, "", str(exc))

    try:
        # Save any pre-existing coverage value as a fallback.
        # The fresh `coverage run -m pytest` below can overwrite coverage.json with 0%
        # when no --source is configured in the project (common for globally-installed
        # mgpy running against a project that generates coverage.json via its own
        # `pytest --cov ... --cov-report=json` run).
        coverage_json_path = workspace_root / "coverage.json"
        coverage_xml_path = workspace_root / "coverage.xml"
        pre_existing_percent: float | None = None
        if coverage_json_path.exists():
            pre_existing_percent = _read_unit_percent_from_coverage_json(coverage_json_path)
        if pre_existing_percent is None and coverage_xml_path.exists():
            pre_existing_percent = _read_unit_percent_from_coverage_xml(coverage_xml_path)

        await _run_pytest_collect_only(
            _run_cmd,
            workspace_root=workspace_root,
            progress=progress,
            metrics=metrics,
            python_executable=python_executable,
        )

        existing_percent = _try_recent_existing_coverage_percent(
            workspace_root,
            metrics.total_tests,
        )
        if existing_percent is not None:
            metrics.unit_percent = existing_percent
            metrics.unit_measured = True
            if progress:
                progress("Using recent existing coverage artifact")
            return metrics

        # Always prefer a fresh coverage run so results are not stale.
        rc = await _run_coverage_with_progress(
            workspace_root=workspace_root,
            metrics=metrics,
            progress=progress,
            python_executable=python_executable,
        )

        if rc == 0:
            # Convert collected data to JSON (portable paths are handled via pyproject
            # [tool.coverage.run] relative_files = true).
            await _run_cmd(
                python_executable,
                "-m",
                "coverage",
                "json",
                "-o",
                "coverage.json",
                timeout=120,
            )

            coverage_json = workspace_root / "coverage.json"
            if coverage_json.exists():
                unit_percent = _read_unit_percent_from_coverage_json(coverage_json)
                if unit_percent is not None:
                    if unit_percent <= 0.0 and pre_existing_percent and pre_existing_percent > 0.0:
                        # Fresh run produced 0% — likely no [tool.coverage.run] source
                        # is configured, so `coverage run -m pytest` ran the tests but
                        # recorded no lines. Fall back to the pre-existing coverage.json
                        # value (e.g. from the user's own `pytest --cov` run).
                        logger.debug(
                            "Fresh coverage run produced 0%%. Falling back to "
                            "pre-existing coverage.json value: %.2f%%",
                            pre_existing_percent,
                        )
                        metrics.unit_percent = pre_existing_percent
                        metrics.unit_measured = True
                    elif _coverage_json_has_meaningful_datapoint(
                        coverage_json,
                        metrics.total_tests,
                    ):
                        metrics.unit_percent = unit_percent
                        metrics.unit_measured = True
                        logger.debug("Coverage collected: %s%%", metrics.unit_percent)
                    else:
                        logger.debug(
                            "Coverage JSON contained no measurable statements/tests; "
                            "treating 0%% as unavailable datapoint",
                        )
        else:
            # Fresh pytest run failed — try existing coverage artifacts in priority order:
            # 1. .coverage binary  → convert via `coverage json`
            # 2. coverage.xml      → parse Cobertura XML directly
            unit_percent: float | None = None
            coverage_binary = workspace_root / ".coverage"
            if coverage_binary.exists():
                unit_percent = await _maybe_collect_unit_percent_from_existing_coverage(
                    _run_cmd,
                    workspace_root=workspace_root,
                    python_executable=python_executable,
                )
            if unit_percent is None and coverage_xml_path.exists():
                unit_percent = _read_unit_percent_from_coverage_xml(coverage_xml_path)
            if unit_percent is not None and (
                not (workspace_root / "coverage.json").exists()
                or _coverage_json_has_meaningful_datapoint(
                    workspace_root / "coverage.json",
                    metrics.total_tests,
                )
            ):
                metrics.unit_percent = unit_percent
                metrics.unit_measured = True
            else:
                logger.debug(
                    "No coverage data found. Generate with:\n"
                    "  pytest --cov=<package> --cov-report=json  (produces coverage.json)\n"
                    "  pytest --cov=<package> --cov-report=xml   (produces coverage.xml)"
                )

    except Exception as exc:
        logger.debug("Coverage collection failed: %s", exc)

    return metrics
