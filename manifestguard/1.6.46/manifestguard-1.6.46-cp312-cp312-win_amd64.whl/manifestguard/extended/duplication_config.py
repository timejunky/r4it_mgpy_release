"""Config dataclass and loader for code duplication detection.

Extracted from duplication.py to keep module size manageable.
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path


_DEFAULT_SKIP_DIR_NAMES: set[str] = {
    ".git",
    ".hg",
    ".svn",
    ".tox",
    ".venv",
    ".manifestguard",
    "venv",
    "env",
    "__pycache__",
    ".mypy_cache",
    ".pytest_cache",
    ".ruff_cache",
    "node_modules",
    "dist",
    "build",
}


@dataclass(frozen=True)
class DuplicationDetectionConfig:
    enabled: bool = True
    include_tests: bool = True

    # Sliding window size, in non-empty normalized lines.
    window_lines: int = 12

    # Minimum occurrences for a block to be reported.
    min_occurrences: int = 2

    # Hard limits to keep runtime/output bounded.
    max_files: int = 5000
    max_file_size_bytes: int = 512 * 1024
    max_results: int = 200

    # Parallelization (opt-in via config). 0 = auto, 1 = disabled.
    parallel_workers: int = 0

    # Incremental cache (best-effort). Stores per-file scan artifacts in
    # .manifestguard to avoid rescanning unchanged files.
    cache_enabled: bool = True
    cache_max_total_windows: int = 250_000


# Intentionally complex for backward-compatible config loading with multiple legacy formats
# manifestguard-ignore-next-line: COMPLEXITY
def load_duplication_detection_config_from_manifestguard_json(
    workspace_root: Path,
) -> DuplicationDetectionConfig:
    """Load duplication detection config from manifestguard.json (best-effort).

    Supported shapes:

    {
      "duplicationDetection": {"enabled": true, "includeTests": true, ...}
    }

    Also accepts a legacy/alternate key "duplication".
    """
    config_path = workspace_root / "manifestguard.json"
    if not config_path.exists():
        return DuplicationDetectionConfig()

    try:
        data = json.loads(config_path.read_text(encoding="utf-8"))
    except Exception:
        return DuplicationDetectionConfig()

    if not isinstance(data, dict):
        return DuplicationDetectionConfig()

    raw = data.get("duplicationDetection")
    if not isinstance(raw, dict):
        raw = data.get("duplication")
    if not isinstance(raw, dict):
        return DuplicationDetectionConfig()

    def _as_int(key: str, default: int) -> int:
        val = raw.get(key)
        if isinstance(val, int):
            return val
        if isinstance(val, str) and val.strip().isdigit():
            return int(val.strip())
        return default

    def _as_int_clamped(key: str, default: int, min_val: int) -> int:
        return max(_as_int(key, default), min_val)

    enabled = raw.get("enabled")
    if not isinstance(enabled, bool):
        enabled = True

    include_tests = raw.get("includeTests")
    if not isinstance(include_tests, bool):
        include_tests = raw.get("include_tests")
    if not isinstance(include_tests, bool):
        include_tests = True

    window_lines = _as_int_clamped("windowLines", DuplicationDetectionConfig.window_lines, 3)
    min_occurrences = _as_int_clamped(
        "minOccurrences", DuplicationDetectionConfig.min_occurrences, 2
    )
    max_files = _as_int_clamped("maxFiles", DuplicationDetectionConfig.max_files, 1)
    max_file_size_bytes = _as_int_clamped(
        "maxFileSizeBytes", DuplicationDetectionConfig.max_file_size_bytes, 1024
    )
    max_results = _as_int_clamped("maxResults", DuplicationDetectionConfig.max_results, 1)

    parallel_workers = _as_int(
        "parallelWorkers",
        DuplicationDetectionConfig.parallel_workers,
    )
    if parallel_workers == DuplicationDetectionConfig.parallel_workers:
        parallel_workers = _as_int(
            "parallel_workers",
            DuplicationDetectionConfig.parallel_workers,
        )
    parallel_workers = max(parallel_workers, 0)

    return DuplicationDetectionConfig(
        enabled=enabled,
        include_tests=include_tests,
        window_lines=window_lines,
        min_occurrences=min_occurrences,
        max_files=max_files,
        max_file_size_bytes=max_file_size_bytes,
        max_results=max_results,
        parallel_workers=parallel_workers,
    )
