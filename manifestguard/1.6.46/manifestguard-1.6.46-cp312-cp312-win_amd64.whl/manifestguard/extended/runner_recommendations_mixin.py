"""Recommendation display mixin for ExtendedTestRunner."""

from __future__ import annotations

from manifestguard.i18n import t

from .metrics import ExtendedTestMetrics, Recommendation
from .runner_console import _get_separator


class _RunnerRecommendationsMixin:
    """Mixin containing CLI recommendation rendering helpers."""

    def _display_next_steps(self, by_priority: dict, verbose: bool) -> None:
        print("\n💡 Next Steps:")
        if by_priority["critical"]:
            print("   1. Fix Critical issues (high impact, quick fixes)")
        if by_priority["high"]:
            print("   2. Tackle High priority (1 week timeline)")
        if by_priority["medium"] and not verbose:
            print("   3. Run with --verbose to see Medium/Low recommendations")
        print("   4. Track progress: manifestguard check --extended")

    def _display_quality_potential(self, quality_score: float, recommendations: list) -> None:
        if quality_score > 0:
            target_score = min(100, quality_score + sum(r.impact_score for r in recommendations))
            print(f"\n🎯 Potential: {quality_score:.1f} → {target_score:.1f}/100")

    def _display_success_summary(self, metrics: ExtendedTestMetrics) -> None:
        if metrics.quality_score > 0:
            print(f"🎯 Quality Score: {metrics.quality_score:.1f}/100")

        coverage = metrics.coverage
        if not coverage.unit_measured:
            print("📈 Coverage: not run (threshold gate — fix E/W first, then rerun --extended)")
            return

        print(
            f"📈 Coverage: {coverage.unit_percent:.1f}% unit, "
            f"{coverage.integration_percent:.1f}% integration"
        )
        if coverage.passing_tests or coverage.skipped_tests or coverage.failing_tests:
            print(
                f"🧪 Tests: {coverage.passing_tests}/{coverage.total_tests} passing "
                f"({coverage.skipped_tests} skipped, {coverage.failing_tests} failing)"
            )
        elif coverage.total_tests > 0:
            print(f"🧪 Tests discovered: {coverage.total_tests}")
        if coverage.untested_modules:
            print(f"🧩 Untested: {len(coverage.untested_modules)} module(s) lack coverage")

    async def show_recommendations(
        self, metrics: ExtendedTestMetrics, verbose: bool = False
    ) -> None:
        if not metrics.recommendations:
            print("\n✅ ManifestGuard: All metrics optimal!")
            self._display_success_summary(metrics)
            return

        by_priority = self._group_recommendations_by_priority(metrics.recommendations)
        separator = _get_separator(70)

        print(f"\n📊 ManifestGuard Extended Test: {len(metrics.recommendations)} recommendation(s)")
        if metrics.quality_score > 0:
            print(f"🎯 Quality Score: {metrics.quality_score:.1f}/100")
        print(separator)

        self._display_critical_recommendations(by_priority["critical"])
        self._display_high_recommendations(by_priority["high"])
        self._display_medium_recommendations(by_priority["medium"], verbose)
        self._display_low_recommendations(by_priority["low"], verbose)

        print(separator)
        self._display_next_steps(by_priority, verbose)
        self._display_quality_potential(metrics.quality_score, metrics.recommendations)
        print("\n" + t("cli.extended.goal_message", module="cli"))

    def _display_critical_recommendations(self, recommendations: list[Recommendation]) -> None:
        if not recommendations:
            return
        print(f"\n🔴 CRITICAL ({len(recommendations)}) — Fix immediately!\n")
        for i, rec in enumerate(recommendations, 1):
            self._display_recommendation_details(i, rec)

    def _display_high_recommendations(self, recommendations: list[Recommendation]) -> None:
        if not recommendations:
            return
        print(f"⚠️  HIGH ({len(recommendations)}) — Fix within 1 week\n")
        for i, rec in enumerate(recommendations, 1):
            self._display_recommendation_details(i, rec)

    def _display_medium_recommendations(
        self,
        recommendations: list[Recommendation],
        verbose: bool,
    ) -> None:
        if not recommendations:
            return
        if verbose:
            print(f"\n🟡 MEDIUM ({len(recommendations)}) — Improve quality\n")
            for i, rec in enumerate(recommendations, 1):
                self._display_recommendation_details(i, rec)
        else:
            print(f"🟡 MEDIUM ({len(recommendations)}) — Improve quality")
            print("   [Run with --verbose for details]\n")

    def _display_low_recommendations(self, recommendations: list[Recommendation], verbose: bool) -> None:
        if not recommendations:
            return
        if verbose:
            print(
                f"\N{INFORMATION SOURCE}\N{VARIATION SELECTOR-16}  LOW "
                f"({len(recommendations)}) — Optional enhancements\n",
            )
            for i, rec in enumerate(recommendations, 1):
                self._display_recommendation_details(i, rec)
        else:
            print(
                f"\N{INFORMATION SOURCE}\N{VARIATION SELECTOR-16}  LOW "
                f"({len(recommendations)}) — Optional enhancements",
            )
            print("   [Run with --verbose for details]\n")

    def _display_recommendation_details(self, index: int, rec: Recommendation) -> None:
        print(f"{index}. [{rec.category.upper()}] {rec.summary}")
        if rec.effort_minutes > 0 and rec.impact_score > 0:
            print(f"   ⏱️  {rec.effort_minutes} min  |  📊 Impact: +{rec.impact_score}")
        if rec.proposed_fix:
            print(f"   📋 {rec.proposed_fix}")
        if rec.guide_command:
            version_suffix = f" [{rec.guide_version}]" if rec.guide_version else ""
            print(f"   📘 {rec.guide_command}{version_suffix}")
        if rec.guide_url:
            print(f"   🌐 {rec.guide_url}")
        print()
