"""Extended Test Runner - Orchestration Module

This module provides the ExtendedTestRunner class that orchestrates the execution
of extended quality metrics collection after regular ManifestGuard checks.

Key Features:
- Async execution with progress callbacks for UI integration
- Graceful error handling with detailed logging
- Configuration-based enable/disable mechanism
- Comprehensive console output with emoji indicators
- AI-powered recommendations display
- Automatic ASCII/UTF-8 detection for terminal compatibility

The runner coordinates the MetricsCollector to gather metrics across all categories
(coverage, dependencies, security, SBOM, packaging, performance, policy, license)
and presents the results in a structured, user-friendly format.

Example Usage:
    # Initialize runner with workspace
    runner = ExtendedTestRunner(Path("/path/to/project"))

    # Check if enabled in config
    if runner.is_enabled():
        # Run with progress callback
        metrics = await runner.run(progress_callback=lambda msg: print(f"Progress: {msg}"))

        # Display recommendations
        await runner.show_recommendations(metrics)

Privacy & Performance:
- All analysis runs locally, no external API calls
- Typical execution time: 2-5 seconds for medium projects
- Results are logged to standard Python logging system
"""

import asyncio
import logging
from collections.abc import Callable
from pathlib import Path
from typing import ClassVar

from .metrics import (
    ComplexityMetrics,
    CoverageMetrics,
    DependencyMetrics,
    ExtendedTestMetrics,
    MetricsCollector,
    PackagingMetrics,
    Recommendation,
    SecurityMetrics,
)
from .runner_console import _get_separator
from .runner_recommendations_mixin import _RunnerRecommendationsMixin

logger = logging.getLogger(__name__)


class ExtendedTestRunner(_RunnerRecommendationsMixin):
    """Extended Test Runner - Orchestrates Comprehensive Quality Analysis

    This class coordinates the execution of extended tests that run after regular
    ManifestGuard checks. It manages the MetricsCollector lifecycle, handles progress
    reporting, and formats results for display.

    Attributes:
        workspace_root (Path): Root directory of the project being analyzed
        config (dict): Configuration dictionary from manifestguard.yaml/json
        collector (MetricsCollector): Metrics collection engine

    Configuration:
        The runner respects the `extendedTest.enabled` setting in the config:

        manifestguard.yaml:
            extendedTest:
              enabled: true  # Set to false to disable extended tests

    Example:
        >>> runner = ExtendedTestRunner(Path("/project"))
        >>> metrics = await runner.run()
        >>> print(f"Coverage: {metrics.coverage.unit_percent}%")

    """

    def __init__(
        self,
        workspace_root: Path,
        config: dict | None = None,
        gate_counts: tuple[int, int, int] | None = None,
        python_override: str | None = None,
    ):
        """Initialize Extended Test Runner

        Args:
            workspace_root: Project root directory
            config: Configuration dict (from manifestguard.yaml/json)
            python_override: Explicit Python interpreter path passed via
                ``--project-python`` CLI flag.

        """
        self.workspace_root = workspace_root
        self.config = config or {}
        self.collector = MetricsCollector(
            workspace_root,
            config=self.config,
            gate_counts=gate_counts,
            python_override=python_override,
        )

    def is_enabled(self) -> bool:
        """Check if extended tests are enabled in configuration.

        Returns:
            bool: True if extended tests should run (default), False if disabled

        Note:
            Extended tests are enabled by default. To disable, set:
            `extendedTest.enabled: false` in manifestguard.yaml/json

        """
        extended_config = self.config.get("extendedTest", {})
        return extended_config.get("enabled", True)  # Default: enabled

    async def run(
        self,
        progress_callback: Callable | None = None,
        focus: tuple[str, ...] | None = None,
    ) -> ExtendedTestMetrics | None:
        """Execute the complete extended test suite with progress tracking.

        This method orchestrates the entire extended test workflow:
        1. Checks if extended tests are enabled
        2. Collects metrics from all categories (coverage, deps, security, etc.)
        3. Generates AI-powered recommendations
        4. Logs structured results to console/log file

        Args:
            progress_callback: Optional callback function that receives progress messages.
                             Signature: callback(message: str) -> None
                             Useful for GUI/CLI progress indicators.

        Returns:
            ExtendedTestMetrics: Complete metrics object with all categories populated,
                               or None if extended tests are disabled or execution failed.

        Raises:
            No exceptions are raised - all errors are caught, logged, and return None.

        Example:
            >>> def show_progress(msg: str):
            ...     print(f"[INFO] {msg}")
            >>>
            >>> runner = ExtendedTestRunner(Path("."))
            >>> metrics = await runner.run(progress_callback=show_progress)
            [INFO] Collecting code quality metrics...
            [INFO] Generating AI recommendations...

        Performance:
            Typical execution time: 2-5 seconds for medium-sized projects.
            Most time is spent in coverage analysis and file system traversal.

        """
        if not self.is_enabled():
            logger.debug("Extended tests disabled in configuration")
            return None

        try:
            if progress_callback:
                if focus:
                    progress_callback(f"Collecting focused metrics ({', '.join(focus)})…")
                else:
                    progress_callback("Collecting code quality metrics…")

            separator = _get_separator(42)
            logger.info(separator)
            logger.info("📊 EXTENDED TEST MODE")
            logger.info(separator)

            # Collect metrics (also generates recommendations + logs internally)
            metrics = await self.collector.collect_metrics(progress=progress_callback, focus=focus)

            # Log structured results to console/log file
            self._log_metrics(metrics)

            return metrics

        except Exception as e:
            logger.error(f"Extended test failed: {e}", exc_info=True)
            return None

    def _log_coverage(self, cov: CoverageMetrics) -> None:
        """Log coverage metrics"""
        if not cov.unit_measured:
            logger.info(
                "   Coverage: not run (threshold gate — fix E/W first, then rerun --extended)"
            )
            return
        logger.info(
            "   Coverage: %.1f%% unit, %.1f%% integration",
            cov.unit_percent,
            cov.integration_percent,
        )
        logger.info(
            "   Tests: %s/%s passing (%s skipped, %s failing)",
            cov.passing_tests,
            cov.total_tests,
            cov.skipped_tests,
            cov.failing_tests,
        )
        if cov.untested_modules:
            logger.info(f"   Untested: {len(cov.untested_modules)} module(s) lack coverage")

    def _log_dependencies(self, dep: DependencyMetrics) -> None:
        """Log dependency health"""
        logger.info("")
        logger.info("📦 DEPENDENCY HEALTH:")
        logger.info(
            "   Status: %s outdated, %s high severity, %s critical",
            dep.outdated_count,
            dep.vulnerable_high,
            dep.vulnerable_critical,
        )
        if dep.conflicting_ranges:
            logger.info(f"   Conflicts: {len(dep.conflicting_ranges)} version range conflict(s)")

    def _log_security(self, sec: SecurityMetrics) -> None:
        """Log security indicators"""
        if sec.unsafe_exec_count > 0 or sec.hardcoded_secrets > 0:
            logger.info("")
            logger.info("🔒 SECURITY INDICATORS:")
            if sec.unsafe_exec_count > 0:
                logger.info("   ⚠️ Unsafe exec: %s file(s)", sec.unsafe_exec_count)
            if sec.hardcoded_secrets > 0:
                logger.info(
                    "   ⚠️ Hardcoded secrets: %s potential occurrence(s)",
                    sec.hardcoded_secrets,
                )

    def _log_packaging(self, pkg: PackagingMetrics) -> None:
        """Log packaging quality"""
        logger.info("")
        logger.info("📦 PACKAGING QUALITY:")
        logger.info(f"   py.typed: {'✅' if pkg.has_py_typed else '❌'}")
        logger.info(f"   README: {'✅' if pkg.readme_present else '❌'}")
        logger.info(f"   LICENSE: {'✅' if pkg.license_present else '❌'}")
        if pkg.missing_classifiers:
            logger.info(f"   ⚠️ Classifiers: {len(pkg.missing_classifiers)} issue(s)")

    def _log_complexity(self, comp: ComplexityMetrics) -> None:
        """Log complexity metrics"""
        if not comp or comp.files_scanned == 0:
            return
        logger.info("")
        logger.info("🔄 CYCLOMATIC COMPLEXITY:")
        logger.info(
            "   Violations: %s function(s) exceed threshold (%s)",
            comp.violations_count,
            comp.threshold,
        )
        logger.info("   Files scanned: %s", comp.files_scanned)
        if comp.violations_count > 0:
            logger.info(
                "   Max complexity: %s, Avg: %.1f",
                comp.max_complexity,
                comp.average_complexity,
            )
            if comp.top_violations:
                logger.info("   Top violations:")
                for v in comp.top_violations[:3]:
                    logger.info(
                        "      • %s in %s (complexity: %s, rank: %s)",
                        v["function"],
                        v["file"],
                        v["complexity"],
                        v["rank"],
                    )

    _PRIORITY_EMOJI: ClassVar[dict[str, str]] = {
        "critical": "🔴",
        "high": "⚠️ ",
        "medium": "🟡",
        "low": "\N{INFORMATION SOURCE}\N{VARIATION SELECTOR-16} ",
    }

    def _log_recommendations(self, recommendations: list[Recommendation]) -> None:
        """Log AI recommendations with enhanced actionable details."""
        if not recommendations:
            return

        logger.info("")
        logger.info("💡 RECOMMENDATIONS (Priority-Based):")
        logger.info("━" * 70)

        grouped = self._group_recommendations_by_priority(recommendations)
        for priority, recs in grouped.items():
            if not recs:
                continue
            self._log_recommendation_group(priority, recs)

        logger.info("\n" + "━" * 70)

    def _group_recommendations_by_priority(
        self,
        recommendations: list[Recommendation],
    ) -> dict[str, list[Recommendation]]:
        return {
            "critical": [rec for rec in recommendations if rec.priority == "critical"],
            "high": [rec for rec in recommendations if rec.priority == "high"],
            "medium": [rec for rec in recommendations if rec.priority == "medium"],
            "low": [rec for rec in recommendations if rec.priority == "low"],
        }

    def _log_recommendation_group(self, priority: str, recs: list[Recommendation]) -> None:
        emoji = self._PRIORITY_EMOJI.get(priority, "⚪")
        logger.info(f"\n{emoji} {priority.upper()} ({len(recs)}):")
        for rec in recs:
            self._log_single_recommendation(rec)

    def _log_single_recommendation(self, rec: Recommendation) -> None:
        logger.info(f"\n   [{rec.category.upper()}] {rec.summary}")
        if rec.effort_minutes > 0 or rec.impact_score > 0:
            effort_str = f"{rec.effort_minutes} min" if rec.effort_minutes > 0 else "N/A"
            impact_str = f"+{rec.impact_score}" if rec.impact_score > 0 else "N/A"
            logger.info(f"   ⏱️  Effort: {effort_str}  |  📊 Impact: {impact_str}")

        if rec.proposed_fix:
            logger.info(f"   📋 Action: {rec.proposed_fix}")
        if rec.guide_command:
            logger.info(f"   📘 Local Guide: {rec.guide_command} (context {rec.guide_version or 'current'})")
        if rec.guide_url:
            logger.info(f"   🌐 Online Guide: {rec.guide_url}")

        if rec.code_example:
            lines = rec.code_example.strip().split("\n")
            preview = "\n".join(lines[:3])
            logger.info(f"   💻 Example:\n      {preview}")
            if len(lines) > 3:
                logger.info("      [... see guide for full example]")

    def _log_metrics(self, metrics: ExtendedTestMetrics) -> None:
        """Format and log metrics to console with structured output"""
        logger.info("")
        logger.info("🔍 CODE QUALITY METRICS:")

        self._log_coverage(metrics.coverage)
        self._log_dependencies(metrics.dependency)
        self._log_security(metrics.security)

        if metrics.sbom.components_count > 0:
            logger.info("")
            logger.info("📋 SBOM METRICS:")
            logger.info(f"   Components: {metrics.sbom.components_count}")
            if metrics.sbom.missing_licenses > 0:
                logger.info(f"   Missing licenses: {metrics.sbom.missing_licenses}")

        self._log_packaging(metrics.packaging)

        logger.info("")
        logger.info("⚡ PERFORMANCE:")
        logger.info(f"   Total analysis: {metrics.performance.total_analysis_ms:.0f}ms")

        self._log_complexity(metrics.complexity)
        self._log_recommendations(metrics.recommendations)

        logger.info("")
        logger.info(_get_separator(42))


# Async helper for synchronous contexts
def run_extended_tests(
    workspace_root: Path,
    config: dict | None = None,
) -> ExtendedTestMetrics | None:
    """Synchronous wrapper for running extended tests (convenience function).

    This function provides a synchronous interface to the async ExtendedTestRunner.
    It manages the asyncio event loop automatically, making it easy to call from
    non-async contexts like CLI commands or scripts.

    Args:
        workspace_root: Root directory of the project to analyze
        config: Optional configuration dict from manifestguard.yaml/json

    Returns:
        ExtendedTestMetrics: Complete metrics object, or None if disabled/failed

    Example:
        >>> from pathlib import Path
        >>> metrics = run_extended_tests(Path("/project"))
        >>> if metrics:
        ...     print(f"Coverage: {metrics.coverage.unit_percent}%")
        Coverage: 87.5%

    Note:
        - Automatically creates/reuses asyncio event loop
        - Blocks until execution completes
        - For async contexts, use ExtendedTestRunner.run() directly

    """
    runner = ExtendedTestRunner(workspace_root, config)

    if not runner.is_enabled():
        return None

    # Run in async context
    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)

    return loop.run_until_complete(runner.run())
