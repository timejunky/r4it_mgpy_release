"""Pure coverage file reader utilities extracted from coverage_collection.py."""

from __future__ import annotations

import json
from pathlib import Path


def _read_unit_percent_from_coverage_json(coverage_json: Path) -> float | None:
    percent, _ = _read_coverage_json_totals(coverage_json)
    return percent


def _read_coverage_json_totals(coverage_json: Path) -> tuple[float | None, int | None]:
    try:
        cov_data = json.loads(coverage_json.read_text(encoding="utf-8"))
        totals = cov_data.get("totals", {})
        percent = float(
            totals.get("percent_covered", totals.get("percent_covered_display", 0.0)),
        )
        num_statements_raw = totals.get("num_statements")
        num_statements = (
            int(num_statements_raw)
            if isinstance(num_statements_raw, (int, float))
            else None
        )
        return percent, num_statements
    except Exception:
        return None, None


def _read_coverage_json_covered_lines(coverage_json: Path) -> int | None:
    try:
        cov_data = json.loads(coverage_json.read_text(encoding="utf-8"))
        covered_lines_raw = cov_data.get("totals", {}).get("covered_lines")
        if isinstance(covered_lines_raw, (int, float)):
            return int(covered_lines_raw)
    except Exception:
        return None
    return None


def _coverage_json_has_meaningful_datapoint(
    coverage_json: Path,
    total_tests: int | None,
) -> bool:
    percent, num_statements = _read_coverage_json_totals(coverage_json)
    if percent is None:
        return False
    covered_lines = _read_coverage_json_covered_lines(coverage_json)
    if isinstance(num_statements, int):
        if num_statements > 0:
            return bool(isinstance(covered_lines, int) and covered_lines > 0)
        return percent > 0.0 or bool(total_tests and total_tests > 0)
    return percent > 0.0 or bool(total_tests and total_tests > 0)


def _read_unit_percent_from_coverage_xml(coverage_xml: Path) -> float | None:
    """Extract line coverage percentage from a coverage.xml (Cobertura format).

    Supports both ``line-rate`` attribute (float 0–1) and the
    ``lines-covered`` / ``lines-valid`` pair as a fallback.
    """
    try:
        import xml.etree.ElementTree as ET  # stdlib, no extra dep  # noqa: N814

        tree = ET.parse(str(coverage_xml))
        root = tree.getroot()
        line_rate = root.attrib.get("line-rate")
        if line_rate is not None:
            return float(line_rate) * 100.0
        # Fallback: compute from absolute line counts
        valid = root.attrib.get("lines-valid")
        covered = root.attrib.get("lines-covered")
        if valid and covered and int(valid) > 0:
            return float(covered) / float(valid) * 100.0
    except Exception:
        pass
    return None
