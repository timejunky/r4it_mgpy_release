"""SmartCheck timing and cache helpers for extended metrics collection."""

from __future__ import annotations

import dataclasses
import json
import logging
import shutil
import subprocess
import time
from collections.abc import Callable
from datetime import datetime, timezone
from typing import Any

from .metrics_models import BugfixMetrics, ComplexityMetrics, ExtendedTestMetrics, SecurityMetrics
from .smartcheck_cache import SmartCheckCache as _SmartCheckCache

logger = logging.getLogger(__name__)


class _MetricsSmartCheckMixin:
    """Mixin with SmartCheck enablement, timing, and cache-aware step helpers."""

    def _smartcheck_enabled(self) -> bool:
        """Return True when SmartCheck timing export is enabled by config."""
        root_cfg = self.config.get("smartCheck")
        if isinstance(root_cfg, dict) and isinstance(root_cfg.get("enabled"), bool):
            return bool(root_cfg.get("enabled"))

        ext_cfg = self.config.get("extendedTest")
        if isinstance(ext_cfg, dict):
            smart_cfg = ext_cfg.get("smartCheck")
            if isinstance(smart_cfg, dict) and isinstance(smart_cfg.get("enabled"), bool):
                return bool(smart_cfg.get("enabled"))

        return False

    def _get_sc_cache(self) -> _SmartCheckCache | None:
        """Return SmartCheckCache instance when SmartCheck is enabled."""
        if not self._smartcheck_enabled():
            return None
        if self._sc_cache is None:
            self._sc_cache = _SmartCheckCache(self.workspace_root)
        return self._sc_cache

    def _sc_fingerprints(self) -> tuple[str, str] | None:
        """Return (workspace_fp, config_fp) pair, memoised for this run."""
        cache = self._get_sc_cache()
        if cache is None:
            return None
        if self._sc_ws_fp is None:
            self._sc_ws_fp = cache.workspace_fingerprint()
        if self._sc_cfg_fp is None:
            self._sc_cfg_fp = _SmartCheckCache.config_fingerprint(self.config)
        return self._sc_ws_fp, self._sc_cfg_fp

    async def _run_timed_step(
        self,
        step_name: str,
        step_fn: Callable[[ExtendedTestMetrics, Callable | None], Any],
        metrics: ExtendedTestMetrics,
        progress: Callable | None,
    ) -> None:
        """Run a step and capture deterministic timing metadata for SmartCheck."""
        step_start = time.time()
        status = "ok"
        error_msg: str | None = None

        try:
            await step_fn(metrics, progress)
        except Exception as exc:
            status = "error"
            error_msg = str(exc)
            raise
        finally:
            elapsed_ms = (time.time() - step_start) * 1000
            entry: dict[str, Any] = {
                "durationMs": round(elapsed_ms, 3),
                "status": status,
            }
            if error_msg:
                entry["error"] = error_msg
            hint = self._sc_cache_hints.get(step_name)
            if hint:
                entry.update(hint)
            self._smartcheck_stage_timings[step_name] = entry

    def _write_smartcheck_timing_artifact(
        self,
        total_ms: float,
        focus: set[str] | None,
        run_status: str,
        run_error: str | None = None,
    ) -> None:
        """Write SmartCheck timing artifact without changing report contract."""
        if not self._smartcheck_enabled():
            return

        out_dir = self.workspace_root / ".manifestguard"
        out_dir.mkdir(parents=True, exist_ok=True)
        out_file = out_dir / "smartcheck-timing-latest.json"

        payload: dict[str, Any] = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "workspaceRoot": str(self.workspace_root),
            "status": run_status,
            "totalAnalysisMs": round(total_ms, 3),
            "focus": sorted(focus) if focus else [],
            "stages": dict(sorted(self._smartcheck_stage_timings.items())),
        }
        if run_error:
            payload["error"] = run_error

        out_file.write_text(json.dumps(payload, indent=2), encoding="utf-8")

    async def _step_security(self, metrics: ExtendedTestMetrics, progress: Callable | None) -> None:
        if progress:
            progress("Step 3/9: Scanning security indicators…")
        fps = self._sc_fingerprints()
        if fps is not None:
            ws_fp, cfg_fp = fps
            cached, miss_reason = self._get_sc_cache().get("security", ws_fp, cfg_fp)  # type: ignore[union-attr]
            if cached is not None:
                try:
                    metrics.security = SecurityMetrics(**cached)
                    self._sc_cache_hints["security"] = {"cacheHit": True}
                    return
                except Exception as exc:
                    logger.debug("SmartCheck: security cache reconstruct failed: %s", exc)
                    miss_reason = "cache-reconstruct-error"
            self._sc_cache_hints["security"] = {"cacheHit": False, "missReason": miss_reason}
        metrics.security = await self._collect_security_metrics()
        if fps is not None:
            ws_fp, cfg_fp = fps
            self._get_sc_cache().put("security", ws_fp, cfg_fp, dataclasses.asdict(metrics.security))  # type: ignore[union-attr]

    async def _step_complexity(
        self, metrics: ExtendedTestMetrics, progress: Callable | None
    ) -> None:
        if progress:
            progress("Step 8/9: Analyzing code complexity…")
        should_run, reason = self._should_run_expensive_step("complexity")
        if not should_run:
            if progress:
                progress(f"Skipped complexity ({reason})")
            metrics.complexity = ComplexityMetrics()
            return

        fps = self._sc_fingerprints()
        if fps is not None:
            ws_fp, cfg_fp = fps
            cached, miss_reason = self._get_sc_cache().get("complexity", ws_fp, cfg_fp)  # type: ignore[union-attr]
            if cached is not None:
                try:
                    metrics.complexity = ComplexityMetrics(**cached)
                    self._sc_cache_hints["complexity"] = {"cacheHit": True}
                    return
                except Exception as exc:
                    logger.debug("SmartCheck: complexity cache reconstruct failed: %s", exc)
                    miss_reason = "cache-reconstruct-error"
            self._sc_cache_hints["complexity"] = {"cacheHit": False, "missReason": miss_reason}
        metrics.complexity = await self._collect_complexity_metrics()
        if fps is not None:
            ws_fp, cfg_fp = fps
            self._get_sc_cache().put("complexity", ws_fp, cfg_fp, dataclasses.asdict(metrics.complexity))  # type: ignore[union-attr]

    def _git_head_fingerprint(self) -> str:
        """Return a fingerprint based on git HEAD commit and current month."""
        now = datetime.now(timezone.utc)
        month_label = now.strftime("%Y-%m")
        head = ""
        try:
            git_path = shutil.which("git")
            if git_path:
                proc = subprocess.run(  # noqa: S603
                    [git_path, "rev-parse", "HEAD"],
                    check=False,
                    cwd=self.workspace_root,
                    capture_output=True,
                    text=True,
                    timeout=5,
                )
                if proc.returncode == 0:
                    head = proc.stdout.strip()
        except Exception:
            pass

        import hashlib as _hl  # noqa: PLC0415

        return _hl.sha256(f"{month_label}:{head}".encode()).hexdigest()

    async def _step_bugfixes(self, metrics: ExtendedTestMetrics, progress: Callable | None) -> None:
        if progress:
            progress("Step 9/9: Mining bugfix history…")
        should_run, reason = self._should_run_expensive_step("bugfixes")
        if not should_run:
            if progress:
                progress(f"Skipped bugfix history ({reason})")
            metrics.bugfixes = BugfixMetrics()
            return

        fps = self._sc_fingerprints()
        git_fp = self._git_head_fingerprint() if fps is not None else ""
        if fps is not None:
            _, cfg_fp = fps
            cached, miss_reason = self._get_sc_cache().get("bugfixes", git_fp, cfg_fp)  # type: ignore[union-attr]
            if cached is not None:
                try:
                    metrics.bugfixes = BugfixMetrics(**cached)
                    self._sc_cache_hints["bugfixes"] = {"cacheHit": True}
                    return
                except Exception as exc:
                    logger.debug("SmartCheck: bugfixes cache reconstruct failed: %s", exc)
                    miss_reason = "cache-reconstruct-error"
            self._sc_cache_hints["bugfixes"] = {"cacheHit": False, "missReason": miss_reason}
        metrics.bugfixes = await self._collect_bugfix_metrics()
        if fps is not None:
            _, cfg_fp = fps
            self._get_sc_cache().put("bugfixes", git_fp, cfg_fp, dataclasses.asdict(metrics.bugfixes))  # type: ignore[union-attr]

    def _attach_smartcheck_report_meta(self, metrics: ExtendedTestMetrics) -> None:
        """Attach SmartCheck diagnostics to report metadata when enabled."""
        if not self._smartcheck_enabled() or not self._sc_cache_hints:
            return

        hits = sum(1 for h in self._sc_cache_hints.values() if h.get("cacheHit") is True)
        misses = sum(1 for h in self._sc_cache_hints.values() if h.get("cacheHit") is False)
        invalidate_reasons = sorted(
            {h["missReason"] for h in self._sc_cache_hints.values() if h.get("missReason")}
        )
        meta: dict[str, Any] = {
            "enabled": True,
            "cacheHits": hits,
            "cacheMisses": misses,
        }
        if invalidate_reasons:
            meta["invalidateReasons"] = invalidate_reasons
        if self._sc_ws_fp:
            meta["workspaceFingerprintPrefix"] = self._sc_ws_fp[:12]
        metrics.smart_check = meta