"""Console/terminal helpers for extended runner output formatting."""

from __future__ import annotations

import os
import sys

try:
    import ctypes
except ImportError:  # pragma: no cover - Windows-specific optional import
    ctypes = None  # type: ignore[assignment]


def _supports_unicode() -> bool:
    """Detect if terminal supports UTF-8/Unicode output."""
    if os.getenv("MANIFESTGUARD_ASCII", "").lower() == "true":
        return False

    if sys.platform == "win32" and ctypes is not None:
        try:
            code_page = ctypes.windll.kernel32.GetConsoleOutputCP()
            if code_page in (65001, 1200, 1201):
                return True
        except AttributeError:
            return False
        except OSError:  # pragma: no cover - defensive guard
            return False

    lang = os.getenv("LANG", "")
    if "UTF-8" in lang.upper() or "UTF8" in lang.upper():
        return True

    encoding = getattr(sys.stdout, "encoding", "").upper()
    return "UTF" in encoding


def _get_separator(length: int = 70) -> str:
    """Get terminal-appropriate separator line."""
    char = "━" if _supports_unicode() else "="
    return char * length
