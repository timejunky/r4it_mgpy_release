"""Quality score calculation helpers for extended metrics."""

from .metrics_models import ExtendedTestMetrics


def calculate_coverage_penalty(coverage_percent: float) -> float:
    """Calculate coverage penalty (0-40 points)."""
    if coverage_percent >= 80:
        return 0.0
    return (80 - coverage_percent) / 80 * 40


def calculate_security_penalty(metrics: ExtendedTestMetrics) -> float:
    """Calculate security penalty (0-30 points)."""
    penalty = 0.0

    if metrics.dependency.vulnerable_critical > 0:
        penalty += 30
    elif metrics.dependency.vulnerable_high > 0:
        penalty += min(20, metrics.dependency.vulnerable_high * 5)

    if metrics.security.unsafe_exec_count > 0:
        penalty += min(10, metrics.security.unsafe_exec_count * 2)

    if metrics.security.hardcoded_secrets > 0:
        penalty += min(10, metrics.security.hardcoded_secrets * 3)

    return min(30, penalty)


def calculate_dependency_penalty(outdated_count: int) -> float:
    """Calculate dependency penalty (0-15 points)."""
    if outdated_count > 20:
        return 15.0
    if outdated_count > 10:
        return 10.0
    if outdated_count > 5:
        return 5.0
    return 0.0


def calculate_quality_score(metrics: ExtendedTestMetrics) -> float:
    """Calculate overall quality score (0-100) based on weighted metrics."""
    score = 100.0

    if metrics.coverage.unit_measured:
        score -= calculate_coverage_penalty(metrics.coverage.unit_percent)
    score -= calculate_security_penalty(metrics)
    score -= calculate_dependency_penalty(metrics.dependency.outdated_count)

    if metrics.complexity and metrics.complexity.violations_count > 0:
        score -= min(10, metrics.complexity.violations_count * 2)

    if metrics.coverage.failing_tests > 0:
        score -= 5

    if metrics.coverage.unit_measured and metrics.coverage.unit_percent >= 90:
        score += 5
    if metrics.packaging.has_py_typed:
        score += 2

    return round(max(0.0, min(100.0, score)), 1)
