"""Extended Test Mode - Metrics Collection Module

This module provides comprehensive quality metrics collection for Python packages,
analyzing 8 critical domains to support AI-driven recommendations for test and
code improvements.

Metric Categories:
    - Coverage: Test breadth, gaps, and untested modules
    - Dependency: Package health, vulnerabilities, and conflicts
    - Security: Risk patterns (eval, secrets, weak crypto)
    - SBOM: Software Bill of Materials completeness
    - Packaging: Distribution quality and metadata
    - Performance: Analysis timing and bottlenecks
    - Policy: Whitelist/blacklist compliance
    - License: SPDX compliance and consistency

Privacy:
    All metrics are collected locally. No code is transmitted to external
    services without explicit user consent. Paths are anonymized in reports.

Usage:
    collector = MetricsCollector(workspace_root)
    metrics = await collector.collect_metrics()
    recommendations = metrics.recommendations
"""

import asyncio
import logging
import sys
import time
import traceback
from collections.abc import Callable, Iterable
from concurrent.futures import Future, ThreadPoolExecutor
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from manifestguard.validation.inline_markers import is_line_suppressed
from manifestguard.core.test_config_helper import (
    ThresholdGateController as _ThresholdGateController,
    ThresholdGateDecision as _ThresholdGateDecision,
)

from .complexity import ComplexityAnalyzer
from .coverage_collection import collect_coverage_metrics
from .dependency_collection import (
    _resolve_project_python_executable,
    collect_dependency_metrics,
)
from .documentation_coverage import analyze_documentation
from .metrics_history_export import export_metrics_history as _export_metrics_history
from .metrics_bugfix_collection import collect_bugfix_metrics as _collect_bugfix_metrics
from .metrics_complexity_collection import (
    collect_complexity_metrics as _collect_complexity_metrics,
    read_complexity_settings_from_manifest as _read_complexity_settings_from_manifest,
)
from .metrics_security_collection import collect_security_metrics as _collect_security_metrics
from .metrics_models import (
    BugfixMetrics,
    ComplexityMetrics,
    CoverageMetrics,
    DependencyMetrics,
    ExtendedTestMetrics,
    LicenseMetrics,
    PackagingMetrics,
    PerformanceMetrics,
    PolicyMetrics,
    Recommendation,
    SBOMMetrics,
    SecurityMetrics,
)
from .metrics_scoring import calculate_quality_score
from .metrics_smartcheck_mixin import _MetricsSmartCheckMixin
from .packaging_collection import collect_packaging_metrics
from .policy_collection import collect_policy_metrics
from .sbom_collection import collect_sbom_metrics
from .scan_utils import load_ignore_patterns, should_skip_path
from .style_checks import check_pep8_violations, check_style_consistency
from .typing_coverage import analyze_type_hints
from .weak_crypto_check import check_weak_crypto
from manifestguard.validation.runtime_metrics import run_manifest_validation_with_metrics

logger = logging.getLogger(__name__)
RECOMMENDATION_ACK_FILE = ".manifestguard/recommendation-acks.json"
_INSTALLED_PACKAGES_EXECUTOR = ThreadPoolExecutor(
    max_workers=1,
    thread_name_prefix="mgpy-installed-packages",
)


from .metrics_recommendations_core import _MetricsRecommendationsCoreMixin
from .metrics_recommendations_quality import _MetricsRecommendationsQualityMixin



class MetricsCollector(
    _MetricsSmartCheckMixin,
    _MetricsRecommendationsCoreMixin,
    _MetricsRecommendationsQualityMixin,
):
    """Collects extended test metrics from Python project workspace.

    This class orchestrates collection of 8 metric categories and generates
    AI-driven recommendations based on thresholds and patterns. All collection
    is done locally with error isolation per category.

    Args:
        workspace_root: Path to project root containing pyproject.toml/setup.py

    Example:
        collector = MetricsCollector(Path('/path/to/project'))
        metrics = await collector.collect_metrics()

        # Access specific metrics
        if metrics.coverage.unit_percent < 70:
            print('Low test coverage!')

        # Review recommendations
        for rec in metrics.recommendations:
            if rec.priority == 'critical':
                print(f'CRITICAL: {rec.summary}')

    """

    def __init__(
        self,
        workspace_root: Path,
        config: dict[str, Any] | None = None,
        gate_counts: tuple[int, int, int] | None = None,
        python_override: str | None = None,
    ):
        """Initialize metrics collector.

        Args:
            workspace_root: Absolute path to project root directory
            python_override: Explicit Python interpreter path for internal
                subprocesses (coverage, dependency collection). Passed via
                ``--project-python`` on the CLI.

        """
        self.workspace_root = workspace_root
        self.start_time = time.time()
        self.config: dict[str, Any] = config or {}
        self.gate_counts = gate_counts
        self.python_override = python_override
        self._threshold_gate_controller = _ThresholdGateController(self.config)
        self._threshold_gate_decisions: dict[str, _ThresholdGateDecision] = {}
        self._threshold_gate_blocked_tests: set[str] = set()
        self._threshold_gate_details: dict[str, str] = {}
        self._installed_packages_task: Future[list[dict[str, str]]] | None = None
        self._smartcheck_stage_timings: dict[str, dict[str, Any]] = {}
        self._sc_cache_hints: dict[str, dict[str, Any]] = {}
        self._sc_cache = None
        self._sc_ws_fp: str | None = None
        self._sc_cfg_fp: str | None = None

    def _should_run_expensive_step(self, test_name: str) -> tuple[bool, str | None]:
        errors: int | None
        warnings: int | None
        info: int | None
        if self.gate_counts is None:
            errors = warnings = info = None
        else:
            errors, warnings, info = self.gate_counts

        decision = self._threshold_gate_controller.evaluate(
            test_name=test_name,
            errors=errors,
            warnings=warnings,
            info=info,
        )
        self._threshold_gate_decisions[test_name] = decision

        if decision.mode == "threshold-blocked":
            self._threshold_gate_blocked_tests.add(test_name)
            self._threshold_gate_details[test_name] = decision.message

        if not decision.should_run:
            return False, decision.message

        return True, None

    async def _step_coverage(self, metrics: ExtendedTestMetrics, progress: Callable | None) -> None:
        if progress:
            progress("Step 1/9: Collecting coverage metrics…")
        should_run, reason = self._should_run_expensive_step("coverage")
        if not should_run:
            if progress:
                progress(f"Skipped coverage ({reason})")
            metrics.coverage = CoverageMetrics()
            return

        metrics.coverage = await self._collect_coverage_metrics(progress=progress)
        if progress and metrics.coverage.total_tests:
            progress(f"Discovered {metrics.coverage.total_tests} tests")

    async def _step_dependency(
        self, metrics: ExtendedTestMetrics, progress: Callable | None
    ) -> None:
        if progress:
            progress("Step 2/9: Evaluating dependency health…")
        step_start = time.time()
        metrics.dependency = await self._collect_dependency_metrics()
        metrics.performance.dependency_graph_ms = (time.time() - step_start) * 1000

    async def _step_sbom(self, metrics: ExtendedTestMetrics, progress: Callable | None) -> None:
        if progress:
            progress("Step 4/9: Assessing SBOM completeness…")
        metrics.sbom = await self._collect_sbom_metrics()

    async def _step_packaging(
        self, metrics: ExtendedTestMetrics, progress: Callable | None
    ) -> None:
        if progress:
            progress("Step 5/9: Checking packaging quality…")
        metrics.packaging = await self._collect_packaging_metrics()

    async def _step_policy(self, metrics: ExtendedTestMetrics, progress: Callable | None) -> None:
        if progress:
            progress("Step 6/9: Reviewing policy compliance…")
        metrics.policy = await self._collect_policy_metrics()

    async def _step_license(self, metrics: ExtendedTestMetrics, progress: Callable | None) -> None:
        if progress:
            progress("Step 7/9: Verifying license metadata…")
        metrics.license = await self._collect_license_metrics()

    # Dispatch tables for focused runs.
    # Maps each focus key to the step names that run in parallel (gather) and sequentially.
    # Adding a new focus key only requires updating these two dicts.
    _FOCUS_PARALLEL: dict[str, list[str]] = {
        "security": ["security"],
        "license": ["license"],
        "quality": ["policy"],
    }
    _FOCUS_SEQUENTIAL: dict[str, list[str]] = {
        "quality": ["complexity"],
    }

    def _build_step_fns(self) -> dict[str, Callable]:
        """Return a mapping of step key → bound coroutine for this collector instance."""
        return {
            "coverage": self._step_coverage,
            "dependency": self._step_dependency,
            "security": self._step_security,
            "sbom": self._step_sbom,
            "packaging": self._step_packaging,
            "policy": self._step_policy,
            "license": self._step_license,
            "complexity": self._step_complexity,
            "bugfixes": self._step_bugfixes,
        }

    async def _collect_all_metric_categories(
        self,
        metrics: ExtendedTestMetrics,
        progress: Callable | None,
    ) -> None:
        """Collect metrics from all 9 categories with progress reporting."""
        await self._run_timed_step("coverage", self._step_coverage, metrics, progress)
        await asyncio.gather(
            self._run_timed_step("dependency", self._step_dependency, metrics, progress),
            self._run_timed_step("security", self._step_security, metrics, progress),
            self._run_timed_step("sbom", self._step_sbom, metrics, progress),
            self._run_timed_step("packaging", self._step_packaging, metrics, progress),
            self._run_timed_step("policy", self._step_policy, metrics, progress),
            self._run_timed_step("license", self._step_license, metrics, progress),
        )
        await self._run_timed_step("complexity", self._step_complexity, metrics, progress)
        await self._run_timed_step("bugfixes", self._step_bugfixes, metrics, progress)

    def _finalize_full_run_metrics(
        self,
        metrics: ExtendedTestMetrics,
        progress: Callable | None,
    ) -> None:
        """Generate recommendations and quality score after a full (non-focused) collection run."""
        if progress:
            progress("Generating AI recommendations…")
        metrics.recommendations = self._generate_recommendations(metrics)

        if self._threshold_gate_decisions:
            for test_name in sorted(self._threshold_gate_decisions, reverse=True):
                decision = self._threshold_gate_decisions[test_name]
                if decision.mode == "allowed":
                    continue

                label = test_name.replace("_", " ").strip().title()
                if decision.mode == "threshold-blocked":
                    rec_id = f"threshold-gate-blocked-{test_name}"
                    summary = (
                        f"ℹ️ {label} metrics not yet run — current error/warning/info "
                        "threshold is not satisfied."
                    )
                    proposed_fix = (
                        "Solange der konfigurierte Threshold fuer Fehler/Warnungen/Infos "
                        "nicht erreicht ist, fuehrt ManifestGuard diesen Test nicht aus. "
                        "Erst die aktuellen Findings reduzieren und danach `manifestguard check --extended` "
                        "erneut ausfuehren."
                        + (f" Gate-Details: {decision.message}" if decision.message else "")
                    )
                elif decision.mode == "deep-analysis-disabled":
                    rec_id = f"threshold-gate-deep-analysis-disabled-{test_name}"
                    summary = f"ℹ️ {label} metrics skipped — deep analysis is disabled by config."
                    proposed_fix = (
                        "Setze `testConfig."
                        f"{test_name}.deepAnalysisMode` auf `true`, wenn dieser Check laufen soll."
                        + (f" Gate-Details: {decision.message}" if decision.message else "")
                    )
                elif decision.mode == "disabled":
                    rec_id = f"threshold-gate-disabled-{test_name}"
                    summary = f"ℹ️ {label} metrics skipped — this check is disabled by config."
                    proposed_fix = (
                        "Setze `testConfig."
                        f"{test_name}.enabled` auf `true`, wenn dieser Check laufen soll."
                        + (f" Gate-Details: {decision.message}" if decision.message else "")
                    )
                else:
                    continue

                metrics.recommendations.insert(
                    0,
                    Recommendation(
                        category="gating",
                        id=rec_id,
                        priority="low",
                        summary=summary,
                        proposed_fix=proposed_fix,
                        confidence=0.95,
                        effort_minutes=0,
                        impact_score=0,
                    ),
                )

        # Info-context for configurable threshold controls.
        dup = metrics.policy.duplication if isinstance(metrics.policy.duplication, dict) else {}
        if dup.get("enabled") is True:
            stats = dup.get("stats") if isinstance(dup.get("stats"), dict) else {}
            reported_blocks = stats.get("reportedBlocks")
            scanned_files = stats.get("scannedFiles")
            cfg = stats.get("config") if isinstance(stats.get("config"), dict) else {}

            if isinstance(reported_blocks, int) and isinstance(scanned_files, int):
                if scanned_files > 0 and reported_blocks == 0:
                    window_lines = cfg.get("windowLines")
                    min_occurrences = cfg.get("minOccurrences")
                    metrics.recommendations.append(
                        Recommendation(
                            category="policy",
                            id="duplication-below-threshold-info",
                            priority="low",
                            summary=(
                                "Duplication currently below configured detection threshold."
                            ),
                            proposed_fix=(
                                "No duplication blocks were reported with current settings "
                                f"(windowLines={window_lines}, minOccurrences={min_occurrences}). "
                                "If you want stricter detection, lower these values in "
                                "manifestguard.json under duplicationDetection."
                            ),
                            confidence=0.95,
                            effort_minutes=2,
                            impact_score=0,
                        )
                    )

        metrics.quality_score = calculate_quality_score(metrics)

    async def collect_metrics(
        self,
        progress: Callable | None = None,
        focus: tuple[str, ...] | None = None,
    ) -> ExtendedTestMetrics:
        """Collect all metrics across 8 categories with error isolation.

        Each metric category is collected independently. If one category fails,
        others continue and the error is logged to metrics.errors. This ensures
        partial results are always available.

        Returns:
            ExtendedTestMetrics containing all collected data and recommendations

        Raises:
            Never raises. All exceptions are caught and logged to metrics.errors

        Performance:
            Typical execution: 2-5 seconds for medium projects
            Large projects (1000+ files): 10-30 seconds

        """
        metrics = ExtendedTestMetrics(timestamp=datetime.now(timezone.utc).isoformat())
        perf_start = time.time()
        run_error: str | None = None
        run_status = "ok"

        normalized_focus: set[str] | None = None
        if focus:
            normalized_focus = {str(f).lower().strip() for f in focus if str(f).strip()}
            # Defensive: silently ignore unknown values instead of failing the run.
            normalized_focus &= {"security", "quality", "license"}
            if not normalized_focus:
                normalized_focus = None

        try:
            validation_metrics = run_manifest_validation_with_metrics(self.workspace_root)
            metrics.performance.manifest_parse_ms = validation_metrics.manifest_parse_ms
            metrics.performance.rule_engine_ms = validation_metrics.rule_engine_ms

            # If not provided by the caller, derive gate counts from the current
            # validation run (always available here).
            if self.gate_counts is None:
                vr = validation_metrics.result
                self.gate_counts = (
                    int(getattr(vr, "error_count", 0)),
                    int(getattr(vr, "warning_count", 0)),
                    int(getattr(vr, "info_count", 0)),
                )

            if normalized_focus is None:
                self._start_installed_packages_prefetch()
                await self._collect_all_metric_categories(metrics, progress)
                metrics.performance.total_analysis_ms = (time.time() - perf_start) * 1000
                self._finalize_full_run_metrics(metrics, progress)
            else:
                if progress:
                    progress(f"Focused run: {', '.join(sorted(normalized_focus))}")

                step_fns = self._build_step_fns()

                parallel_keys: list[str] = []
                sequential_keys: list[str] = []
                seen_parallel: set[str] = set()
                seen_sequential: set[str] = set()
                for f in normalized_focus:
                    for k in self._FOCUS_PARALLEL.get(f, []):
                        if k not in seen_parallel:
                            seen_parallel.add(k)
                            parallel_keys.append(k)
                    for k in self._FOCUS_SEQUENTIAL.get(f, []):
                        if k not in seen_sequential:
                            seen_sequential.add(k)
                            sequential_keys.append(k)

                if parallel_keys:
                    await asyncio.gather(
                        *(
                            asyncio.create_task(
                                self._run_timed_step(k, step_fns[k], metrics, progress)
                            )
                            for k in parallel_keys
                        )
                    )
                for k in sequential_keys:
                    await self._run_timed_step(k, step_fns[k], metrics, progress)

                metrics.performance.total_analysis_ms = (time.time() - perf_start) * 1000
                metrics.recommendations = []
                metrics.quality_score = 0.0

        except Exception as exc:  # pragma: no cover - defensive guard
            run_status = "error"
            run_error = str(exc)
            logger.error("Extended metrics collection failed: %s", exc)
            logger.error(traceback.format_exc())
            metrics.errors.append(f"Collection failed: {exc!s}")

        total_ms = (time.time() - perf_start) * 1000
        if metrics.performance.total_analysis_ms <= 0:
            metrics.performance.total_analysis_ms = total_ms
        self._write_smartcheck_timing_artifact(
            total_ms=metrics.performance.total_analysis_ms,
            focus=normalized_focus,
            run_status=run_status,
            run_error=run_error,
        )
        self._attach_smartcheck_report_meta(metrics)

        return metrics

    # Intentionally complex for robust async coverage collection with multiple fallback paths
    # manifestguard-ignore-next-line: COMPLEXITY
    async def _collect_coverage_metrics(self, progress: Callable | None = None) -> CoverageMetrics:
        """Collect test coverage data from pytest/coverage (non-blocking via asyncio)."""
        return await collect_coverage_metrics(
            self.workspace_root,
            progress=progress,
            python_override=self.python_override,
        )

    async def _collect_dependency_metrics(
        self, *, deep_analysis_mode: bool = True
    ) -> DependencyMetrics:
        """Collect dependency health data."""
        installed_packages = await self._get_installed_packages_snapshot()
        return await collect_dependency_metrics(
            self.workspace_root,
            deep_analysis_mode=deep_analysis_mode,
            installed_packages=installed_packages,
            python_override=self.python_override,
        )

    # Intentionally complex for comprehensive security scanning with inline-suppression support
    # manifestguard-ignore-next-line: COMPLEXITY
    async def _collect_security_metrics(self) -> SecurityMetrics:
        """Collect security risk indicators via static analysis"""
        return await asyncio.to_thread(_collect_security_metrics, self.workspace_root)

    async def _collect_sbom_metrics(self) -> SBOMMetrics:
        """Collect SBOM completeness data."""
        installed_packages = await self._get_installed_packages_snapshot()
        return await collect_sbom_metrics(self.workspace_root, installed_packages=installed_packages)

    def _collect_installed_packages_snapshot_sync(self) -> list[dict[str, str]]:
        from .venv_packages_snapshot import get_venv_packages  # noqa: PLC0415

        try:
            project_python = _resolve_project_python_executable(
                self.workspace_root,
                python_override=self.python_override,
            )
            return get_venv_packages(
                Path(project_python),
                timeout_seconds=15,
            )
        except Exception:
            return []

    def _start_installed_packages_prefetch(self) -> None:
        if self._installed_packages_task is None:
            self._installed_packages_task = _INSTALLED_PACKAGES_EXECUTOR.submit(
                self._collect_installed_packages_snapshot_sync,
            )

    async def _get_installed_packages_snapshot(self) -> list[dict[str, str]]:
        """Return installed packages snapshot for this run.

        This de-duplicates `pip list --format=json` between dependency and SBOM
        collection. The snapshot is best-effort; failures return an empty list.
        """
        if self._installed_packages_task is None:
            self._start_installed_packages_prefetch()
        return await asyncio.wrap_future(self._installed_packages_task)

    async def _collect_packaging_metrics(self) -> PackagingMetrics:
        """Collect packaging quality indicators."""
        return await collect_packaging_metrics(self.workspace_root)

    async def _collect_policy_metrics(self) -> PolicyMetrics:
        """Collect policy enforcement status."""
        return await collect_policy_metrics(self.workspace_root)

    async def _collect_license_metrics(self) -> LicenseMetrics:
        """Collect license consistency data"""
        def _build_license_metrics() -> LicenseMetrics:
            metrics = LicenseMetrics()

            license_files = ["LICENSE", "LICENSE.txt", "LICENSE.md"]
            metrics.license_file_missing = not any(
                (self.workspace_root / filename).exists() for filename in license_files
            )
            return metrics

        return await asyncio.to_thread(_build_license_metrics)

    def _read_complexity_settings_from_manifest(self) -> tuple[int, bool, str, int, int]:
        return _read_complexity_settings_from_manifest(self.workspace_root)

    async def _collect_complexity_metrics(self) -> ComplexityMetrics:
        """Collect cyclomatic complexity metrics using AST-based analyzer."""
        return await asyncio.to_thread(_collect_complexity_metrics, self.workspace_root)

    async def _collect_bugfix_metrics(self) -> BugfixMetrics:
        """Collect bugfix tracking metrics from git commit history.

        Analyzes commit messages since the start of the current month to detect
        bugfixes and calculate bugs per day (BPD) metric.

        Returns:
            BugfixMetrics with bugfix counts, BPD, and categorization

        """
        return await asyncio.to_thread(_collect_bugfix_metrics, self.workspace_root)

def export_metrics_history(
    workspace_root: Path,
    metrics: "ExtendedTestMetrics",
    mgpy_version: str | None = None,
    scan_space_summary: Any | None = None,
) -> None:
    """Export metrics history for dashboards.

    Kept here for backwards-compatible import path:
    `from manifestguard.extended.metrics import export_metrics_history`.
    """
    _export_metrics_history(workspace_root, metrics, mgpy_version, scan_space_summary)
