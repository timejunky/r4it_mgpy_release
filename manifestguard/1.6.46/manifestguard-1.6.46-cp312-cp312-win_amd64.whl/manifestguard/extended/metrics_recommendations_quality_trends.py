from __future__ import annotations

import json
import logging
from datetime import datetime

from .metrics import Recommendation
try:
    from .metrics_history_export import resolve_history_file_path as _resolve_history_file_path
except ImportError:
    _resolve_history_file_path = None  # type: ignore[assignment]

logger = logging.getLogger(__name__)


class _MetricsRecommendationsQualityTrendsMixin:
    def _recommend_cicd_setup(self) -> list[Recommendation]:
        recs: list[Recommendation] = []
        # ManifestGuard itself is the quality/CI tool: if it is configured,
        # the project already has automated quality enforcement.
        has_manifestguard = (
            (self.workspace_root / "manifestguard.json").exists()
            or (self.workspace_root / ".mgpy").exists()
        )
        has_github_actions = (self.workspace_root / ".github" / "workflows").exists()
        has_pre_commit = (self.workspace_root / ".pre-commit-config.yaml").exists()

        if has_manifestguard or has_github_actions or has_pre_commit:
            return recs

        recs.append(
            Recommendation(
                category="cicd",
                id="no-cicd-integration",
                priority="low",
                summary="No automated quality checks detected",
                proposed_fix=(
                    "Add ManifestGuard to your quality workflow: "
                    "run `manifestguard check --extended` as your quality gate. "
                    "Optionally pair with pre-commit hooks for local enforcement."
                ),
                confidence=0.90,
                effort_minutes=60,
                impact_score=7,
                code_example=(
                    "# Run ManifestGuard as your quality gate:\n"
                    "manifestguard check --extended --report report.json\n\n"
                    "# Optional: add pre-commit for local enforcement\n"
                    "# .pre-commit-config.yaml\n"
                    "repos:\n"
                    "  - repo: local\n"
                    "    hooks:\n"
                    "      - id: manifestguard\n"
                    "        name: ManifestGuard quality gate\n"
                    "        entry: manifestguard check\n"
                    "        language: system\n"
                    "        pass_filenames: false"
                ),
                guide_url="https://www.ready-4-it.com/mgpy/guides/quality-gate",
            ),
        )
        return recs

    def _recommend_baseline_visualization(self) -> list[Recommendation]:
        recs: list[Recommendation] = []
        baselines_dir = self.workspace_root / ".manifestguard" / "baselines"
        metrics_history = self.workspace_root / ".manifestguard" / "metrics-history.json"
        # Already tracked via metrics-history export — no separate action needed.
        if metrics_history.exists():
            return recs
        if baselines_dir.exists():
            baseline_files = list(baselines_dir.glob("*.json"))
            if len(baseline_files) > 1:
                recs.append(
                    Recommendation(
                        category="visualization",
                        id="baseline-tracking-ui",
                        priority="low",
                        summary=(
                            "Baseline tracking available but not visualized "
                            f"({len(baseline_files)} baselines stored)"
                        ),
                        proposed_fix=(
                            "Enable trend visualization with --show-trends flag or "
                            "use the dashboard. Track quality score changes, coverage "
                            "trends, and complexity evolution."
                        ),
                        confidence=0.85,
                        effort_minutes=90,
                        impact_score=5,
                        code_example=(
                            "# View trends in CLI\n"
                            "$ manifestguard check --extended --show-trends\n\n"
                            "# Or use the dashboard\n"
                            "$ manifestguard dashboard\n\n"
                            "# Compare with specific baseline\n"
                            "$ manifestguard check --extended --compare-to=v1.0.0\n\n"
                            "# Generate trend report\n"
                            "$ manifestguard trends --output=html --last=30days"
                        ),
                        guide_url="https://www.ready-4-it.com/mgpy/guides/trend-analysis",
                    ),
                )
        return recs

    @staticmethod
    def _extract_metrics_history_entries(payload: object) -> list[dict[str, object]]:
        if isinstance(payload, list):
            return [entry for entry in payload if isinstance(entry, dict)]
        if isinstance(payload, dict):
            entries = payload.get("entries")
            if isinstance(entries, list):
                return [entry for entry in entries if isinstance(entry, dict)]
            history = payload.get("history")
            if isinstance(history, list):
                return [entry for entry in history if isinstance(entry, dict)]
        return []

    @staticmethod
    def _parse_metrics_entry_timestamp(entry: dict[str, object]) -> datetime | None:
        raw = entry.get("timestamp")
        if not isinstance(raw, str) or not raw:
            return None
        try:
            return datetime.fromisoformat(raw.replace("Z", "+00:00"))
        except Exception:
            return None

    @classmethod
    def _metrics_entry_sort_key(cls, entry: dict[str, object]) -> tuple[int, datetime | str]:
        parsed = cls._parse_metrics_entry_timestamp(entry)
        if parsed is not None:
            return (0, parsed)
        raw = entry.get("timestamp")
        return (1, raw if isinstance(raw, str) else "")

    @staticmethod
    def _metrics_entry_quality_score(entry: dict[str, object]) -> float:
        value = entry.get("quality_score")
        if isinstance(value, (int, float)):
            return float(value)

        quality = entry.get("quality")
        if isinstance(quality, dict) and isinstance(quality.get("score"), (int, float)):
            return float(quality["score"])

        value2 = entry.get("qualityScore")
        if isinstance(value2, (int, float)):
            return float(value2)

        return 0.0

    def _load_metrics_history_entries(self) -> list[dict[str, object]]:
        if _resolve_history_file_path is not None:
            history_path = _resolve_history_file_path(self.workspace_root, create_if_missing=False)
        else:
            history_path = self.workspace_root / ".manifestguard" / "metrics-history.json"
        if history_path is None or not history_path.exists():
            return []

        try:
            with history_path.open(encoding="utf-8") as file_pointer:
                payload = json.load(file_pointer)
            entries = self._extract_metrics_history_entries(payload)
            return entries if entries else []
        except (json.JSONDecodeError, Exception) as error:
            logger.debug(f"Metrics history analysis failed: {error}")
            return []

    def _recommend_trend_analysis(self) -> list[Recommendation]:
        recs: list[Recommendation] = []
        entries = self._load_metrics_history_entries()
        if len(entries) < 5:
            return recs

        entries_sorted = sorted(entries, key=self._metrics_entry_sort_key)
        last_five = entries_sorted[-5:]
        recent_scores = [self._metrics_entry_quality_score(entry) for entry in last_five]
        if len(recent_scores) < 2:
            return recs

        if recent_scores[-1] >= recent_scores[0] - 5:
            return recs

        recs.append(
            Recommendation(
                category="trend",
                id="declining-quality-trend",
                priority="low",
                summary=(
                    f"Quality score declining: {recent_scores[0]:.1f} → "
                    f"{recent_scores[-1]:.1f} (last 5 measurements)"
                ),
                proposed_fix=(
                    "Review recent changes that may have degraded quality. "
                    "Check coverage drops, new complexity violations, or "
                    "security issues."
                ),
                confidence=0.80,
                effort_minutes=60,
                impact_score=5,
                code_example=(
                    "# View detailed trend analysis\n"
                    "$ manifestguard trends --metric=quality_score --last=10\n\n"
                    "# Compare current vs baseline\n"
                    "$ manifestguard check --extended --compare-to=1-week-ago\n\n"
                    "# Generate regression report\n"
                    "$ manifestguard trends --regressions-only"
                ),
                guide_url="https://www.ready-4-it.com/mgpy/guides/quality-regression",
            ),
        )
        return recs
