"""Data models for extended metrics collection.

This module contains metric dataclasses and recommendation payloads used by
extended test mode. Keeping models separate from orchestration helps control
module size and improves reuse in focused tests.
"""

from dataclasses import dataclass, field
from typing import Any

from manifestguard import __version__ as _MGPY_VERSION
from manifestguard.guide_catalog import (
    build_local_guide_command,
    derive_guide_slug_from_url,
    resolve_guide_version_context,
)

_GUIDE_VERSION_CONTEXT = resolve_guide_version_context(_MGPY_VERSION)


@dataclass
class CoverageMetrics:
    """Test coverage and test suite health metrics."""

    unit_percent: float = 0.0
    unit_measured: bool = False
    integration_percent: float = 0.0
    untested_modules: list[str] = field(default_factory=list)
    total_tests: int = 0
    passing_tests: int = 0
    failing_tests: int = 0
    skipped_tests: int = 0

    def __post_init__(self) -> None:
        if not self.unit_measured and self.unit_percent != 0.0:
            self.unit_measured = True


@dataclass
class DependencyMetrics:
    """Package dependency health and vulnerability metrics."""

    outdated_count: int = 0
    vulnerable_high: int = 0
    vulnerable_critical: int = 0
    conflicting_ranges: list[str] = field(default_factory=list)
    direct_count: int = 0
    transitive_count: int = 0


@dataclass
class SecurityMetrics:
    """Static security analysis and risk indicators."""

    unsafe_exec_count: int = 0
    hardcoded_secrets: int = 0
    hardcoded_paths: int = 0
    subprocess_shell_true: int = 0
    unsafe_deserialization: int = 0
    tls_verify_disabled: int = 0
    insecure_tempfile: int = 0
    wheel_content_issues: int = 0
    wheel_content_findings: list[str] = field(default_factory=list)
    weak_crypto: list[str] = field(default_factory=list)
    insecure_permissions: list[str] = field(default_factory=list)
    supply_chain_vulnerabilities: int = 0
    supply_chain_findings: list[str] = field(default_factory=list)


@dataclass
class SBOMMetrics:
    """SBOM completeness metrics."""

    components_count: int = 0
    missing_licenses: int = 0
    unknown_origins: int = 0
    spdx_compliance: bool = False


@dataclass
class PackagingMetrics:
    """Package distribution quality."""

    missing_classifiers: list[str] = field(default_factory=list)
    has_py_typed: bool = False
    version_consistency: bool = True
    readme_present: bool = True
    license_present: bool = True


@dataclass
class PerformanceMetrics:
    """Build and analysis timing."""

    manifest_parse_ms: float = 0.0
    rule_engine_ms: float = 0.0
    dependency_graph_ms: float = 0.0
    total_analysis_ms: float = 0.0


@dataclass
class PolicyMetrics:
    """Policy enforcement status."""

    whitelist_violations: list[str] = field(default_factory=list)
    blacklist_violations: list[str] = field(default_factory=list)
    untagged_critical_deps: list[str] = field(default_factory=list)

    dummy_code_total_findings: int = 0
    dummy_code_scanned_files: int = 0
    dummy_code_marker_findings: int = 0
    dummy_code_constant_return_findings: int = 0
    dummy_code_no_op_findings: int = 0
    dummy_code_test_artifact_findings: int = 0
    dummy_code_findings_sample: list[dict[str, Any]] = field(default_factory=list)

    duplication: dict[str, Any] = field(default_factory=dict)

    gui_hardcoded_strings_total_findings: int = 0
    gui_hardcoded_strings_unique_strings: int = 0
    gui_hardcoded_strings_scanned_files: int = 0
    gui_hardcoded_strings_findings_sample: list[dict[str, Any]] = field(default_factory=list)

    cli_hardcoded_strings_total_findings: int = 0
    cli_hardcoded_strings_unique_strings: int = 0
    cli_hardcoded_strings_scanned_files: int = 0
    cli_hardcoded_strings_findings_sample: list[dict[str, Any]] = field(default_factory=list)


@dataclass
class LicenseMetrics:
    """License metadata consistency."""

    spdx_mismatches: list[str] = field(default_factory=list)
    license_file_missing: bool = False
    conflicting_notices: list[str] = field(default_factory=list)


@dataclass
class ComplexityMetrics:
    """Code complexity analysis metrics."""

    violations_count: int = 0
    average_complexity: float = 0.0
    max_complexity: int = 0
    files_scanned: int = 0
    threshold: int = 10
    top_violations: list[dict[str, Any]] = field(default_factory=list)

    engine: str = "mgpy-analyzer"
    engine_version: str | None = None

    max_file_lines_threshold: int | None = None
    max_file_lines_observed: int = 0
    oversized_files_count: int = 0
    oversized_files: list[dict[str, Any]] = field(default_factory=list)


@dataclass
class BugfixMetrics:
    """Bugfix tracking metrics from git commit history."""

    total: int = 0
    bpd: float = 0.0
    days_analyzed: int = 0
    by_severity: dict[str, int] = field(
        default_factory=lambda: {
            "critical": 0,
            "major": 0,
            "minor": 0,
        }
    )
    by_category: dict[str, int] = field(
        default_factory=lambda: {
            "dashboard": 0,
            "api": 0,
            "packaging": 0,
            "tests": 0,
            "documentation": 0,
            "i18n": 0,
            "other": 0,
        }
    )
    recent_fixes: list[dict[str, str]] = field(default_factory=list)


@dataclass
class Recommendation:
    """AI-generated or heuristic-based improvement recommendation."""

    category: str
    id: str
    priority: str
    summary: str
    proposed_fix: str | None = None
    confidence: float = 0.0
    effort_minutes: int = 0
    impact_score: int = 0
    code_example: str | None = None
    guide_url: str | None = None
    guide_slug: str | None = None
    guide_command: str | None = None
    guide_version: str | None = None
    files_affected: list[str] = field(default_factory=list)

    def __post_init__(self) -> None:
        if self.guide_slug is None:
            self.guide_slug = derive_guide_slug_from_url(self.guide_url)
        if self.guide_command is None and self.guide_slug:
            self.guide_command = build_local_guide_command(self.guide_slug)
        if self.guide_version is None and self.guide_slug:
            self.guide_version = _GUIDE_VERSION_CONTEXT


@dataclass
class ExtendedTestMetrics:
    """Complete extended test metrics."""

    timestamp: str
    enabled: bool = True
    coverage: CoverageMetrics = field(default_factory=CoverageMetrics)
    dependency: DependencyMetrics = field(default_factory=DependencyMetrics)
    security: SecurityMetrics = field(default_factory=SecurityMetrics)
    sbom: SBOMMetrics = field(default_factory=SBOMMetrics)
    packaging: PackagingMetrics = field(default_factory=PackagingMetrics)
    performance: PerformanceMetrics = field(default_factory=PerformanceMetrics)
    policy: PolicyMetrics = field(default_factory=PolicyMetrics)
    complexity: ComplexityMetrics = field(default_factory=ComplexityMetrics)
    license: LicenseMetrics = field(default_factory=LicenseMetrics)
    bugfixes: BugfixMetrics = field(default_factory=BugfixMetrics)
    recommendations: list[Recommendation] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)
    quality_score: float = 0.0
    smart_check: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        base: dict[str, Any] = {
            "timestamp": self.timestamp,
            "enabled": self.enabled,
            "quality_score": self.quality_score,
            "metrics": {
                "coverage": self.coverage.__dict__,
                "dependency": self.dependency.__dict__,
                "security": self.security.__dict__,
                "sbom": self.sbom.__dict__,
                "packaging": self.packaging.__dict__,
                "performance": self.performance.__dict__,
                "policy": self.policy.__dict__,
                "license": self.license.__dict__,
                "complexity": self.complexity.__dict__ if self.complexity else None,
                "bugfixes": (
                    {
                        "total": self.bugfixes.total,
                        "bpd": self.bugfixes.bpd,
                        "days_analyzed": self.bugfixes.days_analyzed,
                        "by_severity": self.bugfixes.by_severity,
                        "by_category": self.bugfixes.by_category,
                        "recent_fixes": self.bugfixes.recent_fixes,
                    }
                    if self.bugfixes
                    else None
                ),
            },
            "recommendations": [
                {
                    "category": r.category,
                    "id": r.id,
                    "priority": r.priority,
                    "summary": r.summary,
                    "proposedFix": r.proposed_fix,
                    "confidence": r.confidence,
                    "effort_minutes": r.effort_minutes,
                    "impact_score": r.impact_score,
                    "code_example": r.code_example,
                    "guide_url": r.guide_url,
                    "guide_slug": r.guide_slug,
                    "guide_command": r.guide_command,
                    "guide_version": r.guide_version,
                    "files_affected": r.files_affected,
                }
                for r in self.recommendations
            ],
            "errors": self.errors,
        }
        if self.smart_check:
            base["smartCheck"] = self.smart_check
        return base
