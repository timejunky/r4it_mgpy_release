"""Weekly coverage reconstruction from metrics history.

Aggregates coverage.estimate entries into calendar-week buckets (ISO weeks)
for trend analysis aligned with MGVS concept.testcoverage.en.md.
"""

from __future__ import annotations

import json
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from manifestguard.extended.coverage_metrics import calculate_coverage_trend


def get_iso_week(timestamp: str) -> str:
    """Extract ISO week number from timestamp.
    
    Args:
        timestamp: ISO format timestamp
        
    Returns:
        ISO week string (format: 2026-W02)
    """
    try:
        dt = datetime.fromisoformat(timestamp.replace("Z", "+00:00"))
        iso_cal = dt.isocalendar()
        return f"{iso_cal.year}-W{iso_cal.week:02d}"
    except Exception:
        return "unknown"


def _load_history_entries(history_file: Path) -> list[dict[str, Any]] | None:
    if not history_file.exists():
        return None

    try:
        data = json.loads(history_file.read_text(encoding="utf-8"))
    except Exception:
        return None

    entries = data.get("entries", []) if isinstance(data, dict) else data
    if not isinstance(entries, list):
        return None

    return [e for e in entries if isinstance(e, dict)]


def _iter_coverage_estimates(entries: list[dict[str, Any]]):
    for entry in entries:
        timestamp = entry.get("timestamp", "")
        if not timestamp:
            continue

        # Prefer metrics[] (MGPY-native) but support top-level `coverage.estimate`
        # (MGVS dashboards consume this slice).
        metrics = entry.get("metrics", [])
        if isinstance(metrics, list):
            for metric in metrics:
                if not isinstance(metric, dict):
                    continue
                if metric.get("metric") != "coverage.estimate":
                    continue

                yield get_iso_week(timestamp), timestamp, metric.get("value", 0.0)
                break
            else:
                coverage_slice = entry.get("coverage")
                if isinstance(coverage_slice, dict):
                    explicit_measured = coverage_slice.get("unit_measured")
                    if explicit_measured is False:
                        continue
                    estimate = coverage_slice.get("estimate")
                    if isinstance(estimate, (int, float)):
                        if explicit_measured is True or float(estimate) > 0.0:
                            yield get_iso_week(timestamp), timestamp, float(estimate)
        else:
            coverage_slice = entry.get("coverage")
            if isinstance(coverage_slice, dict):
                explicit_measured = coverage_slice.get("unit_measured")
                if explicit_measured is False:
                    continue
                estimate = coverage_slice.get("estimate")
                if isinstance(estimate, (int, float)):
                    if explicit_measured is True or float(estimate) > 0.0:
                        yield get_iso_week(timestamp), timestamp, float(estimate)


def _trend_for_week(measurements: list[dict[str, Any]], change: float) -> str:
    if len(measurements) < 2:
        return "insufficient_data"
    if abs(change) < 0.5:
        return "stable"
    if change > 0:
        return "improving"
    return "declining"


def _build_week_aggregate(week: str, measurements: list[dict[str, Any]]) -> dict[str, Any] | None:
    if not measurements:
        return None

    measurements.sort(key=lambda x: x["timestamp"])

    values = [m["value"] for m in measurements]
    first_value = measurements[0]["value"]
    last_value = measurements[-1]["value"]
    change = last_value - first_value

    trend = _trend_for_week(measurements, change)

    return {
        "week": week,
        "measurements": len(measurements),
        "min_coverage": round(min(values), 2),
        "max_coverage": round(max(values), 2),
        "avg_coverage": round(sum(values) / len(values), 2),
        "first_coverage": round(first_value, 2),
        "last_coverage": round(last_value, 2),
        "trend": trend,
        "change_percent": round(change, 2),
        "first_timestamp": measurements[0]["timestamp"],
        "last_timestamp": measurements[-1]["timestamp"],
    }


def reconstruct_weekly_coverage(
    history_file: Path
) -> dict[str, dict[str, Any]]:
    """Reconstruct weekly coverage aggregates from metrics history.
    
    Args:
        history_file: Path to metrics history file
        
    Returns:
        Dict mapping ISO week strings to weekly aggregates
        
    Example:
        {
            "2026-W01": {
                "week": "2026-W01",
                "measurements": 5,
                "min_coverage": 45.2,
                "max_coverage": 50.1,
                "avg_coverage": 47.8,
                "first_coverage": 45.2,
                "last_coverage": 50.1,
                "trend": "improving",
                "change_percent": 4.9
            },
            ...
        }
    """
    entries = _load_history_entries(history_file)
    if not entries:
        return {}
    
    # Group coverage entries by ISO week
    weekly_data: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for week, timestamp, value in _iter_coverage_estimates(entries):
        weekly_data[week].append({"timestamp": timestamp, "value": value})
    
    # Calculate aggregates for each week
    weekly_aggregates: dict[str, dict[str, Any]] = {}
    for week, measurements in sorted(weekly_data.items()):
        aggregate = _build_week_aggregate(week, measurements)
        if aggregate is None:
            continue
        weekly_aggregates[week] = aggregate
    
    return weekly_aggregates


def calculate_multi_week_trend(
    weekly_aggregates: dict[str, dict[str, Any]]
) -> dict[str, Any]:
    """Calculate trend across multiple weeks.
    
    Args:
        weekly_aggregates: Output from reconstruct_weekly_coverage
        
    Returns:
        Multi-week trend summary
    """
    if not weekly_aggregates:
        return {"trend": "no_data"}
    
    sorted_weeks = sorted(weekly_aggregates.keys())
    
    if len(sorted_weeks) < 2:
        return {
            "trend": "insufficient_data",
            "weeks": len(sorted_weeks)
        }
    
    first_week = weekly_aggregates[sorted_weeks[0]]
    last_week = weekly_aggregates[sorted_weeks[-1]]
    
    first_value = first_week["avg_coverage"]
    last_value = last_week["avg_coverage"]
    change = last_value - first_value
    
    # Determine trend direction
    if abs(change) < 1.0:  # Less than 1% change
        direction = "stable"
    elif change > 0:
        direction = "improving"
    else:
        direction = "declining"
    
    # Calculate week-over-week changes
    wow_changes: list[float] = []
    for i in range(1, len(sorted_weeks)):
        prev_week = weekly_aggregates[sorted_weeks[i-1]]
        curr_week = weekly_aggregates[sorted_weeks[i]]
        wow_change = curr_week["avg_coverage"] - prev_week["avg_coverage"]
        wow_changes.append(wow_change)
    
    return {
        "trend": direction,
        "total_weeks": len(sorted_weeks),
        "first_week": sorted_weeks[0],
        "last_week": sorted_weeks[-1],
        "first_avg_coverage": round(first_value, 2),
        "last_avg_coverage": round(last_value, 2),
        "total_change_percent": round(change, 2),
        "avg_weekly_change": round(sum(wow_changes) / len(wow_changes), 2) if wow_changes else 0.0,
        "max_weekly_improvement": round(max(wow_changes), 2) if wow_changes else 0.0,
        "max_weekly_decline": round(min(wow_changes), 2) if wow_changes else 0.0
    }


def format_weekly_summary(
    weekly_aggregates: dict[str, dict[str, Any]]
) -> str:
    """Format weekly coverage summary for console display.
    
    Args:
        weekly_aggregates: Output from reconstruct_weekly_coverage
        
    Returns:
        Formatted string
    """
    if not weekly_aggregates:
        return "No weekly coverage data available."
    
    lines = ["Weekly Coverage Summary", "=" * 80]
    
    for week in sorted(weekly_aggregates.keys()):
        agg = weekly_aggregates[week]
        
        trend_icon = {
            "improving": "↗",
            "declining": "↘",
            "stable": "→",
            "insufficient_data": "•"
        }.get(agg["trend"], "?")
        
        lines.append(
            f"{week}: {agg['avg_coverage']:5.2f}% avg "
            f"(min: {agg['min_coverage']:5.2f}%, max: {agg['max_coverage']:5.2f}%) "
            f"| {agg['measurements']:2d} measurements | {trend_icon} {agg['trend']}"
        )
    
    # Add multi-week trend
    multi_trend = calculate_multi_week_trend(weekly_aggregates)
    if multi_trend.get("trend") not in ["no_data", "insufficient_data"]:
        lines.append("")
        lines.append("Multi-Week Trend:")
        lines.append(f"  Period: {multi_trend['first_week']} → {multi_trend['last_week']} ({multi_trend['total_weeks']} weeks)")
        lines.append(f"  Coverage: {multi_trend['first_avg_coverage']:.2f}% → {multi_trend['last_avg_coverage']:.2f}%")
        lines.append(f"  Total Change: {multi_trend['total_change_percent']:+.2f}%")
        lines.append(f"  Avg Weekly Change: {multi_trend['avg_weekly_change']:+.2f}%")
        lines.append(f"  Trend: {multi_trend['trend']}")
    
    return "\n".join(lines)


def export_weekly_summary_json(
    weekly_aggregates: dict[str, dict[str, Any]],
    output_file: Path
) -> None:
    """Export weekly summary to JSON file.
    
    Args:
        weekly_aggregates: Output from reconstruct_weekly_coverage
        output_file: Path for JSON output
    """
    multi_trend = calculate_multi_week_trend(weekly_aggregates)
    
    output_data = {
        "weekly_aggregates": weekly_aggregates,
        "multi_week_trend": multi_trend,
        "summary": {
            "total_weeks": len(weekly_aggregates),
            "weeks": sorted(weekly_aggregates.keys())
        }
    }
    
    output_file.write_text(
        json.dumps(output_data, indent=2, ensure_ascii=False),
        encoding="utf-8"
    )
