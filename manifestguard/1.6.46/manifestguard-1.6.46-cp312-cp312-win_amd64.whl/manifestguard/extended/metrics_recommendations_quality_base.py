from __future__ import annotations

from collections.abc import Callable, Iterable
from typing import TYPE_CHECKING

from .metrics import Recommendation

if TYPE_CHECKING:
    from .metrics import ExtendedTestMetrics


class _MetricsRecommendationsQualityBaseMixin:
    def _quality_recommendation_providers(self) -> Iterable[Callable[[], list[Recommendation]]]:
        """Return recommendation providers that do not require runtime metrics."""
        return (
            self._recommend_typing_improvements,
            self._recommend_documentation_coverage,
            self._recommend_pep8_cleanup,
            self._recommend_style_consistency,
            self._recommend_locale_translation_sync,
            self._recommend_crypto_hardening,
            self._recommend_modern_patterns,
            self._recommend_cicd_setup,
            self._recommend_baseline_visualization,
            self._recommend_trend_analysis,
        )

    def _quality_recommendation_providers_with_metrics(
        self,
    ) -> Iterable[Callable[["ExtendedTestMetrics"], list[Recommendation]]]:
        """Return recommendation providers that require runtime metrics."""
        return (
            self._recommend_packaging_gaps,
            self._recommend_sbom_followups,
            self._recommend_performance_tuning,
            self._recommend_memory_profiling,
        )

    def _generate_quality_recommendations(
        self,
        metrics: "ExtendedTestMetrics",
    ) -> list[Recommendation]:
        """Generate code quality recommendations (type hints, docs, style)."""
        recommendations: list[Recommendation] = []

        for provider in self._quality_recommendation_providers():
            recommendations.extend(provider())

        for metrics_provider in self._quality_recommendation_providers_with_metrics():
            recommendations.extend(metrics_provider(metrics))

        return recommendations
