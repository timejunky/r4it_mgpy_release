"""Low-level history file I/O helpers for metrics history export.

Extracted from metrics_history_export to keep module size manageable.
Contains: atomic write, entry/wrapper helpers, UUID, timestamp, sort, merge.
"""

from __future__ import annotations

import contextlib
import json
import time
import uuid
from datetime import datetime
from pathlib import Path
from typing import Any

from manifestguard.utils import cli_validation


METRICS_HISTORY_FORMAT_VERSION = "1.0.0"

# Default history path (relative to workspace root).
_HISTORY_REL_PATH = Path(".mgpy") / "metrics" / "manifestguard-history.json"


def _new_stable_id() -> str:
    try:
        return str(uuid.uuid4())
    except Exception:
        return f"{int(time.time())}-{int(time.time_ns() % 1_000_000_000)}"


def _parse_timestamp(value: Any) -> datetime | None:
    if not isinstance(value, str) or not value:
        return None
    try:
        return datetime.fromisoformat(value.replace("Z", "+00:00"))
    except Exception:
        return None


def _sort_entries_oldest_first(items: list[dict[str, Any]]) -> list[dict[str, Any]]:
    def _key(entry: dict[str, Any]) -> tuple[int, Any]:
        ts_raw = entry.get("timestamp")
        ts = _parse_timestamp(ts_raw)
        if ts is not None:
            return (0, ts)
        if isinstance(ts_raw, str):
            return (1, ts_raw)
        return (2, "")

    return sorted([e for e in items if isinstance(e, dict)], key=_key)


def _get_entries(payload: Any) -> list[dict[str, Any]]:
    """Extract entries from payload with validation."""
    if isinstance(payload, list):
        validated = []
        for i, entry in enumerate(payload):
            try:
                validated.append(cli_validation.validate_metrics_history_entry(entry))
            except Exception as e:
                import logging
                logging.getLogger(__name__).debug(f"Skipping invalid entry {i}: {e}")
                continue
        return validated

    if isinstance(payload, dict) and isinstance(payload.get("entries"), list):
        entries = payload.get("entries") or []
        validated = []
        for i, entry in enumerate(entries):
            try:
                validated.append(cli_validation.validate_metrics_history_entry(entry))
            except Exception as e:
                import logging
                logging.getLogger(__name__).debug(f"Skipping invalid entry {i}: {e}")
                continue
        return validated

    return []


def _copy_str_field(src: dict[str, Any], dst: dict[str, Any], key: str) -> None:
    """Copy a non-empty string field from src to dst if present."""
    value = src.get(key)
    if isinstance(value, str) and value:
        dst[key] = value


def _write_json_atomic(path: Path, payload: dict[str, Any]) -> None:
    tmp = path.with_suffix(".json.tmp")
    try:
        with tmp.open("w", encoding="utf-8") as handle:
            json.dump(payload, handle, indent=2)
        tmp.replace(path)
    finally:
        if tmp.exists() and not path.exists():
            with contextlib.suppress(Exception):
                tmp.unlink()


def _build_history_wrapper() -> dict[str, Any]:
    return {
        "schemaVersion": "2.0",
        "formatVersion": METRICS_HISTORY_FORMAT_VERSION,
        "historyId": _new_stable_id(),
        "projectId": _new_stable_id(),
        "entries": [],
    }


def _load_existing_wrapper_fields(history_file: Path, wrapper: dict[str, Any]) -> None:
    if not history_file.exists():
        return

    try:
        parsed = json.loads(history_file.read_text(encoding="utf-8"))
    except Exception:
        return

    if not isinstance(parsed, dict):
        return

    for key in ("historyId", "projectId", "formatVersion", "reconstructCutoffIso"):
        _copy_str_field(parsed, wrapper, key)

    last_reconstruct = parsed.get("lastReconstruct")
    if isinstance(last_reconstruct, dict) and last_reconstruct:
        wrapper["lastReconstruct"] = last_reconstruct

    entries = parsed.get("entries")
    if isinstance(entries, list):
        wrapper["entries"] = entries


def _append_entry_trimmed(
    wrapper: dict[str, Any],
    entry: dict[str, Any],
    *,
    max_entries: int = 100,
) -> None:
    entries = wrapper.get("entries", [])
    if not isinstance(entries, list):
        entries = []

    # Dedup: if an entry with the same timestamp already exists, replace it.
    ts = entry.get("timestamp") or ""
    if ts:
        entries = [e for e in entries if not (isinstance(e, dict) and e.get("timestamp") == ts)]

    entries.append(entry)

    if max_entries > 0 and len(entries) > max_entries:
        entries = entries[-max_entries:]

    wrapper["entries"] = entries


def _merge_entries_dedupe_timestamp(
    legacy_entries: list[dict[str, Any]],
    wrapper_entries: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    legacy_sorted = _sort_entries_oldest_first(legacy_entries)
    wrapper_sorted = _sort_entries_oldest_first(wrapper_entries)

    merged: list[dict[str, Any]] = []
    seen_timestamps: set[str] = set()

    # Wrapper entries win over legacy on collisions (so legacy goes first).
    for entry in [*legacy_sorted, *wrapper_sorted]:
        ts_value = entry.get("timestamp")
        if isinstance(ts_value, str) and ts_value:
            if ts_value in seen_timestamps:
                continue
            seen_timestamps.add(ts_value)
        merged.append(entry)

    return merged


def _make_coverage_history_entry(
    *,
    timestamp: str,
    mgpy_version: str,
    coverage_metric: dict[str, Any],
) -> dict[str, Any]:
    estimate = coverage_metric.get("value")
    coverage_slice: dict[str, Any] | None = None
    if isinstance(estimate, (int, float)):
        coverage_slice = {"estimate": float(estimate)}

    return {
        "id": _new_stable_id(),
        "timestamp": timestamp,
        "mgpyVersion": mgpy_version,
        **({"coverage": coverage_slice} if coverage_slice is not None else {}),
        "metrics": [coverage_metric],
    }


def _make_single_metric_history_entry(
    *,
    timestamp: str,
    mgpy_version: str,
    metric_name: str,
    metric_value: dict[str, Any],
) -> dict[str, Any]:
    return {
        "id": _new_stable_id(),
        "timestamp": timestamp,
        "mgpyVersion": mgpy_version,
        "metrics": [{"metric": metric_name, "value": metric_value}],
    }


def resolve_history_file_path(workspace_root: Path, *, create_if_missing: bool = False) -> Path:
    """Resolve metrics history file path with priority: .mgpy/metrics/ → legacy locations.

    Args:
        workspace_root: Project root directory
        create_if_missing: If True, return new location regardless of existence

    Returns:
        Path to metrics history file (new or legacy)
    """
    new_location = workspace_root / ".mgpy" / "metrics" / "manifestguard-history.json"
    legacy_root = workspace_root / ".manifestguard-history.json"
    legacy_dir = workspace_root / ".manifestguard" / "metrics-history.json"

    if create_if_missing:
        return new_location

    # Priority: new → legacy root → legacy dir
    if new_location.exists():
        return new_location
    if legacy_root.exists():
        return legacy_root
    if legacy_dir.exists():
        return legacy_dir

    # Default to writing new history files into the modern location
    return new_location


def write_entry_to_workspace_history(
    workspace_root: Path,
    new_entry: dict[str, Any],
    *,
    max_entries: int = 100,
) -> bool:
    """Append *new_entry* to the workspace history file and return True on success."""
    import logging  # noqa: PLC0415 - runtime-only import

    history_file = workspace_root / _HISTORY_REL_PATH
    wrapper = _build_history_wrapper()
    _load_existing_wrapper_fields(history_file, wrapper)
    _append_entry_trimmed(wrapper, new_entry, max_entries=max_entries)
    history_file.parent.mkdir(parents=True, exist_ok=True)
    try:
        _write_json_atomic(history_file, wrapper)
        return True
    except Exception as e:
        logging.getLogger(__name__).error(f"Failed to write history entry: {e}")
        return False
