"""Cache I/O helpers and path utilities for code duplication detection.

Extracted from duplication.py to keep module size manageable.
Contains: rel_posix, kind_for_path, file_signature, gzip cache read/write,
cache-hit detection, cached-window application, occurrence/meta merge.
"""

from __future__ import annotations

import gzip
import json
import logging
from pathlib import Path
from typing import Any

from manifestguard.extended.duplication_config import DuplicationDetectionConfig

logger = logging.getLogger(__name__)

_DUPLICATION_CACHE_VERSION = 1
_DUPLICATION_NORMALIZER_VERSION = 1


def _rel_posix(path: Path, workspace_root: Path) -> str:
    try:
        rel = path.resolve().relative_to(workspace_root.resolve())
        return str(rel).replace("\\", "/")
    except Exception:
        return str(path).replace("\\", "/")


def _kind_for_path(rel_posix: str) -> str:
    if rel_posix.startswith("tests/") or rel_posix.startswith("test/"):
        return "tests"
    return "core"


def _file_signature(path: Path) -> tuple[int, int] | None:
    try:
        st = path.stat()
        mtime_ns = int(getattr(st, "st_mtime_ns", int(st.st_mtime * 1_000_000_000)))
        size = int(st.st_size)
        return mtime_ns, size
    except OSError:
        return None


def _dup_cache_path(workspace_root: Path) -> Path:
    return workspace_root / ".manifestguard" / "duplication_cache_v1.json.gz"


def _read_duplication_cache(workspace_root: Path) -> dict[str, Any] | None:
    path = _dup_cache_path(workspace_root)
    if not path.exists():
        return None
    try:
        with gzip.open(path, "rt", encoding="utf-8", errors="replace") as f:
            data = json.load(f)
        if not isinstance(data, dict):
            return None
        if int(data.get("version", -1)) != _DUPLICATION_CACHE_VERSION:
            return None
        if int(data.get("normalizerVersion", -1)) != _DUPLICATION_NORMALIZER_VERSION:
            return None
        return data
    except Exception as e:
        logger.debug(f"Failed to read duplication cache: {e}")
        return None


def _write_duplication_cache(workspace_root: Path, payload: dict[str, Any]) -> None:
    path = _dup_cache_path(workspace_root)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    try:
        with gzip.open(tmp, "wt", encoding="utf-8") as f:
            json.dump(payload, f, ensure_ascii=False, indent=None, separators=(",", ":"))
        tmp.replace(path)
    except Exception as e:
        logger.debug(f"Failed to write duplication cache: {e}")
        try:
            if tmp.exists():
                tmp.unlink()
        except Exception:
            pass


def _extract_cached_files(cache: dict[str, Any] | None) -> dict[str, Any]:
    if not isinstance(cache, dict):
        return {}
    files = cache.get("files")
    return files if isinstance(files, dict) else {}


def _can_reuse_cached_entry(
    *,
    cached: object,
    sig: tuple[int, int] | None,
    cfg: DuplicationDetectionConfig,
) -> bool:
    if sig is None or not isinstance(cached, dict):
        return False
    if int(cached.get("mtime_ns", -1)) != sig[0]:
        return False
    if int(cached.get("size", -1)) != sig[1]:
        return False
    if int(cached.get("windowLines", -1)) != cfg.window_lines:
        return False
    if not isinstance(cached.get("windows"), list):
        return False
    return isinstance(cached.get("normalizedLines"), int)


def _apply_cached_windows(
    *,
    rel: str,
    cached: dict[str, Any],
    cfg: DuplicationDetectionConfig,
    occurrences_by_hash: dict[str, list[dict[str, Any]]],
    meta_by_hash: dict[str, dict[str, Any]],
) -> tuple[int, int]:
    """Apply cached window occurrences; returns (normalized_lines, windows_used)."""
    kind = _kind_for_path(rel)
    scanned_lines = int(cached.get("normalizedLines", 0))

    windows: list[Any] = cached.get("windows", [])
    windows_used = 0
    for item in windows:
        if not (isinstance(item, list) and len(item) >= 3):
            continue
        h = item[0]
        start = item[1]
        end = item[2]
        if not isinstance(h, str):
            continue
        if not isinstance(start, int) or not isinstance(end, int):
            continue

        occ = {"file": rel, "startLine": start, "endLine": end, "kind": kind}
        occurrences_by_hash.setdefault(h, []).append(occ)
        meta_by_hash.setdefault(h, {"lines": cfg.window_lines, "first": (rel, start)})
        windows_used += 1

    return scanned_lines, windows_used


def _merge_occurrence_maps(
    dest: dict[str, list[dict[str, Any]]],
    src: dict[str, list[dict[str, Any]]],
) -> None:
    for h, occs in src.items():
        dest.setdefault(h, []).extend(occs)


def _merge_meta_maps(dest: dict[str, dict[str, Any]], src: dict[str, dict[str, Any]]) -> None:
    for h, meta in src.items():
        dest.setdefault(h, meta)


def _maybe_write_duplication_cache(
    *,
    workspace_root: Path,
    cfg: DuplicationDetectionConfig,
    cache_total_windows: int,
    cache_out_files: dict[str, Any],
    files_to_scan: list[Path],
    per_file_cache: dict[str, dict[str, Any]],
) -> None:
    if not cfg.cache_enabled:
        return
    if cache_total_windows > cfg.cache_max_total_windows:
        return

    for fp in files_to_scan:
        rel = _rel_posix(fp, workspace_root)
        sig = _file_signature(fp)
        if sig is None:
            continue

        per = per_file_cache.get(rel, {}) if isinstance(per_file_cache, dict) else {}
        windows = per.get("windows", []) if isinstance(per, dict) else []
        normalized_lines = per.get("normalizedLines", 0) if isinstance(per, dict) else 0
        if not isinstance(windows, list):
            windows = []
        if not isinstance(normalized_lines, int):
            normalized_lines = 0

        cache_out_files[rel] = {
            "mtime_ns": sig[0],
            "size": sig[1],
            "windowLines": cfg.window_lines,
            "normalizedLines": int(normalized_lines),
            "windows": windows,
        }

    payload = {
        "version": _DUPLICATION_CACHE_VERSION,
        "normalizerVersion": _DUPLICATION_NORMALIZER_VERSION,
        "windowLines": cfg.window_lines,
        "files": cache_out_files,
    }
    _write_duplication_cache(workspace_root, payload)
