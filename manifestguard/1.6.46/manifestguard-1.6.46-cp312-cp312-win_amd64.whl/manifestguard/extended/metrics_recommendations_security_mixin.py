"""Security recommendation builders extracted from metrics_recommendations_core.py."""

from __future__ import annotations

from .metrics import Recommendation


class _MetricsRecommendationsSecurityMixin:
    """Mixin: security-specific Recommendation factory methods and _generate_security_recommendations."""

    def _rec_hardcoded_paths(self, count: int) -> Recommendation:
        example_win = "C:\\" + "Users\\dev\\"
        example_linux = "/" + "home/user/"
        example_config = "C:\\\\" + "Users\\\\dev\\\\project\\\\config.json"
        return Recommendation(
            category="security",
            id="hardcoded-paths",
            priority="high",
            summary=(
                f"{count} files with "
                f"hardcoded dev/user paths (e.g., {example_win}, {example_linux})"
            ),
            proposed_fix=(
                "Replace with Path(__file__).parent for relative paths, "
                "or use environment variables for config paths"
            ),
            confidence=0.95,
            effort_minutes=30,
            impact_score=10,
            code_example=(
                "# ❌ BAD: Hardcoded path\n"
                f"config_path = '{example_config}'\n\n"
                "# ✅ GOOD: Relative path\n"
                "from pathlib import Path\n"
                "config_path = Path(__file__).parent / 'config.json'\n\n"
                "# ✅ GOOD: Environment variable\n"
                "import os\n"
                "config_path = os.getenv('CONFIG_PATH', 'config.json')"
            ),
            guide_url="https://www.ready-4-it.com/mgpy/guides/portable-paths",
        )

    def _rec_unsafe_exec(self, count: int) -> Recommendation:
        return Recommendation(
            category="security",
            id="unsafe-exec",
            priority="high",
            summary=f"{count} file(s) use eval/exec",
            proposed_fix="Replace with safe alternatives (ast.literal_eval, importlib)",
            confidence=0.92,
        )

    def _rec_hardcoded_secrets(self, count: int) -> Recommendation:
        return Recommendation(
            category="security",
            id="hardcoded-secrets",
            priority="critical",
            summary=f"{count} potential hardcoded secret(s)",
            proposed_fix="Move to environment variables or secret management service",
            confidence=0.80,
        )

    def _rec_subprocess_shell(self, count: int) -> Recommendation:
        return Recommendation(
            category="security",
            id="subprocess-shell-true",
            priority="high",
            summary=f"{count} file(s) use subprocess with shell=True",
            proposed_fix=(
                "Avoid shell=True where possible. Pass arguments as a list and validate inputs. "
                "If shell is required, strictly control/escape inputs."
            ),
            confidence=0.9,
        )

    def _rec_unsafe_deserialization(self, count: int) -> Recommendation:
        return Recommendation(
            category="security",
            id="unsafe-deserialization",
            priority="high",
            summary=f"{count} file(s) use unsafe deserialization patterns",
            proposed_fix=(
                "Avoid pickle for untrusted data. Prefer JSON. For YAML use yaml.safe_load() or SafeLoader."
            ),
            confidence=0.9,
        )

    def _rec_tls_verify_disabled(self, count: int) -> Recommendation:
        return Recommendation(
            category="security",
            id="tls-verify-disabled",
            priority="high",
            summary=f"{count} file(s) disable TLS verification (certificate verification disabled)",
            proposed_fix=(
                "Enable TLS verification. Use proper CA bundles or certificate pinning instead of disabling certificate verification."
            ),
            confidence=0.9,
        )

    def _rec_insecure_tempfile(self, count: int) -> Recommendation:
        return Recommendation(
            category="security",
            id="insecure-tempfile",
            priority="high",
            summary=f"{count} file(s) use insecure tempfile patterns (mktemp)",
            proposed_fix="Avoid tempfile.mktemp (insecure). Use NamedTemporaryFile or mkstemp instead.",
            confidence=0.9,
        )

    def _rec_insecure_permissions(self, files: list[str]) -> Recommendation:
        return Recommendation(
            category="security",
            id="insecure-permissions",
            priority="high",
            summary=f"{len(files)} file(s) set overly permissive chmod modes",
            proposed_fix="Avoid world-writable modes (e.g. 0o777/0o666). Use least privilege (e.g. 0o600/0o700).",
            confidence=0.85,
            files_affected=files[:5],
        )

    def _rec_wheel_content_issues(self, count: int, findings: list[str]) -> Recommendation:
        return Recommendation(
            category="security",
            id="wheel-content-issues",
            priority="high",
            summary=f"{count} suspicious wheel content item(s) detected",
            proposed_fix=(
                "Verify package include/exclude rules (pyproject.toml / MANIFEST.in). "
                "Ensure tests/fixtures/.manifestguard and secret-like files are not packaged."
            ),
            confidence=0.9,
            files_affected=findings[:5],
        )

    def _rec_supply_chain_vulnerabilities(self, count: int, findings: list[str]) -> Recommendation:
        return Recommendation(
            category="security",
            id="supply-chain-vulnerabilities",
            priority="critical",
            summary=f"{count} known CVE(s) in dependencies (detected via pip-audit)",
            proposed_fix=(
                "Update vulnerable dependencies to patched versions. "
                "Run 'pip-audit --fix' or manually upgrade affected packages."
            ),
            confidence=0.95,
            files_affected=findings[:5],
        )

    def _generate_security_recommendations(self, security: "SecurityMetrics") -> list[Recommendation]:
        """Generate security-related recommendations"""
        recommendations: list[Recommendation] = []

        if security.hardcoded_paths > 0:
            recommendations.append(self._rec_hardcoded_paths(security.hardcoded_paths))
        if security.unsafe_exec_count > 0:
            recommendations.append(self._rec_unsafe_exec(security.unsafe_exec_count))
        if security.hardcoded_secrets > 0:
            recommendations.append(self._rec_hardcoded_secrets(security.hardcoded_secrets))
        if security.subprocess_shell_true > 0:
            recommendations.append(self._rec_subprocess_shell(security.subprocess_shell_true))
        if security.unsafe_deserialization > 0:
            recommendations.append(
                self._rec_unsafe_deserialization(security.unsafe_deserialization)
            )
        if security.tls_verify_disabled > 0:
            recommendations.append(self._rec_tls_verify_disabled(security.tls_verify_disabled))
        if security.insecure_tempfile > 0:
            recommendations.append(self._rec_insecure_tempfile(security.insecure_tempfile))
        if security.insecure_permissions:
            recommendations.append(self._rec_insecure_permissions(security.insecure_permissions))
        if security.wheel_content_issues > 0:
            recommendations.append(
                self._rec_wheel_content_issues(
                    security.wheel_content_issues,
                    security.wheel_content_findings,
                ),
            )
        if security.supply_chain_vulnerabilities > 0:
            recommendations.append(
                self._rec_supply_chain_vulnerabilities(
                    security.supply_chain_vulnerabilities,
                    security.supply_chain_findings,
                ),
            )

        return recommendations
