"""SmartCheck incremental result cache for MGPY extended analysis.

Stores per-step analysis results keyed by:
  - workspace source fingerprint (SHA-256 of all Python source content)
  - config fingerprint (SHA-256 of serialised config dict)
  - mgpy version + cache-format version

Cache layout:
    .manifestguard/cache/smartcheck/<step>_v1.json.gz

Each cache file holds a single entry (most-recent run for that key).
A key mismatch unconditionally invalidates and triggers a fresh computation.
"""

from __future__ import annotations

import gzip
import hashlib
import json
import logging
import os
import threading
import time
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from manifestguard import __version__ as _MGPY_VERSION

logger = logging.getLogger(__name__)

_CACHE_FORMAT_VERSION = 1
_VERSION_TAG = f"mgpy-{_MGPY_VERSION}+sc{_CACHE_FORMAT_VERSION}"
_MAX_CACHE_BYTES = 2 * 1024 * 1024  # 2 MB raw-JSON cap per step
_SOFT_TTL_SECONDS = 86_400  # 24 h — emit debug log, but key still validated
_LOCK_WAIT_TIMEOUT_SECONDS = 5.0
_LOCK_POLL_INTERVAL_SECONDS = 0.025


def _rel_posix(path: Path, workspace_root: Path) -> str:
    try:
        return str(path.resolve().relative_to(workspace_root.resolve())).replace("\\", "/")
    except Exception:
        return str(path).replace("\\", "/")


class SmartCheckCache:
    """Per-step gzip-JSON result cache for incremental extended analysis.

    All public methods are synchronous and safe to call from async context
    (no blocking I/O beyond reading small cached files or scanning sources).

    Usage::

        cache = SmartCheckCache(workspace_root)
        ws_fp = cache.workspace_fingerprint()
        cfg_fp = SmartCheckCache.config_fingerprint(config)

        result, miss_reason = cache.get("security", ws_fp, cfg_fp)
        if result is None:
            # miss_reason describes why (e.g. "cache-miss-key-mismatch")
            result = run_security_analysis()
            cache.put("security", ws_fp, cfg_fp, result)
    """

    def __init__(self, workspace_root: Path) -> None:
        self._root = workspace_root
        self._cache_dir = workspace_root / ".manifestguard" / "cache" / "smartcheck"
        self._ws_fp: str | None = None  # memoised workspace fingerprint

    # ------------------------------------------------------------------
    # Fingerprinting
    # ------------------------------------------------------------------

    def workspace_fingerprint(self, src_dirs: list[Path] | None = None) -> str:
        """Return a SHA-256 fingerprint of all Python sources under *src_dirs*.

        *src_dirs* defaults to the workspace root.  ``__pycache__`` directories
        are excluded.  The result is memoised for the lifetime of this instance.
        """
        if self._ws_fp is not None:
            return self._ws_fp

        search_roots: list[Path] = src_dirs or [self._root]
        py_files: list[Path] = []
        for root_dir in search_roots:
            if not root_dir.is_dir():
                continue
            for py_file in root_dir.rglob("*.py"):
                if "__pycache__" not in py_file.parts:
                    py_files.append(py_file)

        hasher = hashlib.sha256()
        for py_file in sorted(py_files):
            try:
                content = py_file.read_bytes()
            except OSError:
                continue
            rel = _rel_posix(py_file, self._root)
            file_hash = hashlib.sha256(content).hexdigest()
            hasher.update(f"{rel}:{file_hash}\n".encode())

        self._ws_fp = hasher.hexdigest()
        return self._ws_fp

    @staticmethod
    def config_fingerprint(config: dict[str, Any]) -> str:
        """Return SHA-256 fingerprint of *config*."""
        try:
            serialised = json.dumps(config, sort_keys=True, default=str).encode()
        except Exception:
            serialised = repr(config).encode()
        return hashlib.sha256(serialised).hexdigest()

    # ------------------------------------------------------------------
    # Cache I/O
    # ------------------------------------------------------------------

    def _cache_file(self, step_name: str) -> Path:
        return self._cache_dir / f"{step_name}_v1.json.gz"

    def _lock_file(self, step_name: str) -> Path:
        return self._cache_dir / f"{step_name}_v1.json.gz.lock"

    def _tmp_cache_file(self, path: Path) -> Path:
        token = f"{os.getpid()}.{threading.get_ident()}.{uuid.uuid4().hex}"
        return path.with_name(f"{path.name}.{token}.tmp")

    def _acquire_write_lock(self, step_name: str) -> bool:
        lock_path = self._lock_file(step_name)
        deadline = time.monotonic() + _LOCK_WAIT_TIMEOUT_SECONDS
        while True:
            try:
                fd = os.open(str(lock_path), os.O_CREAT | os.O_EXCL | os.O_WRONLY)
                with os.fdopen(fd, "w", encoding="utf-8") as handle:
                    handle.write(f"pid={os.getpid()} thread={threading.get_ident()}\n")
                return True
            except FileExistsError:
                if time.monotonic() >= deadline:
                    logger.debug(
                        "SmartCheckCache: timed out waiting for write lock on %s",
                        lock_path.name,
                    )
                    return False
                time.sleep(_LOCK_POLL_INTERVAL_SECONDS)
            except OSError as exc:
                logger.debug(
                    "SmartCheckCache: failed to acquire write lock for %s: %s",
                    lock_path.name,
                    exc,
                )
                return False

    def _release_write_lock(self, step_name: str) -> None:
        lock_path = self._lock_file(step_name)
        try:
            if lock_path.exists():
                lock_path.unlink()
        except OSError as exc:
            logger.debug(
                "SmartCheckCache: failed to release write lock for %s: %s",
                lock_path.name,
                exc,
            )

    def _make_cache_key(self, workspace_fp: str, config_fp: str) -> str:
        combined = f"{_VERSION_TAG}|ws={workspace_fp}|cfg={config_fp}"
        return hashlib.sha256(combined.encode()).hexdigest()

    def get(
        self,
        step_name: str,
        workspace_fp: str,
        config_fp: str,
    ) -> tuple[dict[str, Any] | None, str | None]:
        """Return ``(result_dict, None)`` on hit, or ``(None, reason)`` on miss.

        *reason* is a short diagnostic string such as ``"cache-miss-key-mismatch"``.
        """
        path = self._cache_file(step_name)
        if not path.exists():
            return None, "cache-miss-no-file"

        try:
            with gzip.open(path, "rt", encoding="utf-8", errors="replace") as fh:
                data = json.load(fh)
        except Exception as exc:
            logger.debug("SmartCheckCache: read error for %s: %s", path.name, exc)
            return None, "cache-read-error"

        if not isinstance(data, dict):
            return None, "cache-corrupt"

        expected = self._make_cache_key(workspace_fp, config_fp)
        if data.get("cacheKey") != expected:
            return None, "cache-miss-key-mismatch"

        # Soft TTL — warn but do not invalidate when key still matches.
        try:
            cached_at_str: str = data.get("cachedAt", "")
            if cached_at_str:
                cached_at = datetime.fromisoformat(cached_at_str)
                age_s = (datetime.now(timezone.utc) - cached_at).total_seconds()
                if age_s > _SOFT_TTL_SECONDS:
                    logger.debug(
                        "SmartCheckCache: %s entry is %.1f h old (TTL exceeded, key valid)",
                        step_name,
                        age_s / 3600.0,
                    )
        except Exception:
            pass

        result = data.get("result")
        if not isinstance(result, dict):
            return None, "cache-corrupt-result"

        return result, None

    def put(
        self,
        step_name: str,
        workspace_fp: str,
        config_fp: str,
        result: dict[str, Any],
    ) -> None:
        """Persist *result* for *step_name*. Silently skips if result exceeds cap."""
        payload: dict[str, Any] = {
            "formatVersion": _CACHE_FORMAT_VERSION,
            "mgpyVersion": _MGPY_VERSION,
            "cacheKey": self._make_cache_key(workspace_fp, config_fp),
            "cachedAt": datetime.now(timezone.utc).isoformat(),
            "step": step_name,
            "result": result,
        }

        try:
            raw = json.dumps(payload, ensure_ascii=False, default=str)
        except Exception as exc:
            logger.debug("SmartCheckCache: serialisation failed for %s: %s", step_name, exc)
            return

        if len(raw.encode()) > _MAX_CACHE_BYTES:
            logger.debug(
                "SmartCheckCache: skipping write for %s (exceeds %d B cap)",
                step_name,
                _MAX_CACHE_BYTES,
            )
            return

        self._cache_dir.mkdir(parents=True, exist_ok=True)
        path = self._cache_file(step_name)
        tmp = self._tmp_cache_file(path)
        if not self._acquire_write_lock(step_name):
            return
        try:
            with gzip.open(tmp, "wt", encoding="utf-8") as fh:
                fh.write(raw)
            tmp.replace(path)
        except Exception as exc:
            logger.debug("SmartCheckCache: write failed for %s: %s", step_name, exc)
            try:
                if tmp.exists():
                    tmp.unlink()
            except Exception:
                pass
        finally:
            self._release_write_lock(step_name)
