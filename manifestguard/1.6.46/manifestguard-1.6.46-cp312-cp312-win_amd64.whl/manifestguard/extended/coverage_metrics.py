"""Calculate and format coverage metrics for metrics history.

This module converts parsed coverage data into the metrics history format
and provides utilities for tracking coverage over time.
"""

from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from manifestguard.extended.coverage_parser import (
    CoverageData,
    parse_coverage_json,
    CoverageParseError
)


def calculate_coverage_metric(coverage_data: CoverageData) -> dict[str, Any]:
    """Calculate coverage metric in metrics history format.
    
    Args:
        coverage_data: Parsed coverage data
        
    Returns:
        Dict with metric name and value for metrics history
    """
    return {
        "metric": "coverage.estimate",
        "value": round(coverage_data.percent_covered, 2),
        "unit": "percent",
        "details": {
            "covered_lines": coverage_data.total_covered_lines,
            "total_lines": coverage_data.total_lines,
            "num_files": coverage_data.num_files,
            "timestamp": coverage_data.timestamp or datetime.now(timezone.utc).isoformat()
        }
    }


def extract_coverage_from_file(coverage_file: Path) -> dict[str, Any]:
    """Extract coverage metric from coverage.json file.
    
    Args:
        coverage_file: Path to coverage.json
        
    Returns:
        Coverage metric dict for metrics history
        
    Raises:
        CoverageParseError: If parsing fails
    """
    coverage_data = parse_coverage_json(coverage_file)
    return calculate_coverage_metric(coverage_data)


def _has_coverage_datapoint(entry: dict[str, Any]) -> bool:
    metrics = entry.get("metrics", [])
    if isinstance(metrics, list) and any(
        isinstance(m, dict) and m.get("metric") == "coverage.estimate" for m in metrics
    ):
        return True
    coverage_slice = entry.get("coverage")
    if not isinstance(coverage_slice, dict):
        return False

    explicit_measured = coverage_slice.get("unit_measured")
    if isinstance(explicit_measured, bool):
        if not explicit_measured:
            return False
        return any(
            isinstance(coverage_slice.get(key), (int, float))
            for key in ("unit_percent", "estimate", "line_rate")
        )

    estimate = coverage_slice.get("estimate")
    if isinstance(estimate, (int, float)):
        return float(estimate) > 0.0

    unit_percent = coverage_slice.get("unit_percent")
    if isinstance(unit_percent, (int, float)):
        return float(unit_percent) > 0.0

    line_rate = coverage_slice.get("line_rate")
    if isinstance(line_rate, (int, float)):
        return float(line_rate) > 0.0

    return False


def _extract_coverage_value(entry: dict[str, Any]) -> float | None:
    """Extract coverage estimate value from a history entry."""
    metrics = entry.get("metrics", [])
    if isinstance(metrics, list):
        for metric in metrics:
            if isinstance(metric, dict) and metric.get("metric") == "coverage.estimate":
                value = metric.get("value", 0.0)
                return float(value) if isinstance(value, (int, float)) else None
    coverage_slice = entry.get("coverage")
    if isinstance(coverage_slice, dict):
        explicit_measured = coverage_slice.get("unit_measured")
        if explicit_measured is False:
            return None

        unit_percent = coverage_slice.get("unit_percent")
        if isinstance(unit_percent, (int, float)):
            if explicit_measured is True or float(unit_percent) > 0.0:
                return float(unit_percent)

        estimate = coverage_slice.get("estimate")
        if isinstance(estimate, (int, float)):
            if explicit_measured is True or float(estimate) > 0.0:
                return float(estimate)

        line_rate = coverage_slice.get("line_rate")
        if isinstance(line_rate, (int, float)):
            normalized = float(line_rate) * 100.0 if float(line_rate) <= 1.0 else float(line_rate)
            if explicit_measured is True or normalized > 0.0:
                return normalized
    return None


def calculate_coverage_trend(
    history_entries: list[dict[str, Any]]
) -> dict[str, Any]:
    """Calculate coverage trend from metrics history entries.
    
    Args:
        history_entries: List of metrics history entries with coverage.estimate
        
    Returns:
        Dict with trend analysis (direction, change, timestamps)
    """
    # Filter for coverage datapoints (metrics[] or top-level slice)
    coverage_entries = [entry for entry in history_entries if _has_coverage_datapoint(entry)]
    
    if len(coverage_entries) < 2:
        return {
            "trend": "insufficient_data",
            "entries": len(coverage_entries)
        }
    
    # Extract coverage values chronologically
    values: list[tuple[str, float]] = []
    for entry in coverage_entries:
        value = _extract_coverage_value(entry)
        if value is not None:
            values.append((entry.get("timestamp", ""), value))
    
    if not values:
        return {"trend": "no_data"}
    
    # Sort by timestamp
    values.sort(key=lambda x: x[0])
    
    first_value = values[0][1]
    last_value = values[-1][1]
    change = last_value - first_value
    
    # Determine trend direction
    if abs(change) < 0.5:  # Less than 0.5% change
        direction = "stable"
    elif change > 0:
        direction = "improving"
    else:
        direction = "declining"
    
    return {
        "trend": direction,
        "change_percent": round(change, 2),
        "first_value": round(first_value, 2),
        "last_value": round(last_value, 2),
        "first_timestamp": values[0][0],
        "last_timestamp": values[-1][0],
        "num_measurements": len(values)
    }


def get_coverage_summary_for_period(
    history_entries: list[dict[str, Any]],
    start_date: str | None = None,
    end_date: str | None = None
) -> dict[str, Any]:
    """Get coverage summary for a specific time period.
    
    Args:
        history_entries: Metrics history entries
        start_date: ISO format start date (inclusive), None for no limit
        end_date: ISO format end date (inclusive), None for no limit
        
    Returns:
        Summary dict with min/max/avg coverage for period
    """
    # Filter entries by date range
    filtered = []
    for entry in history_entries:
        timestamp = entry.get("timestamp", "")
        if start_date and timestamp < start_date:
            continue
        if end_date and timestamp > end_date:
            continue

        value = _extract_coverage_value(entry)
        if value is not None:
            filtered.append({
                "timestamp": timestamp,
                "value": value,
            })
    
    if not filtered:
        return {
            "period": f"{start_date or 'start'} to {end_date or 'end'}",
            "measurements": 0,
            "status": "no_data"
        }
    
    values = [item["value"] for item in filtered]
    
    return {
        "period": f"{start_date or 'start'} to {end_date or 'end'}",
        "measurements": len(values),
        "min_coverage": round(min(values), 2),
        "max_coverage": round(max(values), 2),
        "avg_coverage": round(sum(values) / len(values), 2),
        "latest_coverage": round(filtered[-1]["value"], 2),
        "latest_timestamp": filtered[-1]["timestamp"]
    }


def format_coverage_metric_for_display(metric: dict[str, Any]) -> str:
    """Format coverage metric for console display.
    
    Args:
        metric: Coverage metric dict
        
    Returns:
        Formatted string
    """
    value = metric.get("value", 0.0)
    details = metric.get("details", {})
    covered = details.get("covered_lines", 0)
    total = details.get("total_lines", 0)
    files = details.get("num_files", 0)
    
    return f"{value:.2f}% ({covered}/{total} lines, {files} files)"
