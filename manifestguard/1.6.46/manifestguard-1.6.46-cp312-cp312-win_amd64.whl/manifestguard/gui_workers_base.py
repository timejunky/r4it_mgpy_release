"""Base worker classes for ManifestGuard GUI workers."""
from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path

from PySide6.QtCore import QObject, Signal

from manifestguard import __version__
from manifestguard.gui_support import discover_python_projects


class _CancelStateMixin:
    """Shared cancel-state machinery for subprocess-based QObject workers."""

    _cancel_requested: bool
    _process: "subprocess.Popen[str] | None"

    def _init_cancel_state(self) -> None:
        self._cancel_requested = False
        self._process = None

    def cancel(self) -> None:
        self._cancel_requested = True
        self._kill_process()

    def _kill_process(self) -> None:
        proc = self._process
        if proc is None:
            return
        try:
            proc.terminate()
        except Exception:
            pass


class ValidationWorker(_CancelStateMixin, QObject):
    output = Signal(str)
    finished = Signal(int)

    def __init__(
        self,
        *,
        workspace_root: Path,
        extended: bool,
        report_path: Path,
    ) -> None:
        super().__init__()
        self._init_cancel_state()
        self._workspace_root = workspace_root
        self._extended = extended
        self._report_path = report_path

    def run(self) -> None:
        cmd: list[str] = [sys.executable, "-m", "manifestguard", "check"]
        if self._extended:
            cmd.append("--extended")
        cmd.extend(["--report", str(self._report_path)])

        self.output.emit(f"$ {' '.join(cmd)}")
        self.output.emit(f"cwd: {self._workspace_root}")

        env = dict(os.environ)
        env.setdefault("PYTHONIOENCODING", "utf-8")

        try:
            self._process = subprocess.Popen(
                cmd,
                cwd=str(self._workspace_root),
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                encoding="utf-8",
                errors="replace",
                bufsize=1,
                env=env,
            )
        except Exception as e:
            self.output.emit(f"Failed to start process: {e}")
            self.finished.emit(1)
            return

        assert self._process.stdout is not None
        for line in self._process.stdout:
            if self._cancel_requested:
                break
            self.output.emit(line.rstrip("\n"))

        try:
            exit_code = self._process.wait(timeout=5 if self._cancel_requested else None)
        except Exception:
            try:
                self._process.kill()
            except Exception:
                pass
            exit_code = 1

        if self._cancel_requested:
            self.output.emit("\nCancelled.")
        else:
            self.output.emit(f"\nExit code: {exit_code}")

        self.finished.emit(int(exit_code))


class PreflightAndValidationWorker(_CancelStateMixin, QObject):
    output = Signal(str)
    finished = Signal(int)

    def __init__(
        self,
        *,
        workspace_root: Path,
        extended: bool,
        report_path: Path,
        preflight_timeout_seconds: float,
    ) -> None:
        super().__init__()
        self._workspace_root = workspace_root
        self._extended = extended
        self._report_path = report_path
        self._preflight_timeout_seconds = float(preflight_timeout_seconds)
        self._init_cancel_state()

    def _run_streamed(self, cmd: list[str]) -> int:
        self.output.emit(f"$ {' '.join(cmd)}")
        self.output.emit(f"cwd: {self._workspace_root}")

        env = dict(os.environ)
        env.setdefault("PYTHONIOENCODING", "utf-8")

        try:
            self._process = subprocess.Popen(
                cmd,
                cwd=str(self._workspace_root),
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                encoding="utf-8",
                errors="replace",
                bufsize=1,
                env=env,
            )
        except Exception as e:
            self.output.emit(f"Failed to start process: {e}")
            return 1

        assert self._process.stdout is not None
        for line in self._process.stdout:
            if self._cancel_requested:
                break
            self.output.emit(line.rstrip("\n"))

        try:
            exit_code = self._process.wait(timeout=5 if self._cancel_requested else None)
        except Exception:
            try:
                self._process.kill()
            except Exception:
                pass
            exit_code = 1

        return int(exit_code)

    def run(self) -> None:
        self.output.emit("Starting vwpy preflight (venv_wizard)...")
        preflight_cmd: list[str] = [
            sys.executable,
            "-m",
            "manifestguard",
            "worker",
            "venv-wizard-preflight",
            "--project-root",
            str(self._workspace_root),
            "--python",
            sys.executable,
            "--workspace",
            str(self._workspace_root),
            "--timeout",
            str(self._preflight_timeout_seconds),
        ]

        preflight_exit = self._run_streamed(preflight_cmd)
        if self._cancel_requested:
            self.output.emit("\nCancelled.")
            self.finished.emit(1)
            return

        self.output.emit(f"\nPreflight exit code: {preflight_exit}")

        self.output.emit("\nStarting ManifestGuard validation...")
        validate_cmd: list[str] = [sys.executable, "-m", "manifestguard", "check"]
        if self._extended:
            validate_cmd.append("--extended")
        validate_cmd.extend(["--report", str(self._report_path)])

        validate_exit = self._run_streamed(validate_cmd)
        if self._cancel_requested:
            self.output.emit("\nCancelled.")
            self.finished.emit(1)
            return

        self.output.emit(f"\nValidation exit code: {validate_exit}")

        final_exit = validate_exit if validate_exit != 0 else preflight_exit
        self.finished.emit(int(final_exit))


class _PackagesAndMetricsMixin:
    """Helper mixin shared by workers that capture venv package metrics."""

    output: Signal
    _cwd: Path
    _wheel_backfill_enabled: bool
    _wheel_repo_path: str | None
    _cancel_requested: bool
    _packages_write_full_snapshot: bool

    def _maybe_backfill_missing_wheels(self, workspace_root: Path, venv_python: Path, meta: dict, venv_path: str) -> None:
        try:
            from manifestguard.extended.wheel_backfill import (  # noqa: PLC0415
                backfill_missing_wheels,
            )

            if (
                not self._wheel_backfill_enabled
                or not self._wheel_repo_path
                or not isinstance(meta.get("delta"), dict)
                or self._cancel_requested
            ):
                return

            summary = backfill_missing_wheels(
                python_exe=venv_python,
                wheel_repo_dir=Path(self._wheel_repo_path),
                delta=meta.get("delta") or {},
                emit=lambda s: self.output.emit(s),
                cancel_requested=lambda: self._cancel_requested,
            )
            self.output.emit(
                "(backfill) Done: "
                f"downloaded={summary.get('downloaded', 0)} "
                f"skipped={summary.get('skipped', 0)} "
                f"failed={summary.get('failed', 0)}"
            )
        except Exception as e:  # pragma: no cover - defensive logging
            self.output.emit(f"(backfill) Failed: {e}")

    def _build_venv_packages_history_payload(self, workspace_root: Path, venv_path: str, meta: dict) -> dict:
        venv_abs = Path(venv_path)
        try:
            venv_rel = str(venv_abs.resolve().relative_to(workspace_root.resolve()))
        except Exception:
            venv_rel = str(venv_abs)

        def _rel_path(p: str | None) -> str | None:
            if not p:
                return None
            try:
                return str(Path(p).resolve().relative_to(workspace_root.resolve()))
            except Exception:
                return p

        return {
            "venvPath": venv_rel,
            "venvAbsolutePath": str(venv_abs.resolve()),
            "venvId": meta.get("venvId"),
            "delta": meta.get("delta"),
            "deltaRequirementsPath": _rel_path(meta.get("deltaRequirementsPath")),
            "removedRequirementsPath": _rel_path(meta.get("removedRequirementsPath")),
            "snapshotPath": _rel_path(meta.get("snapshotPath")) if self._packages_write_full_snapshot else None,
        }


class CommandWorker(_CancelStateMixin, QObject):
    output = Signal(str)
    finished = Signal(int)

    def __init__(self, *, cwd: Path, cmd: list[str]) -> None:
        super().__init__()
        self._cwd = cwd
        self._cmd = cmd
        self._init_cancel_state()

    def run(self) -> None:
        self.output.emit(f"$ {' '.join(self._cmd)}")
        self.output.emit(f"cwd: {self._cwd}")

        env = dict(os.environ)
        env.setdefault("PYTHONIOENCODING", "utf-8")

        try:
            self._process = subprocess.Popen(
                self._cmd,
                cwd=str(self._cwd),
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                encoding="utf-8",
                errors="replace",
                bufsize=1,
                env=env,
            )
        except Exception as e:
            self.output.emit(f"Failed to start process: {e}")
            self.finished.emit(1)
            return

        assert self._process.stdout is not None
        for line in self._process.stdout:
            if self._cancel_requested:
                break
            self.output.emit(line.rstrip("\n"))

        try:
            exit_code = self._process.wait(timeout=5 if self._cancel_requested else None)
        except Exception:
            try:
                self._process.kill()
            except Exception:
                pass
            exit_code = 1

        if self._cancel_requested:
            self.output.emit("\nCancelled.")
        else:
            self.output.emit(f"\nExit code: {exit_code}")

        self.finished.emit(int(exit_code))


class ProjectDiscoveryWorker(_CancelStateMixin, QObject):
    output = Signal(str)
    finished = Signal(object)

    def __init__(
        self,
        *,
        base_dir: Path,
        max_depth: int,
        max_projects: int,
    ) -> None:
        super().__init__()
        self._base_dir = base_dir
        self._max_depth = max(0, int(max_depth))
        self._max_projects = max(1, int(max_projects))
        self._init_cancel_state()

    def run(self) -> None:
        results = discover_python_projects(
            base_dir=self._base_dir,
            max_depth=self._max_depth,
            max_projects=self._max_projects,
            progress=lambda s: self.output.emit(s),
            cancel_requested=lambda: self._cancel_requested,
        )
        self.finished.emit([str(p) for p in results])
