"""Versioned local help catalog for ManifestGuard guides.

Guide content is sourced from a packaged PIM-shaped data artifact so CLI and
MGVS preview consume the same structure that downstream documentation tooling
expects.
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass
from functools import lru_cache
from importlib.resources import files
from typing import Any


_GUIDE_DATA_FILES = {
    "1.6": "mgpy-guide-doc-pages.1.6.json",
}


def _runtime_version_fallback() -> str:
    try:
        from manifestguard import __version__

        return str(__version__)
    except Exception:
        return "1.6.0"


def _normalize_version_context(raw: str | None) -> str:
    value = (raw or "").strip()
    match = re.search(r"(\d+)\.(\d+)", value)
    if match:
        return f"{match.group(1)}.{match.group(2)}"
    return "1.6"


def build_online_guide_url(slug: str) -> str:
    return f"https://www.ready-4-it.com/mgpy/guides/{slug}"


def derive_guide_slug_from_url(guide_url: str | None) -> str | None:
    value = (guide_url or "").strip()
    if not value:
        return None
    match = re.search(r"/guides/([a-z0-9-]+)(?:$|[?#/])", value)
    if match:
        return match.group(1)
    return None


def build_local_guide_command(slug: str) -> str:
    return f"manifestguard guide {slug}"


def resolve_guide_version_context(runtime_version: str | None = None) -> str:
    return _normalize_version_context(runtime_version or _runtime_version_fallback())


@dataclass(frozen=True)
class GuideEntry:
    slug: str
    title: str
    summary: str
    content_md: str
    svg_content: str | None
    page_path: str
    page_type: str
    sort_order: int
    locale: str
    target_url: str
    related_guides: list[str]
    svg_filename: str | None = None


@dataclass(frozen=True)
class GuideDocument:
    slug: str
    title: str
    summary: str
    online_url: str
    local_command: str
    version_context: str
    runtime_version: str
    has_diagram: bool
    svg_filename: str | None
    svg_content: str | None
    markdown: str

    def to_dict(self, include_content: bool = True) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "slug": self.slug,
            "title": self.title,
            "summary": self.summary,
            "onlineUrl": self.online_url,
            "localCommand": self.local_command,
            "versionContext": self.version_context,
            "runtimeVersion": self.runtime_version,
            "hasDiagram": self.has_diagram,
            "svgFilename": self.svg_filename,
        }
        if include_content:
            payload["markdown"] = self.markdown
            payload["svgContent"] = self.svg_content
        return payload


def _load_catalog_payload(version_context: str) -> dict[str, Any]:
    artifact_name = _GUIDE_DATA_FILES[version_context]
    raw = files("manifestguard").joinpath("doc", artifact_name).read_text(encoding="utf-8")
    return json.loads(raw)


def _coerce_guide_entry(page: dict[str, Any]) -> GuideEntry:
    slug = str(page.get("page_slug") or "").strip()
    if not slug:
        raise ValueError("Guide page is missing page_slug")
    title = str(page.get("title") or slug).strip()
    summary = str(page.get("summary") or "").strip()
    content_md = str(page.get("content_md") or "").strip()
    svg_content = str(page.get("svg_content") or "").strip() or None
    page_path = str(page.get("page_path") or f"guides/{slug}").strip()
    page_type = str(page.get("page_type") or "guide").strip() or "guide"
    sort_order = int(page.get("sort_order") or 0)
    locale = str(page.get("locale") or "en").strip() or "en"
    target_url = str(page.get("target_url") or build_online_guide_url(slug)).strip()
    svg_filename = str(page.get("svg_filename") or "").strip() or None
    related_guides = [
        str(item).strip()
        for item in (page.get("related_page_slugs") or [])
        if str(item).strip()
    ]
    return GuideEntry(
        slug=slug,
        title=title,
        summary=summary,
        content_md=content_md,
        svg_content=svg_content,
        page_path=page_path,
        page_type=page_type,
        sort_order=sort_order,
        locale=locale,
        target_url=target_url,
        related_guides=related_guides,
        svg_filename=svg_filename,
    )


@lru_cache(maxsize=1)
def _versioned_guides() -> dict[str, dict[str, GuideEntry]]:
    catalog: dict[str, dict[str, GuideEntry]] = {}
    for version_context in _GUIDE_DATA_FILES:
        payload = _load_catalog_payload(version_context)
        pages = payload.get("doc_pages") or []
        catalog[version_context] = {
            entry.slug: entry
            for entry in (_coerce_guide_entry(page) for page in pages)
        }
    return catalog


def _available_version_contexts() -> list[str]:
    return sorted(_versioned_guides().keys())


def _fallback_version_context(runtime_version: str | None = None) -> str:
    requested = resolve_guide_version_context(runtime_version)
    if requested in _versioned_guides():
        return requested
    available = _available_version_contexts()
    if not available:
        return requested
    return available[-1]


def list_guides(runtime_version: str | None = None) -> list[GuideDocument]:
    runtime = runtime_version or _runtime_version_fallback()
    version_context = _fallback_version_context(runtime)
    guides = _versioned_guides().get(version_context, {})
    ordered_slugs = [
        entry.slug
        for entry in sorted(guides.values(), key=lambda entry: (entry.sort_order, entry.slug))
    ]
    return [
        render_guide_document(slug, runtime_version=runtime, version_context=version_context)
        for slug in ordered_slugs
    ]


def _guide_entry(
    slug: str,
    runtime_version: str | None = None,
    version_context: str | None = None,
) -> tuple[GuideEntry, str, str]:
    runtime = runtime_version or _runtime_version_fallback()
    resolved_context = version_context or _fallback_version_context(runtime)
    entry = _versioned_guides().get(resolved_context, {}).get(slug)
    if entry is None:
        raise KeyError(slug)
    return entry, resolved_context, runtime


def render_guide_document(
    slug: str,
    runtime_version: str | None = None,
    version_context: str | None = None,
) -> GuideDocument:
    entry, resolved_context, runtime = _guide_entry(slug, runtime_version, version_context)
    markdown = render_guide_markdown(slug, runtime_version=runtime, version_context=resolved_context)
    return GuideDocument(
        slug=entry.slug,
        title=entry.title,
        summary=entry.summary,
        online_url=entry.target_url,
        local_command=build_local_guide_command(entry.slug),
        version_context=resolved_context,
        runtime_version=runtime,
        has_diagram=entry.svg_content is not None or entry.svg_filename is not None,
        svg_filename=entry.svg_filename,
        svg_content=entry.svg_content,
        markdown=markdown,
    )


def render_guide_markdown(
    slug: str,
    runtime_version: str | None = None,
    version_context: str | None = None,
) -> str:
    entry, resolved_context, runtime = _guide_entry(slug, runtime_version, version_context)
    lines: list[str] = [
        f"# {entry.title}",
        "",
        entry.summary,
        "",
        f"- Runtime version: `{runtime}`",
        f"- Local guide context: `{resolved_context}`",
        f"- CLI: `{build_local_guide_command(entry.slug)}`",
        f"- Online: {entry.target_url}",
        f"- Page path: `{entry.page_path}`",
        f"- SVG asset: `{entry.svg_filename}`" if entry.svg_filename else "- SVG asset: not packaged in current local artifact",
        "",
        entry.content_md,
    ]
    if entry.svg_content:
        lines.extend(
            [
                "",
                "## Diagram",
                "",
                "Rendered from PIM `svg_content`; best viewed in MGVS Markdown Preview.",
                "",
                entry.svg_content,
            ]
        )
    if entry.related_guides:
        lines.extend(["", "## Related Guides", ""])
        for related in entry.related_guides:
            lines.append(f"- `{build_local_guide_command(related)}`")
    lines.extend(
        [
            "",
            "## Preview",
            "",
            "- MGVS command: `ManifestGuard: Open Python Guide Preview`",
            "- Online guide remains the SEO/public documentation source.",
        ]
    )
    return "\n".join(line.rstrip() for line in lines).rstrip() + "\n"


def _markdownish_to_text(markdown: str) -> str:
    text = re.sub(r"<svg\b.*?</svg>", "[inline svg diagram omitted]", markdown, flags=re.DOTALL | re.IGNORECASE)
    text = re.sub(r"```[a-zA-Z0-9_-]*\n", "", markdown)
    text = text.replace("```", "")
    text = re.sub(r"^#{1,6}\s+", "", text, flags=re.MULTILINE)
    text = text.replace("`", "")
    return text


def render_guide_text(
    slug: str,
    runtime_version: str | None = None,
    version_context: str | None = None,
) -> str:
    markdown = render_guide_markdown(slug, runtime_version=runtime_version, version_context=version_context)
    text = _markdownish_to_text(markdown)
    entry, _, _ = _guide_entry(slug, runtime_version, version_context)
    if entry.svg_filename:
        text += f"\nSVG asset: {entry.svg_filename}\n"
    return text