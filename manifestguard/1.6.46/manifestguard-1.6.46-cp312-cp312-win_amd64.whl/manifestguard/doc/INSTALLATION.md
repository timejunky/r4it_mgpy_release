# ManifestGuard Installation Guide

This guide is bundled with the package so installation instructions remain available even in restricted or offline environments.

## Online installation

Standard installation:

```bash
# Windows (preferred, user-wide Python 3.12)
py -3.12 -m pip install manifestguard

# Linux / macOS
python3.12 -m pip install manifestguard
```

Windows note:
- Prefer `py -3.12 -m pip ...` over bare `pip ...` so installation and later CLI runs use the same user-wide Python 3.12 interpreter.
- ManifestGuard reuses the interpreter that launched it for internal subprocesses. Example: `py -3.12 -m manifestguard check` keeps using that same Python 3.12 for coverage and dependency collection.

Inside a virtual environment:

```bash
python -m venv .venv
.venv\Scripts\activate
python -m pip install manifestguard
```

## Offline installation

ManifestGuard can also be installed without internet access if you prepare the wheel files in advance.

### Option 1: Download by package name on an online machine

```bash
mkdir offline_bundle
python -m pip download --dest offline_bundle manifestguard
```

This downloads the package wheel plus dependency wheels into `offline_bundle`.

Copy that folder to the offline machine and install with:

```bash
python -m pip install --no-index --find-links offline_bundle manifestguard
```

### Option 2: Install from a specific local wheel

If you received a wheel file directly, place it together with all required dependency wheels in one folder, for example `offline_bundle`.

Then install with:

```bash
python -m pip install --no-index --find-links offline_bundle manifestguard-<version>-py3-none-any.whl
```

### Protected payload case

If your organization uses a protected/commercial ManifestGuard wheel distributed outside public PyPI, the recommended flow is still `pip`-based:

```bash
python -m pip install --no-index --find-links offline_bundle manifestguard-<version>-py3-none-any.whl
```

Do not unpack wheels manually into Python directories. Keep `pip` as the installer backend so dependency handling and uninstall/update behavior remain consistent.

## Verify installation

```bash
# Windows
py -3.12 -m manifestguard --version
py -3.12 -m manifestguard check --help

# Linux / macOS
python3.12 -m manifestguard --version
python3.12 -m manifestguard check --help
```