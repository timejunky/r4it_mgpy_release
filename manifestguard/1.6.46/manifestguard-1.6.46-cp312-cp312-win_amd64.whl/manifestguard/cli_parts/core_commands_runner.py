"""Extended test runner helper for core CLI commands."""
from __future__ import annotations

import asyncio
import json
import sys
from datetime import datetime
from pathlib import Path
from threading import Event, Thread
from typing import Any

import click

from manifestguard import __version__
from manifestguard.extended import BaselineManager, ExtendedTestRunner
from manifestguard.extended.metrics import export_metrics_history
from manifestguard.i18n import t, t_format
from manifestguard.orchestration.pretest_commands import run_pretest_commands
from manifestguard.reporting.sarif import build_sarif_report
from manifestguard.validation import ValidationResult


def _run_extended_tests(
    workspace_root: Path,
    report: str | None,
    verbose: bool = False,
    fail_on_security: bool = False,
    format_: str | None = None,
    validation_result: ValidationResult | None = None,
    live: bool = True,
    live_interval_s: int = 30,
    runner_config: dict[str, Any] | None = None,
    focus: tuple[str, ...] | None = None,
    project_python: str | None = None,
    run_pre_tests: bool = False,
    skip_pre_tests: bool = False,
    pre_test_on_error: str | None = None,
    pre_test_timeout_s: int | None = None,
) -> None:
    """Run extended test mode and save results."""
    from manifestguard.cli import _build_quality_slice, _summarize_security_findings
    from manifestguard.core.git_check import format_git_check_report, is_git_repo, run_git_check
    from manifestguard.reporting.refactor_guidelines import ensure_refactor_guidelines

    import time

    click.echo(f"\n{t('cli.extended.title', module='cli')}")

    started = time.monotonic()
    last_output_at = started

    def _progress(msg: str) -> None:
        now = datetime.now().strftime("%H:%M:%S")
        elapsed_s = time.monotonic() - started
        nonlocal last_output_at
        last_output_at = time.monotonic()
        click.echo(f"   [{now} +{elapsed_s:0.1f}s] {msg}")

    stop_event = Event()

    def _heartbeat() -> None:
        """Emit periodic liveness messages while extended analysis is running."""
        nonlocal last_output_at
        interval = max(5, int(live_interval_s or 30))
        while not stop_event.wait(timeout=1):
            now_mono = time.monotonic()
            if now_mono - last_output_at < interval:
                continue
            wall = datetime.now().strftime("%H:%M:%S")
            elapsed_s = now_mono - started
            click.echo(f"   [{wall} +{elapsed_s:0.1f}s] … still running")
            last_output_at = now_mono

    try:
        pretest_summary = run_pretest_commands(
            workspace_root,
            project_python=project_python,
            force_run=run_pre_tests,
            force_skip=skip_pre_tests,
            on_error_override=pre_test_on_error,
            timeout_override_seconds=pre_test_timeout_s,
        )
    except RuntimeError as e:
        click.echo(f"\n❌ {e}")
        raise click.Abort() from e

    if pretest_summary.get("executed"):
        click.echo("   Pre-test commands executed.")

    gate_counts: tuple[int, int, int] | None = None
    if validation_result is not None:
        gate_counts = (
            int(getattr(validation_result, "error_count", 0)),
            int(getattr(validation_result, "warning_count", 0)),
            int(getattr(validation_result, "info_count", 0)),
        )

    runner = ExtendedTestRunner(
        workspace_root,
        config=runner_config or {},
        gate_counts=gate_counts,
        python_override=project_python,
    )
    if not runner.is_enabled():
        click.echo(f"   {t('cli.extended.disabled', module='cli')}")
        return

    heartbeat_thread: Thread | None = None
    if live and sys.stdout.isatty():
        heartbeat_thread = Thread(target=_heartbeat, name="mgpy-cli-heartbeat", daemon=True)
        heartbeat_thread.start()

    try:
        if focus:
            click.echo(f"   Focus: {', '.join(focus)}")
        metrics = asyncio.run(runner.run(progress_callback=_progress, focus=focus))
    finally:
        stop_event.set()
        if heartbeat_thread is not None:
            heartbeat_thread.join(timeout=2)
    if not metrics:
        return

    if not focus:
        asyncio.run(runner.show_recommendations(metrics, verbose=verbose))

    security_summary = _summarize_security_findings(getattr(metrics, "security", None))

    if report:
        report_path = Path(report)
        if (format_ or "").lower() == "sarif":
            sarif = build_sarif_report(workspace_root, validation_result, metrics)
            report_path.write_text(json.dumps(sarif, indent=2))
        else:
            report_data: dict[str, Any] = {"extended": metrics.to_dict()}
            if focus:
                report_data.setdefault("meta", {})["focus"] = list(focus)
            report_data.setdefault("meta", {})["preTestCommands"] = pretest_summary

            if is_git_repo(workspace_root):
                git_check_summary = format_git_check_report(run_git_check(workspace_root)).get("summary", {})
                report_data.setdefault("meta", {})["gitCheck"] = {
                    "warnings": int(git_check_summary.get("warnings", 0)),
                    "needs_commit": int(git_check_summary.get("needs_commit", 0)),
                    "ok_ignored": int(git_check_summary.get("ok_ignored", 0)),
                }
            if not focus:
                try:
                    quality = _build_quality_slice(metrics, workspace_root)
                    report_data["quality"] = quality
                except Exception as e:
                    click.echo(
                        f"   {t_format('cli.extended.export_failed', error=e, module='cli')}", err=True
                    )

                ensure_refactor_guidelines(report_data, workspace_root=workspace_root)
            report_path.write_text(json.dumps(report_data, indent=2))

        click.echo(t_format("cli.extended.report_saved_extended", path=report_path, module="cli"))
        if "refactor" in report_path.name.lower():
            click.echo("   Die Regeln von mg.rules.refactoring sind strikt einzuhalten.")

    if not focus:
        try:
            export_metrics_history(workspace_root, metrics, mgpy_version=__version__)
            click.echo(f"   {t('cli.extended.metrics_exported', module='cli')}")
        except Exception as e:
            click.echo(f"   {t_format('cli.extended.export_failed', error=e, module='cli')}", err=True)

        baseline_mgr = BaselineManager(workspace_root)
        baseline_mgr.save_baseline(metrics, label="latest")
        click.echo(f"   {t('cli.extended.baseline_updated', module='cli')}")

    wall_s = time.monotonic() - started
    metrics_s = getattr(getattr(metrics, "performance", None), "total_analysis_ms", 0.0) / 1000.0
    click.echo(f"   ⏱️  Extended duration (wall): {wall_s:0.1f}s")
    if metrics_s:
        click.echo(f"   ⏱️  Extended analysis time (measured): {metrics_s:0.1f}s")

    if fail_on_security and security_summary.get("has_findings"):
        click.echo("\n❌ Security gate failed: security findings detected.")
        click.echo(f"   Details: {json.dumps(security_summary, ensure_ascii=False)}")
        sys.exit(2)
