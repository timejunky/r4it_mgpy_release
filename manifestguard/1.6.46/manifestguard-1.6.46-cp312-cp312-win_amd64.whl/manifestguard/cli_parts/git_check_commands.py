"""CLI command: manifestguard git-check

Lists files/dirs that should or should not be committed to git,
with reasoning for each item in the selected language.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import click

from manifestguard.core.config import resolve_workspace_root
from manifestguard.core.git_check import GitCheckAction, format_git_check_report, run_git_check
from manifestguard.i18n import t


_ACTION_ICON = {
    GitCheckAction.WARNING: "⚠️ ",
    GitCheckAction.COMMIT:  "➕",
    GitCheckAction.IGNORE:  "✅",
}

_ACTION_LABEL = {
    GitCheckAction.WARNING: "WARNING — tracked, should be removed (git rm --cached)",
    GitCheckAction.COMMIT:  "COMMIT  — should be added to git",
    GitCheckAction.IGNORE:  "OK      — correctly not tracked",
}


@click.command("git-check")
@click.option(
    "--format",
    "output_format",
    type=click.Choice(["table", "json"]),
    default="table",
    show_default=True,
    help=t("cli.git_check.opt.format", module="cli"),
)
@click.option(
    "--output",
    type=click.Path(),
    default=None,
    help=t("cli.git_check.opt.output", module="cli"),
)
@click.option(
    "--verbose",
    is_flag=True,
    default=False,
    help=t("cli.git_check.opt.verbose", module="cli"),
)
@click.option(
    "--fix",
    "fix",
    is_flag=True,
    default=False,
    help=t("cli.git_check.opt.fix", module="cli"),
)
def git_check_command(output_format: str, output: str | None, verbose: bool, fix: bool) -> None:
    """List files that should or should not be in git, with reasoning.

    \b
    Actions:
      ⚠️  WARNING  — tracked but should be removed (git rm --cached)
      ➕  COMMIT   — important config exists but not yet tracked
      ✅  OK       — correctly ignored or already committed
    """
    workspace_root = resolve_workspace_root(Path.cwd())
    items = run_git_check(workspace_root)
    warnings = [i for i in items if i.action == GitCheckAction.WARNING]

    def _fix_command_for(item_path: str) -> str:
        try:
            is_dir = (workspace_root / item_path).is_dir()
        except Exception:
            is_dir = False
        if is_dir:
            return f"git rm -r --cached {item_path}"
        return f"git rm --cached {item_path}"

    if output_format == "json":
        report = format_git_check_report(items)
        if fix:
            report["fixCommands"] = [_fix_command_for(i.path) for i in warnings]
        content = json.dumps(report, ensure_ascii=False, indent=2)
        if output:
            Path(output).write_text(content, encoding="utf-8")
            click.echo(f"✅ Wrote git-check report to {output}")
        else:
            click.echo(content)
        return

    # ---- table format ----
    click.echo(f"\n{t('git_check.title', module='core')}")
    click.echo("─" * 70)

    needs_commit = [i for i in items if i.action == GitCheckAction.COMMIT and not i.tracked]
    ok_items = [i for i in items if i.action in (GitCheckAction.IGNORE, GitCheckAction.COMMIT) and i.tracked]

    if warnings:
        click.echo(click.style(f"\n⚠️  {t('git_check.section.warnings', module='core')}:", fg="yellow", bold=True))
        for item in warnings:
            click.echo(click.style(f"   {item.path}", fg="red"))
            click.echo(f"   → {item.reason}")

        if fix:
            click.echo(click.style("\n   Suggested fix commands (dry-run):", fg="yellow"))
            for item in warnings:
                click.echo(click.style(f"   {_fix_command_for(item.path)}", fg="yellow"))

    if needs_commit:
        click.echo(click.style(f"\n➕  {t('git_check.section.needs_commit', module='core')}:", fg="cyan", bold=True))
        for item in needs_commit:
            exists_tag = "" if item.exists else f" [{t('git_check.label.missing', module='core')}]"
            click.echo(click.style(f"   {item.path}{exists_tag}", fg="cyan"))
            click.echo(f"   → {item.reason}")

    if verbose and ok_items:
        click.echo(click.style(f"\n✅  {t('git_check.section.ok', module='core')}:", fg="green", bold=True))
        for item in ok_items:
            click.echo(click.style(f"   {item.path}", fg="green"))
            click.echo(f"   → {item.reason}")

    # summary
    click.echo("\n" + "─" * 70)
    summary_parts = []
    if warnings:
        summary_parts.append(click.style(f"{len(warnings)} {t('git_check.summary.warnings', module='core')}", fg="yellow"))
    if needs_commit:
        summary_parts.append(click.style(f"{len(needs_commit)} {t('git_check.summary.needs_commit', module='core')}", fg="cyan"))
    if not warnings and not needs_commit:
        summary_parts.append(click.style(t("git_check.summary.ok", module="core"), fg="green"))

    click.echo("   " + "   ".join(summary_parts))
    click.echo()

    if warnings:
        sys.exit(1)


def register(cli_group: click.Group) -> None:
    cli_group.add_command(git_check_command)
