from __future__ import annotations

import asyncio
import contextlib
import json
import logging
import sys
from datetime import datetime
from pathlib import Path
from threading import Event, Thread
from typing import Any

import click

from manifestguard import __version__, get_runtime_version
from manifestguard.core.config import ConfigurationService
from manifestguard.core.config_analysis import ConfigAnalyzer, format_warning_output
from manifestguard.core.user_settings import load_user_settings, save_user_settings, user_settings_path
from manifestguard.extended import BaselineManager, ExtendedTestRunner
from manifestguard.extended.metrics import export_metrics_history
from manifestguard.i18n import (
    SUPPORTED_LANGUAGES,
    get_current_language,
    get_current_language_source,
    set_language,
    t,
    t_format,
)
from manifestguard.quickfix import BackupContext, QuickFixAction, apply_quickfix, get_quickfixes, preview_quickfix
from manifestguard.quickfix.backup import create_snapshot
from manifestguard.reporting.sarif import build_sarif_report
from manifestguard.validation import DiagnosticSeverity, ValidationResult
from manifestguard.validation.base import Diagnostic

from .language_commands import languages_command, set_language_command
from .fix_command import fix
from .focused_commands import license_check_command, quality_command, security_command
from .core_commands_helpers import (
    _build_refactor_rules_help_hint,
    _default_refactor_rules_paths,
    _detect_installation_type,
    _display_diagnostic_group,
    _display_validation_results,
    _display_validation_summary,
    _find_misplaced_refactor_rule_warning,
    _format_diagnostic_location,
    _format_relative_path,
    _handle_deprecated_format,
    _show_config_info,
    _warn_extended_config_mismatch,
)
from .core_commands_runner import _run_extended_tests

logger = logging.getLogger(__name__)


def register(cli_group: click.Group) -> None:
    cli_group.add_command(check)
    cli_group.add_command(extended)
    cli_group.add_command(security_command)
    cli_group.add_command(quality_command)
    cli_group.add_command(license_check_command)
    cli_group.add_command(fix)
    cli_group.add_command(refactor_plan)
    cli_group.add_command(sbom)
    cli_group.add_command(set_language_command)
    cli_group.add_command(languages_command)


@click.command(name="check")
@click.argument("file", required=False, type=click.Path(exists=True))
@click.option(
    "--extended/--no-extended",
    default=True,
    help="Run extended test mode (default: enabled)",
)
@click.option(
    "--focus",
    type=click.Choice(["security", "quality", "license"], case_sensitive=False),
    multiple=True,
    help=(
        "Focus extended analysis on a subset of checks. "
        "May be repeated (e.g. --focus security --focus license). "
        "Focused runs write a minimal report (meta.focus, no quality slice) and do not update history/baseline."
    ),
)
@click.option(
    "--report",
    type=click.Path(),
    default=None,
    help="Save extended metrics to JSON file (includes refactorGuidelines for AI tooling)",
)
@click.option(
    "--format",
    "format_",
    type=click.Choice(["json", "sarif"], case_sensitive=False),
    default=None,
    help="[DEPRECATED] Output format (use --report instead)",
)
@click.option(
    "--verbose",
    "-v",
    is_flag=True,
    default=False,
    help="Show detailed Medium/Low priority recommendations",
)
@click.option(
    "--fail-on-security/--no-fail-on-security",
    default=False,
    help="Exit non-zero if extended security findings are present",
)
@click.option(
    "--acknowledge-config-warning",
    is_flag=True,
    default=False,
    help=(
        "Proceed even if an abnormal ignore configuration is detected "
        "(mass ignores / wildcard ignores)."
    ),
)
@click.option(
    "--refactor",
    is_flag=True,
    default=False,
    help=(
        "Refactor mode: skip extended test run, write only refactorGuidelines to a JSON report "
        "(default output: manifestguard-report-refactor.json). "
        "Use during AI-assisted refactor/fix loops."
    ),
)
@click.option(
    "--live/--no-live",
    default=True,
    help=(
        "Show liveness output during long-running steps (prints a heartbeat line if no progress was emitted for a while)."
    ),
)
@click.option(
    "--live-interval",
    "live_interval_s",
    type=int,
    default=30,
    show_default=True,
    help="Heartbeat interval in seconds for --live.",
)
@click.option(
    "--project-python",
    "project_python",
    type=click.Path(),
    default=None,
    help=(
        "Explicit Python interpreter for internal subprocesses (coverage, dependency collection). "
        "By default, ManifestGuard reuses the interpreter that launched the current command. "
        "Example: --project-python C:/Python312/python.exe"
    ),
)
@click.option(
    "--run-pre-tests",
    is_flag=True,
    default=False,
    help="Force-enable native mgpy pre-test command execution for this run.",
)
@click.option(
    "--skip-pre-tests",
    is_flag=True,
    default=False,
    help="Force-skip native mgpy pre-test command execution for this run.",
)
@click.option(
    "--pre-test-on-error",
    type=click.Choice(["stop", "warn", "skip"], case_sensitive=False),
    default=None,
    help="Override pre-test onError behavior for this run.",
)
@click.option(
    "--pre-test-timeout",
    "pre_test_timeout_s",
    type=int,
    default=None,
    help="Override pre-test command timeout (seconds) for this run.",
)
def check(
    file: str | None,
    extended: bool,
    focus: tuple[str, ...],
    report: str | None,
    format_: str | None,
    verbose: bool,
    fail_on_security: bool,
    acknowledge_config_warning: bool,
    refactor: bool,
    live: bool,
    live_interval_s: int,
    project_python: str | None,
    run_pre_tests: bool,
    skip_pre_tests: bool,
    pre_test_on_error: str | None,
    pre_test_timeout_s: int | None,
) -> None:
    """Validate manifest files and optionally run extended code-quality analysis.

    \b
    EXTENDED MODE (default: on)
      Runs coverage, complexity, dependency, security, SBOM and license checks.
      Results are written to the report file (--report) and printed as
      prioritised recommendations.

    \b
    NATIVE PRE-TEST COMMANDS
      Before extended analysis, mgpy can run project-local commands (e.g. pytest).
      Opt-in via .mgpy/config.json (extended.preTestCommands.enabled = true) or
      force for a single run with --run-pre-tests.
      Use --skip-pre-tests to suppress them (useful when MGVS is the outer
      orchestrator and already ran the tests).
      Timeout per command: controlled by .mgpy/config.json or --pre-test-timeout.

    \b
    USEFUL COMBINATIONS
      manifestguard check --extended --report report.json
      manifestguard check --extended --run-pre-tests --pre-test-on-error stop
      manifestguard check --extended --skip-pre-tests   # MGVS outer orchestration
      manifestguard check --refactor                    # AI refactor loop (no test run)
    """
    from manifestguard.cli import _has_license_feature, _license_tier_label, _resolve_workspace_root
    from manifestguard.cli import _run_manifest_validation
    from manifestguard.core.test_config_helper import load_manifest_config

    from manifestguard.core.run_lock import RunLock, RunLockHeldError

    import time
    from datetime import datetime

    total_started = time.monotonic()
    started_at = datetime.now().astimezone()
    runtime_version = get_runtime_version()

    def _format_wallclock(ts: datetime) -> str:
        return ts.strftime("%Y-%m-%d %H:%M:%S")

    click.echo(t("cli.banner.separator", module="cli"))
    click.echo(f"🛡️  {t('cli.description', module='cli')}")
    click.echo(f"   {t('app.version')}: {runtime_version}")
    click.echo(f"   Start time: {_format_wallclock(started_at)}")

    _detect_installation_type()

    workspace_root = _resolve_workspace_root()

    # max_repos portfolio gate (community/free tier only)
    from manifestguard.licensing.client import LicensingClient
    from manifestguard.licensing.repo_registry import check_repo_limit

    _limits = LicensingClient.get_instance().get_feature_limits()
    _max_repos = _limits.get("max_repos")
    if isinstance(_max_repos, int):
        _exceeded = check_repo_limit(workspace_root, _max_repos)
        if _exceeded is not None:
            click.echo(
                f"\n🔒 FEATURE_LIMIT_EXCEEDED: This license allows {_exceeded.max_repos} "
                f"distinct repositories."
            )
            click.echo(
                f"   {_exceeded.count} distinct project(s) tracked on this device."
            )
            click.echo("   Upgrade to Pro for unlimited repositories.")
            raise click.Abort()

    _show_config_info(workspace_root, cli_extended=extended)
    _warn_extended_config_mismatch(workspace_root, extended)

    config_service = ConfigurationService(workspace_root)
    effective_config = config_service.get_config()
    rules = effective_config.rules or {}

    ignored_rules: list[str] = []
    for rule_code, value in rules.items():
        if value is False:
            ignored_rules.append(rule_code)
        elif isinstance(value, str) and value.lower() == "off":
            ignored_rules.append(rule_code)
        elif isinstance(value, dict) and str(value.get("level", "")).lower() == "off":
            ignored_rules.append(rule_code)

    if ignored_rules:
        analyzer = ConfigAnalyzer()
        warnings = analyzer.detect_abnormal_ignores(ignored_rules)
        if warnings and not acknowledge_config_warning:
            click.echo(format_warning_output(warnings))
            raise click.Abort()

    click.echo(t("cli.banner.separator", module="cli") + "\n")

    report = _handle_deprecated_format(format_, report)

    normalized_focus = tuple(sorted({f.lower() for f in focus})) if focus else None
    if normalized_focus and not extended:
        raise click.UsageError("--focus requires --extended (remove --no-extended).")

    if run_pre_tests and skip_pre_tests:
        raise click.UsageError("Use either --run-pre-tests or --skip-pre-tests, not both.")

    if normalized_focus and refactor:
        raise click.UsageError("--focus cannot be combined with --refactor.")

    # --refactor: use a dedicated report name and always write refactorGuidelines.
    # The full validation + extended test run still executes normally.
    if refactor and report is None:
        report = "manifestguard-report-refactor.json"

    file = file or "pyproject.toml"

    lock: RunLock | None = None
    if extended:
        lock_path = workspace_root / ".manifestguard" / "manifestguard-report.lock"
        resolved_report_path: str | None = None
        if report is not None:
            report_path = Path(report)
            if not report_path.is_absolute():
                report_path = workspace_root / report_path
            resolved_report_path = str(report_path)
        lock = RunLock(lock_path, command="check", report_path=resolved_report_path)
        try:
            lock.acquire()
        except RunLockHeldError as e:
            click.echo("\n[ManifestGuard] Lauf blockiert: bereits aktiv.")
            click.echo(str(e))
            raise click.Abort() from e

    click.echo(f"🔍 {t('cli.validation.running', module='cli')}...")

    try:
        validation_result = _run_manifest_validation(workspace_root)
        _display_validation_results(validation_result)

        if validation_result.is_valid:
            click.echo(f"✅ {t('cli.validation.no_issues', module='cli')}")

        if extended:
            if not _has_license_feature("extended_analysis"):
                click.echo("\n🔒 Extended analysis requires a Pro (or higher) license.")
                click.echo(f"   Current: {_license_tier_label()}. Running basic validation only.")
                return

            _run_extended_tests(
                workspace_root,
                report,
                verbose,
                fail_on_security=fail_on_security,
                format_=format_,
                validation_result=validation_result,
                live=live,
                live_interval_s=live_interval_s,
                runner_config=load_manifest_config(workspace_root),
                focus=normalized_focus,
                project_python=project_python,
                run_pre_tests=run_pre_tests,
                skip_pre_tests=skip_pre_tests,
                pre_test_on_error=pre_test_on_error,
                pre_test_timeout_s=pre_test_timeout_s,
            )
    finally:
        if lock is not None:
            lock.release()

    ended_at = datetime.now().astimezone()
    total_s = time.monotonic() - total_started
    click.echo(f"   End time: {_format_wallclock(ended_at)}")
    click.echo(f"\n⏱️  Total duration: {total_s:0.1f}s")


@click.command(name="extended")
@click.option("--verbose", "-v", is_flag=True, default=False, help="Show detailed recommendations")
@click.option(
    "--refactor",
    is_flag=True,
    default=False,
    help="Refactor mode: write only refactorGuidelines to JSON report",
)
@click.option(
    "--focus",
    type=click.Choice(["security", "quality", "license"], case_sensitive=False),
    multiple=True,
    help=(
        "Focus extended analysis on a subset of checks. "
        "May be repeated (e.g. --focus security --focus license). "
        "Focused runs write a minimal report (meta.focus, no quality slice) and do not update history/baseline."
    ),
)
@click.option(
    "--report",
    type=click.Path(),
    default=None,
    help="Save extended metrics to JSON file",
)
@click.option(
    "--project-python",
    "project_python",
    type=click.Path(),
    default=None,
    help=(
        "Explicit Python interpreter for internal subprocesses (coverage, dependency collection). "
        "By default, ManifestGuard reuses the interpreter that launched the current command."
    ),
)
@click.option(
    "--run-pre-tests",
    is_flag=True,
    default=False,
    help="Force-enable native mgpy pre-test command execution for this run.",
)
@click.option(
    "--skip-pre-tests",
    is_flag=True,
    default=False,
    help="Force-skip native mgpy pre-test command execution for this run.",
)
@click.option(
    "--pre-test-on-error",
    type=click.Choice(["stop", "warn", "skip"], case_sensitive=False),
    default=None,
    help="Override pre-test onError behavior for this run.",
)
@click.option(
    "--pre-test-timeout",
    "pre_test_timeout_s",
    type=int,
    default=None,
    help="Override pre-test command timeout (seconds) for this run.",
)
@click.pass_context
def extended(
    ctx: click.Context,
    verbose: bool,
    refactor: bool,
    focus: tuple[str, ...],
    report: str | None,
    project_python: str | None,
    run_pre_tests: bool,
    skip_pre_tests: bool,
    pre_test_on_error: str | None,
    pre_test_timeout_s: int | None,
) -> None:
    """Full extended analysis — alias for 'check --extended'."""
    ctx.invoke(
        check,
        file=None,
        extended=True,
        focus=focus,
        report=report,
        format_=None,
        verbose=verbose,
        fail_on_security=False,
        acknowledge_config_warning=False,
        refactor=refactor,
        live=True,
        live_interval_s=30,
        project_python=project_python,
        run_pre_tests=run_pre_tests,
        skip_pre_tests=skip_pre_tests,
        pre_test_on_error=pre_test_on_error,
        pre_test_timeout_s=pre_test_timeout_s,
    )




@click.command(name="refactor-plan")
@click.option(
    "--format",
    "format_",
    type=click.Choice(["text", "json"], case_sensitive=False),
    default="text",
    help="Output format (default: text)",
)
@click.option(
    "--path",
    "rules_path",
    type=click.Path(path_type=Path),
    default=None,
    help=(
        "Optional explicit path to a mg.rules.refactoring.json file. "
        "If omitted, refactor-plan checks .mgpy/mg.rules.refactoring.json first, "
        "then .mgvs/mg.rules.refactoring.json. Refactoring rules do not live in manifestguard.json."
    ),
)
def refactor_plan(format_: str, rules_path: Path | None) -> None:
    """Print an ordered refactoring plan derived from mg.rules.refactoring.json.

    \b
    Rules file locations:
      - Preferred: .mgpy/mg.rules.refactoring.json
      - Fallback:  .mgvs/mg.rules.refactoring.json
      - Not used:  manifestguard.json

    \b
    Baseline behavior:
    - A baseline plan is always active and cannot be bypassed by configuration.
    - If a rules file exists, it can extend the plan but cannot disable baseline rules.
    - If a rules file exists but is invalid: exits non-zero with a config error.
    """

    from manifestguard.cli import _resolve_workspace_root
    from manifestguard.core.refactoring_rules import (
        RefactoringRulesError,
        build_baseline_refactoring_plan,
        load_refactoring_rules_plan,
    )

    workspace_root = _resolve_workspace_root()

    candidate_paths = []
    if rules_path is not None:
        candidate_paths.append(rules_path)
    else:
        candidate_paths.extend(_default_refactor_rules_paths(workspace_root))

    source: Path | None = None
    for p in candidate_paths:
        if p.exists():
            source = p
            break

    if source is None:
        plan = build_baseline_refactoring_plan(workspace_root / "<baseline>")
        plan.warnings.append(_build_refactor_rules_help_hint(workspace_root))
        misplaced_warning = _find_misplaced_refactor_rule_warning(workspace_root)
        if misplaced_warning:
            plan.warnings.append(misplaced_warning)
    else:
        try:
            plan = load_refactoring_rules_plan(source)
        except RefactoringRulesError as e:
            raise click.UsageError(str(e)) from e

    if format_.lower() == "json":
        out = {
            "sourcePath": str(plan.source_path),
            "version": plan.version,
            "aiInstruction": plan.ai_instruction,
            "rulesActive": [{"ruleId": r.rule_id, "order": r.order} for r in plan.rules_active],
            "aiHintsActive": [{"hintId": h.hint_id, "order": h.order} for h in plan.ai_hints_active],
            "stages": plan.stages,
            "warnings": plan.warnings,
        }
        click.echo(json.dumps(out, ensure_ascii=False, indent=2))
        return

    # text
    rel = _format_relative_path(workspace_root, plan.source_path)
    click.echo(f"Refactoring rules: {rel}")
    if plan.warnings:
        click.echo("Warnings:")
        for w in plan.warnings:
            click.echo(f"- {w}")

    if plan.ai_hints_active:
        click.echo("AI hints:")
        for h in plan.ai_hints_active:
            click.echo(f"- {h.order}:{h.hint_id}")

    if plan.ai_instruction:
        click.echo("AI instruction:")
        click.echo(plan.ai_instruction)
    if not plan.rules_active:
        click.echo("No active rules (all 0 or unknown).")
        return
    click.echo("Plan:")
    for stage in plan.stages:
        order = stage.get("order")
        rule_ids = stage.get("ruleIds") or []
        click.echo(f"- Stage {order}: " + ", ".join(rule_ids))


@click.command(name="sbom")
@click.option(
    "--format",
    "format_",
    type=click.Choice(["spdx", "cyclonedx"]),
    default="spdx",
    help="SBOM format",
)
@click.option("--output", type=click.Path(), default="sbom.json", help="Output file")
def sbom(format_: str, output: str) -> None:
    """Generate Software Bill of Materials (SBOM)."""
    from manifestguard.cli import _has_license_feature, _license_tier_label

    if not _has_license_feature("sbom_export"):
        click.echo("🔒 SBOM export requires a Pro (or higher) license.")
        click.echo(f"   Current: {_license_tier_label()}.")
        raise SystemExit(3)

    click.echo(f"📦 {t('cli.sbom.generating', module='cli')} ({format_})...")
    click.echo(t("cli.sbom.not_implemented", module="cli"))
    click.echo(f"💾 Output: {output}")
