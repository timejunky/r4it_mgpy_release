from __future__ import annotations

import csv
import json
import io
import sys
from pathlib import Path
from typing import Any

import click


def _history_entries_to_csv(entries: list[dict[str, Any]]) -> str:
    """Serialize history entries into a machine-readable CSV payload."""
    buffer = io.StringIO()
    writer = csv.DictWriter(
        buffer,
        fieldnames=["id", "timestamp", "mgpyVersion", "metricCount", "metricsJson"],
        lineterminator="\n",
    )
    writer.writeheader()
    for entry in entries:
        metrics = entry.get("metrics")
        metrics_list = metrics if isinstance(metrics, list) else []
        writer.writerow({
            "id": entry.get("id") or "",
            "timestamp": entry.get("timestamp") or "",
            "mgpyVersion": entry.get("mgpyVersion") or "",
            "metricCount": len(metrics_list),
            "metricsJson": json.dumps(metrics_list, ensure_ascii=False, separators=(",", ":")),
        })
    return buffer.getvalue()


@click.command("export-metrics")
@click.option(
    "--format",
    "format_",
    type=click.Choice(["json"], case_sensitive=False),
    default="json",
    help="Export format (currently only JSON supported)",
)
@click.option(
    "--output",
    "-o",
    type=click.Path(),
    default=None,
    help="Output file path (default: print to stdout)",
)
@click.option(
    "--pretty/--compact",
    default=True,
    help="Pretty-print JSON with indentation (default: enabled)",
)
def export_metrics_cmd(format_: str, output: str | None, pretty: bool) -> None:
    """Export quality metrics in structured format for dashboards (TODO-016)."""
    try:
        # Note: tests patch `manifestguard.cli.run_extended_tests`, so we must
        # import from there (not directly from extended.runner).
        from manifestguard.cli import _build_quality_slice, run_extended_tests

        workspace_root = Path.cwd()
        metrics = run_extended_tests(workspace_root)
        if not metrics:
            click.echo("❌ Extended tests failed or is disabled")
            sys.exit(1)

        telemetry_dict: dict[str, Any] = _build_quality_slice(metrics, workspace_root)

        json_output = (
            json.dumps(telemetry_dict, indent=2, ensure_ascii=False)
            if pretty
            else json.dumps(telemetry_dict, ensure_ascii=False)
        )

        if output:
            output_path = Path(output)
            output_path.write_text(json_output, encoding="utf-8")
            click.echo(f"✅ Metrics exported to: {output_path}")
        else:
            click.echo(json_output)

    except Exception as e:
        click.echo(f"❌ Metrics export failed: {e}", err=True)
        import traceback

        traceback.print_exc()
        sys.exit(1)


@click.command("reconstruct-metrics")
@click.option(
    "--starting-point",
    type=click.Choice(["sinceLastReconstruct", "lastYear", "fixedDate"], case_sensitive=False),
    default="sinceLastReconstruct",
    show_default=True,
    help="How far back to reconstruct Git-derived metrics.",
)
@click.option(
    "--fixed-date-iso",
    type=str,
    default=None,
    help="Fixed cutoff (ISO-8601) when --starting-point=fixedDate (e.g. 2026-01-01T00:00:00Z).",
)
@click.option(
    "--allow-widening",
    is_flag=True,
    help="Allow widening reconstruction window further back than existing reconstructCutoffIso.",
)
@click.option(
    "--window-days",
    type=int,
    default=30,
    show_default=True,
    help="Sliding window size (days) used per history entry.",
)
@click.option(
    "--path",
    "path_filter",
    type=click.Path(path_type=Path),
    default=None,
    help="Optional repo sub-path to limit git analysis (e.g. src/).",
)
@click.option(
    "--json",
    "output_json",
    is_flag=True,
    help="Output result as JSON.",
)
@click.option(
    "--dry-run",
    is_flag=True,
    help="Print what would be written without mutating the history file.",
)
def reconstruct_metrics(
    starting_point: str,
    fixed_date_iso: str | None,
    allow_widening: bool,
    window_days: int,
    path_filter: Path | None,
    output_json: bool,
    dry_run: bool,
) -> None:
    """Reconstruct repo-derived metrics into `.mgpy/metrics/manifestguard-history.json`.

    Updates existing history entries by computing Git-based metrics (bugfixes/BPD
    + repo activity) in a sliding window ending at each entry timestamp.
    """

    from manifestguard.cli import _resolve_workspace_root
    from manifestguard.extended.metrics_history_reconstruct import (
        reconstruct_metrics_history_from_repo_history,
    )
    from manifestguard.extended.metrics_history_export import resolve_history_file_path

    workspace_root = _resolve_workspace_root()

    if dry_run:
        history_path = resolve_history_file_path(workspace_root, create_if_missing=False)
        if not history_path.exists():
            click.echo("[dry-run] No history file found — nothing to reconstruct.")
            return
        try:
            wrapper = json.loads(history_path.read_text(encoding="utf-8"))
            entries = [e for e in (wrapper.get("entries") or []) if isinstance(e, dict)]
        except Exception as exc:
            click.echo(f"[dry-run] Could not read history file: {exc}", err=True)
            sys.exit(1)
        click.echo(f"[dry-run] History: {history_path}")
        click.echo(f"[dry-run] Total entries: {len(entries)}")
        click.echo(
            f"[dry-run] Would reconstruct git-derived metrics "
            f"(starting-point={starting_point}, window={window_days}d)"
        )
        click.echo("[dry-run] No files were modified.")
        return

    try:
        result = reconstruct_metrics_history_from_repo_history(
            workspace_root=workspace_root,
            starting_point=starting_point,
            fixed_date_iso=fixed_date_iso,
            allow_widening=allow_widening,
            window_days=window_days,
            path_filter=path_filter,
        )
    except Exception as exc:
        if output_json:
            click.echo(json.dumps({"success": False, "error": str(exc)}, indent=2))
        else:
            click.echo(f"❌ Reconstruction failed: {exc}")
        sys.exit(1)

    if output_json:
        click.echo(json.dumps({"success": True, **result}, indent=2))
        return

    click.echo("✅ Reconstructed repo-derived metrics")
    click.echo(f"   History: {result.get('historyFile')}")
    if result.get("backupFile"):
        click.echo(f"   Backup: {result.get('backupFile')}")
    click.echo(f"   Updated entries: {result.get('updatedEntries')}")
    click.echo(f"   Cutoff: {result.get('effectiveCutoffIso')}")
    if result.get("wideningBlocked"):
        click.echo("   Note: widening blocked (use --allow-widening to override)")
    click.echo(f"   Window: {result.get('windowDays')} days")
    if result.get("pathFilter"):
        click.echo(f"   Path filter: {result.get('pathFilter')}")


@click.command("history-export")
@click.option(
    "--format",
    "format_",
    type=click.Choice(["json", "csv"], case_sensitive=False),
    default="json",
    show_default=True,
    help="Output format.",
)
@click.option(
    "--output",
    "-o",
    type=click.Path(),
    default=None,
    help="Output file path (default: print to stdout).",
)
@click.option(
    "--prune-duplicates",
    is_flag=True,
    help="Deduplicate entries by timestamp (keep last-written). Writes back to history file with backup.",
)
@click.option(
    "--since",
    "since_iso",
    type=str,
    default=None,
    help="Only emit entries at or after this ISO-8601 date (e.g. 2026-01-01 or 2026-01-01T00:00:00Z).",
)
def history_export_cmd(
    format_: str,
    output: str | None,
    prune_duplicates: bool,
    since_iso: str | None,
) -> None:
    """Export or inspect the metrics history file.

    Without flags, dumps the full history JSON to stdout (or --output file).
    Use --prune-duplicates to deduplicate in-place (atomic write + .bak backup).
    Use --since ISO_DATE to filter entries by timestamp.
    Use --format csv for a flat machine-readable export.
    """
    import shutil
    from datetime import datetime, timezone

    from manifestguard.cli import _resolve_workspace_root
    from manifestguard.extended.metrics_history_export import resolve_history_file_path

    workspace_root = _resolve_workspace_root()
    history_path = resolve_history_file_path(workspace_root, create_if_missing=False)

    if not history_path.exists():
        click.echo("❌ No history file found.", err=True)
        sys.exit(1)

    try:
        data = json.loads(history_path.read_text(encoding="utf-8"))
    except Exception as exc:
        click.echo(f"❌ Could not read history file: {exc}", err=True)
        sys.exit(1)

    entries: list[dict] = [e for e in (data.get("entries") or []) if isinstance(e, dict)]

    if since_iso is not None:
        # Validate and parse --since value.
        since_iso_clean = since_iso.strip()
        if "T" not in since_iso_clean:
            since_iso_clean += "T00:00:00Z"
        if not since_iso_clean.endswith("Z"):
            since_iso_clean += "Z"
        try:
            since_dt = datetime.fromisoformat(since_iso_clean.replace("Z", "+00:00"))
        except ValueError:
            click.echo(f"❌ Invalid --since value: {since_iso!r} (expected ISO-8601 date)", err=True)
            sys.exit(1)
        filtered = []
        for entry in entries:
            ts_raw = entry.get("timestamp") or ""
            try:
                ts_clean = ts_raw.replace("Z", "+00:00")
                entry_dt = datetime.fromisoformat(ts_clean)
                if entry_dt.tzinfo is None:
                    entry_dt = entry_dt.replace(tzinfo=timezone.utc)
                if entry_dt >= since_dt:
                    filtered.append(entry)
            except ValueError:
                pass  # entries with un-parseable timestamps are excluded
        entries = filtered

    if prune_duplicates:
        seen: dict[str, dict] = {}
        for entry in entries:
            ts = entry.get("timestamp") or ""
            seen[ts] = entry  # last-written wins
        entries = list(seen.values())
        data["entries"] = entries
        backup = history_path.with_suffix(".bak.json")
        shutil.copy2(history_path, backup)
        # Atomic write.
        tmp = history_path.with_suffix(".tmp.json")
        tmp.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
        tmp.replace(history_path)
        click.echo(f"✅ Pruned to {len(entries)} unique entries.")
        click.echo(f"   Backup: {backup}")
        return

    if format_.lower() == "csv":
        out_str = _history_entries_to_csv(entries)
    else:
        data["entries"] = entries
        out_str = json.dumps(data, indent=2, ensure_ascii=False)

    if output:
        Path(output).write_text(out_str, encoding="utf-8")
        click.echo(f"✅ Exported {len(entries)} entries to: {output}")
    else:
        click.echo(out_str)


@click.command("repo-status")
@click.option("--json", "output_json", is_flag=True, help="Output repo registry data as JSON.")
def repo_status_cmd(output_json: bool) -> None:
    """Print repo-registry entries used for max_repos feature enforcement."""
    from manifestguard.licensing.client import LicensingClient
    from manifestguard.licensing.repo_registry import list_registered_repos

    entries = list_registered_repos()
    limits = LicensingClient.get_instance().get_feature_limits()
    max_repos = limits.get("max_repos") if isinstance(limits.get("max_repos"), int) else -1
    payload = {
        "count": len(entries),
        "maxRepos": max_repos,
        "entries": [
            {
                "fingerprint": entry.fingerprint,
                "firstSeen": entry.first_seen,
                "lastSeen": entry.last_seen,
            }
            for entry in entries
        ],
    }

    if output_json:
        click.echo(json.dumps(payload, indent=2, ensure_ascii=False))
        return

    cap_label = "unlimited" if max_repos < 0 else str(max_repos)
    click.echo(f"Repo registry: {len(entries)} entries (tier cap: {cap_label})")
    if not entries:
        click.echo("No registered repositories.")
        return

    for entry in entries:
        last_seen = entry.last_seen or "-"
        click.echo(f"{entry.fingerprint}  last-seen={last_seen}  tier-cap={cap_label}")


@click.command("ruff-metrics")
@click.option("--json", "output_json", is_flag=True, help="Output result as JSON.")
def ruff_metrics_cmd(output_json: bool) -> None:
    """Run ruff check and record violation counts in metrics history."""
    import subprocess
    import uuid
    from datetime import datetime, timezone

    from manifestguard import __version__ as mgpy_version
    from manifestguard.cli import _resolve_workspace_root
    from manifestguard.extended.metrics_history_export import _write_entry_to_workspace_history

    workspace_root = _resolve_workspace_root()
    try:
        proc = subprocess.run(
            ["ruff", "check", "--format", "json", str(workspace_root)],
            capture_output=True,
            text=True,
            cwd=workspace_root,
        )
        findings: list[dict[str, Any]] = json.loads(proc.stdout) if proc.stdout.strip() else []
    except (FileNotFoundError, json.JSONDecodeError, Exception):
        findings = []

    by_rule: dict[str, int] = {}
    for f in findings:
        code = (f.get("code") or "unknown").upper()
        by_rule[code] = by_rule.get(code, 0) + 1
    metric: dict[str, Any] = {"total": len(findings), "by_rule": by_rule}

    timestamp = datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
    entry: dict[str, Any] = {
        "id": str(uuid.uuid4()),
        "timestamp": timestamp,
        "mgpyVersion": mgpy_version,
        "metrics": [{"metric": "ruffViolations", "value": metric}],
    }
    _write_entry_to_workspace_history(workspace_root, entry)

    if output_json:
        click.echo(json.dumps({"ruffViolations": metric}, indent=2))
        return
    click.echo(f"\u2705 Ruff: {metric['total']} total violations")
    for rule, count in sorted(by_rule.items()):
        click.echo(f"   {rule}: {count}")
