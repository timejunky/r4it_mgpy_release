from __future__ import annotations

import json
from pathlib import Path
import sys
from datetime import datetime

import click

from manifestguard.licensing.client import LicenseStatusCode
from manifestguard.licensing.feature_limits import FEATURE_LIMITS
from manifestguard.licensing.tier_utils import normalize_tier
from manifestguard.i18n import t, t_format


def _get_license_client():
    from manifestguard.cli import _get_license_client as cli_get_license_client

    return cli_get_license_client()


def _parse_activation_input(raw: str) -> tuple[str, str | dict]:
    value = str(raw or "").strip()
    if not value:
        return "token", ""

    candidate_path = Path(value)
    if candidate_path.exists() and candidate_path.is_file():
        value = candidate_path.read_text(encoding="utf-8").strip()

    if value.startswith("{"):
        data = json.loads(value)
        if isinstance(data, dict) and (
            data.get("activation_key") or data.get("token") or data.get("updateEntitlementUntil")
        ):
            return "activation", data

    return "token", value


@click.command("status")
@click.option(
    "--json",
    "json_output",
    is_flag=True,
    default=False,
    help="Print machine-readable JSON (tier, status, features).",
)
def license_status(json_output: bool) -> None:
    """Show current license status and available features.

    Tip:
        Run `manifestguard license guide` for a step-by-step activation HowTo.
    """
    client = _get_license_client()
    status = client.get_status()
    raw_tier = (status.payload.get("tier") or status.payload.get("plan") or "community") if status.payload else "community"
    tier = normalize_tier(raw_tier)

    tier_features = FEATURE_LIMITS.get(tier, FEATURE_LIMITS["community"])

    feature_labels = {
        "extended_analysis": "Extended Analysis (coverage, complexity, security)",
        "sbom_export": "SBOM Export (CycloneDX, SPDX)",
        "cve_checks": "CVE Vulnerability Checks",
        "quickfix_suggestions": "QuickFix Suggestions",
        "quickfix_apply": "QuickFix Auto-Apply",
        "ci_cd": "CI/CD Integration Templates",
        "custom_rules": "Custom Validation Rules",
        "dashboard": "Dashboard & Visualization",
        "sso": "SSO / LDAP Integration   👥 Team+",
        "audit_logs": "Audit Logging            👥 Team+",
    }

    all_feature_keys = set(tier_features.keys()) | set(feature_labels.keys())
    features_json = {k: tier_features.get(k, False) for k in sorted(all_feature_keys)}

    if json_output:
        payload: dict[str, object] = {
            "tier": tier,
            "status": status.code.value,
            "expiresAt": status.expires_at,
            "features": features_json,
        }
        click.echo(json.dumps(payload, ensure_ascii=False))
        return

    tier_icons = {
        "community": "🆓",
        "pro": "⭐",
        "team": "👥",
        "enterprise": "🏢",
    }
    tier_icon = tier_icons.get(tier, "🎫")

    click.echo("=" * 60)
    click.echo("📄 ManifestGuard License Status")
    click.echo("=" * 60)

    click.echo(f"\n{tier_icon} Tier: {tier.upper()}")

    if status.code.value != "ok":
        click.echo(f"⚠️  Status: {status.code.value}")
        if status.message:
            click.echo(f"   {status.message}")
    else:
        click.echo("✅ Status: Active")

    # Show expiry if available
    if status.expires_at:
        expiry_date = datetime.fromtimestamp(status.expires_at).strftime("%Y-%m-%d")
        click.echo(f"📅 Expires: {expiry_date}")

    # Show features for current tier
    click.echo(f"\n✨ Available Features ({tier}):")

    for feature, label in feature_labels.items():
        available = tier_features.get(feature, False)
        icon = "✅" if available else "🔒"
        click.echo(f"   {icon} {label}")

    if tier == "community":
        click.echo("\n💡 Upgrade to Pro or higher to unlock premium features:")
        click.echo("   manifestguard license activate <your-token>")
    elif tier == "pro":
        click.echo("\n💡 Upgrade to Team or higher for SSO and Audit Logging:")
        click.echo("   Contact: support@ready-4-it.de")

    click.echo("=" * 60)


def license_activate(token: str) -> None:
    """Activate license with token or activation JSON.

    HowTo:
        manifestguard license guide

    Token format:
        R4IT.<base64_payload>.<base64_signature>

    Inputs:
        - TOKEN string
        - activation JSON string
        - or a file path to either of the above
    """
    client = _get_license_client()

    click.echo("🔑 Activating license...")

    try:
        input_type, payload = _parse_activation_input(token)
        if input_type == "activation":
            status = client.store_activation(payload)
        else:
            status = client.store_token(payload)

        if status.code == LicenseStatusCode.OK:
            tier = "community"
            if status.payload:
                tier = status.payload.get("tier") or status.payload.get("plan") or "community"
            click.echo("✅ License activated successfully!")
            click.echo(f"   Tier: {tier.upper()}")
            if input_type == "activation":
                click.echo("   Source: activation object")
            click.echo("\n   Use 'manifestguard license status' to view features.")
        elif status.code == LicenseStatusCode.RENEWAL_BLOCKED:
            # Token is valid but blocked — existing license is already active/better
            if "Duplicate token" in (status.message or ""):
                click.echo("✅ License already active — token is already stored.")
                click.echo("   Use 'manifestguard license status' to view your features.")
            else:
                click.echo(f"ℹ️  Activation blocked: {status.message}")
                click.echo("   Use 'manifestguard license status' to check current status.")
        else:
            click.echo("❌ License activation failed.")
            if status.message:
                click.echo(f"   Reason: {status.message}")
            click.echo("   Please check the token and try again.")
            sys.exit(1)
    except Exception as e:
        click.echo(f"❌ License activation error: {e}")
        sys.exit(1)


def license_deactivate() -> None:
    """Deactivate current license."""
    client = _get_license_client()

    # Confirm deactivation
    if not click.confirm("Are you sure you want to deactivate your license?"):
        click.echo("❌ Deactivation cancelled.")
        return

    try:
        client.deactivate()
        click.echo("✅ License deactivated.")
        click.echo("   You are now using the Community tier.")
        click.echo("\n   To reactivate: manifestguard license activate <token>")
    except Exception as e:
        click.echo(f"❌ Deactivation error: {e}")
        sys.exit(1)


def license_device_hash() -> None:
    """Print the device hash used for licensing.

    This hash is what you typically paste into the R4IT activation portal.

    HowTo:
      manifestguard license guide
    """
    client = _get_license_client()
    click.echo(client.get_device_hash())


def license_guide() -> None:
    """Print a step-by-step license activation guide (localized)."""
    click.echo(t("cli.license.guide.title", module="cli"))
    click.echo(
        t_format(
            "cli.license.guide.body",
            module="cli",
            cmd_hash="manifestguard license device-hash",
            cmd_activate="manifestguard license activate <TOKEN>",
            cmd_status="manifestguard license status",
        )
    )


def register(cli_group: click.Group) -> None:
    cli_group.add_command(license_status)
    cli_group.add_command(click.command("activate")(click.argument("token")(license_activate)))
    cli_group.add_command(click.command("deactivate")(license_deactivate))
    cli_group.add_command(click.command("device-hash")(license_device_hash))
    cli_group.add_command(click.command("guide")(license_guide))
