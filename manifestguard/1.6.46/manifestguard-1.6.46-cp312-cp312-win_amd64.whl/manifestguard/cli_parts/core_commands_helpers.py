"""Private helper functions for core CLI commands (check, extended, refactor-plan)."""
from __future__ import annotations

import json
import sys
from pathlib import Path

import click

from manifestguard.i18n import t
from manifestguard.validation import DiagnosticSeverity, ValidationResult
from manifestguard.validation.base import Diagnostic


# ---------------------------------------------------------------------------
# Installation / config banner helpers
# ---------------------------------------------------------------------------

def _detect_installation_type() -> None:
    """Display installation type information."""
    try:
        import manifestguard  # noqa: PLC0415 - avoid circular import at module level

        install_path = Path(manifestguard.__file__).parent
        install_str = str(install_path)

        label = t("cli.install.label", module="cli")
        if "site-packages" not in install_str:
            if "dev" in install_str.lower():
                install_type = t("cli.install.local_dev", module="cli")
            else:
                install_type = t("cli.install.unknown", module="cli")
            click.echo(f"   {label}: {install_type}")
        elif "Roaming" in install_str or "Local" in install_str:
            click.echo(f"   {label}: {t('cli.install.global_user', module='cli')}")
        else:
            click.echo(f"   {label}: {t('cli.install.global_system', module='cli')}")
    except Exception:
        label = t("cli.install.label", module="cli")
        click.echo(f"   {label}: {t('cli.install.unknown', module='cli')}")


def _show_config_info(workspace_root: Path, cli_extended: bool | None = None) -> None:
    """Display configuration information if available."""
    from manifestguard.cli import _find_existing_config_path

    config_path = _find_existing_config_path(workspace_root)
    if not config_path:
        return

    try:
        with config_path.open(encoding="utf-8") as handle:
            config = json.load(handle)
            config_version = config.get("version", "unknown")
            extended_enabled = cli_extended if cli_extended is not None else config.get("extended", False)
            if extended_enabled:
                status = t("cli.config.extended_enabled", module="cli")
            else:
                status = t("cli.config.extended_disabled", module="cli")
            label = t("cli.config.label", module="cli")
            click.echo(f"   {label}: v{config_version} ({status})")
    except Exception:
        return


def _warn_extended_config_mismatch(workspace_root: Path, cli_extended: bool) -> None:
    """Warn when --extended is active but manifestguard.json has extended=false."""
    if not cli_extended:
        return

    from manifestguard.cli import _find_existing_config_path

    config_path = _find_existing_config_path(workspace_root)
    if not config_path:
        return

    try:
        config = json.loads(config_path.read_text(encoding="utf-8"))
        if not config.get("extended", False):
            click.echo(
                f"⚠️  Config mismatch: --extended is active but "
                f"{config_path.name} has extended=false.\n"
                f"   Autorepair: add '\"extended\": true' to {config_path.name}, "
                f"or run:\n"
                f"     python -m manifestguard init-config --merge"
            )
    except Exception:
        pass


# ---------------------------------------------------------------------------
# Diagnostic display helpers
# ---------------------------------------------------------------------------

def _format_diagnostic_location(diag: Diagnostic) -> str:
    from manifestguard.cli import _has_license_feature

    file_name = getattr(getattr(diag, "file_path", None), "name", None) or "unknown"
    location = f"{file_name}"
    if _has_license_feature("quickfix_suggestions") and getattr(diag, "line", None):
        location += f":{diag.line}"
    return location


def _display_diagnostic_group(diagnostics: list, emoji: str, label: str) -> None:
    if not diagnostics:
        return

    from manifestguard.cli import _has_license_feature

    can_show_details = _has_license_feature("quickfix_suggestions")

    click.echo(f"\n{emoji} {len(diagnostics)} {label}:\n")

    if not can_show_details:
        seen: set[str] = set()
        ordered_files: list[str] = []
        for diag in diagnostics:
            file_name = getattr(getattr(diag, "file_path", None), "name", None)
            if not file_name:
                continue
            if file_name in seen:
                continue
            seen.add(file_name)
            ordered_files.append(file_name)
        for file_name in ordered_files:
            click.echo(f"  {file_name}")
        click.echo()
        return

    for diag in diagnostics:
        location = _format_diagnostic_location(diag)
        click.echo(f"  [{diag.code}] {location}")
        click.echo(f"  {diag.message}")
        if getattr(diag, "fix_suggestion", None):
            click.echo(f"  💡 {diag.fix_suggestion}")
        click.echo()


def _display_validation_summary(result: ValidationResult) -> None:
    unique_files = {str(path) for path in result.validated_files}
    click.echo("\n📊 Validation Summary:")
    click.echo(f"   Manifest files checked: {len(unique_files)}")
    click.echo(f"   Errors: {result.error_count}")
    click.echo(f"   Warnings: {result.warning_count}")
    click.echo(f"   Infos: {result.info_count}")


def _display_validation_results(result: ValidationResult) -> None:
    if result.is_valid and not result.diagnostics:
        return

    errors = [d for d in result.diagnostics if d.severity == DiagnosticSeverity.ERROR]
    warnings = [d for d in result.diagnostics if d.severity == DiagnosticSeverity.WARNING]

    _display_diagnostic_group(errors, "❌", "Error(s) found")
    _display_diagnostic_group(warnings, "⚠️ ", "Warning(s)")

    _display_validation_summary(result)

    if not result.is_valid:
        click.echo(f"\n❌ Validation failed with {result.error_count} error(s)")
        sys.exit(1)


def _handle_deprecated_format(format_: str | None, report: str | None) -> str | None:
    """Handle deprecated --format option and return report path."""
    from manifestguard.i18n import t as _t
    if format_ is None:
        return report

    click.echo(_t("cli.warning.format_deprecated", module="cli"), err=True)
    if report is not None:
        return report

    if format_ == "json":
        return "manifestguard-report.json"
    if format_ == "sarif":
        return "manifestguard-report.sarif"

    return report


# ---------------------------------------------------------------------------
# Refactor-plan helpers
# ---------------------------------------------------------------------------

def _format_relative_path(base: Path, path: Path) -> str:
    try:
        return str(path.relative_to(base)).replace("\\", "/")
    except ValueError:
        return str(path).replace("\\", "/")


def _default_refactor_rules_paths(workspace_root: Path) -> list[Path]:
    return [
        workspace_root / ".mgpy" / "mg.rules.refactoring.json",
        workspace_root / ".mgvs" / "mg.rules.refactoring.json",
    ]


def _build_refactor_rules_help_hint(workspace_root: Path) -> str:
    preferred, fallback = [_format_relative_path(workspace_root, path) for path in _default_refactor_rules_paths(workspace_root)]
    return (
        "Refactoring rules are not read from manifestguard.json. "
        f"Put them in '{preferred}' (preferred) or '{fallback}', or pass --path explicitly."
    )


def _find_misplaced_refactor_rule_warning(workspace_root: Path) -> str | None:
    config_path = workspace_root / "manifestguard.json"
    if not config_path.exists():
        return None

    try:
        with config_path.open(encoding="utf-8") as handle:
            config = json.load(handle)
    except Exception:
        return None

    if not isinstance(config, dict):
        return None

    misplaced_keys = [key for key in ("rules", "aiHints", "aiInstruction") if key in config]
    if not misplaced_keys:
        return None

    keys_rendered = ", ".join(misplaced_keys)
    return (
        "Found refactoring-style keys in manifestguard.json "
        f"({keys_rendered}), but refactor-plan only reads mg.rules.refactoring.json files. "
        + _build_refactor_rules_help_hint(workspace_root)
    )
