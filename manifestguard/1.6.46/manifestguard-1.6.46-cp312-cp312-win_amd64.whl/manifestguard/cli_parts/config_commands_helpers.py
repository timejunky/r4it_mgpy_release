"""Private helper functions for config CLI commands.

Extracted from config_commands.py to keep module size manageable.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, cast

import click

import manifestguard.quickcheck as qc
from manifestguard import CONFIG_SCHEMA_VERSION, __version__, get_runtime_version
from manifestguard.api.quick_check import ProjectInfo, QuickCheck
from manifestguard.i18n import t, t_format


def _show_banner() -> None:
    """Display CLI banner."""
    runtime_version = get_runtime_version()
    click.echo(t("cli.banner.separator", module="cli"))
    click.echo(t("cli.banner.config_generator", module="cli"))
    click.echo(f"   Version: {runtime_version}")
    click.echo(t("cli.banner.separator", module="cli") + "\n")


def _load_existing_config(config_path: Path) -> tuple[dict[str, Any] | None, str | None]:
    """Load existing config and return (config_dict, old_version)."""
    if not config_path.exists():
        return None, None

    try:
        with config_path.open(encoding="utf-8") as handle:
            existing = json.load(handle)
            old_version = existing.get("version", "unknown")
            click.echo(f"📄 Current config version: {old_version}")
            return existing, old_version
    except Exception:
        return None, None


def _show_project_info(project_info: ProjectInfo) -> None:
    """Display detected project information."""
    click.echo(f"   📦 Project Type: {project_info.project_type.value}")
    if project_info.detected_features:
        features_str = ", ".join(sorted(project_info.detected_features))
        click.echo(f"   ✨ Features: {features_str}")


def _show_recommendations_summary(recommendations: list[Any]) -> None:
    """Display recommendations summary."""
    high_prio = [r for r in recommendations if r.priority.value == "high"]
    medium_prio = [r for r in recommendations if r.priority.value == "medium"]
    click.echo(f"\n📋 Recommended Tests ({len(recommendations)} total):")
    click.echo(f"   🔴 High Priority: {len(high_prio)}")
    click.echo(f"   🟡 Medium Priority: {len(medium_prio)}")


def _generate_ai_recommendations(
    project_info: ProjectInfo, recommendations: list[Any]
) -> list[Any]:
    """Generate AI recommendations if available."""
    try:
        click.echo("\n" + t("cli.ai.generating", module="cli"))
        quick_check = QuickCheck()
        ai_recs = quick_check.generate_ai_recommendations(project_info, recommendations)
        if ai_recs:
            click.echo(f"   ✨ Generated {len(ai_recs)} AI recommendation(s)")
        return ai_recs
    except Exception as e:
        click.echo(f"   ⚠️  AI recommendations unavailable: {e}", err=True)
        return []


def _merge_with_existing(
    existing_config: dict[str, Any], config_template: Any, output: str
) -> dict[str, Any]:
    """Merge new config with existing config."""
    try:
        click.echo(f"\n🔄 Merging with existing {output}...")
        merged = qc.merge_configs(existing_config, config_template, preserve_user=True)

        diff = qc.compare_configs(existing_config, merged)
        if diff.get("added"):
            click.echo(f"   + Added: {', '.join(diff['added'])}")
        if diff.get("removed"):
            click.echo(f"   - Removed: {', '.join(diff['removed'])}")
        if diff.get("changed"):
            click.echo(f"   🔄 Changed: {', '.join(diff['changed'])}")

        return merged
    except Exception as e:
        click.echo(f"   ⚠️  Failed to merge: {e}", err=True)
        click.echo(f"   {t('cli.ai.using_template', module='cli')}")
        return cast(dict[Any, Any], config_template.__dict__)


def _build_final_config(config_template: Any, ai_recommendations: list[Any]) -> dict[str, Any]:
    """Build final configuration dict."""
    final_config: dict[str, Any] = {
        "version": config_template.version,
        "enabled": config_template.enabled,
        "extended": False,
        "recommended_tests": config_template.recommended_tests,
        "settings": config_template.settings,
    }

    if config_template.complexity:
        final_config["complexity"] = config_template.complexity
    if config_template.coverage:
        final_config["coverage"] = config_template.coverage
    if ai_recommendations and "recommendations" not in final_config:
        final_config["recommendations"] = ai_recommendations

    return final_config


def _write_config_file(
    config_path: Path, final_config: dict[str, Any], old_version: str | None
) -> None:
    """Write configuration to file and display success message."""
    final_config["generated_by"] = {
        "tool": "manifestguard",
        "version": __version__,
    }

    with config_path.open("w", encoding="utf-8") as handle:
        json.dump(final_config, handle, indent=2, ensure_ascii=False)
        handle.write("\n")

    new_version = final_config.get("version", CONFIG_SCHEMA_VERSION)
    if old_version and old_version != new_version:
        msg = t_format(
            "cli.init_config.config_updated",
            old_version=old_version,
            new_version=new_version,
            module="cli",
        )
        click.echo(msg)

    click.echo(t_format("cli.init_config.config_saved", filename=config_path.name, module="cli"))
    test_count = len(final_config.get("recommended_tests", []))
    click.echo(f"   {t_format('cli.init_config.tests_configured', count=test_count, module='cli')}")

    click.echo(f"\n{t('cli.init_config.next_steps', module='cli')}")
    click.echo(
        f"   {t_format('cli.init_config.step1_review', filename=config_path.name, module='cli')}"
    )
    click.echo(f"   {t('cli.init_config.step2_run', module='cli')}")
    click.echo(f"   {t('cli.init_config.step3_view', module='cli')}")
    click.echo("   Refactoring rules belong in .mgpy/mg.rules.refactoring.json, not in manifestguard.json.")


def _detect_default_report_path(workspace_root: Path) -> Path | None:
    for candidate_name in (
        "manifestguard-report.latest.json",
        "manifestguard-report.json",
        ".manifestguard/manifestguard-report.latest.json",
        ".manifestguard/manifestguard-report.json",
    ):
        candidate = workspace_root / candidate_name
        if candidate.exists() and candidate.is_file():
            return candidate
    return None


def _render_dashboard_stats_text(view_model: Any) -> str:
    lines = [
        "ManifestGuard Dashboard Stats",
        f"Data source: {view_model.data_source}",
        f"Latest timestamp: {view_model.timestamp}",
        "",
        "Cards:",
    ]

    for card in view_model.cards:
        lines.append(f"- {card.title}: {card.value} ({card.subtitle})")

    if getattr(view_model, "charts", None):
        lines.append("")
        lines.append("Charts:")
        for chart in view_model.charts:
            lines.append(f"- {chart.title}: {chart.sparkline}  {chart.value} [{chart.trend_label}]")

    lines.append("")
    lines.append("Sections:")
    for section in view_model.sections:
        lines.append(f"[{section.title}]")
        for row in section.rows:
            lines.append(f"- {row.label}: {row.value}")
        lines.append("")

    return "\n".join(lines).rstrip() + "\n"


def _load_user_config(config_path: Path, default_config: dict[str, Any]) -> dict[str, Any]:
    """Load and merge user config with defaults."""
    if not config_path.exists():
        return default_config

    try:
        user_config = json.loads(config_path.read_text())
        for key in user_config:
            if key in default_config:
                if isinstance(default_config[key], dict):
                    default_config[key].update(user_config[key])
                else:
                    default_config[key] = user_config[key]
    except json.JSONDecodeError:
        click.echo(t("cli.config.warning_invalid", module="cli"), err=True)

    return default_config


def _display_config_text(config: dict[str, Any], workspace_root: Path, config_path: Path) -> None:
    """Display configuration in text format."""
    click.echo(t("cli.show_config.title", module="cli") + "\n")
    click.echo(f"{t('cli.show_config.workspace_label', module='cli')} {workspace_root}")
    status = (
        t("cli.show_config.config_found", module="cli")
        if config_path.exists()
        else t("cli.show_config.config_not_found", module="cli")
    )
    click.echo(
        f"{t('cli.show_config.config_file_label', module='cli')} {config_path} {status}\n"
    )

    click.echo(t("cli.show_config.extended_tests_label", module="cli"))
    for test_name, test_config in config["extended_tests"].items():
        if test_name == "enabled":
            continue
        enabled = test_config.get("enabled", True) if isinstance(test_config, dict) else test_config
        status = (
            t("cli.show_config.test_enabled", module="cli")
            if enabled
            else t("cli.show_config.test_disabled", module="cli")
        )
        click.echo(f"  {status} {test_name}")
        if isinstance(test_config, dict):
            for key, value in test_config.items():
                if key != "enabled":
                    click.echo(f"      • {key}: {value}")
