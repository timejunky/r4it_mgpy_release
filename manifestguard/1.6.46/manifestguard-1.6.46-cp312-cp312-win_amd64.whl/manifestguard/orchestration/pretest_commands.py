"""Native pre-test command orchestration for mgpy extended runs.

This module allows standalone mgpy usage to run optional pre-test commands
before ``manifestguard check --extended`` continues with internal metrics.
"""

from __future__ import annotations

import json
import os
import subprocess
import sys
import time
from pathlib import Path
from typing import Any


def _load_mgpy_config(workspace_root: Path) -> dict[str, Any]:
    config_path = workspace_root / ".mgpy" / "config.json"
    if not config_path.exists():
        return {}
    try:
        parsed = json.loads(config_path.read_text(encoding="utf-8"))
    except Exception as exc:
        import sys as _sys
        print(f"[mgpy] Warning: .mgpy/config.json is not valid JSON: {exc}", file=_sys.stderr)
        return {}
    if not isinstance(parsed, dict):
        import sys as _sys
        print("[mgpy] Warning: .mgpy/config.json must be a JSON object at root level.", file=_sys.stderr)
        return {}
    _validate_mgpy_config(parsed, config_path)
    return parsed


_VALID_KINDS = frozenset({"python-module", "python-script", "exec"})
_VALID_ON_ERROR = frozenset({"stop", "warn", "skip"})


def _validate_timeout(value: Any, field: str, warn: Any) -> None:
    if value is not None and (not isinstance(value, int) or isinstance(value, bool) or value < 1):
        warn(f"'{field}' must be a positive integer.")


def _validate_on_error(value: Any, field: str, warn: Any) -> None:
    if value is not None and value not in _VALID_ON_ERROR:
        warn(f"'{field}' must be one of {sorted(_VALID_ON_ERROR)}, got {value!r}.")


def _validate_pretest_command(idx: int, cmd: Any, warn: Any) -> None:
    prefix = f"'extended.preTestCommands.commands[{idx}]'"
    if not isinstance(cmd, dict):
        warn(f"{prefix} must be an object.")
        return
    kind = cmd.get("kind")
    if kind is None:
        warn(f"{prefix}: 'kind' is required.")
    elif kind not in _VALID_KINDS:
        warn(f"{prefix}: 'kind' must be one of {sorted(_VALID_KINDS)}, got {kind!r}.")
    _validate_on_error(cmd.get("onError"), f"{prefix[1:-1]}.onError", warn)
    _validate_timeout(cmd.get("timeoutSeconds"), f"{prefix[1:-1]}.timeoutSeconds", warn)
    if cmd.get("args") is not None and not isinstance(cmd.get("args"), list):
        warn(f"{prefix}: 'args' must be an array.")
    if cmd.get("env") is not None and not isinstance(cmd.get("env"), dict):
        warn(f"{prefix}: 'env' must be an object.")


def _validate_pretest_block(ptc: dict[str, Any], warn: Any) -> None:
    enabled = ptc.get("enabled")
    if enabled is not None and not isinstance(enabled, bool):
        warn("'extended.preTestCommands.enabled' must be a boolean.")
    _validate_on_error(ptc.get("onError"), "extended.preTestCommands.onError", warn)
    _validate_timeout(ptc.get("timeoutSeconds"), "extended.preTestCommands.timeoutSeconds", warn)
    commands = ptc.get("commands")
    if commands is None:
        return
    if not isinstance(commands, list):
        warn("'extended.preTestCommands.commands' must be an array.")
        return
    for idx, cmd in enumerate(commands):
        _validate_pretest_command(idx, cmd, warn)


def _validate_mgpy_config(config: dict[str, Any], config_path: Path) -> None:
    """Lightweight structural validation of .mgpy/config.json.

    Emits warnings to stderr for schema violations rather than aborting, so a
    partially invalid config does not block a CI run.
    """
    import sys as _sys

    def _warn(msg: str) -> None:
        print(f"[mgpy] Warning: {config_path}: {msg}", file=_sys.stderr)

    extended = config.get("extended")
    if extended is None:
        return
    if not isinstance(extended, dict):
        _warn("'extended' must be an object.")
        return

    ptc = extended.get("preTestCommands")
    if ptc is None:
        return
    if not isinstance(ptc, dict):
        _warn("'extended.preTestCommands' must be an object.")
        return

    _validate_pretest_block(ptc, _warn)


def _as_bool(value: Any, default: bool = False) -> bool:
    if isinstance(value, bool):
        return value
    return default


def _as_int(value: Any, default: int) -> int:
    if isinstance(value, bool):
        return default
    if isinstance(value, int):
        return value
    if isinstance(value, float):
        return int(value)
    return default


def _as_dict(value: Any) -> dict[str, Any]:
    return value if isinstance(value, dict) else {}


def _as_list(value: Any) -> list[Any]:
    return value if isinstance(value, list) else []


def _build_command_argv(command: dict[str, Any], *, project_python: str | None) -> list[str]:
    kind = str(command.get("kind") or "").strip().lower()
    args = [str(a) for a in _as_list(command.get("args")) if str(a)]

    python_exe = str(project_python or sys.executable)
    if kind == "python-module":
        module = str(command.get("module") or "").strip()
        if not module:
            raise ValueError("preTestCommands: python-module requires 'module'")
        return [python_exe, "-m", module, *args]

    if kind == "python-script":
        script = str(command.get("script") or "").strip()
        if not script:
            raise ValueError("preTestCommands: python-script requires 'script'")
        return [python_exe, script, *args]

    if kind == "exec":
        executable = str(command.get("command") or "").strip()
        if not executable:
            raise ValueError("preTestCommands: exec requires 'command'")
        return [executable, *args]

    raise ValueError(f"preTestCommands: unsupported kind '{kind}'")


def run_pretest_commands(
    workspace_root: Path,
    *,
    project_python: str | None,
    force_run: bool = False,
    force_skip: bool = False,
    on_error_override: str | None = None,
    timeout_override_seconds: int | None = None,
) -> dict[str, Any]:
    config = _load_mgpy_config(workspace_root)
    extended = _as_dict(config.get("extended"))
    pretest = _as_dict(extended.get("preTestCommands"))

    enabled = _as_bool(pretest.get("enabled"), default=False)
    commands = [c for c in _as_list(pretest.get("commands")) if isinstance(c, dict)]

    env_skip = os.environ.get("MGPY_SKIP_PRE_TESTS", "").strip() not in ("", "0", "false", "False")

    summary: dict[str, Any] = {
        "enabled": enabled,
        "executed": False,
        "reason": "disabled",
        "results": [],
    }

    if force_skip:
        summary["reason"] = "forced-skip"
        return summary

    if env_skip:
        summary["reason"] = "env-skip"
        return summary

    should_run = bool(force_run or enabled)
    if not should_run:
        return summary

    summary["executed"] = True
    summary["reason"] = "forced-run" if force_run else "enabled"
    summary["effectiveInterpreter"] = str(project_python or sys.executable)

    for idx, cmd in enumerate(commands, start=1):
        cmd_id = str(cmd.get("id") or f"cmd-{idx}")
        on_error = str(on_error_override or cmd.get("onError") or "stop").strip().lower()
        timeout_seconds = (
            timeout_override_seconds
            if isinstance(timeout_override_seconds, int) and timeout_override_seconds > 0
            else _as_int(cmd.get("timeoutSeconds"), 600)
        )

        cwd_value = str(cmd.get("cwd") or ".")
        cwd_path = Path(cwd_value)
        if not cwd_path.is_absolute():
            cwd_path = workspace_root / cwd_path

        env_extra = {
            str(k): str(v)
            for k, v in _as_dict(cmd.get("env")).items()
            if isinstance(k, str)
        }
        env = dict(os.environ)
        env.update(env_extra)

        started = time.monotonic()
        argv = _build_command_argv(cmd, project_python=project_python)

        proc = subprocess.run(  # noqa: S603 - explicit argv list, no shell
            argv,
            cwd=str(cwd_path),
            env=env,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=max(1, timeout_seconds),
            shell=False,
            check=False,
        )

        duration_ms = int((time.monotonic() - started) * 1000)
        result = {
            "id": cmd_id,
            "kind": str(cmd.get("kind") or ""),
            "ok": proc.returncode == 0,
            "exitCode": int(proc.returncode),
            "durationMs": duration_ms,
            "argv": argv,
            "cwd": str(cwd_path),
            "onError": on_error,
            "producesCoverage": _as_bool(cmd.get("producesCoverage"), default=False),
        }
        summary["results"].append(result)

        if proc.returncode != 0 and on_error == "stop":
            raise RuntimeError(
                f"Pre-test command '{cmd_id}' failed with exit code {proc.returncode}."
            )

    return summary
