"""Project-management + OS-open helper mixin for ManifestGuard GUI."""
from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path
from typing import TYPE_CHECKING, Any

from PySide6.QtCore import QObject, QThread
from PySide6.QtWidgets import (
    QFileDialog,
    QInputDialog,
    QMessageBox,
    QWidget,
)

if TYPE_CHECKING:
    pass


class GuiProjectMixin:
    if TYPE_CHECKING:
        def __getattr__(self, name: str) -> Any: ...

    def _add_project_via_dialog(self) -> None:
        start = self._get_active_project_root()
        directory = QFileDialog.getExistingDirectory(
            self,  # type: ignore[arg-type]
            "Add Project Folder",
            str(start) if start else str(Path.cwd()),
        )
        if not directory:
            return
        self._set_active_project_root(Path(directory))

    def _remove_selected_project(self) -> None:
        if not hasattr(self, "project_selector_combo"):
            return
        root_str = self.project_selector_combo.currentData()
        if not isinstance(root_str, str) or not root_str:
            return

        projects = self._get_projects()
        projects = [p for p in projects if p.get("root") != root_str]
        projects = self._sorted_projects(projects)

        new_active = ""
        if projects:
            new_active = str(projects[0].get("root") or "")

        self._save_projects(projects, active_root=new_active)
        self._refresh_project_selector_ui()
        self._apply_active_project_to_views()

    def _toggle_pin_selected_project(self) -> None:
        if not hasattr(self, "project_selector_combo"):
            return
        root_str = self.project_selector_combo.currentData()
        if not isinstance(root_str, str) or not root_str:
            return

        projects = self._get_projects()
        changed = False
        for rec in projects:
            if rec.get("root") != root_str:
                continue
            rec["pinned"] = not bool(rec.get("pinned", False))
            rec["lastUsedAt"] = self._now_iso()
            changed = True
            break
        if not changed:
            return

        projects = self._sorted_projects(projects)
        active = self._get_active_project_root_str()
        self._save_projects(projects, active_root=active)
        self._refresh_project_selector_ui()

    def _is_thread_running(self, attr_name: str) -> bool:
        thread = getattr(self, attr_name, None)
        return thread is not None and thread.isRunning()

    def _start_worker_thread(
        self,
        *,
        thread_attr: str,
        worker_attr: str,
        worker: QObject,
        on_output: object | None,
        on_finished: object,
    ) -> None:
        thread = QThread(self)  # type: ignore[arg-type]
        setattr(self, thread_attr, thread)
        setattr(self, worker_attr, worker)

        worker.moveToThread(thread)
        thread.started.connect(worker.run)  # type: ignore[attr-defined]

        if on_output is not None and hasattr(worker, "output"):
            worker.output.connect(on_output)  # type: ignore[attr-defined]

        if hasattr(worker, "finished"):
            worker.finished.connect(on_finished)  # type: ignore[attr-defined]
            worker.finished.connect(thread.quit)  # type: ignore[attr-defined]
            worker.finished.connect(worker.deleteLater)  # type: ignore[attr-defined]

        thread.finished.connect(thread.deleteLater)
        thread.start()

    def _cancel_worker(self, worker_attr: str) -> None:
        worker = getattr(self, worker_attr, None)
        if worker is None:
            return
        try:
            worker.cancel()  # type: ignore[attr-defined]
        except Exception:
            return

    def _scan_projects_dialog(self) -> None:
        base = QFileDialog.getExistingDirectory(
            self,  # type: ignore[arg-type]
            "Select Folder to Scan",
            str(self._get_active_project_root() or Path.cwd()),
        )
        if not base:
            return

        depth, ok = QInputDialog.getInt(self, "Scan Depth", "Max depth:", 4, 0, 20, 1)  # type: ignore[arg-type]
        if not ok:
            return
        max_projects, ok = QInputDialog.getInt(
            self, "Max Projects", "Max projects:", 50, 1, 5000, 1  # type: ignore[arg-type]
        )
        if not ok:
            return

        base_dir = Path(base).expanduser().resolve()
        if not base_dir.exists() or not base_dir.is_dir():
            QMessageBox.warning(self, "Invalid Folder", f"Not a directory: {base_dir}")  # type: ignore[arg-type]
            return

        if self._is_thread_running("_scan_thread"):
            QMessageBox.information(self, "Already Running", "Project scan is already running.")  # type: ignore[arg-type]
            return

        self.config_output.clear()
        self._append_config_output("Starting project discovery scan...")

        self.btn_scan_projects.setEnabled(False)
        self.btn_cancel_scan_projects.setEnabled(True)

        from manifestguard.gui_workers import ProjectDiscoveryWorker as _ProjectDiscoveryWorker

        self._scan_worker = _ProjectDiscoveryWorker(
            base_dir=base_dir,
            max_depth=int(depth),
            max_projects=int(max_projects),
        )
        self._start_worker_thread(
            thread_attr="_scan_thread",
            worker_attr="_scan_worker",
            worker=self._scan_worker,
            on_output=self._append_config_output,
            on_finished=self._on_project_scan_finished,
        )

    def _cancel_project_scan(self) -> None:
        self._cancel_worker("_scan_worker")

    def _on_project_scan_finished(self, found: object) -> None:
        self.btn_scan_projects.setEnabled(True)
        self.btn_cancel_scan_projects.setEnabled(False)

        if not isinstance(found, list):
            self._append_config_output("Scan returned unexpected result.")
            return

        projects = self._get_projects()
        existing_roots = {p.get("root") for p in projects if isinstance(p.get("root"), str)}
        added = 0

        for root_str in found:
            if not isinstance(root_str, str) or not root_str:
                continue
            normalized = self._normalize_root(root_str)
            if normalized in existing_roots:
                continue
            projects.append(self._create_project_record(Path(normalized)))
            existing_roots.add(normalized)
            added += 1

        projects = self._sorted_projects(projects)

        active = self._get_active_project_root_str()
        if not active and projects:
            active = str(projects[0].get("root") or "")

        self._save_projects(projects, active_root=active)
        self._append_config_output(f"Added {added} new project(s) to catalog.")
        self._refresh_project_selector_ui()
        self._apply_active_project_to_views()

    def _append_config_output(self, text: str) -> None:
        if hasattr(self, "config_output"):
            self.config_output.append(text)

    def _open_path_in_os(self, path: Path) -> None:
        try:
            if sys.platform == "win32":
                os.startfile(str(path))  # noqa: S606
            elif sys.platform == "darwin":
                subprocess.Popen(["open", str(path)])
            else:
                subprocess.Popen(["xdg-open", str(path)])
        except Exception as e:
            QMessageBox.critical(self, "Open Failed", str(e))  # type: ignore[arg-type]

    def _open_project_folder(self) -> None:
        root = self._selected_project_root()
        if root is None:
            QMessageBox.warning(self, "Missing Project Folder", "Please select a project folder.")  # type: ignore[arg-type]
            return
        self._open_path_in_os(root)

    def _open_manifestguard_json(self) -> None:
        root = self._selected_project_root()
        if root is None:
            QMessageBox.warning(self, "Missing Project Folder", "Please select a project folder.")  # type: ignore[arg-type]
            return

        config_path = root / "manifestguard.json"
        if not config_path.exists():
            reply = QMessageBox.question(
                self,  # type: ignore[arg-type]
                "Config Missing",
                "manifestguard.json does not exist. Create it now?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            )
            if reply != QMessageBox.StandardButton.Yes:
                return
            self._run_init_config(open_after=True)
            return

        self._open_path_in_os(config_path)
