from __future__ import annotations

from typing import Any, cast

from PySide6.QtWidgets import QMessageBox, QWidget

from manifestguard.ai.shared_preferences import get_shared_preferences


class _GuiAISettingsMixin:
    """AI settings persistence and provider/model selection helpers."""

    def _load_ai_settings(self) -> None:
        """Load AI settings from shared preferences and GUI state."""
        try:
            prefs = get_shared_preferences(config_file=self._get_manifestguard_json_path())
            config = prefs.get_provider_config()

            provider_map = {
                "ollama": "Local (Ollama)",
                "openai-compatible": "OpenAI",
            }
            provider_display = provider_map.get(config.provider, "Local (Ollama)")

            self.ai_provider_combo.setCurrentText(provider_display)
            if config.model:
                self.ai_model_combo.setCurrentText(config.model)

            state = self._load_gui_state()
            ai_settings = state.get("aiSettings", {})

            hints_enabled = state.get("ai_hints_enabled")
            if hints_enabled is None:
                hints_enabled = ai_settings.get("hintsEnabled", True)
            self.ai_hints_checkbox.setChecked(bool(hints_enabled))

            preflight_enabled = state.get("preflight_ai_enabled")
            if preflight_enabled is None:
                preflight_enabled = ai_settings.get("preflightEnabled", False)
            self.ai_preflight_checkbox.setChecked(bool(preflight_enabled))

        except Exception as e:
            QMessageBox.warning(cast(QWidget, self), "Load Settings Error", f"Failed to load AI settings:\n{e}")

    def _save_ai_settings(self) -> None:
        """Save AI settings to shared preferences and GUI state."""
        try:
            provider_display = self.ai_provider_combo.currentText()
            provider_map = {
                "Local (Ollama)": "ollama",
                "OpenAI": "openai-compatible",
                "Anthropic Claude": "openai-compatible",
                "DeepSeek": "openai-compatible",
                "Azure OpenAI": "openai-compatible",
            }
            provider = provider_map.get(provider_display, "ollama")

            state = self._load_gui_state()
            state["ai_hints_enabled"] = self.ai_hints_checkbox.isChecked()
            state["preflight_ai_enabled"] = self.ai_preflight_checkbox.isChecked()

            state["aiSettings"] = {
                "hintsEnabled": self.ai_hints_checkbox.isChecked(),
                "preflightEnabled": self.ai_preflight_checkbox.isChecked(),
                "provider": provider,
                "model": self.ai_model_combo.currentText(),
            }
            self._save_gui_state(state)

            self._merge_manifestguard_json_settings(
                updates={
                    "manifestguard.ai.provider": provider,
                    "manifestguard.ai.model": self.ai_model_combo.currentText(),
                }
            )
            _ = get_shared_preferences(config_file=self._get_manifestguard_json_path())

            QMessageBox.information(cast(QWidget, self), "Settings Saved", "AI settings saved successfully!")

        except Exception as e:
            QMessageBox.critical(cast(QWidget, self), "Save Error", f"Failed to save AI settings:\n{e}")

    def _auto_save_ai_settings(self) -> None:
        """Auto-save AI settings when checkboxes/combos change."""
        try:
            state = self._load_gui_state()
            ai_settings = state.get("aiSettings", {})

            state["ai_hints_enabled"] = self.ai_hints_checkbox.isChecked()
            state["preflight_ai_enabled"] = self.ai_preflight_checkbox.isChecked()

            ai_settings["hintsEnabled"] = self.ai_hints_checkbox.isChecked()
            ai_settings["preflightEnabled"] = self.ai_preflight_checkbox.isChecked()

            provider_display = self.ai_provider_combo.currentText()
            provider_map = {
                "Local (Ollama)": "ollama",
                "OpenAI": "openai-compatible",
                "Anthropic Claude": "openai-compatible",
                "DeepSeek": "openai-compatible",
                "Azure OpenAI": "openai-compatible",
            }
            ai_settings["provider"] = provider_map.get(provider_display, "ollama")
            ai_settings["model"] = self.ai_model_combo.currentText()

            state["aiSettings"] = ai_settings
            self._save_gui_state(state)
        except Exception:
            pass

    def _update_model_list(self) -> None:
        """Update model dropdown based on selected provider."""
        provider = self.ai_provider_combo.currentText()

        model_map = {
            "Local (Ollama)": [
                "qwen2.5-coder:7b",
                "deepseek-coder:6.7b",
                "codellama:13b",
                "deepseek-coder:33b",
            ],
            "OpenAI": ["gpt-4-turbo", "gpt-4", "gpt-3.5-turbo"],
            "Anthropic Claude": ["claude-3-opus", "claude-3-sonnet", "claude-3-haiku"],
            "DeepSeek": ["deepseek-coder", "deepseek-chat"],
            "Azure OpenAI": ["gpt-4-turbo", "gpt-4", "gpt-35-turbo"],
            "None": [],
        }

        self.ai_model_combo.clear()
        models = model_map.get(provider, [])
        if models:
            self.ai_model_combo.addItems(models)
        else:
            self.ai_model_combo.addItem("(No model required)")
