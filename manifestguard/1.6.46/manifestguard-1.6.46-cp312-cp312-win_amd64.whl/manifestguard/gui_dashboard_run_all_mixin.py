"""Run-all suite methods for the ManifestGuard GUI dashboard."""
from __future__ import annotations

import sys
from pathlib import Path
from typing import TYPE_CHECKING, Any, cast

from PySide6.QtWidgets import QMessageBox, QWidget


class GuiDashboardRunAllMixin:
    if TYPE_CHECKING:
        def __getattr__(self, name: str) -> Any: ...

    def _run_tool_run_all_quick(self) -> None:
        root = self._get_active_project_root()
        if root is None:
            QMessageBox.warning(cast(QWidget, self), "Missing Project", "Please select an active project first.")
            return

        rec = self._get_active_project_record() or {}
        last_report = rec.get("lastReport")
        report_path = self._resolve_project_relative_path(
            root,
            last_report if isinstance(last_report, str) and last_report else "manifestguard-report.json",
        )

        last_ext = rec.get("lastExtended")
        extended = bool(last_ext) if isinstance(last_ext, bool) else True

        check_cmd: list[str] = [sys.executable, "-m", "manifestguard", "check"]
        if extended:
            check_cmd.append("--extended")
        check_cmd.extend(["--report", str(report_path)])

        commands = [
            check_cmd,
            [
                sys.executable,
                "-m",
                "manifestguard",
                "complexity",
                "--output",
                str(Path(".manifestguard") / "metrics.json"),
            ],
            [sys.executable, "-m", "manifestguard", "coverage-weekly"],
        ]

        self._start_tools_sequence(commands=commands, title="Running quick full suite...\n")

    def _run_tool_run_all_basic(self) -> None:
        root = self._get_active_project_root()
        if root is None:
            QMessageBox.warning(cast(QWidget, self), "Missing Project", "Please select an active project first.")
            return

        rec = self._get_active_project_record() or {}
        last_report = rec.get("lastReport")
        report_path = self._resolve_project_relative_path(
            root,
            last_report if isinstance(last_report, str) and last_report else "manifestguard-report.json",
        )

        projects = self._get_projects()
        active = self._get_active_project_root_str()
        for p in projects:
            if p.get("root") == active:
                p["lastExtended"] = False
                p["lastUsedAt"] = self._now_iso()
                break
        self._save_projects(self._sorted_projects(projects), active_root=active)

        check_cmd: list[str] = [sys.executable, "-m", "manifestguard", "check", "--report", str(report_path)]

        commands = [
            check_cmd,
            [
                sys.executable,
                "-m",
                "manifestguard",
                "complexity",
                "--output",
                str(Path(".manifestguard") / "metrics.json"),
            ],
            [sys.executable, "-m", "manifestguard", "coverage-weekly"],
        ]

        self._start_tools_sequence(commands=commands, title="Running basic suite...\n")

    def _run_tool_run_all_extended(self) -> None:
        root = self._get_active_project_root()
        if root is None:
            QMessageBox.warning(cast(QWidget, self), "Missing Project", "Please select an active project first.")
            return

        rec = self._get_active_project_record() or {}
        last_report = rec.get("lastReport")
        report_path = self._resolve_project_relative_path(
            root,
            last_report if isinstance(last_report, str) and last_report else "manifestguard-report.json",
        )

        projects = self._get_projects()
        active = self._get_active_project_root_str()
        for p in projects:
            if p.get("root") == active:
                p["lastExtended"] = True
                p["lastUsedAt"] = self._now_iso()
                break
        self._save_projects(self._sorted_projects(projects), active_root=active)

        check_cmd: list[str] = [
            sys.executable,
            "-m",
            "manifestguard",
            "check",
            "--extended",
            "--report",
            str(report_path),
        ]

        commands = [
            check_cmd,
            [
                sys.executable,
                "-m",
                "manifestguard",
                "complexity",
                "--output",
                str(Path(".manifestguard") / "metrics.json"),
            ],
            [sys.executable, "-m", "manifestguard", "coverage-weekly"],
        ]

        self._start_tools_sequence(commands=commands, title="Running extended suite...\n")
