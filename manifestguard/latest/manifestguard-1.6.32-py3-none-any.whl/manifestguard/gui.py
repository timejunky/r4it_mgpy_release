"""GUI for ManifestGuard Python.

Qt-based graphical user interface with 4-tab AI configuration panel.
Based on R4IT shared AI configuration pattern.

Tabs:
- ⚙️ Config: Basic AI settings & tooling advisor
- 🤖 Models: Provider selection, model management, API keys
- 📖 Guide: Usage documentation & troubleshooting
- 🔬 Advanced: Expert features & automation
"""

from __future__ import annotations

import json
import os
import subprocess
import sys
import webbrowser
from datetime import datetime, timezone
from importlib.util import find_spec
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    pass

try:
    from PySide6.QtCore import QObject, QThread, Qt, Signal
    from PySide6.QtGui import QColor, QPalette
    from PySide6.QtWidgets import (
        QApplication,
        QCheckBox,
        QComboBox,
        QGroupBox,
        QHBoxLayout,
        QInputDialog,
        QLabel,
        QLineEdit,
        QFileDialog,
        QMainWindow,
        QMessageBox,
        QPushButton,
        QSplitter,
        QSpinBox,
        QStackedWidget,
        QTabWidget,
        QTextEdit,
        QTreeWidget,
        QTreeWidgetItem,
        QVBoxLayout,
        QWidget,
    )
except ImportError as e:
    # Keep this path dependency-free: i18n is stdlib-only.
    from manifestguard.i18n import t_format

    print(
        t_format(
            "gui.pyside_missing",
            module="gui",
            original_error=str(e),
        ),
        file=sys.stderr,
    )
    sys.exit(1)

from manifestguard import get_runtime_version
from manifestguard.ai.shared_preferences import get_shared_preferences
from manifestguard.core.safe_json_writer import write_json_file_sync
from manifestguard.gui_dashboard_stats import build_dashboard_stats_html
from manifestguard.gui_support import detect_git_origin_url
from manifestguard.gui_ai_mixin import GuiAIMixin
from manifestguard.gui_dashboard_mixin import GuiDashboardMixin
from manifestguard.gui_state_mixin import GuiStateMixin
from manifestguard.gui_workers import (
    CommandSequenceWorker as _CommandSequenceWorker,
    CommandWorker as _CommandWorker,
    PreflightAndValidationWorker as _PreflightAndValidationWorker,
    PreflightCrossAIWorker as _PreflightCrossAIWorker,
    ProjectDiscoveryWorker as _ProjectDiscoveryWorker,
    ValidationWorker as _ValidationWorker,
)


class ManifestGuardGUI(GuiStateMixin, GuiDashboardMixin, GuiAIMixin, QMainWindow):
    """Main window for ManifestGuard GUI."""

    def __init__(self) -> None:
        super().__init__()
        self._runtime_version = get_runtime_version()
        self.setWindowTitle(f"ManifestGuard v{self._runtime_version}")
        self.resize(1000, 700)

        # Set window icon if logo exists
        logo_path = Path(__file__).parent.parent.parent / "docs" / "images" / "logo.png"
        if logo_path.exists():
            from PySide6.QtGui import QIcon
            self.setWindowIcon(QIcon(str(logo_path)))

        gui_state = self._load_gui_state()
        self._dark_mode = bool(gui_state.get("darkMode", False))

        # Last preflight reports for cross-venv comparison
        self._preflight_last_reports: dict[str, dict] = {}

        # Central widget with tabs
        central_widget = QWidget()
        main_layout = QVBoxLayout(central_widget)

        # Header
        header_layout = QHBoxLayout()
        title_label = QLabel(f"ManifestGuard v{self._runtime_version}")
        title_label.setStyleSheet("font-size: 16pt; font-weight: bold;")
        header_layout.addWidget(title_label)
        header_layout.addStretch()

        self.dark_mode_checkbox = QCheckBox("Dark Mode")
        self.dark_mode_checkbox.setChecked(self._dark_mode)
        self.dark_mode_checkbox.stateChanged.connect(self._toggle_dark_mode)
        header_layout.addWidget(self.dark_mode_checkbox)
        main_layout.addLayout(header_layout)

        # Main tabs
        self.tabs = QTabWidget()
        self.tabs.addTab(self._create_dashboard_tab(), "📊 Dashboard")
        self.tabs.addTab(self._create_validation_tab(), "✅ Validation")
        self.tabs.addTab(self._create_ai_tab(), "🤖 AI Assistant")
        self.tabs.addTab(self._create_settings_tab(), "⚙️ Settings")

        main_layout.addWidget(self.tabs)

        self.setCentralWidget(central_widget)

        self._apply_theme()

        # Load initial settings
        self._load_ai_settings()
        self._load_repo_settings()

    def _create_validation_tab(self) -> QWidget:
        """Validation controls tab."""
        widget = QWidget()
        layout = QVBoxLayout(widget)

        info = QLabel(
            "<h2>✅ Validation</h2>"
            "<p><b>Note:</b> Validation and reports live in the <b>Dashboard</b> workflow (MGVS-style).</p>"
            "<ul>"
            "<li>Dashboard → Control (run checks)</li>"
            "<li>Dashboard → Report (open JSON report)</li>"
            "</ul>"
        )
        info.setWordWrap(True)
        layout.addWidget(info)

        buttons = QHBoxLayout()
        btn_open_control = QPushButton("Open Dashboard → Control")
        btn_open_control.clicked.connect(lambda: self._open_dashboard("control"))
        buttons.addWidget(btn_open_control)

        btn_open_report = QPushButton("Open Dashboard → Report")
        btn_open_report.clicked.connect(lambda: self._open_dashboard("report"))
        buttons.addWidget(btn_open_report)

        buttons.addStretch()
        layout.addLayout(buttons)

        layout.addStretch()

        return widget

    def _create_settings_tab(self) -> QWidget:
        """Settings tab for repo-scoped GUI preferences and preflight defaults."""
        widget = QWidget()
        layout = QVBoxLayout(widget)

        info = QLabel(
            "<h2>⚙️ Settings</h2>"
            "<p>Configure shared repository paths and GUI defaults used by dashboard tools.</p>"
            "<p>These values are stored in your per-user GUI state and can optionally be scoped per project.</p>"
        )
        info.setWordWrap(True)
        layout.addWidget(info)

        scope_group = QGroupBox("Settings Scope")
        scope_layout = QHBoxLayout(scope_group)
        scope_layout.addWidget(QLabel("Apply repo settings to:"))
        self.repo_settings_scope_combo = QComboBox()
        self.repo_settings_scope_combo.addItem("User-wide", "userwide")
        self.repo_settings_scope_combo.addItem("Active project only", "project")
        self.repo_settings_scope_combo.currentIndexChanged.connect(self._on_repo_settings_scope_changed)
        scope_layout.addWidget(self.repo_settings_scope_combo)
        scope_layout.addStretch()
        layout.addWidget(scope_group)

        repo_group = QGroupBox("Repository Paths")
        repo_layout = QVBoxLayout(repo_group)

        def add_path_row(label_text: str, attr_name: str, button_text: str = "Browse…") -> None:
            row = QHBoxLayout()
            row.addWidget(QLabel(label_text))
            edit = QLineEdit()
            setattr(self, attr_name, edit)
            row.addWidget(edit, 1)
            button = QPushButton(button_text)
            button.clicked.connect(lambda _checked=False, line_edit=edit: self._browse_folder_into(line_edit))
            row.addWidget(button)
            repo_layout.addLayout(row)

        add_path_row("User repo root", "user_repo_root_edit")
        add_path_row("Wheel repository", "wheel_repo_path_edit")

        origin_row = QHBoxLayout()
        origin_row.addWidget(QLabel("Remote origin URL"))
        self.remote_origin_url_edit = QLineEdit()
        origin_row.addWidget(self.remote_origin_url_edit, 1)
        btn_detect_origin = QPushButton("Detect")
        btn_detect_origin.clicked.connect(lambda: self._maybe_autofill_repo_fields(persist=True))
        origin_row.addWidget(btn_detect_origin)
        repo_layout.addLayout(origin_row)

        buttons_row = QHBoxLayout()
        btn_reload_repo_settings = QPushButton("Reload")
        btn_reload_repo_settings.clicked.connect(self._load_repo_settings)
        buttons_row.addWidget(btn_reload_repo_settings)

        btn_save_repo_settings = QPushButton("Save")
        btn_save_repo_settings.clicked.connect(self._save_repo_settings)
        buttons_row.addWidget(btn_save_repo_settings)
        buttons_row.addStretch()
        repo_layout.addLayout(buttons_row)

        layout.addWidget(repo_group)

        preflight_group = QGroupBox("Preflight / Package Capture")
        preflight_layout = QVBoxLayout(preflight_group)

        self.preflight_capture_packages_checkbox = QCheckBox(
            "Capture installed packages after VENV preflight"
        )
        self.preflight_capture_packages_checkbox.stateChanged.connect(
            lambda _state: self._save_repo_settings()
        )
        preflight_layout.addWidget(self.preflight_capture_packages_checkbox)

        self.preflight_packages_write_full_checkbox = QCheckBox(
            "Write full package snapshots in addition to timeline deltas"
        )
        self.preflight_packages_write_full_checkbox.stateChanged.connect(
            lambda _state: self._save_repo_settings()
        )
        preflight_layout.addWidget(self.preflight_packages_write_full_checkbox)

        self.wheel_backfill_enabled_checkbox = QCheckBox(
            "Enable automatic wheel backfill for missing packages"
        )
        self.wheel_backfill_enabled_checkbox.stateChanged.connect(self._on_toggle_wheel_backfill)
        preflight_layout.addWidget(self.wheel_backfill_enabled_checkbox)

        hint = QLabel(
            "These options are used by the dashboard preflight and package-history workflow. "
            "Wheel backfill is gated by a one-time confirmation."
        )
        hint.setWordWrap(True)
        preflight_layout.addWidget(hint)

        layout.addWidget(preflight_group)
        layout.addStretch()

        return widget

    def _browse_validation_workspace(self) -> None:
        # Legacy entrypoint: treat as “Add/Select project”.
        self._add_project_via_dialog()

    def _browse_project_root(self) -> None:
        # Legacy entrypoint: treat as “Add/Select project”.
        self._add_project_via_dialog()

    def _selected_project_root(self) -> Path | None:
        return self._get_active_project_root()

    def _on_active_project_changed(self, index: int) -> None:
        if index < 0:
            return
        if not hasattr(self, "project_selector_combo"):
            return
        root_str = self.project_selector_combo.currentData()
        if not isinstance(root_str, str) or not root_str:
            return
        try:
            root = Path(root_str).expanduser().resolve()
        except Exception:
            return
        if not root.exists() or not root.is_dir():
            QMessageBox.warning(self, "Missing Folder", f"Folder does not exist: {root}")
            return
        self._set_active_project_root(root)

    def _add_project_via_dialog(self) -> None:
        start = self._get_active_project_root()
        directory = QFileDialog.getExistingDirectory(
            self,
            "Add Project Folder",
            str(start) if start else str(Path.cwd()),
        )
        if not directory:
            return
        self._set_active_project_root(Path(directory))

    def _remove_selected_project(self) -> None:
        if not hasattr(self, "project_selector_combo"):
            return
        root_str = self.project_selector_combo.currentData()
        if not isinstance(root_str, str) or not root_str:
            return

        projects = self._get_projects()
        projects = [p for p in projects if p.get("root") != root_str]
        projects = self._sorted_projects(projects)

        new_active = ""
        if projects:
            new_active = str(projects[0].get("root") or "")

        self._save_projects(projects, active_root=new_active)
        self._refresh_project_selector_ui()
        self._apply_active_project_to_views()

    def _toggle_pin_selected_project(self) -> None:
        if not hasattr(self, "project_selector_combo"):
            return
        root_str = self.project_selector_combo.currentData()
        if not isinstance(root_str, str) or not root_str:
            return

        projects = self._get_projects()
        changed = False
        for rec in projects:
            if rec.get("root") != root_str:
                continue
            rec["pinned"] = not bool(rec.get("pinned", False))
            rec["lastUsedAt"] = self._now_iso()
            changed = True
            break
        if not changed:
            return

        projects = self._sorted_projects(projects)
        active = self._get_active_project_root_str()
        self._save_projects(projects, active_root=active)
        self._refresh_project_selector_ui()

    def _is_thread_running(self, attr_name: str) -> bool:
        thread = getattr(self, attr_name, None)
        return thread is not None and thread.isRunning()

    def _start_worker_thread(
        self,
        *,
        thread_attr: str,
        worker_attr: str,
        worker: QObject,
        on_output: object | None,
        on_finished: object,
    ) -> None:
        thread = QThread(self)
        setattr(self, thread_attr, thread)
        setattr(self, worker_attr, worker)

        worker.moveToThread(thread)
        thread.started.connect(worker.run)  # type: ignore[attr-defined]

        if on_output is not None and hasattr(worker, "output"):
            worker.output.connect(on_output)  # type: ignore[attr-defined]

        if hasattr(worker, "finished"):
            worker.finished.connect(on_finished)  # type: ignore[attr-defined]
            worker.finished.connect(thread.quit)  # type: ignore[attr-defined]
            worker.finished.connect(worker.deleteLater)  # type: ignore[attr-defined]

        thread.finished.connect(thread.deleteLater)
        thread.start()

    def _cancel_worker(self, worker_attr: str) -> None:
        worker = getattr(self, worker_attr, None)
        if worker is None:
            return
        try:
            worker.cancel()  # type: ignore[attr-defined]
        except Exception:
            return

    def _scan_projects_dialog(self) -> None:
        base = QFileDialog.getExistingDirectory(
            self,
            "Select Folder to Scan",
            str(self._get_active_project_root() or Path.cwd()),
        )
        if not base:
            return

        depth, ok = QInputDialog.getInt(self, "Scan Depth", "Max depth:", 4, 0, 20, 1)
        if not ok:
            return
        max_projects, ok = QInputDialog.getInt(
            self, "Max Projects", "Max projects:", 50, 1, 5000, 1
        )
        if not ok:
            return

        base_dir = Path(base).expanduser().resolve()
        if not base_dir.exists() or not base_dir.is_dir():
            QMessageBox.warning(self, "Invalid Folder", f"Not a directory: {base_dir}")
            return

        if self._is_thread_running("_scan_thread"):
            QMessageBox.information(self, "Already Running", "Project scan is already running.")
            return

        self.config_output.clear()
        self._append_config_output("Starting project discovery scan...")

        self.btn_scan_projects.setEnabled(False)
        self.btn_cancel_scan_projects.setEnabled(True)

        self._scan_worker = _ProjectDiscoveryWorker(
            base_dir=base_dir,
            max_depth=int(depth),
            max_projects=int(max_projects),
        )
        self._start_worker_thread(
            thread_attr="_scan_thread",
            worker_attr="_scan_worker",
            worker=self._scan_worker,
            on_output=self._append_config_output,
            on_finished=self._on_project_scan_finished,
        )

    def _cancel_project_scan(self) -> None:
        self._cancel_worker("_scan_worker")

    def _on_project_scan_finished(self, found: object) -> None:
        self.btn_scan_projects.setEnabled(True)
        self.btn_cancel_scan_projects.setEnabled(False)

        if not isinstance(found, list):
            self._append_config_output("Scan returned unexpected result.")
            return

        projects = self._get_projects()
        existing_roots = {p.get("root") for p in projects if isinstance(p.get("root"), str)}
        added = 0

        for root_str in found:
            if not isinstance(root_str, str) or not root_str:
                continue
            normalized = self._normalize_root(root_str)
            if normalized in existing_roots:
                continue
            projects.append(self._create_project_record(Path(normalized)))
            existing_roots.add(normalized)
            added += 1

        projects = self._sorted_projects(projects)

        active = self._get_active_project_root_str()
        if not active and projects:
            active = str(projects[0].get("root") or "")

        self._save_projects(projects, active_root=active)
        self._append_config_output(f"Added {added} new project(s) to catalog.")
        self._refresh_project_selector_ui()
        self._apply_active_project_to_views()

    def _append_config_output(self, text: str) -> None:
        if hasattr(self, "config_output"):
            self.config_output.append(text)

    def _open_path_in_os(self, path: Path) -> None:
        try:
            if sys.platform == "win32":
                os.startfile(str(path))  # noqa: S606
            elif sys.platform == "darwin":
                subprocess.Popen(["open", str(path)])
            else:
                subprocess.Popen(["xdg-open", str(path)])
        except Exception as e:
            QMessageBox.critical(self, "Open Failed", str(e))

    def _open_project_folder(self) -> None:
        root = self._selected_project_root()
        if root is None:
            QMessageBox.warning(self, "Missing Project Folder", "Please select a project folder.")
            return
        self._open_path_in_os(root)

    def _open_manifestguard_json(self) -> None:
        root = self._selected_project_root()
        if root is None:
            QMessageBox.warning(self, "Missing Project Folder", "Please select a project folder.")
            return

        config_path = root / "manifestguard.json"
        if not config_path.exists():
            reply = QMessageBox.question(
                self,
                "Config Missing",
                "manifestguard.json does not exist. Create it now?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            )
            if reply != QMessageBox.StandardButton.Yes:
                return
            self._run_init_config(open_after=True)
            return

        self._open_path_in_os(config_path)

    def _run_init_config(self, *, open_after: bool) -> None:
        root = self._selected_project_root()
        if root is None:
            QMessageBox.warning(self, "Missing Project Folder", "Please select a project folder.")
            return

        if self._is_thread_running("_init_config_thread"):
            QMessageBox.information(self, "Already Running", "init-config is already running.")
            return

        self._init_config_open_after = bool(open_after)
        self.config_output.clear()
        self._append_config_output("Starting init-config...")

        self.btn_init_config.setEnabled(False)
        self.btn_cancel_init_config.setEnabled(True)

        cmd = [
            sys.executable,
            "-m",
            "manifestguard",
            "init-config",
            "--merge",
            "--output",
            "manifestguard.json",
        ]

        self._init_config_worker = _CommandWorker(cwd=root, cmd=cmd)
        self._start_worker_thread(
            thread_attr="_init_config_thread",
            worker_attr="_init_config_worker",
            worker=self._init_config_worker,
            on_output=self._append_config_output,
            on_finished=self._on_init_config_finished,
        )

    def _cancel_init_config(self) -> None:
        self._cancel_worker("_init_config_worker")

    def _prepare_validation_run(self, headline: str) -> tuple[Path, Path, bool] | None:
        workspace_root = self._get_active_project_root()
        if workspace_root is None:
            QMessageBox.warning(self, "Missing Project Folder", "Please select a project.")
            return None

        if not workspace_root.exists() or not workspace_root.is_dir():
            QMessageBox.warning(
                self, "Invalid Project Folder", f"Not a directory: {workspace_root}"
            )
            return None

        report_raw = (self.validation_report_edit.text() or "").strip() or "manifestguard-report.json"
        report_path = Path(report_raw)
        if not report_path.is_absolute():
            report_path = (workspace_root / report_path).resolve()

        try:
            report_path.parent.mkdir(parents=True, exist_ok=True)
        except Exception as e:
            QMessageBox.critical(
                self,
                "Report Path Error",
                f"Cannot create report directory: {report_path.parent}\n\n{e}",
            )
            return None

        extended = bool(self.validation_extended_checkbox.isChecked())

        # Persist per-user + per-project state
        state = self._load_gui_state()
        state.update({"validationExtended": extended})
        self._save_gui_state(state)

        projects = self._get_projects()
        active = self._get_active_project_root_str()
        for rec in projects:
            if rec.get("root") != active:
                continue
            try:
                rel = report_path.resolve().relative_to(workspace_root.resolve())
                rec["lastReport"] = rel.as_posix()
            except Exception:
                rec["lastReport"] = str(report_path)
            rec["lastExtended"] = extended
            rec["lastUsedAt"] = self._now_iso()
            break
        self._save_projects(self._sorted_projects(projects), active_root=active)

        self.validation_output.clear()
        self._append_validation_output(headline)
        self._set_validation_running(True)

        return workspace_root, report_path, extended

    def _on_init_config_finished(self, exit_code: int) -> None:
        self.btn_init_config.setEnabled(True)
        self.btn_cancel_init_config.setEnabled(False)

        if exit_code == 0:
            self._append_config_output("\n✅ init-config succeeded.")
            state = self._load_gui_state()
            root = self._selected_project_root()
            if root is not None:
                state["projectRoot"] = str(root)
                self._save_gui_state(state)
            if getattr(self, "_init_config_open_after", False) and root is not None:
                self._open_path_in_os(root / "manifestguard.json")
        else:
            self._append_config_output(f"\n❌ init-config failed (exit code {exit_code}).")

    def _open_cli_help(self) -> None:
        QMessageBox.information(
            self,
            "CLI Help",
            "Run in a terminal:\n\npython -m manifestguard --help\npython -m manifestguard init-config --help",
        )

    def _open_manifestguard_docs(self) -> None:
        url = "https://github.com/ready-4-it/r4it_manifestguard_py"
        try:
            webbrowser.open(url)
        except Exception as e:
            QMessageBox.critical(self, "Open Docs Failed", str(e))

    def _browse_validation_report(self) -> None:
        start_dir = self.validation_workspace_edit.text() or str(Path.cwd())
        suggested_name = self.validation_report_edit.text() or "manifestguard-report.json"
        file_path, _ = QFileDialog.getSaveFileName(
            self,
            "Select Report File",
            str(Path(start_dir) / suggested_name),
            "JSON (*.json);;All Files (*)",
        )
        if file_path:
            self.validation_report_edit.setText(file_path)

    def _append_validation_output(self, text: str) -> None:
        self.validation_output.append(text)

    def _browse_dashboard_report(self) -> None:
        start_dir = str(self._get_active_project_root() or Path.cwd())
        file_path, _ = QFileDialog.getOpenFileName(
            self,
            "Open Report JSON",
            start_dir,
            "JSON (*.json);;All Files (*)",
        )
        if file_path:
            self.dashboard_report_path_edit.setText(file_path)

    def _load_dashboard_report(self) -> None:
        report_raw = (self.dashboard_report_path_edit.text() or "").strip()
        if not report_raw:
            QMessageBox.warning(self, "Missing Report", "Please select a report JSON file.")
            return

        report_path = Path(report_raw).expanduser().resolve()
        if not report_path.exists() or not report_path.is_file():
            QMessageBox.warning(self, "Invalid Report", f"Not a file: {report_path}")
            return

        try:
            data = json.loads(report_path.read_text(encoding="utf-8", errors="replace"))
        except Exception as e:
            QMessageBox.critical(self, "Parse Error", f"Failed to parse JSON:\n{e}")
            return

        files_checked = data.get("filesChecked") or data.get("files_checked")
        errors = data.get("errors")
        warnings = data.get("warnings")
        infos = data.get("infos")

        summary_lines = [
            f"Report: {report_path}",
            "",
            "Summary:",
            f"- filesChecked: {files_checked if files_checked is not None else 'n/a'}",
            f"- errors: {errors if errors is not None else 'n/a'}",
            f"- warnings: {warnings if warnings is not None else 'n/a'}",
            f"- infos: {infos if infos is not None else 'n/a'}",
        ]
        self.dashboard_report_summary.setPlainText("\n".join(summary_lines))

        if hasattr(self, "dashboard_stats_text"):
            workspace_root = self._get_active_project_root() or report_path.parent
            self.dashboard_stats_text.setHtml(build_dashboard_stats_html(workspace_root, report_path))

        state = self._load_gui_state()
        state["dashboardReport"] = str(report_path)
        self._save_gui_state(state)

        # Also store as last report for active project (relative if possible)
        root = self._get_active_project_root()
        if root is not None:
            projects = self._get_projects()
            active = self._get_active_project_root_str()
            for rec in projects:
                if rec.get("root") == active:
                    try:
                        rel = report_path.resolve().relative_to(root.resolve())
                        rec["lastReport"] = rel.as_posix()
                    except Exception:
                        rec["lastReport"] = str(report_path)
                    rec["lastUsedAt"] = self._now_iso()
                    break
            self._save_projects(self._sorted_projects(projects), active_root=active)

    def _open_dashboard_report_folder(self) -> None:
        report_raw = (self.dashboard_report_path_edit.text() or "").strip()
        if not report_raw:
            QMessageBox.warning(self, "Missing Report", "Please select a report JSON file.")
            return
        report_path = Path(report_raw).expanduser().resolve()
        folder = report_path.parent
        try:
            if sys.platform == "win32":
                os.startfile(str(folder))  # noqa: S606
            elif sys.platform == "darwin":
                subprocess.Popen(["open", str(folder)])
            else:
                subprocess.Popen(["xdg-open", str(folder)])
        except Exception as e:
            QMessageBox.critical(self, "Open Folder Failed", str(e))

    def _refresh_license_status(self) -> None:
        self.license_output.setPlainText("Running license status...\n")
        try:
            cmd = [sys.executable, "-m", "manifestguard", "license", "status"]
            result = subprocess.run(
                cmd,
                cwd=str(self._get_active_project_root() or Path.cwd()),
                capture_output=True,
                text=True,
                encoding="utf-8",
                errors="replace",
                check=False,
            )
            out = (result.stdout or "") + ("\n" + result.stderr if result.stderr else "")
            self.license_output.append(out.strip())
            if result.returncode != 0:
                self.license_output.append(f"\nExit code: {result.returncode}")
        except Exception as e:
            self.license_output.append(f"\nError: {e}")

    def _python_from_venv(self, venv_path: Path) -> Path:
        # Return candidate python executable in venv for current platform
        if sys.platform == "win32":
            candidate = venv_path / "Scripts" / "python.exe"
        else:
            candidate = venv_path / "bin" / "python"
        if candidate.exists():
            return candidate
        # fallback to system python
        return Path(sys.executable)

    def _run_validation(self) -> None:
        """Run ManifestGuard validation."""
        prepared = self._prepare_validation_run("Starting ManifestGuard validation...")
        if prepared is None:
            return
        workspace_root, report_path, extended = prepared

        self._validation_worker = _ValidationWorker(
            workspace_root=workspace_root,
            extended=extended,
            report_path=report_path,
        )
        self._start_worker_thread(
            thread_attr="_validation_thread",
            worker_attr="_validation_worker",
            worker=self._validation_worker,
            on_output=self._append_validation_output,
            on_finished=self._on_validation_finished,
        )

    def _run_preflight_and_validation(self) -> None:
        """Run vwpy preflight first, then validate (always produces report)."""
        prepared = self._prepare_validation_run("Starting vwpy preflight + validation...")
        if prepared is None:
            return
        workspace_root, report_path, extended = prepared

        self._validation_worker = _PreflightAndValidationWorker(
            workspace_root=workspace_root,
            extended=extended,
            report_path=report_path,
            preflight_timeout_seconds=30.0,
        )
        self._start_worker_thread(
            thread_attr="_validation_thread",
            worker_attr="_validation_worker",
            worker=self._validation_worker,
            on_output=self._append_validation_output,
            on_finished=self._on_validation_finished,
        )

    def _cancel_validation(self) -> None:
        self._cancel_worker("_validation_worker")

    def _on_validation_finished(self, exit_code: int) -> None:
        self._set_validation_running(False)

        if exit_code == 0:
            self._append_validation_output("\n✅ Validation succeeded.")
            # Convenience: prefill Report page and switch.
            root = self._get_active_project_root()
            rec = self._get_active_project_record() or {}
            last_report = rec.get("lastReport")
            if root is not None and isinstance(last_report, str) and hasattr(self, "dashboard_report_path_edit"):
                self.dashboard_report_path_edit.setText(
                    str(self._resolve_project_relative_path(root, last_report))
                )
            self._open_dashboard("report")
        else:
            self._append_validation_output(f"\n❌ Validation failed (exit code {exit_code}).")

    def _set_validation_running(self, running: bool) -> None:
        if hasattr(self, "btn_validate"):
            self.btn_validate.setEnabled(not running)
        if hasattr(self, "btn_preflight_validate"):
            self.btn_preflight_validate.setEnabled(not running)
        if hasattr(self, "btn_cancel_validation"):
            self.btn_cancel_validation.setEnabled(running)

    def _show_about_dialog(self) -> None:
        """Display About dialog with logo and version information."""
        from PySide6.QtGui import QPixmap

        runtime_version = get_runtime_version()
        
        msg = QMessageBox(self)
        msg.setWindowTitle("About ManifestGuard")
        
        # Load logo if available
        logo_path = Path(__file__).parent.parent.parent / "docs" / "images" / "logo.png"
        if logo_path.exists():
            pixmap = QPixmap(str(logo_path))
            # Scale down to reasonable size (max 200px wide)
            if pixmap.width() > 200:
                pixmap = pixmap.scaledToWidth(200, Qt.TransformationMode.SmoothTransformation)
            msg.setIconPixmap(pixmap)
        else:
            msg.setIcon(QMessageBox.Icon.Information)
        
        msg.setText(
            f"<h2>ManifestGuard</h2>"
            f"<p><b>Version:</b> {runtime_version}</p>"
            f"<p><b>Author:</b> Nejat Philip Eryigit</p>"
            f"<p><b>Website:</b> <a href='https://www.ready-4-it.com'>www.ready-4-it.com</a></p>"
            f"<p><b>Repository:</b> <a href='https://github.com/timejunky/r4it_manifest_guard_py'>GitHub</a></p>"
            f"<p>Python Package Manifest Validation Tool</p>"
        )
        msg.setTextFormat(Qt.TextFormat.RichText)
        msg.setStandardButtons(QMessageBox.StandardButton.Ok)
        msg.exec()


def main():
    """Launch ManifestGuard GUI."""
    app = QApplication(sys.argv)
    window = ManifestGuardGUI()
    window.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
