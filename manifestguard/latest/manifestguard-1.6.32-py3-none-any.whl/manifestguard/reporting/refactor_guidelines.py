from __future__ import annotations

from collections.abc import MutableMapping
from typing import Any


def get_refactor_guidelines() -> dict[str, Any]:
    """Return AI refactoring ground rules injected into JSON reports.

    These guidelines are intended to be consumed by automation (including AI tools)
    and should be kept in sync with MGVS, as far as possible.

    Notes:
    - Only injected into JSON reports (not SARIF) to avoid schema surprises.
    - The structure is intentionally simple and stable.
    """

    return {
        "version": "1",
        "principles": [
            {
                "id": "dummy-todo-demands-feature",
                "title": "Implement demanded features instead of preserving dummy/TODO shells",
                "description": "If dummy markers, TODOs, placeholders, or stub paths indicate that a concrete feature is expected at that location, implement the feature there instead of preserving or relocating the placeholder. Do not treat these findings as pure text-cleanup when they expose a missing behavior contract.",
            },
            {
                "id": "no-backward-compat-for-new-code",
                "title": "No backward compatibility for new development code",
                "description": "For new development/refactoring code, do not keep compatibility shims, wrappers, or legacy branches just to preserve old internal code paths. Simplify aggressively unless the compatibility requirement concerns an external data/file format contract (for example SVG/schema/versioned artifacts) rather than the implementation code itself.",
            },
            {
                "id": "threshold-gate-first",
                "title": "Pass threshold gate before expensive metrics",
                "description": "Expensive extended checks (coverage, complexity, bugfix history, etc.) may be gated until validation issue counts (errors/warnings/info) are within configured thresholds. Default gate: errors=0 and warnings=0 unless overridden in manifestguard.json testConfig. If expensive metrics were skipped, first reduce E/W to meet the gate, rerun extended analysis, then fix the extended findings properly (including duplication/redundancy findings).",
            },
            {
                "id": "modularize-not-split",
                "title": "Modularize; don’t arbitrarily split",
                "description": "Prefer modularization with clear responsibilities (extract cohesive helpers/services into dedicated modules) and keep a stable facade API in the original entry module. Avoid arbitrary splitting into many tiny files; refactors should improve architecture and reusability without fragmenting the codebase.",
            },
            {
                "id": "small-files-first",
                "title": "Start with smaller files",
                "description": "Refactor small, self-contained modules first so their functions and types can be reused from larger Python modules (prefer modularization with a stable facade, not arbitrary splitting).",
            },
            {
                "id": "python-tree-focused",
                "title": "Focus on Python source tree boundaries",
                "description": "Prioritise issues in src/, package import boundaries, CLI-vs-core separation, tests-vs-runtime separation, and venv hygiene. Prefer Python package structure improvements that make imports and reuse more predictable.",
            },
            {
                "id": "python-user-install-preferred",
                "title": "Prefer per-user ManifestGuard installs for Python",
                "description": "For Python workflows, avoid relying on a project venv copy of ManifestGuard when a global per-user installation is sufficient. If you must force the current interpreter/version instead of the preferred global one, use --force-current-python; if you must keep the install inside the current environment, use --pip-scope current explicitly.",
            },
            {
                "id": "ci-vs-refactor-views",
                "title": "Separate CI and refactor views",
                "description": "Use this refactor report as a backlog for structural improvements; use the CI view for release gating and pass/fail decisions.",
            },
            {
                "id": "tools-read-only",
                "title": "Tools stay read-only",
                "description": "Automation reports issues and suggests refactors but does not modify source code directly; humans and editors own the actual code changes.",
            },
            {
                "id": "no-placeholders",
                "title": "No placeholders",
                "description": 'Do not leave empty shells ("TODO", "placeholder", "reserved", empty providers). Either implement the intended behavior or remove the code path to avoid misleading safety/quality signals.',
            },
            {
                "id": "command-prefix-first",
                "title": "Fix command prefixes early",
                "description": "Prioritise command prefix consistency (package.json contributes + related references) early because it reduces follow-up noise in command/activation/menu checks and keeps modules reusable.",
            },
            {
                "id": "bpd-after-bugfix",
                "title": "Count bugfixes toward BPD",
                "description": "After fixing a real bug, ensure the change is recorded as a bugfix so BPD (Bugs Per Day) and bugfix totals derived from Git history remain accurate.",
            },
        ],
    }


def ensure_refactor_guidelines(report_data: MutableMapping[str, Any]) -> None:
    """Ensure JSON report objects include the `refactorGuidelines` section.

    Best-effort and non-breaking:
    - Only adds the key when missing.
    - Never overwrites user-supplied/custom report content.
    """

    if not isinstance(report_data, dict):
        return
    report_data.setdefault("refactorGuidelines", get_refactor_guidelines())
