"""ManifestGuard License Client (Step 1.3 - GREEN Phase)

Ed25519 signature-based license verification.
Singleton pattern ensures only one client instance exists.
"""

from __future__ import annotations

import base64
import contextlib
import hashlib
import json
import os
import platform
import re
import secrets
import time
from dataclasses import dataclass
from enum import Enum
from pathlib import Path
from typing import Any, ClassVar

from packaging.version import InvalidVersion, Version

from . import validator as entitlement_validator

try:
    import nacl.encoding
    import nacl.exceptions
    import nacl.signing

    NACL_AVAILABLE = True
except ImportError:
    NACL_AVAILABLE = False

import rfc8785  # type: ignore

try:
    import keyring

    KEYRING_AVAILABLE = True
except ImportError:
    KEYRING_AVAILABLE = False

from .feature_limits import FEATURE_LIMITS
from .jwt_utils import parse_token_payload, validate_token_expiry, verify_token_signature


def _canonicalize_rfc8785(obj: dict[str, Any]) -> str:
    """RFC8785 canonical JSON serialization.

    Args:
        obj: Dictionary to canonicalize

    Returns:
        Canonical JSON string

    """
    return rfc8785.dumps(obj).decode("utf8")


class LicenseStatusCode(Enum):
    """License validation status codes"""

    OK = "ok"
    MISSING = "missing"
    EXPIRED = "expired"
    TIME_WINDOW = "time_window"  # License not yet active (iat > now)
    INVALID_FORMAT = "invalid_format"  # Token format invalid
    BAD_SIGNATURE = "bad_signature"  # Signature verification failed
    PRODUCT_MISMATCH = "product_mismatch"
    TIME_ROLLBACK_BLOCKED = "time_rollback_blocked"
    MAX_DEVICES_EXCEEDED = "max_devices_exceeded"
    RENEWAL_BLOCKED = "renewal_blocked"
    DEVICE_LIMIT = "device_limit"  # Device activation limit reached
    UPDATE_ENTITLEMENT_EXPIRED = "update_entitlement_expired"  # Perpetual: token.exp passed but maintenance_until still valid


@dataclass
class LicenseStatus:
    """License status result"""

    code: LicenseStatusCode
    message: str
    payload: dict[str, Any] | None = None
    warnings: list[str] | None = None
    trial: bool = False
    expires_at: int | None = None


@dataclass
class DeviceActivation:
    """Device activation record"""

    device_hash: str
    activated_at: int
    last_seen: int


class LicensingClient:
    """Singleton License Client for ManifestGuard

    Usage:
        client = LicensingClient.get_instance()
        status = client.assess_status()
    """

    _instance: LicensingClient | None = None

    # Ed25519 Public Keys (for signature verification)
    # Key rotation: Add new keys, keep old keys for grace period
    PUBLIC_KEYS: ClassVar[dict[str, str]] = {
        "2025-11-0001": "o7y9E0nFjYX4JpscVt4dk+7crW1eQV3hCweLuVU2u1s=",  # Product dev key
        "crm-mgpy-dev-0001": "kz7/OrzrFtj8qJdR1o1Fjb/uXJZQ3i/BsxEhoyV/hvI=",  # CRM dev bridge key
        "dev-v1": "kz7/OrzrFtj8qJdR1o1Fjb/uXJZQ3i/BsxEhoyV/hvI=",  # Legacy CRM dev bridge key id
    }

    def __init__(self):
        """Private constructor - use get_instance()"""
        if LicensingClient._instance is not None:
            raise RuntimeError("Use LicensingClient.get_instance() instead")

        self.product_id = "manifestguard-python"
        self.app_name = "manifestguard"
        self._scope_root: Path | None = None

    @property
    def scope_root(self) -> Path | None:
        """Per-project scope root for isolated license storage.

        When set, ``_license_token_file_path()`` returns
        ``scope_root / ".mgpy" / "license.enc"`` instead of the global
        ``~/.manifestguard/license.token`` path. Useful for multi-project
        desktop workflows where each workspace may carry its own license token.
        """
        return self._scope_root

    @scope_root.setter
    def scope_root(self, value: "Path | str | None") -> None:
        self._scope_root = Path(value).resolve() if value is not None else None

    @classmethod
    def get_instance(cls) -> "LicensingClient":
        """Get singleton instance

        Returns:
            LicensingClient instance

        """
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    def _accepted_product_ids(self) -> set[str]:
        return {self.product_id, "manifestguard-py", "mgpy"}

    def _license_token_file_path(self) -> Path:
        # When scope_root is set, use per-project token path (.mgpy/license.enc).
        # Otherwise fall back to the user-wide path (~/.manifestguard/license.token).
        if self._scope_root is not None:
            return self._scope_root / ".mgpy" / "license.enc"
        return Path.home() / ".manifestguard" / "license.token"

    def _activation_file_path(self) -> Path:
        # Per-user activation object (persisted JSON)
        return Path.home() / ".manifestguard" / "activation.json"

    def _device_salt_file_path(self) -> Path:
        return Path.home() / ".manifestguard" / "device.salt"

    def _get_or_create_device_salt(self) -> str:
        path = self._device_salt_file_path()
        path.parent.mkdir(parents=True, exist_ok=True)
        try:
            if path.exists():
                salt = path.read_text(encoding="utf-8").strip()
                if salt:
                    return salt
        except Exception:
            pass
        salt = secrets.token_hex(16)
        try:
            tmp = path.with_suffix(path.suffix + ".tmp")
            tmp.write_text(salt, encoding="utf-8")
            tmp.replace(path)
        except Exception:
            pass
        return salt

    def get_device_hash(self) -> str:
        """Return a stable, salted SHA-256 device fingerprint (64 hex chars).

        Compatible with CRM CLI ``--device-hash`` parameter.
        Combines hostname, OS platform, and a per-user salt stored in
        ``~/.manifestguard/device.salt`` (created on first call).
        """
        salt = self._get_or_create_device_salt()
        components = "|".join([
            platform.node(),      # hostname
            platform.system(),    # OS name (Windows / Linux / Darwin)
            platform.machine(),   # CPU architecture
            salt,
        ])
        return hashlib.sha256(components.encode("utf-8")).hexdigest()

    def _device_hash_mismatch_status(
        self, activation_obj: dict[str, Any]
    ) -> LicenseStatus | None:
        expected_hash = str(activation_obj.get("device_hash") or "").strip()
        if not expected_hash:
            return None

        current_hash = self.get_device_hash()
        if expected_hash == current_hash:
            return None

        return LicenseStatus(
            code=LicenseStatusCode.DEVICE_LIMIT,
            message="Activation object is bound to a different device",
            payload=activation_obj,
            warnings=[],
        )

    def _get_persisted_activation(self) -> dict[str, Any] | None:
        if KEYRING_AVAILABLE:
            try:
                raw = keyring.get_password(self.app_name, "activation")
                if raw:
                    if (
                        os.getenv("MANIFESTGUARD_LICENSE_NOFILE", "").strip().lower()
                        != "true"
                    ):
                        path = self._activation_file_path()
                        if not path.exists():
                            with contextlib.suppress(Exception):
                                path.parent.mkdir(parents=True, exist_ok=True)
                                path.write_text(raw, encoding="utf-8")
                    return json.loads(raw)
            except Exception:
                pass

        path = self._activation_file_path()
        try:
            if not path.exists():
                return None
            text = path.read_text(encoding="utf-8").strip()
            if not text:
                return None
            return json.loads(text)
        except Exception:
            return None

    def _set_persisted_activation(self, activation_obj: dict[str, Any]) -> None:
        raw = json.dumps(activation_obj, ensure_ascii=False)
        if KEYRING_AVAILABLE:
            with contextlib.suppress(Exception):
                keyring.set_password(self.app_name, "activation", raw)

        if os.getenv("MANIFESTGUARD_LICENSE_NOFILE", "").strip().lower() == "true":
            return

        path = self._activation_file_path()
        path.parent.mkdir(parents=True, exist_ok=True)
        tmp = path.with_suffix(path.suffix + ".tmp")
        tmp.write_text(raw, encoding="utf-8")
        tmp.replace(path)

    def _delete_persisted_activation(self) -> None:
        if KEYRING_AVAILABLE:
            with contextlib.suppress(Exception):
                keyring.delete_password(self.app_name, "activation")

        path = self._activation_file_path()
        with contextlib.suppress(Exception):
            if path.exists():
                path.unlink()

    def _get_env_token(self) -> str | None:
        explicit_token = os.getenv("MANIFESTGUARD_ACTIVATION_KEY_PY", "").strip()
        if explicit_token:
            return explicit_token

        # Generic and legacy env vars may be shared by other ManifestGuard
        # products. Only honor them for mgpy when the embedded payload targets
        # this product family; otherwise fall back to the persisted mgpy token.
        for key in (
            "MANIFESTGUARD_ACTIVATION_KEY",
            "MANIFESTGUARD_LICENSE_TOKEN",
            "MANIFESTGUARD_LICENSE",
        ):
            value = os.getenv(key, "").strip()
            if value and self._is_compatible_env_override_token(value):
                return value
        return None

    def _is_compatible_env_override_token(self, token: str) -> bool:
        try:
            payload = self._parse_token(token)
        except ValueError:
            return False

        accepted_products = self._accepted_product_ids()
        product_id = str(payload.get("product_id", "")).strip().lower()
        if product_id in accepted_products:
            return True

        product = str(payload.get("product", "")).strip().lower()
        return product in accepted_products

    def _read_token_file(self) -> str | None:
        path = self._license_token_file_path()
        try:
            if not path.exists():
                return None
            token = path.read_text(encoding="utf-8").strip()
            return token or None
        except Exception:
            return None

    def _write_token_file(self, token: str) -> None:
        path = self._license_token_file_path()
        path.parent.mkdir(parents=True, exist_ok=True)
        # Best-effort atomic write.
        tmp = path.with_suffix(path.suffix + ".tmp")
        tmp.write_text(token, encoding="utf-8")
        tmp.replace(path)

    def _delete_token_file(self) -> None:
        path = self._license_token_file_path()
        with contextlib.suppress(Exception):
            if path.exists():
                path.unlink()

    def _get_persisted_token(self) -> str | None:
        # Keyring preferred; file is fallback.
        if KEYRING_AVAILABLE:
            try:
                token = keyring.get_password(self.app_name, "license")
                if token:
                    # One-time migration: if a license was activated when only
                    # keyring persistence existed, ensure the user-wide fallback
                    # file is created so other environments can see it.
                    if (
                        os.getenv("MANIFESTGUARD_LICENSE_NOFILE", "").strip().lower()
                        != "true"
                    ):
                        path = self._license_token_file_path()
                        if not path.exists():
                            with contextlib.suppress(Exception):
                                self._write_token_file(token)

                    return token
            except Exception:
                pass
        return self._read_token_file()

    def get_activation(self) -> dict[str, Any] | None:
        """Return persisted activation object if present."""
        # Prefer environment override? Not for activation objects - always persisted.
        return self._get_persisted_activation()

    def store_activation(self, activation_obj: dict[str, Any]) -> LicenseStatus:
        """Persist activation object and establish baseline per ADR-0001/ADR-0011.

        activation_obj: expected fields include `activation_key` and optional
        `updateEntitlementUntil`, `maxActivations`, `licenseId` / `sub`, `lastEligibleVersion`.
        """
        now = int(time.time())
        activation_key = str(
            activation_obj.get("activation_key") or activation_obj.get("token") or ""
        ).strip()

        if activation_key:
            token_status = self.verify_token(activation_key)
            if token_status.code in {
                LicenseStatusCode.INVALID_FORMAT,
                LicenseStatusCode.BAD_SIGNATURE,
                LicenseStatusCode.PRODUCT_MISMATCH,
            }:
                return token_status

        device_hash_status = self._device_hash_mismatch_status(activation_obj)
        if device_hash_status is not None:
            return device_hash_status

        if activation_key:
            self._set_persisted_token(activation_key)

        existing = self._get_persisted_activation()
        # If first activation for this licenseId, set baseline
        license_id = activation_obj.get("licenseId") or activation_obj.get("sub")

        if existing is None:
            # establish baseline
            baseline_first = now
            ue = activation_obj.get("updateEntitlementUntil")
            try:
                ue_epoch = entitlement_validator._to_epoch_seconds(ue) if ue is not None else None
            except Exception:
                ue_epoch = None

            if ue_epoch is None:
                baseline_max = baseline_first + 365 * 24 * 3600
            else:
                baseline_max = min(ue_epoch, baseline_first + 365 * 24 * 3600)

            activation_obj.setdefault("_baseline", {})
            activation_obj["_baseline"]["first_activation"] = baseline_first
            activation_obj["_baseline"]["max_expires_at"] = baseline_max
            self._set_persisted_activation(activation_obj)
            return LicenseStatus(code=LicenseStatusCode.OK, message="Activation stored", payload=activation_obj, expires_at=baseline_max)

        # If existing exists, enforce baseline cap per licenseId
        existing_baseline = existing.get("_baseline", {})
        if existing_baseline:
            # If new activation attempts to extend beyond baseline cap, reject
            try:
                ue_epoch = entitlement_validator._to_epoch_seconds(activation_obj.get("updateEntitlementUntil")) if activation_obj.get("updateEntitlementUntil") is not None else None
            except Exception:
                ue_epoch = None

            cap = int(existing_baseline.get("max_expires_at", 0))
            if ue_epoch is not None and ue_epoch > cap:
                return LicenseStatus(code=LicenseStatusCode.RENEWAL_BLOCKED, message="Activation would exceed baseline cap", payload=activation_obj)

        # Replace stored activation
        # carry forward baseline if present
        if existing_baseline:
            activation_obj.setdefault("_baseline", {})
            activation_obj["_baseline"]["first_activation"] = existing_baseline.get("first_activation")
            activation_obj["_baseline"]["max_expires_at"] = existing_baseline.get("max_expires_at")

        self._set_persisted_activation(activation_obj)
        effective_expiry = None
        try:
            ue_epoch = entitlement_validator._to_epoch_seconds(activation_obj.get("updateEntitlementUntil")) if activation_obj.get("updateEntitlementUntil") is not None else None
            if ue_epoch is not None:
                if activation_obj.get("_baseline"):
                    effective_expiry = min(ue_epoch, int(activation_obj["_baseline"].get("max_expires_at", ue_epoch)))
                else:
                    effective_expiry = ue_epoch
        except Exception:
            effective_expiry = None

        return LicenseStatus(code=LicenseStatusCode.OK, message="Activation stored", payload=activation_obj, expires_at=effective_expiry)

    def remove_activation(self) -> None:
        self._delete_persisted_activation()

    def is_update_entitled(self, now: int | None = None, skew_seconds: int = entitlement_validator.DEFAULT_SKEW_SECONDS) -> bool:
        act = self.get_activation()
        if not act:
            return False
        status = self._status_from_activation(act)
        if status.code not in {
            LicenseStatusCode.OK,
            LicenseStatusCode.UPDATE_ENTITLEMENT_EXPIRED,
        }:
            return False
        return entitlement_validator.is_update_entitled(act, now=now, skew_seconds=skew_seconds)

    def _safe_version(self, raw: Any) -> Version | None:
        text = str(raw or "").strip()
        if not text:
            return None

        match = re.search(r"\d+(?:\.\d+){0,3}", text)
        if not match:
            return None

        try:
            return Version(match.group(0))
        except InvalidVersion:
            return None

    def _current_runtime_version(self) -> Version | None:
        try:
            from manifestguard import get_runtime_version

            return self._safe_version(get_runtime_version())
        except Exception:
            return None

    def _is_last_eligible_version_available(self, activation_obj: dict[str, Any]) -> bool:
        current = self._current_runtime_version()
        last_eligible = self._safe_version(activation_obj.get("lastEligibleVersion"))
        if current is None or last_eligible is None:
            return False
        return current <= last_eligible

    def _merge_activation_payload(
        self,
        activation_obj: dict[str, Any],
        token_payload: dict[str, Any] | None,
    ) -> dict[str, Any]:
        payload = dict(token_payload or {})

        if activation_obj.get("licenseId") and not payload.get("sub"):
            payload["sub"] = activation_obj["licenseId"]
        if activation_obj.get("plan") and not payload.get("tier"):
            payload["tier"] = activation_obj["plan"]
        if activation_obj.get("tier"):
            payload["tier"] = activation_obj["tier"]
        if isinstance(activation_obj.get("features"), dict):
            payload["features"] = activation_obj["features"]
        if activation_obj.get("maxActivations") is not None:
            payload["maxActivations"] = activation_obj["maxActivations"]
        if activation_obj.get("lastEligibleVersion"):
            payload["lastEligibleVersion"] = activation_obj["lastEligibleVersion"]
        if activation_obj.get("updateEntitlementUntil") is not None:
            payload["updateEntitlementUntil"] = activation_obj["updateEntitlementUntil"]

        return payload

    def _status_from_activation(self, activation_obj: dict[str, Any]) -> LicenseStatus:
        activation_key = str(
            activation_obj.get("activation_key") or activation_obj.get("token") or ""
        ).strip()
        token_payload: dict[str, Any] | None = None
        trial = False

        if activation_key:
            token_status = self.verify_token(activation_key)
            if token_status.code in {
                LicenseStatusCode.INVALID_FORMAT,
                LicenseStatusCode.BAD_SIGNATURE,
                LicenseStatusCode.PRODUCT_MISMATCH,
                LicenseStatusCode.TIME_WINDOW,
                LicenseStatusCode.EXPIRED,
                LicenseStatusCode.TIME_ROLLBACK_BLOCKED,
                LicenseStatusCode.MAX_DEVICES_EXCEEDED,
                LicenseStatusCode.DEVICE_LIMIT,
                LicenseStatusCode.RENEWAL_BLOCKED,
            }:
                return token_status
            token_payload = token_status.payload
            trial = token_status.trial

        device_hash_status = self._device_hash_mismatch_status(activation_obj)
        if device_hash_status is not None:
            device_hash_status.trial = trial
            return device_hash_status

        payload = self._merge_activation_payload(activation_obj, token_payload)

        try:
            expiry = entitlement_validator._to_epoch_seconds(
                activation_obj.get("updateEntitlementUntil")
            )
        except ValueError:
            expiry = 0

        baseline = activation_obj.get("_baseline", {})
        if expiry and isinstance(baseline, dict):
            try:
                cap = int(baseline.get("max_expires_at", 0) or 0)
            except Exception:
                cap = 0
            if cap > 0:
                expiry = min(expiry, cap)

        if expiry:
            now = int(time.time())
            skew = entitlement_validator.DEFAULT_SKEW_SECONDS
            if now > (expiry + skew):
                if self._is_last_eligible_version_available(activation_obj):
                    return LicenseStatus(
                        code=LicenseStatusCode.UPDATE_ENTITLEMENT_EXPIRED,
                        message=(
                            "Update entitlement expired. Current installation is still within "
                            "the last eligible version window."
                        ),
                        payload=payload,
                        warnings=[],
                        trial=trial,
                        expires_at=expiry,
                    )
                return LicenseStatus(
                    code=LicenseStatusCode.UPDATE_ENTITLEMENT_EXPIRED,
                    message=(
                        "Update entitlement expired and the installed version is newer than "
                        "the last eligible version."
                    ),
                    payload=payload,
                    warnings=[],
                    trial=trial,
                    expires_at=expiry,
                )

        return LicenseStatus(
            code=LicenseStatusCode.OK,
            message="Activation object valid",
            payload=payload,
            warnings=[],
            trial=trial,
            expires_at=expiry or None,
        )

    def _activation_allows_paid_features(self, activation_obj: dict[str, Any]) -> bool:
        if self.is_update_entitled():
            return True
        return self._is_last_eligible_version_available(activation_obj)

    def _normalized_tier(self, raw_tier: Any) -> str:
        from .tier_utils import normalize_tier
        return normalize_tier(raw_tier)

    def _set_persisted_token(self, token: str) -> None:
        # User-wide persistence goal:
        # - Always try keyring when available (secure store)
        # - Also write a per-user fallback file so other Python environments
        #   without a working keyring backend can still see the activation.
        #
        # Opt-out: MANIFESTGUARD_LICENSE_NOFILE=true
        if KEYRING_AVAILABLE:
            with contextlib.suppress(Exception):
                keyring.set_password(self.app_name, "license", token)

        if os.getenv("MANIFESTGUARD_LICENSE_NOFILE", "").strip().lower() == "true":
            return

        self._write_token_file(token)

    def _delete_persisted_token(self) -> None:
        if KEYRING_AVAILABLE:
            with contextlib.suppress(Exception):
                keyring.delete_password(self.app_name, "license")
        self._delete_token_file()

    def _parse_token(self, token: str) -> dict[str, Any]:
        """Parse R4IT.payload.signature token — delegates to jwt_utils."""
        return parse_token_payload(token)

    def _verify_signature(self, token: str, public_key_b64: str) -> bool:
        """Verify Ed25519 signature — delegates to jwt_utils."""
        return verify_token_signature(token, public_key_b64)

    def _validate_time_window(
        self,
        payload: dict[str, Any],
    ) -> tuple[bool, LicenseStatusCode | None, str]:
        """Validate license time window (iat <= now <= exp).

        For perpetual licenses (maintenance_until present):
        - When now > exp but now < maintenance_until: returns UPDATE_ENTITLEMENT_EXPIRED
          (extension runs but update entitlement has lapsed).
        - When now > maintenance_until as well: returns EXPIRED.

        Args:
            payload: License token payload

        Returns:
            Tuple of (is_valid, status_code, message)
            - is_valid: True if time window is valid
            - status_code: LicenseStatusCode if invalid
            - message: Error message if invalid

        """
        now = int(time.time())
        iat = payload.get("iat", 0)
        exp = payload.get("exp", 0)

        if now < iat:
            return False, LicenseStatusCode.TIME_WINDOW, f"License not yet valid (starts at {iat})"

        if now > exp:
            maintenance_until = payload.get("maintenance_until")
            if maintenance_until is not None:
                try:
                    from manifestguard.licensing import validator as entitlement_validator
                    maintenance_epoch = entitlement_validator._to_epoch_seconds(maintenance_until)
                except Exception:
                    maintenance_epoch = int(maintenance_until) if isinstance(maintenance_until, (int, float)) else 0
                if maintenance_epoch > 0 and now < maintenance_epoch:
                    # Perpetual license: update entitlement lapsed, but product still runs
                    return False, LicenseStatusCode.UPDATE_ENTITLEMENT_EXPIRED, (
                        f"Update entitlement expired at {exp}. "
                        f"Maintenance window ends at {maintenance_epoch}. "
                        "Renew to restore updates."
                    )
            return False, LicenseStatusCode.EXPIRED, f"License expired at {exp}"

        return True, None, ""

    def verify_token(self, token: str) -> LicenseStatus:
        """Verify license token (Step 2.2 - GREEN Phase)

        Validates:
        - Token format (R4IT.payload.signature)
        - Signature verification (Ed25519)
        - Time window (iat <= now <= exp)
        - Product ID match

        Args:
            token: License token string

        Returns:
            LicenseStatus with validation result

        """
        # Step 1: Parse token format
        try:
            payload = self._parse_token(token)
        except ValueError as e:
            return LicenseStatus(
                code=LicenseStatusCode.INVALID_FORMAT,
                message=f"Invalid token format: {e}",
                payload=None,
            )

        # Step 2: Get key_id and public key
        # Note: Generator uses "kid" (key ID), not "key_id"
        key_id = payload.get("kid") or payload.get("key_id")
        if not key_id or key_id not in self.PUBLIC_KEYS:
            return LicenseStatus(
                code=LicenseStatusCode.BAD_SIGNATURE,
                message=f"Unknown key ID: {key_id}",
                payload=payload,
                warnings=[],
            )

        public_key_b64 = self.PUBLIC_KEYS[key_id]

        # Step 3: Verify signature
        if not self._verify_signature(token, public_key_b64):
            return LicenseStatus(
                code=LicenseStatusCode.BAD_SIGNATURE,
                message="Signature verification failed",
                payload=payload,
                warnings=[],
            )

        # Step 4: Validate product ID
        product_id = str(payload.get("product_id") or payload.get("product") or "").strip().lower()
        if product_id not in self._accepted_product_ids():
            return LicenseStatus(
                code=LicenseStatusCode.PRODUCT_MISMATCH,
                message=f"Product mismatch: expected a ManifestGuard token, got '{product_id}'",
                payload=payload,
                warnings=[],
            )

        # Step 5: Validate time window (refactored)
        is_valid, error_code, error_message = self._validate_time_window(payload)
        if not is_valid:
            exp = payload.get("exp", 0)
            # error_code should never be None here, but provide fallback
            status_code = error_code if error_code is not None else LicenseStatusCode.INVALID_FORMAT
            return LicenseStatus(
                code=status_code,
                message=error_message,
                payload=payload,
                warnings=[],
                expires_at=exp,
            )

        # Step 6: Success - return OK status
        trial = payload.get("trial", False)
        exp = payload.get("exp", 0)

        return LicenseStatus(
            code=LicenseStatusCode.OK,
            message="License valid",
            payload=payload,
            warnings=[],
            trial=trial,
            expires_at=exp,
        )

    def get_token(self) -> str | None:
        """Get stored license token from keyring (Week 2 - Step 3)

        Returns:
            Token string if stored, None otherwise

        """
        env_token = self._get_env_token()
        if env_token:
            return env_token
        return self._get_persisted_token()

    def remove_token(self) -> None:
        """Remove stored license token from keyring (Week 2 - Step 5)

        Used for license deactivation.
        """
        self._delete_persisted_token()

    def _check_renewal_policy(
        self,
        token: str,
        new_payload: dict[str, Any],
        new_status: "LicenseStatus",
        existing_token: str,
    ) -> "LicenseStatus | None":
        """Check renewal rules against an existing persisted token.

        Returns a LicenseStatus if the operation is complete (blocked or already
        stored for the "replace invalid" path).  Returns None when the renewal
        check passes — the caller is then responsible for persisting the token.

        Renewal rules:
        - Duplicate token: BLOCK
        - Existing token invalid/unparseable: replace silently + return OK
        - Different order (sub): BLOCK (with downgrade hint when applicable)
        - Same order + equal-or-earlier expiration: BLOCK
        - Same order + later expiration: PASS (return None)
        """
        import time as _time

        new_order = new_payload.get("sub")
        new_exp = int(new_payload.get("exp", 0))

        def _fmt_exp(ts: Any) -> str:
            try:
                tts = int(ts)
                if tts <= 0:
                    return "unknown"
                return _time.strftime("%Y-%m-%d", _time.localtime(tts))
            except Exception:
                return "unknown"

        def _is_trial(payload: dict[str, Any] | None) -> bool:
            if not payload:
                return False
            if bool(payload.get("trial")):
                return True
            plan = str(payload.get("plan") or "").strip().lower()
            tier = str(payload.get("tier") or "").strip().lower()
            return plan == "trial" or tier == "trial"

        # Block duplicate token.
        if existing_token == token:
            return LicenseStatus(
                code=LicenseStatusCode.RENEWAL_BLOCKED,
                message="Duplicate token - already activated",
                payload=new_payload,
                warnings=[],
            )

        # Parse existing token; replace silently if it has become invalid.
        existing_status = self.verify_token(existing_token)
        if existing_status.code != LicenseStatusCode.OK:
            self._set_persisted_token(token)
            return LicenseStatus(
                code=LicenseStatusCode.OK,
                message="License stored successfully (replaced invalid)",
                payload=new_payload,
                warnings=[],
                trial=new_status.trial,
                expires_at=new_exp,
            )

        existing_payload = existing_status.payload
        if existing_payload is None:
            self._set_persisted_token(token)
            return LicenseStatus(code=LicenseStatusCode.OK, message="License activated")

        existing_order = existing_payload.get("sub")
        existing_exp = int(existing_payload.get("exp", 0))

        # Block different order/subscription.
        if new_order != existing_order:
            now = int(_time.time())
            try:
                existing_active = existing_exp > now
            except Exception:
                existing_active = False

            new_is_trial = _is_trial(new_payload)
            existing_is_trial = _is_trial(existing_payload)
            existing_plan = str(
                existing_payload.get("plan") or existing_payload.get("tier") or ""
            ).strip().lower()
            new_plan = str(new_payload.get("plan") or new_payload.get("tier") or "").strip().lower()

            if existing_active and not existing_is_trial and new_is_trial:
                return LicenseStatus(
                    code=LicenseStatusCode.RENEWAL_BLOCKED,
                    message=(
                        "Downgrade blocked: an active license is already stored and valid until "
                        f"{_fmt_exp(existing_exp)} (plan: {existing_plan or 'unknown'}). "
                        "A trial token cannot replace an active paid license. "
                        "If you really want to switch, run 'manifestguard license deactivate' first. "
                        f"(existing sub: {existing_order}, new sub: {new_order}; new plan: {new_plan or 'trial'})"
                    ),
                    payload=new_payload,
                    warnings=[],
                )

            return LicenseStatus(
                code=LicenseStatusCode.RENEWAL_BLOCKED,
                message=(
                    "Different order/subscription - not a renewal "
                    f"(existing sub: {existing_order}, new sub: {new_order})"
                ),
                payload=new_payload,
                warnings=[],
            )

        # Block downgrade (equal or earlier expiration).
        if new_exp <= existing_exp:
            return LicenseStatus(
                code=LicenseStatusCode.RENEWAL_BLOCKED,
                message=(
                    "Downgrade blocked: new expiration is not later than the existing license "
                    f"(existing: {_fmt_exp(existing_exp)}, new: {_fmt_exp(new_exp)})"
                ),
                payload=new_payload,
                warnings=[],
            )

        # Renewal check passed: caller stores and returns OK.
        return None

    def store_token(self, token: str) -> LicenseStatus:
        """Store license token with renewal validation.

        Renewal rules:
        - Same order (sub) + later expiration: ALLOW
        - Duplicate token: BLOCK
        - Different order: BLOCK
        - Earlier expiration: BLOCK
        - Invalid token: BLOCK
        - Device-hash mismatch in token payload: BLOCK
        """
        new_status = self.verify_token(token)
        if new_status.code != LicenseStatusCode.OK:
            return new_status

        new_payload = new_status.payload
        if new_payload is None:
            return LicenseStatus(
                code=LicenseStatusCode.INVALID_FORMAT, message="Token payload is missing"
            )

        new_exp = int(new_payload.get("exp", 0))

        # Reject tokens bound to a different device.
        token_device_hash = new_payload.get("device_hash")
        if token_device_hash:
            if token_device_hash != self.get_device_hash():
                return LicenseStatus(
                    code=LicenseStatusCode.DEVICE_LIMIT,
                    message="Token was issued for a different device",
                )

        existing_token = self._get_persisted_token()

        if existing_token is None:
            self._set_persisted_token(token)
            return LicenseStatus(
                code=LicenseStatusCode.OK,
                message="License stored successfully",
                payload=new_payload,
                warnings=[],
                trial=new_status.trial,
                expires_at=new_exp,
            )

        policy_result = self._check_renewal_policy(token, new_payload, new_status, existing_token)
        if policy_result is not None:
            return policy_result

        # Renewal allowed: same order + later expiration.
        self._set_persisted_token(token)
        return LicenseStatus(
            code=LicenseStatusCode.OK,
            message="License renewed successfully",
            payload=new_payload,
            warnings=[],
            trial=new_status.trial,
            expires_at=new_exp,
        )

    def get_status(self) -> LicenseStatus:
        """Best-effort current license status.

        Never raises; callers should handle MISSING/INVALID codes.
        """
        try:
            activation = self.get_activation()
        except Exception:
            activation = None
        if activation:
            return self._status_from_activation(activation)

        try:
            token = self.get_token()
        except Exception:
            token = None
        if not token:
            return LicenseStatus(
                code=LicenseStatusCode.MISSING,
                message="No license activated",
                payload=None,
                warnings=[],
                trial=False,
                expires_at=None,
            )
        return self.verify_token(token)

    def activate(self, token: str) -> bool:
        """Activate a license token (store it if valid)."""
        status = self.store_token(token)
        return status.code == LicenseStatusCode.OK

    def deactivate(self) -> None:
        """Deactivate current license (remove persisted token)."""
        self.remove_token()
        self.remove_activation()

    def _resolve_feature_base(self) -> dict[str, Any]:
        """Resolve the effective feature dict for the current license state.

        Returns the merged feature limits for the active tier.  Activation-level
        feature overrides (explicit ``features`` dict) are merged via
        :meth:`_merge_activation_features`.  Falls back to ``community`` for any
        invalid / missing credential.
        """
        activation = self.get_activation()
        if activation:
            st = self._status_from_activation(activation)
            if st.code not in {
                LicenseStatusCode.OK,
                LicenseStatusCode.UPDATE_ENTITLEMENT_EXPIRED,
            }:
                return FEATURE_LIMITS["community"]
            if (
                isinstance(activation.get("features"), dict)
                and self._activation_allows_paid_features(activation)
            ):
                return self._merge_activation_features(activation)
            tier = self._normalized_tier(activation.get("tier") or activation.get("plan"))
            return FEATURE_LIMITS.get(tier, FEATURE_LIMITS["community"])

        token = self.get_token()
        if token is None:
            return FEATURE_LIMITS["community"]
        st = self.verify_token(token)
        if st.code != LicenseStatusCode.OK or st.payload is None:
            return FEATURE_LIMITS["community"]
        if not validate_token_expiry(st.payload):
            return FEATURE_LIMITS["community"]
        tier = self._normalized_tier(
            st.payload.get("tier") or st.payload.get("plan") or "community"
        )
        return FEATURE_LIMITS.get(tier, FEATURE_LIMITS["community"])

    def has_feature(self, feature: str) -> bool:
        """Check if current license has access to a feature

        Args:
            feature: Feature name to check (e.g., "dashboard", "self_hosted")

        Returns:
            True if feature is available, False otherwise

        """
        value = self._resolve_feature_base().get(feature, False)
        return bool(value) if isinstance(value, (int, bool)) else False

    def _merge_activation_features(self, activation: dict[str, Any]) -> dict[str, Any]:
        """Merge activation payload into tier-baseline feature limits.

        Activation features override tier defaults; `maxActivations` overrides
        `max_devices`.  Returns a new dict (does not mutate either source).
        """
        tier = self._normalized_tier(activation.get("tier") or activation.get("plan"))
        merged = dict(FEATURE_LIMITS.get(tier, FEATURE_LIMITS["community"]))
        merged.update(activation.get("features") or {})
        if activation.get("maxActivations") is not None:
            merged["max_devices"] = activation["maxActivations"]
        return merged

    def get_feature_limits(self) -> dict[str, Any]:
        """Get feature limits for current license."""
        return self._resolve_feature_base()


