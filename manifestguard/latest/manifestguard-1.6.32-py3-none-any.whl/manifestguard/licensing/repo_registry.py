"""Global repo registry — tracks distinct project roots for max_repos tier enforcement.

Stores a hashed set of workspace root paths in ~/.manifestguard/repo_registry.json.
This allows community-tier enforcement of the portfolio limit (max_repos) across
multiple tool invocations on different projects.
"""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from pathlib import Path

_REGISTRY_PATH = Path.home() / ".manifestguard" / "repo_registry.json"


@dataclass(frozen=True)
class RepoLimitExceeded:
    max_repos: int
    count: int


def _fingerprint(path: Path) -> str:
    """Return a short, stable SHA-256 hash of the resolved absolute path."""
    return hashlib.sha256(str(path.resolve()).encode()).hexdigest()[:16]


def _load_registry() -> set[str]:
    try:
        data = json.loads(_REGISTRY_PATH.read_text(encoding="utf-8"))
        if isinstance(data, list):
            return set(data)
    except Exception:
        pass
    return set()


def _save_registry(registry: set[str]) -> None:
    _REGISTRY_PATH.parent.mkdir(parents=True, exist_ok=True)
    tmp = _REGISTRY_PATH.with_suffix(_REGISTRY_PATH.suffix + ".tmp")
    try:
        tmp.write_text(json.dumps(sorted(registry), indent=2), encoding="utf-8")
        tmp.replace(_REGISTRY_PATH)
    except Exception:
        pass


def check_repo_limit(workspace_root: Path, max_repos: int) -> RepoLimitExceeded | None:
    """Register workspace_root and check whether max_repos is exceeded.

    Args:
        workspace_root: The project root being scanned.
        max_repos: The tier's repository limit. Use -1 (or any negative) for
            unlimited — in that case this function always returns None.

    Returns:
        None if the limit is not exceeded (or unlimited), RepoLimitExceeded otherwise.
    """
    if max_repos < 0:
        return None

    fp = _fingerprint(workspace_root)
    registry = _load_registry()

    # Already registered → within limit (re-scanning a known repo is always allowed).
    if fp in registry:
        return None

    registry.add(fp)
    _save_registry(registry)

    count = len(registry)
    if count > max_repos:
        return RepoLimitExceeded(max_repos=max_repos, count=count)

    return None
