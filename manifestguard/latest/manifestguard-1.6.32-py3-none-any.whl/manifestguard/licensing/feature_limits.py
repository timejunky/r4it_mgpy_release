"""Feature limits per license tier.

This module intentionally contains only data (no imports from `client.py`) to
avoid circular imports.

Seat/device limits:
- The *default* tier values here are fallbacks.
- Real seat packs (e.g. Team 5 vs Team 10) are expected to be enforced via the
  persisted activation object / token payload (e.g. `maxActivations`) and are
  merged at runtime in `LicensingClient.get_feature_limits()`.
"""

from __future__ import annotations

from typing import Any


FEATURE_LIMITS: dict[str, dict[str, Any]] = {
    # "free" is the public-facing name; "community" is the internal implementation alias.
    # Both map to the same feature set. Code should prefer "community" internally;
    # user-facing messages should use "free".
    "community": {
        "max_repos": 5,
        "max_rules": 20,
        "custom_rules": False,
        "ci_cd": False,
        "extended_analysis": False,
        "sbom_export": False,
        "cve_checks": False,
        "quickfix_suggestions": False,
        "quickfix_apply": False,
    },
    # Alias — identical feature set to "community"
    "free": {
        "max_repos": 5,
        "max_rules": 20,
        "custom_rules": False,
        "ci_cd": False,
        "extended_analysis": False,
        "sbom_export": False,
        "cve_checks": False,
        "quickfix_suggestions": False,
        "quickfix_apply": False,
    },
    # Trial: full Pro feature set, time-limited (enforced via token exp).
    # "early_access" activates the same features as "trial" during the EA period.
    "trial": {
        "max_repos": -1,  # unlimited during trial
        "max_rules": 100,
        "custom_rules": True,
        "ci_cd": True,
        "extended_analysis": True,
        "sbom_export": True,
        "cve_checks": True,
        "quickfix_suggestions": True,
        "quickfix_apply": False,  # apply disabled in trial — suggestions only
        "dashboard": True,
        "max_devices": 1,
    },
    "pro": {
        "max_rules": 100,
        "custom_rules": True,
        "ci_cd": True,
        "extended_analysis": True,
        "sbom_export": True,
        "cve_checks": True,
        "quickfix_suggestions": True,
        "quickfix_apply": True,
        "max_devices": 2,
    },
    "team": {
        "max_rules": 500,
        "custom_rules": True,
        "ci_cd": True,
        "extended_analysis": True,
        "sbom_export": True,
        "cve_checks": True,
        "quickfix_suggestions": True,
        "quickfix_apply": True,
        "dashboard": True,
        "sso": True,
        "audit_logs": True,
        "max_devices": -1,  # overridden by activation `maxActivations` when present
    },
    "enterprise": {
        "max_rules": -1,  # unlimited
        "custom_rules": True,
        "ci_cd": True,
        "extended_analysis": True,
        "sbom_export": True,
        "cve_checks": True,
        "quickfix_suggestions": True,
        "quickfix_apply": True,
        "dashboard": True,
        "sso": True,
        "audit_logs": True,
        "self_hosted": True,
        "air_gapped": True,
        "ldap": True,
        "sla_4h": True,
        "max_devices": -1,  # overridden by activation `maxActivations` when present
    },
}
