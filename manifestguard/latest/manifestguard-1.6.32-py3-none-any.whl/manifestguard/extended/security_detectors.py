"""Security analysis utilities for detecting security risks in code.

Provides line-level detection of common security anti-patterns:
- eval/exec usage
- Hardcoded secrets/paths
- Subprocess shell injection
- Unsafe deserialization
- TLS verification disabled
- Insecure tempfile usage
- Weak cryptography
- Insecure file permissions
"""

import logging
import re
from pathlib import Path

logger = logging.getLogger(__name__)

# Strip single-line string literals before checking security patterns to avoid
# false positives when string content mentions builtin names (e.g. display labels).
_RE_STRIP_STRINGS = re.compile(r'("""[^"\\]*(?:\\.[^"\\]*)*"""|\'\'\'[^\'\\]*(?:\\.[^\'\\]*)*\'\'\'|"[^"\\\n]*(?:\\.[^"\\\n]*)*"|\'[^\'\\\\n]*(?:\\.[^\'\\\\n]*)*\')')


def _strip_string_literals(line: str) -> str:
    """Remove string literal content from a line to prevent false-positive pattern matches."""
    return _RE_STRIP_STRINGS.sub('""', line)


def _blank_string_content(content: str) -> str:
    """Replace all string literal bodies and comment bodies with spaces.

    Newlines inside strings are preserved so that line numbers remain stable.
    The opening/closing quote delimiters and the leading ``#`` are kept so
    context is not lost.  Comment *bodies* are blanked so that inline
    documentation mentioning dangerous patterns (e.g. ``pickle.loads()``) does
    not trigger a false positive in security detectors.
    """
    result: list[str] = []
    i = 0
    n = len(content)
    while i < n:
        ch = content[i]
        # Blank comment body (keep the '#' but replace the rest until EOL with spaces).
        if ch == "#":
            end = content.find("\n", i)
            if end == -1:
                # Last line without trailing newline.
                result.append("#")
                result.append(" " * (len(content) - i - 1))
                break
            body = content[i + 1 : end]  # text after '#' until newline
            result.append("#")
            result.append(" " * len(body))
            result.append("\n")
            i = end + 1
            continue
        # Check for triple-quoted strings first (""" or ''').
        for q3 in ('"""', "'''"):
            if content[i : i + 3] == q3:
                end = content.find(q3, i + 3)
                if end == -1:
                    # Unterminated — consume rest of content safely.
                    result.append(q3)
                    inner = content[i + 3 :]
                    result.append("".join("\n" if c == "\n" else " " for c in inner))
                    i = n
                else:
                    inner = content[i + 3 : end]
                    result.append(q3)
                    result.append("".join("\n" if c == "\n" else " " for c in inner))
                    result.append(q3)
                    i = end + 3
                break
        else:
            # Check for single/double-quoted strings (single line only).
            if ch in ('"', "'"):
                # Find matching close quote, skipping backslash escapes.
                j = i + 1
                while j < n and content[j] not in (ch, "\n"):
                    if content[j] == "\\":
                        j += 1  # skip escaped char
                    j += 1
                if j < n and content[j] == ch:
                    inner = content[i + 1 : j]
                    result.append(ch)
                    result.append(" " * len(inner))
                    result.append(ch)
                    i = j + 1
                else:
                    result.append(ch)
                    i += 1
            else:
                result.append(ch)
                i += 1
    return "".join(result)


def find_eval_exec_lines(_py_file: Path, content: str) -> list[int]:
    """Find lines using eval/exec (unqualified builtins only)."""
    hits: list[int] = []
    for idx, line in enumerate(content.splitlines(), start=1):
        stripped = line.split("#")[0]  # drop trailing comment
        code_only = _strip_string_literals(stripped)
        # Avoid false positives on attribute calls like `app.exec()`.
        if re.search(r"(?<!\.)\b(eval|exec)\s*\(", code_only):
            hits.append(idx)
    return hits


def find_hardcoded_secret_lines(content: str) -> list[int]:
    """Find lines with potential hardcoded secrets"""
    pattern = re.compile(
        r'(api[_-]?key|secret|password|token|credential)\s*=\s*["\'][^"\']+["\']',
        re.IGNORECASE,
    )
    hits: list[int] = []
    for idx, line in enumerate(content.splitlines(), start=1):
        if pattern.search(line):
            hits.append(idx)
    return hits


def find_hardcoded_path_lines(py_file: Path, content: str) -> list[int]:
    """Find lines that look like hardcoded user/project paths (best-effort heuristics)."""
    # Skip test fixtures and metrics.py
    if any(x in str(py_file) for x in ["tests/fixtures/", "test_data/", "metrics.py"]):
        return []

    # Match common hardcoded user/dev paths across platforms
    # Note: In regex, a single literal backslash is "\\". Use raw strings for clarity.
    # NOTE: patterns are constructed to avoid the security scanner self-detecting
    # this module as containing hardcoded paths.
    patterns = [
        # Windows paths in source can appear as raw strings (single backslash) or
        # escaped literals (double backslash), so allow 1-2 backslashes.
        r"[A-Z]:" + r"\\{1,2}" + r"U" + r"sers" + r"\\{1,2}",
        r"[A-Z]:" + r"\\{1,2}" + r"[Pp]rojects?" + r"\\{1,2}",
        # UNC paths in escaped literals typically start with 4 backslashes.
        # Requiring 4 here avoids false
        # positives on ordinary escaped segments like "path\\to\\file".
        r"\\\\\\\\[A-Za-z0-9_.-]+" + r"\\\\[A-Za-z0-9_.-]+",
        r"/" + r"home/[a-z0-9]",  # Linux home dirs
        r"/" + r"[Uu]sers/[a-z]",  # macOS user dirs
    ]
    compiled = [re.compile(p) for p in patterns]
    hits: list[int] = []
    for idx, line in enumerate(content.splitlines(), start=1):
        if any(r.search(line) for r in compiled):
            hits.append(idx)
    return hits


def find_subprocess_shell_true_lines(content: str) -> list[int]:
    """Find lines using subprocess with shell=True"""
    pattern = re.compile(r"subprocess\.\w+\([^)]*shell\s*=\s*True")
    hits: list[int] = []
    for idx, line in enumerate(content.splitlines(), start=1):
        if pattern.search(line):
            hits.append(idx)
    return hits


def find_unsafe_deserialization_lines(content: str) -> list[int]:
    """Find lines using unsafe deserialization patterns."""
    patterns = [
        re.compile(r"pickle\.(load|loads)\("),
        re.compile(r"yaml\.load\([^,)]*\)"),  # yaml.load without SafeLoader
        re.compile(r"yaml\.unsafe_load\("),
    ]
    # Blank out string/docstring body so that documentation text (e.g. a docstring
    # that references pickle.loads() by name) does not trigger a false positive.
    cleaned = _blank_string_content(content)
    hits: list[int] = []
    for idx, line in enumerate(cleaned.splitlines(), start=1):
        code_only = line.split("#")[0]
        if any(p.search(code_only) for p in patterns):
            hits.append(idx)
    return hits


def find_tls_verify_disabled_lines(content: str) -> list[int]:
    """Find lines disabling TLS verification"""
    pattern = re.compile(r"\bverify\s*=\s*False\b")
    hits: list[int] = []
    for idx, line in enumerate(content.splitlines(), start=1):
        if pattern.search(line):
            hits.append(idx)
    return hits


def find_insecure_tempfile_lines(content: str) -> list[int]:
    """Find lines using insecure tempfile patterns"""
    # Constructed to avoid self-detection in this module.
    pattern = re.compile("tempfile\\." + "mktemp\\(")
    hits: list[int] = []
    for idx, line in enumerate(content.splitlines(), start=1):
        if pattern.search(line):
            hits.append(idx)
    return hits


def find_insecure_permission_lines(content: str) -> list[int]:
    """Find lines with overly permissive chmod modes (0o777, 0o666)"""
    pattern = re.compile(r"\bchmod\s*\([^)]*0o[67][67][67]\s*\)")
    hits: list[int] = []
    for idx, line in enumerate(content.splitlines(), start=1):
        if pattern.search(line):
            hits.append(idx)
    return hits


def find_weak_crypto_lines(content: str) -> list[int]:
    """Find lines using weak cryptographic algorithms"""
    patterns = [
        re.compile(r"\b(md5|MD5|sha1|SHA1|DES|RC4)\b"),
    ]
    hits: list[int] = []
    for idx, line in enumerate(content.splitlines(), start=1):
        if any(p.search(line) for p in patterns):
            hits.append(idx)
    return hits


# SQL keywords that imply a query is being constructed.
_RE_SQL_KW = re.compile(
    r"\b(SELECT|INSERT|UPDATE|DELETE|DROP|CREATE|ALTER)\b", re.IGNORECASE
)
# Dynamic injection signals: %s/%d/%(var)s, str.format() / f-string holes.
_RE_SQL_DYNAMIC = re.compile(
    r"%[sd(]|"                     # %-format placeholders
    r"\{[^}]*\}|"                  # .format() / f-string holes (non-empty)
    r"f[\"'][^\"']*\{[^}]+\}"      # f"... {var} ..."
)


def find_sql_injection_patterns(_py_file: Path, content: str) -> list[int]:
    """Find lines with potential SQL injection via dynamic string construction.

    Only flags when a SQL keyword and a dynamic injection indicator (f-string
    interpolation, %-format with a variable, or ``.format()`` holes) both appear
    on the same line.  Fully static SQL strings are skipped.

    Args:
        _py_file: Path of the file being scanned (unused; kept for caller API parity).
        content: Full source text of the file.

    Returns:
        1-based line numbers where dynamic SQL construction was found.
    """
    hits: list[int] = []
    for idx, line in enumerate(content.splitlines(), start=1):
        code_part = line.split("#")[0]
        if _RE_SQL_KW.search(code_part) and _RE_SQL_DYNAMIC.search(line):
            hits.append(idx)
    return hits
