"""Async coverage collection used by extended metrics."""

from __future__ import annotations

import asyncio
import contextlib
import json
import logging
import os
import re
import sys
from collections.abc import Awaitable, Callable
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .metrics import CoverageMetrics

logger = logging.getLogger(__name__)


RunCmd = Callable[..., Awaitable[tuple[int, str, str]]]


def _resolve_project_python_executable(workspace_root: Path) -> str:
    """Resolve Python executable for running project tests/coverage.

    This enables a "global mgpy" workflow where the ManifestGuard CLI runs from a
    global installation, but test/coverage subprocesses execute inside the
    project's venv (when present).

    Override with:
        MANIFESTGUARD_PROJECT_PYTHON
    """

    override = os.environ.get("MANIFESTGUARD_PROJECT_PYTHON")
    if override:
        try:
            override_path = Path(override)
            if override_path.exists():
                return str(override_path)
        except Exception:
            pass

    candidates: list[Path] = []
    for venv_dir in [".venv", "venv", ".env"]:
        base = workspace_root / venv_dir
        candidates.append(base / "Scripts" / "python.exe")
        candidates.append(base / "bin" / "python")

    for cand in candidates:
        try:
            if cand.exists():
                return str(cand)
        except Exception:
            continue

    return sys.executable


def _build_pytest_env(workspace_root: Path) -> dict[str, str]:
    existing_pythonpath = os.environ.get("PYTHONPATH", "")
    src_path = str(workspace_root / "src")

    mgpy_import_root = ""
    try:
        import manifestguard  # noqa: PLC0415

        mgpy_import_root = str(Path(manifestguard.__file__).resolve().parent.parent)
    except Exception:
        mgpy_import_root = ""

    pythonpath_parts: list[str] = [src_path]
    if mgpy_import_root:
        pythonpath_parts.append(mgpy_import_root)
    if existing_pythonpath:
        pythonpath_parts.append(existing_pythonpath)

    pythonpath = os.pathsep.join([p for p in pythonpath_parts if p])
    return {
        **os.environ,
        "PYTHONPATH": pythonpath,
    }


def _parse_collected_test_count(output: str) -> int | None:
    match = re.search(r"collected\s+(\d+)\s+items", output)
    if not match:
        match = re.search(r"(\d+)\s+tests\s+collected", output)
    if not match:
        return None
    try:
        return int(match.group(1))
    except Exception:
        return None


def _try_parse_progress_total(line: str) -> int | None:
    if not line.startswith("[MG-PROGRESS] TOTAL "):
        return None
    try:
        return int(line.split()[-1])
    except Exception:
        return None


def _try_parse_progress_run(line: str) -> tuple[int, int, int | None] | None:
    if not line.startswith("[MG-PROGRESS] RUN "):
        return None
    try:
        parts = line.split()
        cur_total = parts[3] if len(parts) > 3 else parts[2]
        eta = int(parts[-1]) if len(parts) > 2 and parts[-2] == "ETA" else None
        cur_str, total_str = cur_total.split("/")
        return (int(cur_str), int(total_str), eta)
    except Exception:
        return None


def _read_unit_percent_from_coverage_json(coverage_json: Path) -> float | None:
    try:
        cov_data = json.loads(coverage_json.read_text(encoding="utf-8"))
        totals = cov_data.get("totals", {})
        return float(
            totals.get("percent_covered", totals.get("percent_covered_display", 0.0)),
        )
    except Exception:
        return None


def _read_unit_percent_from_coverage_xml(coverage_xml: Path) -> float | None:
    """Extract line coverage percentage from a coverage.xml (Cobertura format).

    Supports both ``line-rate`` attribute (float 0–1) and the
    ``lines-covered`` / ``lines-valid`` pair as a fallback.
    """
    try:
        import xml.etree.ElementTree as ET  # stdlib, no extra dep  # noqa: N814

        tree = ET.parse(str(coverage_xml))
        root = tree.getroot()
        line_rate = root.attrib.get("line-rate")
        if line_rate is not None:
            return float(line_rate) * 100.0
        # Fallback: compute from absolute line counts
        valid = root.attrib.get("lines-valid")
        covered = root.attrib.get("lines-covered")
        if valid and covered and int(valid) > 0:
            return float(covered) / float(valid) * 100.0
    except Exception:
        pass
    return None


def _maybe_report_total_tests(
    metrics: "CoverageMetrics", total_tests: int | None, progress: Callable | None
) -> None:
    if total_tests is None:
        return
    if getattr(metrics, "total_tests", None) == total_tests:
        return
    metrics.total_tests = total_tests
    if progress:
        progress(f"Discovered {total_tests} tests")


async def _spawn_pytest_with_cov(
    *,
    workspace_root: Path,
    env: dict[str, str],
    python_executable: str,
) -> asyncio.subprocess.Process:
    return await asyncio.create_subprocess_exec(
        python_executable,
        "-m",
        "coverage",
        "run",
        "-m",
        "pytest",
        "-q",
        "-p",
        "manifestguard.pytest_progress",
        cwd=str(workspace_root),
        env=env,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.STDOUT,
    )


async def _drain_progress_output(
    *,
    proc: asyncio.subprocess.Process,
    metrics: "CoverageMetrics",
    progress: Callable | None,
) -> None:
    assert proc.stdout is not None
    async for raw in proc.stdout:
        line = raw.decode(errors="ignore").strip()

        total = _try_parse_progress_total(line)
        if total is not None:
            _maybe_report_total_tests(metrics, total, progress)
            continue

        run_progress = _try_parse_progress_run(line)
        if run_progress is None:
            continue

        cur, total, eta = run_progress
        msg = f"Tests {cur}/{total}"
        if eta is not None:
            msg += f" (ETA {eta}s)"
        if progress:
            progress(msg)


async def _kill_proc(proc: asyncio.subprocess.Process) -> None:
    with contextlib.suppress(Exception):
        proc.kill()
    with contextlib.suppress(Exception):
        await proc.wait()


async def _run_pytest_collect_only(
    run_cmd: RunCmd,
    *,
    progress: Callable | None,
    metrics: "CoverageMetrics",
    python_executable: str,
) -> None:
    rc, out, _ = await run_cmd(
        python_executable,
        "-m",
        "pytest",
        "--collect-only",
        "-q",
        timeout=60,
    )
    if rc != 0:
        return

    total = _parse_collected_test_count(out)
    if total is None:
        return

    metrics.total_tests = total
    if progress:
        progress(f"Discovered {total} tests")


async def _maybe_collect_unit_percent_from_existing_coverage(
    run_cmd: RunCmd,
    *,
    workspace_root: Path,
    python_executable: str,
) -> float | None:
    rc, _, _ = await run_cmd(
        python_executable,
        "-m",
        "coverage",
        "json",
        "-o",
        "coverage.json",
        timeout=60,
    )

    coverage_json = workspace_root / "coverage.json"
    if rc == 0 and coverage_json.exists():
        return _read_unit_percent_from_coverage_json(coverage_json)
    if coverage_json.exists():
        return _read_unit_percent_from_coverage_json(coverage_json)
    return None


async def _run_coverage_with_progress(
    *,
    workspace_root: Path,
    metrics: "CoverageMetrics",
    progress: Callable | None,
    python_executable: str,
) -> int:
    try:
        env = _build_pytest_env(workspace_root)
        proc = await _spawn_pytest_with_cov(
            workspace_root=workspace_root,
            env=env,
            python_executable=python_executable,
        )

        drain_task = asyncio.create_task(
            _drain_progress_output(proc=proc, metrics=metrics, progress=progress)
        )

        timeout_seconds = float(
            os.environ.get("MANIFESTGUARD_EXTENDED_COVERAGE_TIMEOUT", "1800")
        )
        try:
            await asyncio.wait_for(proc.wait(), timeout=timeout_seconds)
        except asyncio.TimeoutError:
            await _kill_proc(proc)
            return 1
        except asyncio.CancelledError:
            await _kill_proc(proc)
            raise
        finally:
            if not drain_task.done():
                drain_task.cancel()
            with contextlib.suppress(Exception):
                await drain_task

        return proc.returncode or 0
    except Exception:
        return 1


async def collect_coverage_metrics(
    workspace_root: Path, progress: Callable | None = None
) -> CoverageMetrics:
    """Collect test coverage data from pytest/coverage (best-effort).

    Returns a CoverageMetrics instance (imported lazily to avoid cycles).
    """

    from .metrics import CoverageMetrics  # noqa: PLC0415 - avoid circular import

    metrics = CoverageMetrics()
    python_executable = _resolve_project_python_executable(workspace_root)

    async def _run_cmd(*args: str, timeout: float = 30.0) -> tuple[int, str, str]:
        try:
            env = _build_pytest_env(workspace_root)
            proc = await asyncio.create_subprocess_exec(
                *args,
                cwd=str(workspace_root),
                env=env,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            try:
                stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=timeout)
            except asyncio.TimeoutError:
                with contextlib.suppress(Exception):
                    proc.kill()
                return (1, "", "Timeout")
            rc = proc.returncode if proc.returncode is not None else 1
            return (rc, stdout.decode(errors="ignore"), stderr.decode(errors="ignore"))
        except Exception as exc:
            return (1, "", str(exc))

    try:
        # Save any pre-existing coverage value as a fallback.
        # The fresh `coverage run -m pytest` below can overwrite coverage.json with 0%
        # when no --source is configured in the project (common for globally-installed
        # mgpy running against a project that generates coverage.json via its own
        # `pytest --cov ... --cov-report=json` run).
        coverage_json_path = workspace_root / "coverage.json"
        coverage_xml_path = workspace_root / "coverage.xml"
        pre_existing_percent: float | None = None
        if coverage_json_path.exists():
            pre_existing_percent = _read_unit_percent_from_coverage_json(coverage_json_path)
        if pre_existing_percent is None and coverage_xml_path.exists():
            pre_existing_percent = _read_unit_percent_from_coverage_xml(coverage_xml_path)

        await _run_pytest_collect_only(
            _run_cmd,
            progress=progress,
            metrics=metrics,
            python_executable=python_executable,
        )

        # Always prefer a fresh coverage run so results are not stale.
        rc = await _run_coverage_with_progress(
            workspace_root=workspace_root,
            metrics=metrics,
            progress=progress,
            python_executable=python_executable,
        )

        if rc == 0:
            # Convert collected data to JSON (portable paths are handled via pyproject
            # [tool.coverage.run] relative_files = true).
            await _run_cmd(
                python_executable,
                "-m",
                "coverage",
                "json",
                "-o",
                "coverage.json",
                timeout=120,
            )

            coverage_json = workspace_root / "coverage.json"
            if coverage_json.exists():
                unit_percent = _read_unit_percent_from_coverage_json(coverage_json)
                if unit_percent is not None:
                    if unit_percent <= 0.0 and pre_existing_percent and pre_existing_percent > 0.0:
                        # Fresh run produced 0% — likely no [tool.coverage.run] source
                        # is configured, so `coverage run -m pytest` ran the tests but
                        # recorded no lines. Fall back to the pre-existing coverage.json
                        # value (e.g. from the user's own `pytest --cov` run).
                        logger.debug(
                            "Fresh coverage run produced 0%%. Falling back to "
                            "pre-existing coverage.json value: %.2f%%",
                            pre_existing_percent,
                        )
                        metrics.unit_percent = pre_existing_percent
                        metrics.unit_measured = True
                    else:
                        metrics.unit_percent = unit_percent
                        metrics.unit_measured = True
                        logger.debug("Coverage collected: %s%%", metrics.unit_percent)
        else:
            # Fresh pytest run failed — try existing coverage artifacts in priority order:
            # 1. .coverage binary  → convert via `coverage json`
            # 2. coverage.xml      → parse Cobertura XML directly
            unit_percent: float | None = None
            coverage_binary = workspace_root / ".coverage"
            if coverage_binary.exists():
                unit_percent = await _maybe_collect_unit_percent_from_existing_coverage(
                    _run_cmd,
                    workspace_root=workspace_root,
                    python_executable=python_executable,
                )
            if unit_percent is None and coverage_xml_path.exists():
                unit_percent = _read_unit_percent_from_coverage_xml(coverage_xml_path)
            if unit_percent is not None:
                metrics.unit_percent = unit_percent
                metrics.unit_measured = True
            else:
                logger.debug(
                    "No coverage data found. Generate with:\n"
                    "  pytest --cov=<package> --cov-report=json  (produces coverage.json)\n"
                    "  pytest --cov=<package> --cov-report=xml   (produces coverage.xml)"
                )

    except Exception as exc:
        logger.debug("Coverage collection failed: %s", exc)

    return metrics
