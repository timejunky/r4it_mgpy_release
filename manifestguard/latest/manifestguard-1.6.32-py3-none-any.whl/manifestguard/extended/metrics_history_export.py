"""Metrics history export (schema v2 + legacy) for dashboards.

Extracted from `manifestguard.extended.metrics` to keep that module manageable.
"""

from __future__ import annotations

import contextlib
import json
import math
import time
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from manifestguard import __version__ as default_mgpy_version
from manifestguard.core.scan_space import ScanSpaceResolver
from manifestguard.extended.filesystem_safety import safe_rglob
from manifestguard.utils import cli_validation
from manifestguard.extended.coverage_metrics import extract_coverage_from_file, CoverageParseError


METRICS_HISTORY_FORMAT_VERSION = "1.0.0"

# Default history path (relative to workspace root).
_HISTORY_REL_PATH = Path(".mgpy") / "metrics" / "manifestguard-history.json"


def _write_entry_to_workspace_history(
    workspace_root: Path,
    new_entry: dict[str, Any],
    *,
    max_entries: int = 100,
) -> bool:
    """Append *new_entry* to the workspace history file and return True on success.

    Shared boilerplate extracted from add_coverage_metric_to_history,
    add_venv_packages_delta_to_history, add_venv_health_to_history.
    """
    import logging  # noqa: PLC0415 - runtime-only import

    history_file = workspace_root / _HISTORY_REL_PATH
    wrapper = _build_history_wrapper()
    _load_existing_wrapper_fields(history_file, wrapper)
    _append_entry_trimmed(wrapper, new_entry, max_entries=max_entries)
    history_file.parent.mkdir(parents=True, exist_ok=True)
    try:
        _write_json_atomic(history_file, wrapper)
        return True
    except Exception as e:
        logging.getLogger(__name__).error(f"Failed to write history entry: {e}")
        return False


def resolve_history_file_path(workspace_root: Path, *, create_if_missing: bool = False) -> Path:
    """Resolve metrics history file path with priority: .mgpy/metrics/ → legacy locations.
    
    Args:
        workspace_root: Project root directory
        create_if_missing: If True, return new location regardless of existence
        
    Returns:
        Path to metrics history file (new or legacy)
    """
    new_location = workspace_root / ".mgpy" / "metrics" / "manifestguard-history.json"
    legacy_root = workspace_root / ".manifestguard-history.json"
    legacy_dir = workspace_root / ".manifestguard" / "metrics-history.json"
    
    if create_if_missing:
        return new_location
    
    # Priority: new → legacy root → legacy dir
    if new_location.exists():
        return new_location
    if legacy_root.exists():
        return legacy_root
    if legacy_dir.exists():
        return legacy_dir
    
    # Default to writing new history files into the modern location
    return new_location


def _build_history_wrapper() -> dict[str, Any]:
    return {
        "schemaVersion": "2.0",
        "formatVersion": METRICS_HISTORY_FORMAT_VERSION,
        "historyId": _new_stable_id(),
        "projectId": _new_stable_id(),
        "entries": [],
    }


def _copy_str_field(src: dict[str, Any], dst: dict[str, Any], key: str) -> None:
    """Copy a non-empty string field from src to dst if present."""
    value = src.get(key)
    if isinstance(value, str) and value:
        dst[key] = value


def _load_existing_wrapper_fields(history_file: Path, wrapper: dict[str, Any]) -> None:
    if not history_file.exists():
        return

    try:
        parsed = json.loads(history_file.read_text(encoding="utf-8"))
    except Exception:
        return

    if not isinstance(parsed, dict):
        return

    for key in ("historyId", "projectId", "formatVersion", "reconstructCutoffIso"):
        _copy_str_field(parsed, wrapper, key)

    last_reconstruct = parsed.get("lastReconstruct")
    if isinstance(last_reconstruct, dict) and last_reconstruct:
        wrapper["lastReconstruct"] = last_reconstruct

    entries = parsed.get("entries")
    if isinstance(entries, list):
        wrapper["entries"] = entries


def _make_coverage_history_entry(
    *,
    timestamp: str,
    mgpy_version: str,
    coverage_metric: dict[str, Any],
) -> dict[str, Any]:
    estimate = coverage_metric.get("value")
    coverage_slice: dict[str, Any] | None = None
    if isinstance(estimate, (int, float)):
        coverage_slice = {"estimate": float(estimate)}

    return {
        "id": _new_stable_id(),
        "timestamp": timestamp,
        "mgpyVersion": mgpy_version,
        # MGVS dashboards read top-level coverage.estimate (not metrics[]), so we
        # mirror the metric here for cross-tool compatibility.
        **({"coverage": coverage_slice} if coverage_slice is not None else {}),
        "metrics": [coverage_metric],
    }


def _make_single_metric_history_entry(
    *,
    timestamp: str,
    mgpy_version: str,
    metric_name: str,
    metric_value: dict[str, Any],
) -> dict[str, Any]:
    return {
        "id": _new_stable_id(),
        "timestamp": timestamp,
        "mgpyVersion": mgpy_version,
        "metrics": [{"metric": metric_name, "value": metric_value}],
    }


def _append_entry_trimmed(
    wrapper: dict[str, Any],
    entry: dict[str, Any],
    *,
    max_entries: int = 100,
) -> None:
    entries = wrapper.get("entries", [])
    if not isinstance(entries, list):
        entries = []

    # Dedup: if an entry with the same timestamp already exists, replace it.
    ts = entry.get("timestamp") or ""
    if ts:
        entries = [e for e in entries if not (isinstance(e, dict) and e.get("timestamp") == ts)]

    entries.append(entry)

    if max_entries > 0 and len(entries) > max_entries:
        entries = entries[-max_entries:]

    wrapper["entries"] = entries


def _new_stable_id() -> str:
    try:
        return str(uuid.uuid4())
    except Exception:
        return f"{int(time.time())}-{int(time.time_ns() % 1_000_000_000)}"


def _get_entries(payload: Any) -> list[dict[str, Any]]:
    """Extract entries from payload with validation.
    
    Args:
        payload: Raw payload (list or wrapper dict)
        
    Returns:
        List of validated entry dictionaries
    """
    if isinstance(payload, list):
        # Validate each entry
        validated = []
        for i, entry in enumerate(payload):
            try:
                validated.append(cli_validation.validate_metrics_history_entry(entry))
            except Exception as e:
                # Log and skip invalid entries
                import logging
                logging.getLogger(__name__).debug(f"Skipping invalid entry {i}: {e}")
                continue
        return validated
        
    if isinstance(payload, dict) and isinstance(payload.get("entries"), list):
        entries = payload.get("entries") or []
        validated = []
        for i, entry in enumerate(entries):
            try:
                validated.append(cli_validation.validate_metrics_history_entry(entry))
            except Exception as e:
                import logging
                logging.getLogger(__name__).debug(f"Skipping invalid entry {i}: {e}")
                continue
        return validated
        
    return []


def _parse_timestamp(value: Any) -> datetime | None:
    if not isinstance(value, str) or not value:
        return None
    try:
        return datetime.fromisoformat(value.replace("Z", "+00:00"))
    except Exception:
        return None


def _sort_entries_oldest_first(items: list[dict[str, Any]]) -> list[dict[str, Any]]:
    def _key(entry: dict[str, Any]) -> tuple[int, Any]:
        ts_raw = entry.get("timestamp")
        ts = _parse_timestamp(ts_raw)
        if ts is not None:
            return (0, ts)
        if isinstance(ts_raw, str):
            return (1, ts_raw)
        return (2, "")

    return sorted([e for e in items if isinstance(e, dict)], key=_key)


def _write_json_atomic(path: Path, payload: dict[str, Any]) -> None:
    tmp = path.with_suffix(".json.tmp")
    try:
        with tmp.open("w", encoding="utf-8") as handle:
            json.dump(payload, handle, indent=2)
        tmp.replace(path)
    finally:
        if tmp.exists() and not path.exists():
            with contextlib.suppress(Exception):
                tmp.unlink()


def _merge_entries_dedupe_timestamp(
    legacy_entries: list[dict[str, Any]],
    wrapper_entries: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    legacy_sorted = _sort_entries_oldest_first(legacy_entries)
    wrapper_sorted = _sort_entries_oldest_first(wrapper_entries)

    merged: list[dict[str, Any]] = []
    seen_timestamps: set[str] = set()

    # Wrapper entries win over legacy on collisions (so legacy goes first).
    for entry in [*legacy_sorted, *wrapper_sorted]:
        ts_value = entry.get("timestamp")
        if isinstance(ts_value, str) and ts_value:
            if ts_value in seen_timestamps:
                continue
            seen_timestamps.add(ts_value)
        merged.append(entry)

    return merged


def _aggregate_excluded_by(file_to_source: dict[str, str]) -> dict[str, int]:
    """Aggregate excludedBy file→source mapping to source counts (ADR-020)."""
    counts = {"config": 0, "gitignore": 0, "default": 0, "unknown": 0}
    for source in file_to_source.values():
        if "manifestguard.json" in source or ".manifestguardignore" in source:
            counts["config"] += 1
        elif "gitignore" in source or "svnignore" in source:
            counts["gitignore"] += 1
        elif source == "built-in":
            counts["default"] += 1
        else:
            counts["unknown"] += 1
    return counts


def _build_new_entry(
    metrics: Any,
    scan_space_summary: Any | None = None,
    *,
    mgpy_version: str,
    timestamp: str,
) -> dict[str, Any]:
    issue_count = (
        metrics.coverage.failing_tests
        + metrics.dependency.vulnerable_high
        + metrics.dependency.vulnerable_critical
        + metrics.security.unsafe_exec_count
        + metrics.security.hardcoded_secrets
        + metrics.security.hardcoded_paths
    )

    quality_score: float = 100.0

    if issue_count > 0:
        penalty = min(50, math.log10(issue_count + 1) * 20)
        quality_score -= penalty

    if metrics.coverage.unit_measured and metrics.coverage.unit_percent >= 80:
        quality_score = min(100, quality_score + 5)

    if metrics.coverage.total_tests > 0:
        success_rate = metrics.coverage.passing_tests / metrics.coverage.total_tests
        if success_rate >= 0.95:
            quality_score = min(100, quality_score + 5)

    quality_score = max(0, round(quality_score, 1))

    entry = {
        "version": "1.0",
        "validatorVersion": mgpy_version,
        "timestamp": timestamp,
        "quality": {"score": quality_score},
        "issues": {"totalIssues": issue_count},
        "complexity": {
            "violations": metrics.complexity.violations_count,
            "avgComplexity": round(metrics.complexity.average_complexity, 1),
            "maxComplexity": metrics.complexity.max_complexity,
            "filesScanned": metrics.complexity.files_scanned,
            "threshold": metrics.complexity.threshold,
            "engine": getattr(metrics.complexity, "engine", "mgpy-analyzer"),
            "engineVersion": (
                getattr(metrics.complexity, "engine_version", None)
                or (mgpy_version if getattr(metrics.complexity, "engine", "mgpy-analyzer") == "mgpy-analyzer" else None)
            ),
        },
        "tests": {
            "total": metrics.coverage.total_tests,
            "passed": metrics.coverage.passing_tests,
            "failed": metrics.coverage.failing_tests,
            "skipped": metrics.coverage.skipped_tests,
        },
        "dependencies": {
            "total": metrics.dependency.direct_count + metrics.dependency.transitive_count,
            "outdated": metrics.dependency.outdated_count,
            "vulnerable": (
                metrics.dependency.vulnerable_high + metrics.dependency.vulnerable_critical
            ),
        },
        "bugfixes": {
            "total": metrics.bugfixes.total,
            "bpd": metrics.bugfixes.bpd,
            "daysAnalyzed": metrics.bugfixes.days_analyzed,
            "bySeverity": metrics.bugfixes.by_severity,
            "byCategory": metrics.bugfixes.by_category,
        },
        "python": {
            "coverage": {
                "integration_percent": round(metrics.coverage.integration_percent, 1),
            },
            "tests": {
                "total": metrics.coverage.total_tests,
                "passed": metrics.coverage.passing_tests,
                "failed": metrics.coverage.failing_tests,
                "skipped": metrics.coverage.skipped_tests,
            },
            "dependencies": {
                "outdated": metrics.dependency.outdated_count,
                "vulnerable_high": metrics.dependency.vulnerable_high,
                "vulnerable_critical": metrics.dependency.vulnerable_critical,
            },
        },
    }

    # Missing vs zero: only include unit coverage when it was measured.
    if metrics.coverage.unit_measured:
        entry["coverage"] = {"estimate": round(metrics.coverage.unit_percent, 1)}
        entry["python"]["coverage"]["unit_percent"] = round(metrics.coverage.unit_percent, 1)

    # ADR-020: Add top-level scanSpace slice if summary available
    if scan_space_summary is not None:
        entry["scanSpace"] = {
            "candidates": len(scan_space_summary.included_files)
            + len(scan_space_summary.excluded_files),
            "included": len(scan_space_summary.included_files),
            "excluded": len(scan_space_summary.excluded_files),
            "excludedBy": _aggregate_excluded_by(scan_space_summary.excluded_by),
            "linesOfCode": scan_space_summary.lines_of_code,
        }

    return entry


def _compute_scan_space_summary(workspace_root: Path) -> Any | None:
    """Best-effort scan-space summary for history export (ADR-020).

    Uses ScanSpaceResolver attribution so downstream dashboards can show excludedBy
    slices. Limited to Python files to keep the scan fast and aligned with extended
    metrics scope.
    """

    try:
        resolver = ScanSpaceResolver(workspace_root)
        resolver.load()

        candidates = safe_rglob(workspace_root, "*.py", max_files=20000)
        included: list[Path] = []
        excluded: list[Path] = []

        for path in candidates:
            if resolver.is_ignored(path):
                excluded.append(path)
            else:
                included.append(path)

        summary = resolver.build_scan_summary(included, excluded)

        # Count lines of code across all included files
        loc = 0
        for py_file in included:
            try:
                loc += py_file.read_text(encoding="utf-8", errors="replace").count("\n") + 1
            except Exception:
                pass
        summary.lines_of_code = loc

        return summary
    except Exception:
        return None


def _load_wrapper_entries(history_file: Path, wrapper: dict[str, Any]) -> list[dict[str, Any]]:
    if not history_file.exists():
        return []
    try:
        parsed = json.loads(history_file.read_text(encoding="utf-8"))
        if isinstance(parsed, dict):
            if isinstance(parsed.get("historyId"), str) and parsed.get("historyId"):
                wrapper["historyId"] = parsed["historyId"]
            if isinstance(parsed.get("projectId"), str) and parsed.get("projectId"):
                wrapper["projectId"] = parsed["projectId"]
            if isinstance(parsed.get("formatVersion"), str) and parsed.get("formatVersion"):
                wrapper["formatVersion"] = parsed["formatVersion"]
        return _get_entries(parsed)
    except Exception:
        return []


def _load_legacy_entries(legacy_history_file: Path) -> list[dict[str, Any]]:
    if not legacy_history_file.exists():
        return []
    try:
        legacy_payload = json.loads(legacy_history_file.read_text(encoding="utf-8"))
        return _get_entries(legacy_payload)
    except Exception:
        return []


def _build_merged_wrapper_entries(
    *,
    legacy_entries: list[dict[str, Any]],
    wrapper_entries: list[dict[str, Any]],
    timestamp: str,
    new_entry: dict[str, Any],
    max_entries: int = 100,
) -> list[dict[str, Any]]:
    merged = _merge_entries_dedupe_timestamp(legacy_entries, wrapper_entries)
    entries = _sort_entries_oldest_first(list(merged))
    entries = [e for e in entries if not (isinstance(e, dict) and e.get("timestamp") == timestamp)]
    entries.append(new_entry)
    if len(entries) > max_entries:
        entries = entries[-max_entries:]
    return entries


def _write_legacy_history_best_effort(
    *,
    legacy_history_dir: Path,
    legacy_history_file: Path,
    new_entry: dict[str, Any],
) -> None:
    try:
        legacy_history_dir.mkdir(parents=True, exist_ok=True)

        legacy_entry = dict(new_entry)
        legacy_entry.pop("python", None)

        legacy_payload_write: dict[str, Any] = {"entries": []}
        if legacy_history_file.exists():
            try:
                legacy_payload_write = json.loads(legacy_history_file.read_text(encoding="utf-8"))
            except Exception:
                legacy_payload_write = {"entries": []}

        entries_legacy = list(legacy_payload_write.get("entries") or [])
        entries_legacy = [legacy_entry, *entries_legacy]
        if len(entries_legacy) > 100:
            entries_legacy = entries_legacy[:100]
        legacy_payload_write["entries"] = entries_legacy

        _write_json_atomic(legacy_history_file, legacy_payload_write)
    except Exception:
        # best-effort
        pass


def export_metrics_history(
    workspace_root: Path,
    metrics: Any,
    mgpy_version: str | None = None,
    scan_space_summary: Any | None = None,
) -> None:
    """Export metrics history to .mgpy/metrics/manifestguard-history.json (ADR-020).

    Args:
        workspace_root: Project root directory
        metrics: Collected ExtendedTestMetrics
        mgpy_version: Version string (defaults to package __version__)
        scan_space_summary: Optional ScanSpaceSummary from ScanSpaceResolver.
            If provided, adds top-level scanSpace slice to enable MGVS scan-space charts.

    Example:
        from manifestguard.core.scan_space import ScanSpaceResolver
        from manifestguard.extended.metrics import export_metrics_history

        # Collect metrics...
        metrics = collector.collect_metrics()

        # Optional: Build scan-space summary
        resolver = ScanSpaceResolver(workspace_root)
        resolver.load()
        included_files = [...]  # Your collected files
        excluded_files = [...]  # Your excluded files
        scan_summary = resolver.build_scan_summary(included_files, excluded_files)

        # Export with scan-space
        export_metrics_history(workspace_root, metrics, scan_space_summary=scan_summary)
    """
    if mgpy_version is None:
        mgpy_version = default_mgpy_version

    # Auto-collect scan-space summary when not provided so MGVS dashboards
    # receive excludedBy attribution and candidate counts without extra wiring.
    if scan_space_summary is None:
        scan_space_summary = _compute_scan_space_summary(workspace_root)

    # Primary location: .mgpy/metrics/ (parallel to MGVS .mgvs/history/)
    history_file = workspace_root / ".mgpy" / "metrics" / "manifestguard-history.json"
    legacy_history_dir = workspace_root / ".manifestguard"
    legacy_history_file = legacy_history_dir / "metrics-history.json"
    legacy_root_file = workspace_root / ".manifestguard-history.json"

    timestamp = datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
    new_entry = _build_new_entry(
        metrics,
        scan_space_summary=scan_space_summary,
        mgpy_version=mgpy_version or "unknown",
        timestamp=timestamp,
    )

    wrapper: dict[str, Any] = {
        "schemaVersion": "2.0",
        "formatVersion": METRICS_HISTORY_FORMAT_VERSION,
        "historyId": _new_stable_id(),
        "projectId": _new_stable_id(),
        "entries": [],
    }

    wrapper_entries = _load_wrapper_entries(history_file, wrapper)
    legacy_entries = _load_legacy_entries(legacy_history_file)
    legacy_root_entries = _load_legacy_entries(legacy_root_file)
    
    # Merge all legacy sources (oldest legacy dir, then root, then new wrapper)
    merged_legacy = _merge_entries_dedupe_timestamp(legacy_entries, legacy_root_entries)
    entries = _build_merged_wrapper_entries(
        legacy_entries=merged_legacy,
        wrapper_entries=wrapper_entries,
        timestamp=timestamp,
        new_entry=new_entry,
        max_entries=100,
    )

    wrapper["schemaVersion"] = "2.0"
    wrapper["entries"] = entries

    # Ensure .mgpy/metrics/ directory exists
    history_file.parent.mkdir(parents=True, exist_ok=True)
    _write_json_atomic(history_file, wrapper)

    # Legacy write (omit python namespace)
    _write_legacy_history_best_effort(
        legacy_history_dir=legacy_history_dir,
        legacy_history_file=legacy_history_file,
        new_entry=new_entry,
    )


def add_coverage_metric_to_history(
    workspace_root: Path,
    coverage_file: Path | None = None,
    mgpy_version: str | None = None
) -> bool:
    """Add coverage metric to metrics history without full metrics collection.
    
    This is a lightweight alternative to export_metrics_history() for adding
    just the coverage.estimate metric to .mgpy/metrics/manifestguard-history.json.
    
    Args:
        workspace_root: Project root directory
        coverage_file: Path to coverage.json (default: workspace_root/coverage.json)
        mgpy_version: Version string (defaults to package __version__)
        
    Returns:
        True if coverage metric was added successfully, False otherwise
    """
    import logging  # noqa: PLC0415

    resolved_version = mgpy_version or default_mgpy_version
    resolved_coverage_file = coverage_file or (workspace_root / "coverage.json")

    try:
        coverage_metric = extract_coverage_from_file(resolved_coverage_file)
    except (CoverageParseError, FileNotFoundError) as e:
        logging.getLogger(__name__).warning(f"Failed to extract coverage: {e}")
        return False

    timestamp = datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
    new_entry = _make_coverage_history_entry(
        timestamp=timestamp,
        mgpy_version=resolved_version,
        coverage_metric=coverage_metric,
    )
    return _write_entry_to_workspace_history(workspace_root, new_entry)


def add_venv_packages_delta_to_history(
    workspace_root: Path,
    venv_packages_delta: dict[str, Any],
    mgpy_version: str | None = None,
) -> bool:
    """Add venv packages delta entry to metrics history.

    This is intended to keep the history timeline small by appending only
    the delta between package snapshots, while full snapshots can live as
    artifacts under `.manifestguard/venv-packages/...`.

    Required keys in venv_packages_delta:
        - venvPath (str)
        - delta (dict)

    Returns True on success.
    """
    import logging  # noqa: PLC0415

    resolved_version = mgpy_version or default_mgpy_version

    for field in ("venvPath", "delta"):
        if field not in venv_packages_delta:
            logging.getLogger(__name__).warning(
                f"Missing required field in venv_packages_delta: {field}"
            )

    timestamp = datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
    new_entry = {
        "timestamp": timestamp,
        "version": resolved_version,
        "validatorVersion": resolved_version,
        "venvPackagesDelta": venv_packages_delta,
    }
    return _write_entry_to_workspace_history(workspace_root, new_entry)


def add_venv_health_to_history(
    workspace_root: Path,
    venv_health: dict[str, Any],
    mgpy_version: str | None = None
) -> bool:
    """Add venv health metric to metrics history.
    
    Lightweight alternative to export_metrics_history() for adding
    just the venvHealth slice to .mgpy/metrics/manifestguard-history.json.
    
    Args:
        workspace_root: Project root directory
        venv_health: Health data dict with keys:
            - venvPath (str): Relative path to venv
            - status (str): ok|warning|error
            - processStats (dict): totalManaged, running, zombies, dead
            - warnings (list[str]): Human-readable warnings
            - autoFixApplied (bool): Was auto-fix applied?
            - psutilAvailable (bool): Was psutil available?
            Optional:
            - venvAbsolutePath (str)
            - autoFixDetails (dict)
            - executionTimeSeconds (float)
        mgpy_version: Version string (defaults to package __version__)
        
    Returns:
        True if venv health was added successfully, False otherwise
    """
    import logging  # noqa: PLC0415

    resolved_version = mgpy_version or default_mgpy_version

    required_fields = [
        "venvPath", "status", "warnings",
        "managedChildren", "running", "zombie", "dead", "unknown",
    ]
    for field in required_fields:
        if field not in venv_health:
            logging.getLogger(__name__).warning(f"Missing required field in venv_health: {field}")
            return False

    timestamp = datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
    new_entry = _make_single_metric_history_entry(
        timestamp=timestamp,
        mgpy_version=resolved_version,
        metric_name="venvHealth",
        metric_value=venv_health,
    )
    return _write_entry_to_workspace_history(workspace_root, new_entry)

