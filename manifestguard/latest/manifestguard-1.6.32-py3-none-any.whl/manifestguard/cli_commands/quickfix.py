"""CLI commands for QuickFix operations (ADR-037)."""

from __future__ import annotations

import json
import sys
from pathlib import Path

import click

from manifestguard.quickfix import apply_quickfix, find_quickfix, get_quickfixes, preview_quickfix
from manifestguard.core.config import resolve_project_root
from manifestguard.validation.base import Diagnostic


@click.group(name="quickfix")
def quickfix_group() -> None:
    """QuickFix operations: list, preview, and apply automated fixes."""


@quickfix_group.command(name="list")
@click.option(
    "--project-root",
    type=click.Path(exists=True, file_okay=False, dir_okay=True, resolve_path=True),
    default=".",
    help="Project root directory (default: current directory)",
)
@click.option(
    "--format",
    type=click.Choice(["text", "json"], case_sensitive=False),
    default="text",
    help="Output format (default: text)",
)
def list_quickfixes(project_root: str, format: str) -> None:
    """List all available QuickFix actions for the project.
    
    This command scans for diagnostics and shows available fixes.
    Use --format json for machine-readable output.
    """
    root = resolve_project_root(project_root)
    # In production, this would integrate with the validation pipeline
    click.echo(f"Scanning project: {root}")
    click.echo("")
    
    # Example: Show registered fix types
    click.echo("Available QuickFix types:")
    click.echo("  • EP-001: Create missing entry point module")
    click.echo("  • EP-002: Suggest correct entry point format")
    click.echo("  • EP-003: Add missing function to module")
    click.echo("  • DUMMY-001: Remove/convert TODO markers")
    click.echo("  • DUMMY-002: Replace NotImplementedError with stub")
    click.echo("")
    click.echo("Run 'mgpy validate' to find diagnostics, then use 'mgpy quickfix preview <id>' to preview fixes.")


@quickfix_group.command(name="preview")
@click.argument("fix-id")
@click.option(
    "--project-root",
    type=click.Path(exists=True, file_okay=False, dir_okay=True, resolve_path=True),
    default=".",
    help="Project root directory (default: current directory)",
)
@click.option(
    "--diagnostic-code",
    required=True,
    help="Diagnostic code (e.g., EP-001, DUMMY-001)",
)
@click.option(
    "--file",
    type=click.Path(exists=True, file_okay=True, dir_okay=False),
    help="File path for the diagnostic (required for some fixes)",
)
@click.option(
    "--line",
    type=int,
    help="Line number for the diagnostic (required for some fixes)",
)
@click.option(
    "--data",
    help="Diagnostic data as JSON string (e.g., '{\"module\": \"package.module\"}')",
)
def preview_quickfix_cmd(
    fix_id: str, project_root: str, diagnostic_code: str, file: str | None, line: int | None, data: str | None
) -> None:
    """Preview a QuickFix without applying changes.
    
    Shows what would be changed without modifying files.
    """
    root = resolve_project_root(project_root)

    # Parse diagnostic data
    diagnostic_data = json.loads(data) if data else {}

    # Create diagnostic object
    diagnostic = Diagnostic(
        code=diagnostic_code,
        severity="ERROR",
        message="[Preview mode diagnostic]",
        file_path=Path(file) if file else None,
        line=line,
        data=diagnostic_data,
    )
    
    # Find the specific fix
    action = find_quickfix(root, diagnostic, fix_id)
    
    if not action:
        click.echo(f"❌ QuickFix '{fix_id}' not found for diagnostic {diagnostic_code}", err=True)
        sys.exit(1)
    
    # Run preview
    click.echo(f"Previewing QuickFix: {action.title}")
    click.echo(f"Description: {action.description}")
    click.echo("")
    
    result = preview_quickfix(action, root)
    
    if result.applied:
        click.echo(f"✓ {result.message}")
    else:
        click.echo(f"Preview: {result.message}")
    
    if result.details:
        click.echo("")
        click.echo("Details:")
        click.echo(json.dumps(result.details, indent=2))


@quickfix_group.command(name="apply")
@click.argument("fix-id")
@click.option(
    "--project-root",
    type=click.Path(exists=True, file_okay=False, dir_okay=True, resolve_path=True),
    default=".",
    help="Project root directory (default: current directory)",
)
@click.option(
    "--diagnostic-code",
    required=True,
    help="Diagnostic code (e.g., EP-001, DUMMY-001)",
)
@click.option(
    "--file",
    type=click.Path(exists=True, file_okay=True, dir_okay=False),
    help="File path for the diagnostic (required for some fixes)",
)
@click.option(
    "--line",
    type=int,
    help="Line number for the diagnostic (required for some fixes)",
)
@click.option(
    "--data",
    help="Diagnostic data as JSON string (e.g., '{\"module\": \"package.module\"}')",
)
@click.option(
    "--backup-label",
    help="Optional label for the snapshot backup (default: timestamp)",
)
@click.option(
    "--yes",
    is_flag=True,
    help="Skip confirmation prompt",
)
def apply_quickfix_cmd(
    fix_id: str,
    project_root: str,
    diagnostic_code: str,
    file: str | None,
    line: int | None,
    data: str | None,
    backup_label: str | None,
    yes: bool,
) -> None:
    """Apply a QuickFix to modify project files.
    
    Creates a snapshot backup before applying changes.
    Use --yes to skip confirmation prompt.
    """
    root = resolve_project_root(project_root)
    
    # Parse diagnostic data
    diagnostic_data = json.loads(data) if data else {}
    
    # Create diagnostic object
    diagnostic = Diagnostic(
        code=diagnostic_code,
        severity="ERROR",
        message="[Apply mode diagnostic]",
        file_path=Path(file) if file else None,
        line=line,
        data=diagnostic_data,
    )
    
    # Find the specific fix
    action = find_quickfix(root, diagnostic, fix_id)
    
    if not action:
        click.echo(f"❌ QuickFix '{fix_id}' not found for diagnostic {diagnostic_code}", err=True)
        sys.exit(1)
    
    # Confirmation
    if not yes:
        click.echo(f"About to apply: {action.title}")
        click.echo(f"Description: {action.description}")
        click.echo("")
        if not click.confirm("Continue?"):
            click.echo("Aborted.")
            sys.exit(0)
    
    # Create snapshot backup
    from manifestguard.quickfix.backup import create_snapshot
    
    try:
        click.echo("Creating snapshot backup...")
        snapshot_path = create_snapshot(root)
        click.echo(f"✓ Snapshot saved: {snapshot_path.relative_to(root)}")
        click.echo("")
    except Exception as e:
        click.echo(f"❌ Failed to create snapshot: {e}", err=True)
        sys.exit(1)
    
    # Apply the fix
    click.echo(f"Applying QuickFix: {action.title}")
    result = apply_quickfix(action, root)
    
    if result.applied:
        click.echo(f"✓ {result.message}")
        sys.exit(0)
    else:
        click.echo(f"❌ {result.message}", err=True)
        sys.exit(1)


__all__ = ["quickfix_group"]
