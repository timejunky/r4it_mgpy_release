"""CLI command for duplication detection."""

from __future__ import annotations

import json
from pathlib import Path

import click


@click.group(name="duplication")
def duplication_group() -> None:
    """Code duplication detection commands."""



@duplication_group.command(name="check")
@click.option(
    "--project-root",
    type=click.Path(exists=True, file_okay=False, dir_okay=True, resolve_path=True),
    default=".",
    help="Project root directory (default: current directory)",
)
@click.option(
    "--include-tests",
    is_flag=True,
    default=False,
    help="Include test files in duplication detection",
)
@click.option(
    "--window-lines",
    type=int,
    default=6,
    help="Minimum number of lines for duplicate block (default: 6)",
)
@click.option(
    "--min-occurrences",
    type=int,
    default=2,
    help="Minimum occurrences to report duplicate (default: 2)",
)
@click.option(
    "--format",
    type=click.Choice(["text", "json"], case_sensitive=False),
    default="text",
    help="Output format (default: text)",
)
@click.option(
    "--max-results",
    type=int,
    default=50,
    help="Maximum number of duplication groups to report (default: 50)",
)
def check_duplication(
    project_root: str,
    include_tests: bool,
    window_lines: int,
    min_occurrences: int,
    format: str,
    max_results: int,
) -> None:
    """Run code duplication detection and report duplicate code blocks.
    
    Detects exact duplicate blocks across Python files using whitespace-normalized
    hashing. Respects ignore patterns from manifestguard.json and .gitignore.
    
    Examples:
    
        # Check for duplicates in current project
        mgpy duplication check
        
        # Include test files and use stricter threshold
        mgpy duplication check --include-tests --window-lines 4
        
        # Output as JSON for tooling integration
        mgpy duplication check --format json > duplicates.json
    """
    from manifestguard.core.ignore_patterns import IgnorePatterns
    from manifestguard.core.config import resolve_project_root
    from manifestguard.extended.duplication import (
        DuplicationDetectionConfig,
        run_duplication_detection,
    )

    project_path = resolve_project_root(project_root)
    
    # Load ignore patterns
    ignore = IgnorePatterns(project_path)
    ignore.load()
    
    # Configure duplication detection
    config = DuplicationDetectionConfig(
        enabled=True,
        include_tests=include_tests,
        window_lines=window_lines,
        min_occurrences=min_occurrences,
        max_results=max_results,
    )
    
    click.echo(f"🔍 Scanning for duplicate code blocks in {project_path}...")
    click.echo(f"   Window size: {window_lines} lines")
    click.echo(f"   Including tests: {'Yes' if include_tests else 'No'}")
    click.echo()
    
    # Run detection
    result = run_duplication_detection(project_path, config=config, ignore=ignore)
    
    if format == "json":
        click.echo(json.dumps(result, indent=2))
        return
    
    # Text format output
    if not result.get("enabled"):
        click.echo("⚠️  Duplication detection is disabled")
        return
    
    stats = result.get("stats", {})
    groups = result.get("groups", [])
    
    click.echo("=" * 80)
    click.echo("CODE DUPLICATION DETECTION REPORT")
    click.echo("=" * 80)
    click.echo()
    
    click.echo(f"Files scanned: {stats.get('filesScanned', 0)}")
    click.echo(f"Duplicate groups found: {stats.get('reportedBlocks', 0)}")
    click.echo(f"Total occurrences: {stats.get('totalOccurrences', 0)}")
    click.echo(f"Duplicate lines: {stats.get('duplicatedLines', 0)}")
    click.echo(f"Engine: {stats.get('engine', 'mgpy-duplication')} v{stats.get('engineVersion', '1.0')}")
    click.echo()
    
    if not groups:
        click.echo("✅ No significant code duplication found!")
        return
    
    # Show top duplicate groups
    click.echo("=" * 80)
    click.echo(f"TOP DUPLICATION GROUPS (showing up to {min(10, len(groups))})")
    click.echo("=" * 80)
    click.echo()
    
    for i, group in enumerate(groups[:10], 1):
        fingerprint = group.get("fingerprint", "unknown")[:12]
        occurrences = group.get("occurrences", [])
        lines = group.get("lines", 0)
        tokens = group.get("tokens", 0)
        
        click.echo(f"Group {i}: {len(occurrences)} occurrences, {lines} lines, {tokens} tokens")
        click.echo(f"Fingerprint: {fingerprint}...")
        click.echo()
        
        click.echo("Locations:")
        for occ in occurrences[:5]:  # Limit to 5 occurrences per group
            file_path = occ.get("file", "unknown")
            start = occ.get("startLine", 0)
            end = occ.get("endLine", 0)
            click.echo(f"  - {file_path}:{start}-{end}")
        
        if len(occurrences) > 5:
            click.echo(f"  ... and {len(occurrences) - 5} more location(s)")
        
        click.echo()
    
    if len(groups) > 10:
        click.echo(f"... and {len(groups) - 10} more duplication group(s)")
        click.echo()
    
    click.echo("=" * 80)
    click.echo()
    
    # Summary and suggestions
    total_duplicated_lines = stats.get("duplicatedLines", 0)
    if total_duplicated_lines > 100:
        click.echo("💡 High duplication detected! Consider:")
        click.echo("   - Extracting common code into reusable functions")
        click.echo("   - Creating utility modules for shared logic")
        click.echo("   - Using inheritance or composition patterns")
    elif total_duplicated_lines > 50:
        click.echo("💡 Moderate duplication detected. Review duplicate blocks for refactoring opportunities.")
    else:
        click.echo("✅ Duplication levels are acceptable.")
