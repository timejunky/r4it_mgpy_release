from __future__ import annotations

import asyncio
import contextlib
import json
import logging
import sys
from datetime import datetime
from pathlib import Path
from threading import Event, Thread
from typing import Any

import click

from manifestguard import __version__, get_runtime_version
from manifestguard.core.config import ConfigurationService
from manifestguard.core.config_analysis import ConfigAnalyzer, format_warning_output
from manifestguard.core.user_settings import load_user_settings, save_user_settings, user_settings_path
from manifestguard.extended import BaselineManager, ExtendedTestRunner
from manifestguard.extended.metrics import export_metrics_history
from manifestguard.i18n import (
    SUPPORTED_LANGUAGES,
    get_current_language,
    get_current_language_source,
    set_language,
    t,
    t_format,
)
from manifestguard.quickfix import BackupContext, QuickFixAction, apply_quickfix, get_quickfixes, preview_quickfix
from manifestguard.quickfix.backup import create_snapshot
from manifestguard.reporting.sarif import build_sarif_report
from manifestguard.validation import DiagnosticSeverity, ValidationResult
from manifestguard.validation.base import Diagnostic


from .language_commands import languages_command, set_language_command
from .fix_command import fix

logger = logging.getLogger(__name__)


def register(cli_group: click.Group) -> None:
    cli_group.add_command(check)
    cli_group.add_command(fix)
    cli_group.add_command(refactor_plan)
    cli_group.add_command(sbom)
    cli_group.add_command(set_language_command)
    cli_group.add_command(languages_command)

def _detect_installation_type() -> None:
    """Display installation type information."""
    try:
        import manifestguard  # noqa: PLC0415 - avoid circular import at module level

        install_path = Path(manifestguard.__file__).parent
        install_str = str(install_path)

        label = t("cli.install.label", module="cli")
        if "site-packages" not in install_str:
            if "dev" in install_str.lower():
                install_type = t("cli.install.local_dev", module="cli")
            else:
                install_type = t("cli.install.unknown", module="cli")
            click.echo(f"   {label}: {install_type}")
        elif "Roaming" in install_str or "Local" in install_str:
            click.echo(f"   {label}: {t('cli.install.global_user', module='cli')}")
        else:
            click.echo(f"   {label}: {t('cli.install.global_system', module='cli')}")
    except Exception:
        label = t("cli.install.label", module="cli")
        click.echo(f"   {label}: {t('cli.install.unknown', module='cli')}")


def _show_config_info(workspace_root: Path, cli_extended: bool | None = None) -> None:
    """Display configuration information if available.

    Args:
        workspace_root: Root directory to locate manifestguard.json.
        cli_extended: The value of the --extended CLI flag, if provided. When True,
            the banner shows extended as enabled regardless of the config file value
            (CLI flag takes precedence for display purposes).
    """
    from manifestguard.cli import _find_existing_config_path

    config_path = _find_existing_config_path(workspace_root)
    if not config_path:
        return

    try:
        with config_path.open(encoding="utf-8") as handle:
            config = json.load(handle)
            config_version = config.get("version", "unknown")
            # CLI flag takes precedence: if --extended was passed, show ✅ even if the
            # config file has extended=false (the flag overrides for this run).
            extended_enabled = cli_extended if cli_extended is not None else config.get("extended", False)
            if extended_enabled:
                status = t("cli.config.extended_enabled", module="cli")
            else:
                status = t("cli.config.extended_disabled", module="cli")
            label = t("cli.config.label", module="cli")
            click.echo(f"   {label}: v{config_version} ({status})")
    except Exception:
        return


def _warn_extended_config_mismatch(workspace_root: Path, cli_extended: bool) -> None:
    """Warn when --extended is active but manifestguard.json has extended=false.

    This catches the common mistake of running with --extended while the config
    file still has the default extended=false, which causes confusing ❌ display.
    Prints a one-line autorepair suggestion so the user can fix the config.
    """
    if not cli_extended:
        return

    from manifestguard.cli import _find_existing_config_path

    config_path = _find_existing_config_path(workspace_root)
    if not config_path:
        return

    try:
        config = json.loads(config_path.read_text(encoding="utf-8"))
        if not config.get("extended", False):
            click.echo(
                f"⚠️  Config mismatch: --extended is active but "
                f"{config_path.name} has extended=false.\n"
                f"   Autorepair: add '\"extended\": true' to {config_path.name}, "
                f"or run:\n"
                f"     python -m manifestguard init-config --merge"
            )
    except Exception:
        pass



def _format_diagnostic_location(diag: Diagnostic) -> str:
    from manifestguard.cli import _has_license_feature

    # Licensing UX:
    # - Community: only filenames (no line numbers)
    # - Pro+: include exact line numbers
    file_name = getattr(getattr(diag, "file_path", None), "name", None) or "unknown"
    location = f"{file_name}"
    if _has_license_feature("quickfix_suggestions") and getattr(diag, "line", None):
        location += f":{diag.line}"
    return location


def _display_diagnostic_group(diagnostics: list, emoji: str, label: str) -> None:
    if not diagnostics:
        return

    from manifestguard.cli import _has_license_feature

    can_show_details = _has_license_feature("quickfix_suggestions")

    click.echo(f"\n{emoji} {len(diagnostics)} {label}:\n")

    # Community license: only show filenames (no line, no code, no messages).
    if not can_show_details:
        seen: set[str] = set()
        ordered_files: list[str] = []
        for diag in diagnostics:
            file_name = getattr(getattr(diag, "file_path", None), "name", None)
            if not file_name:
                continue
            if file_name in seen:
                continue
            seen.add(file_name)
            ordered_files.append(file_name)
        for file_name in ordered_files:
            click.echo(f"  {file_name}")
        click.echo()
        return

    # Pro+ license: show full details.
    for diag in diagnostics:
        location = _format_diagnostic_location(diag)
        click.echo(f"  [{diag.code}] {location}")
        click.echo(f"  {diag.message}")
        if getattr(diag, "fix_suggestion", None):
            click.echo(f"  💡 {diag.fix_suggestion}")
        click.echo()


def _display_validation_summary(result: ValidationResult) -> None:
    click.echo("\n📊 Validation Summary:")
    click.echo(f"   Files checked: {len(result.validated_files)}")
    click.echo(f"   Errors: {result.error_count}")
    click.echo(f"   Warnings: {result.warning_count}")
    click.echo(f"   Infos: {result.info_count}")


def _display_validation_results(result: ValidationResult) -> None:
    if result.is_valid and not result.diagnostics:
        return

    errors = [d for d in result.diagnostics if d.severity == DiagnosticSeverity.ERROR]
    warnings = [d for d in result.diagnostics if d.severity == DiagnosticSeverity.WARNING]

    _display_diagnostic_group(errors, "❌", "Error(s) found")
    _display_diagnostic_group(warnings, "⚠️ ", "Warning(s)")

    _display_validation_summary(result)

    if not result.is_valid:
        click.echo(f"\n❌ Validation failed with {result.error_count} error(s)")
        sys.exit(1)


def _handle_deprecated_format(format_: str | None, report: str | None) -> str | None:
    """Handle deprecated --format option and return report path."""
    if format_ is None:
        return report

    click.echo(t("cli.warning.format_deprecated", module="cli"), err=True)
    if report is not None:
        return report

    if format_ == "json":
        return "manifestguard-report.json"
    if format_ == "sarif":
        return "manifestguard-report.sarif"

    return report


def _run_extended_tests(
    workspace_root: Path,
    report: str | None,
    verbose: bool = False,
    fail_on_security: bool = False,
    format_: str | None = None,
    validation_result: ValidationResult | None = None,
    live: bool = True,
    live_interval_s: int = 30,
    runner_config: dict[str, Any] | None = None,
) -> None:
    """Run extended test mode and save results."""
    from manifestguard.cli import _build_quality_slice, _summarize_security_findings
    from manifestguard.reporting.refactor_guidelines import ensure_refactor_guidelines

    import time

    click.echo(f"\n{t('cli.extended.title', module='cli')}")

    started = time.monotonic()
    last_output_at = started

    def _progress(msg: str) -> None:
        now = datetime.now().strftime("%H:%M:%S")
        elapsed_s = time.monotonic() - started
        nonlocal last_output_at
        last_output_at = time.monotonic()
        click.echo(f"   [{now} +{elapsed_s:0.1f}s] {msg}")

    stop_event = Event()

    def _heartbeat() -> None:
        """Emit periodic liveness messages while extended analysis is running.

        Only prints when no other progress output has been emitted recently.
        """
        nonlocal last_output_at
        # sanity guard: avoid spam / misconfig
        interval = max(5, int(live_interval_s or 30))
        while not stop_event.wait(timeout=1):
            now_mono = time.monotonic()
            if now_mono - last_output_at < interval:
                continue
            wall = datetime.now().strftime("%H:%M:%S")
            elapsed_s = now_mono - started
            click.echo(f"   [{wall} +{elapsed_s:0.1f}s] … still running")
            last_output_at = now_mono

    gate_counts: tuple[int, int, int] | None = None
    if validation_result is not None:
        gate_counts = (
            int(getattr(validation_result, "error_count", 0)),
            int(getattr(validation_result, "warning_count", 0)),
            int(getattr(validation_result, "info_count", 0)),
        )

    runner = ExtendedTestRunner(
        workspace_root,
        config=runner_config or {},
        gate_counts=gate_counts,
    )
    if not runner.is_enabled():
        click.echo(f"   {t('cli.extended.disabled', module='cli')}")
        return

    heartbeat_thread: Thread | None = None
    if live and sys.stdout.isatty():
        heartbeat_thread = Thread(target=_heartbeat, name="mgpy-cli-heartbeat", daemon=True)
        heartbeat_thread.start()

    try:
        metrics = asyncio.run(runner.run(progress_callback=_progress))
    finally:
        stop_event.set()
        if heartbeat_thread is not None:
            heartbeat_thread.join(timeout=2)
    if not metrics:
        return

    asyncio.run(runner.show_recommendations(metrics, verbose=verbose))

    security_summary = _summarize_security_findings(getattr(metrics, "security", None))

    if report:
        report_path = Path(report)
        if (format_ or "").lower() == "sarif":
            sarif = build_sarif_report(workspace_root, validation_result, metrics)
            report_path.write_text(json.dumps(sarif, indent=2))
        else:
            report_data = {"extended": metrics.to_dict()}
            try:
                quality = _build_quality_slice(metrics, workspace_root)
                report_data["quality"] = quality
            except Exception as e:
                click.echo(
                    f"   {t_format('cli.extended.export_failed', error=e, module='cli')}", err=True
                )

            # AI ground rules for refactor/fix loops (kept in sync with MGVS where possible).
            ensure_refactor_guidelines(report_data)
            report_path.write_text(json.dumps(report_data, indent=2))

        click.echo(t_format("cli.extended.report_saved_extended", path=report_path, module="cli"))

    try:
        export_metrics_history(workspace_root, metrics, mgpy_version=__version__)
        click.echo(f"   {t('cli.extended.metrics_exported', module='cli')}")
    except Exception as e:
        click.echo(f"   {t_format('cli.extended.export_failed', error=e, module='cli')}", err=True)

    baseline_mgr = BaselineManager(workspace_root)
    baseline_mgr.save_baseline(metrics, label="latest")
    click.echo(f"   {t('cli.extended.baseline_updated', module='cli')}")

    # Duration summary (always show)
    wall_s = time.monotonic() - started
    metrics_s = getattr(getattr(metrics, "performance", None), "total_analysis_ms", 0.0) / 1000.0
    click.echo(f"   ⏱️  Extended duration (wall): {wall_s:0.1f}s")
    if metrics_s:
        click.echo(f"   ⏱️  Extended analysis time (measured): {metrics_s:0.1f}s")

    if fail_on_security and security_summary.get("has_findings"):
        click.echo("\n❌ Security gate failed: security findings detected.")
        click.echo(f"   Details: {json.dumps(security_summary, ensure_ascii=False)}")
        sys.exit(2)


@click.command(name="check")
@click.argument("file", required=False, type=click.Path(exists=True))
@click.option(
    "--extended/--no-extended",
    default=True,
    help="Run extended test mode (default: enabled)",
)
@click.option(
    "--report",
    type=click.Path(),
    default=None,
    help="Save extended metrics to JSON file (includes refactorGuidelines for AI tooling)",
)
@click.option(
    "--format",
    "format_",
    type=click.Choice(["json", "sarif"], case_sensitive=False),
    default=None,
    help="[DEPRECATED] Output format (use --report instead)",
)
@click.option(
    "--verbose",
    "-v",
    is_flag=True,
    default=False,
    help="Show detailed Medium/Low priority recommendations",
)
@click.option(
    "--fail-on-security/--no-fail-on-security",
    default=False,
    help="Exit non-zero if extended security findings are present",
)
@click.option(
    "--acknowledge-config-warning",
    is_flag=True,
    default=False,
    help=(
        "Proceed even if an abnormal ignore configuration is detected "
        "(mass ignores / wildcard ignores)."
    ),
)
@click.option(
    "--refactor",
    is_flag=True,
    default=False,
    help=(
        "Refactor mode: skip extended test run, write only refactorGuidelines to a JSON report "
        "(default output: manifestguard-report-refactor.json). "
        "Use during AI-assisted refactor/fix loops."
    ),
)
@click.option(
    "--live/--no-live",
    default=True,
    help=(
        "Show liveness output during long-running steps (prints a heartbeat line if no progress was emitted for a while)."
    ),
)
@click.option(
    "--live-interval",
    "live_interval_s",
    type=int,
    default=30,
    show_default=True,
    help="Heartbeat interval in seconds for --live.",
)
def check(
    file: str | None,
    extended: bool,
    report: str | None,
    format_: str | None,
    verbose: bool,
    fail_on_security: bool,
    acknowledge_config_warning: bool,
    refactor: bool,
    live: bool,
    live_interval_s: int,
) -> None:
    """Validate manifest files with optional extended analysis."""
    from manifestguard.cli import _has_license_feature, _license_tier_label, _resolve_workspace_root
    from manifestguard.cli import _run_manifest_validation
    from manifestguard.core.test_config_helper import load_manifest_config

    from manifestguard.core.run_lock import RunLock, RunLockHeldError

    import time

    total_started = time.monotonic()
    runtime_version = get_runtime_version()

    click.echo(t("cli.banner.separator", module="cli"))
    click.echo(f"🛡️  {t('cli.description', module='cli')}")
    click.echo(f"   {t('app.version')}: {runtime_version}")

    _detect_installation_type()

    workspace_root = _resolve_workspace_root()
    _show_config_info(workspace_root, cli_extended=extended)
    _warn_extended_config_mismatch(workspace_root, extended)

    config_service = ConfigurationService(workspace_root)
    effective_config = config_service.get_config()
    rules = effective_config.rules or {}

    ignored_rules: list[str] = []
    for rule_code, value in rules.items():
        if value is False:
            ignored_rules.append(rule_code)
        elif isinstance(value, str) and value.lower() == "off":
            ignored_rules.append(rule_code)
        elif isinstance(value, dict) and str(value.get("level", "")).lower() == "off":
            ignored_rules.append(rule_code)

    if ignored_rules:
        analyzer = ConfigAnalyzer()
        warnings = analyzer.detect_abnormal_ignores(ignored_rules)
        if warnings and not acknowledge_config_warning:
            click.echo(format_warning_output(warnings))
            raise click.Abort()

    click.echo(t("cli.banner.separator", module="cli") + "\n")

    report = _handle_deprecated_format(format_, report)

    # --refactor: use a dedicated report name and always write refactorGuidelines.
    # The full validation + extended test run still executes normally.
    if refactor and report is None:
        report = "manifestguard-report-refactor.json"

    file = file or "pyproject.toml"

    lock: RunLock | None = None
    if extended:
        lock_path = workspace_root / ".manifestguard" / "manifestguard-report.lock"
        resolved_report_path: str | None = None
        if report is not None:
            report_path = Path(report)
            if not report_path.is_absolute():
                report_path = workspace_root / report_path
            resolved_report_path = str(report_path)
        lock = RunLock(lock_path, command="check", report_path=resolved_report_path)
        try:
            lock.acquire()
        except RunLockHeldError as e:
            click.echo("\n[ManifestGuard] Lauf blockiert: bereits aktiv.")
            click.echo(str(e))
            raise click.Abort() from e

    click.echo(f"🔍 {t('cli.validation.running', module='cli')}...")

    try:
        validation_result = _run_manifest_validation(workspace_root)
        _display_validation_results(validation_result)

        if validation_result.is_valid:
            click.echo(t_format("cli.warning.beta", name="ManifestGuard", module="cli"))
            click.echo(f"✅ {t('cli.validation.no_issues', module='cli')}")

        if extended:
            if not _has_license_feature("extended_analysis"):
                click.echo("\n🔒 Extended analysis requires a Pro (or higher) license.")
                click.echo(f"   Current: {_license_tier_label()}. Running basic validation only.")
                return

            _run_extended_tests(
                workspace_root,
                report,
                verbose,
                fail_on_security=fail_on_security,
                format_=format_,
                validation_result=validation_result,
                live=live,
                live_interval_s=live_interval_s,
                runner_config=load_manifest_config(workspace_root),
            )
    finally:
        if lock is not None:
            lock.release()

    total_s = time.monotonic() - total_started
    click.echo(f"\n⏱️  Total duration: {total_s:0.1f}s")


def _format_relative_path(base: Path, path: Path) -> str:
    try:
        return str(path.relative_to(base))
    except ValueError:
        return str(path)


@click.command(name="refactor-plan")
@click.option(
    "--format",
    "format_",
    type=click.Choice(["text", "json"], case_sensitive=False),
    default="text",
    help="Output format (default: text)",
)
@click.option(
    "--path",
    "rules_path",
    type=click.Path(path_type=Path),
    default=None,
    help="Optional explicit path to a mg.rules.refactoring.json file",
)
def refactor_plan(format_: str, rules_path: Path | None) -> None:
    """Print an ordered refactoring plan derived from mg.rules.refactoring.json.

    Baseline behavior:
    - A baseline plan is always active and cannot be bypassed by configuration.
    - If a rules file exists, it can extend the plan but cannot disable baseline rules.
    - If a rules file exists but is invalid: exits non-zero with a config error.
    """

    from manifestguard.cli import _resolve_workspace_root
    from manifestguard.core.refactoring_rules import (
        RefactoringRulesError,
        build_baseline_refactoring_plan,
        load_refactoring_rules_plan,
    )

    workspace_root = _resolve_workspace_root()

    candidate_paths = []
    if rules_path is not None:
        candidate_paths.append(rules_path)
    else:
        candidate_paths.extend(
            [
                workspace_root / ".mgpy" / "mg.rules.refactoring.json",
                workspace_root / ".mgvs" / "mg.rules.refactoring.json",
            ]
        )

    source: Path | None = None
    for p in candidate_paths:
        if p.exists():
            source = p
            break

    if source is None:
        plan = build_baseline_refactoring_plan(workspace_root / "<baseline>")
    else:
        try:
            plan = load_refactoring_rules_plan(source)
        except RefactoringRulesError as e:
            raise click.UsageError(str(e)) from e

    if format_.lower() == "json":
        out = {
            "sourcePath": str(plan.source_path),
            "version": plan.version,
            "aiInstruction": plan.ai_instruction,
            "rulesActive": [{"ruleId": r.rule_id, "order": r.order} for r in plan.rules_active],
            "aiHintsActive": [{"hintId": h.hint_id, "order": h.order} for h in plan.ai_hints_active],
            "stages": plan.stages,
            "warnings": plan.warnings,
        }
        click.echo(json.dumps(out, ensure_ascii=False, indent=2))
        return

    # text
    rel = _format_relative_path(workspace_root, plan.source_path)
    click.echo(f"Refactoring rules: {rel}")
    if plan.warnings:
        click.echo("Warnings:")
        for w in plan.warnings:
            click.echo(f"- {w}")

    if plan.ai_hints_active:
        click.echo("AI hints:")
        for h in plan.ai_hints_active:
            click.echo(f"- {h.order}:{h.hint_id}")

    if plan.ai_instruction:
        click.echo("AI instruction:")
        click.echo(plan.ai_instruction)
    if not plan.rules_active:
        click.echo("No active rules (all 0 or unknown).")
        return
    click.echo("Plan:")
    for stage in plan.stages:
        order = stage.get("order")
        rule_ids = stage.get("ruleIds") or []
        click.echo(f"- Stage {order}: " + ", ".join(rule_ids))


@click.command(name="sbom")
@click.option(
    "--format",
    "format_",
    type=click.Choice(["spdx", "cyclonedx"]),
    default="spdx",
    help="SBOM format",
)
@click.option("--output", type=click.Path(), default="sbom.json", help="Output file")
def sbom(format_: str, output: str) -> None:
    """Generate Software Bill of Materials (SBOM)."""
    from manifestguard.cli import _has_license_feature, _license_tier_label

    if not _has_license_feature("sbom_export"):
        click.echo("🔒 SBOM export requires a Pro (or higher) license.")
        click.echo(f"   Current: {_license_tier_label()}.")
        raise SystemExit(3)

    click.echo(f"📦 {t('cli.sbom.generating', module='cli')} ({format_})...")
    click.echo(t("cli.sbom.not_implemented", module="cli"))
    click.echo(f"💾 Output: {output}")
